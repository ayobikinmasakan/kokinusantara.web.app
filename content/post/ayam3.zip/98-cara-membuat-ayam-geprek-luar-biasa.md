---
description: "Cara membuat Ayam geprek Luar biasa"
title: "Cara membuat Ayam geprek Luar biasa"
slug: 98-cara-membuat-ayam-geprek-luar-biasa
date: 2020-11-10T05:17:43.621Z
image: https://img-global.cpcdn.com/recipes/5388263c3823c738/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5388263c3823c738/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5388263c3823c738/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: William Ball
ratingvalue: 4.9
reviewcount: 24109
recipeingredient:
- "1 kilo ayam"
- " Tepung Terigu"
- " Bahan  bahan untuk membuat sambal "
- " Bawang putih"
- " Bawang merah"
- " Cabai rawit merah"
- " Garam"
- " Lemon"
- " Bahan2 untuk merebus ayam"
- " Bawang putih"
- " Kunyit"
- " Ketumbar"
- " Cuka"
- " Garam"
recipeinstructions:
- "Cara pertama bersihkan ayam lalu potong2"
- "Siapkan air matang untuk merebus ayam"
- "Lalu biarkan air mendidih lalu masukkan ayam dan buang busa yg ada di dalam rebusan ayam sampai bersih"
- "Jika sudah bersih lalu beri bumbu ketumbar powder, bawang putih, garam, kunyit dan sedikit cuka lalu biarkan sampai ayam matang lalu angkat,,"
- "Siapkan tepung terigu yg sudah di campur oleh ketumbar bubuk, lada bubuk, garam lalu jadikan 2 tempat,, yg adonan 1 di beri air jngn terlalu encer"
- "Lalu gulingkan ayam di atas tepung terigu biasa lalu gulingkan lagi di tepung yg sudah di campur air lakukan berulang sampai selesai,,"
- "Lalu panaskan minyak sayur dan ayam siap di goreng dengan api yg sedang biarkan ayam sampai garing lalu angkat dan tiriskan,,"
- "Haluskan cabai, bawang merah, bawang putih dan garam lalu beri sedikit minyak sayur sisah menggoreng ayam kedalam sambal lalu aduk2 rata dan beri lemon"
- "Ambil ayam lalu geprek bersama sambal yg sudah di haluskan tadi,,"
- "So,, ayam geprek siap di sajikan bersama nasi khas mesir,, mudah bukan? 🙂"
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 201 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT30M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam geprek](https://img-global.cpcdn.com/recipes/5388263c3823c738/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang harus kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam geprek yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Nusantara

Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam geprek untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang bisa anda buat salah satunya ayam geprek yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam geprek tanpa harus bersusah payah.
Berikut ini resep Ayam geprek yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam geprek:

1. Diperlukan 1 kilo ayam
1. Harap siapkan  Tepung Terigu
1. Dibutuhkan  Bahan - bahan untuk membuat sambal :
1. Siapkan  Bawang putih
1. Siapkan  Bawang merah
1. Tambah  Cabai rawit merah
1. Tambah  Garam
1. Tambah  Lemon
1. Dibutuhkan  Bahan2 untuk merebus ayam:
1. Jangan lupa  Bawang putih
1. Tambah  Kunyit
1. Siapkan  Ketumbar
1. Harap siapkan  Cuka
1. Dibutuhkan  Garam




<!--inarticleads2-->

##### Bagaimana membuat  Ayam geprek:

1. Cara pertama bersihkan ayam lalu potong2
1. Siapkan air matang untuk merebus ayam
1. Lalu biarkan air mendidih lalu masukkan ayam dan buang busa yg ada di dalam rebusan ayam sampai bersih
1. Jika sudah bersih lalu beri bumbu ketumbar powder, bawang putih, garam, kunyit dan sedikit cuka lalu biarkan sampai ayam matang lalu angkat,,
1. Siapkan tepung terigu yg sudah di campur oleh ketumbar bubuk, lada bubuk, garam lalu jadikan 2 tempat,, yg adonan 1 di beri air jngn terlalu encer
1. Lalu gulingkan ayam di atas tepung terigu biasa lalu gulingkan lagi di tepung yg sudah di campur air lakukan berulang sampai selesai,,
1. Lalu panaskan minyak sayur dan ayam siap di goreng dengan api yg sedang biarkan ayam sampai garing lalu angkat dan tiriskan,,
1. Haluskan cabai, bawang merah, bawang putih dan garam lalu beri sedikit minyak sayur sisah menggoreng ayam kedalam sambal lalu aduk2 rata dan beri lemon
1. Ambil ayam lalu geprek bersama sambal yg sudah di haluskan tadi,,
1. So,, ayam geprek siap di sajikan bersama nasi khas mesir,, mudah bukan? 🙂




Demikianlah cara membuat ayam geprek yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
