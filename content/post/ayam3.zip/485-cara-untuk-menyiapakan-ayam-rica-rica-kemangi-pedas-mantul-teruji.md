---
description: "Cara untuk menyiapakan Ayam Rica - Rica Kemangi Pedas Mantul Teruji"
title: "Cara untuk menyiapakan Ayam Rica - Rica Kemangi Pedas Mantul Teruji"
slug: 485-cara-untuk-menyiapakan-ayam-rica-rica-kemangi-pedas-mantul-teruji
date: 2020-10-11T22:42:25.429Z
image: https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg
author: Lucille French
ratingvalue: 4.1
reviewcount: 32832
recipeingredient:
- "1/2 kg Ayam potong dada dan sayap sesuai selera"
- "1/2 potong jeruk limau"
- " Bumbu Halus"
- "3 buah bawang putih"
- "4 buah bawang merah"
- "5 buah cabe merah besar"
- "10 cabe rawit sesuai selera"
- "1/2 cm Jahe"
- "Sedikit kunyit"
- "3 buah kemiri"
- " Bahan cemplung"
- "secukupnya Garam"
- "secukupnya Gula"
- " Merica secukupny"
- " penyedap rasa"
- "4 lembar daun jeruk"
- "2 daun sereh geprek"
- "1/2 ruas lengkuas"
- "2 lembar daun salam"
- "4 buah cabe hijau boleh skip"
- "1 ikat daun kemangi"
- "1 buah daun bawang"
- " Air matang"
recipeinstructions:
- "Cuci bersih ayam, kemudian lumuri ayam dgn jeruk limau, beri penyedap rasa, garam, ketumbar (bubuk) dan merica (bubuk) untuk marinasi yang simpel. Diamkan dikulkas 5-10 menit. Kemudian goreng setengah matang."
- "Potong- potong bumbu halus untuk di blender/diulek sesuai selera. Kemudian tambahkan minyak, tumis bumbu hingga wangi, masukkan bumbu cemplung tadi aduk rata."
- "Kemudian masukkan ayam potong, aduk sebentar, tambahkan air secukupnya. Setelah itu tambahkan garam, gula, penyedap rasa, dan merica."
- "Tutup sebentar biarkan meresap. Masukkan daun bawang, cabe hijau, cabe rawit utuh dan kemangi aduk rata, kemudian biarkan hingga meresap dan matang."
- "Koreksi rasa, siapkan mangkok ukuran sedang kemudian sajikan 😍. siap untuk dinikmati"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 227 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica - Rica Kemangi Pedas Mantul](https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica - rica kemangi pedas mantul yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara



Kehangatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Rica - Rica Kemangi Pedas Mantul untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang bisa anda praktekkan salah satunya ayam rica - rica kemangi pedas mantul yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep ayam rica - rica kemangi pedas mantul tanpa harus bersusah payah.
Seperti resep Ayam Rica - Rica Kemangi Pedas Mantul yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 23 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica - Rica Kemangi Pedas Mantul:

1. Harap siapkan 1/2 kg Ayam potong (dada dan sayap) sesuai selera
1. Harus ada 1/2 potong jeruk limau
1. Tambah  Bumbu Halus
1. Siapkan 3 buah bawang putih
1. Siapkan 4 buah bawang merah
1. Jangan lupa 5 buah cabe merah besar
1. Dibutuhkan 10 cabe rawit (sesuai selera)
1. Diperlukan 1/2 cm Jahe
1. Jangan lupa Sedikit kunyit
1. Harus ada 3 buah kemiri
1. Tambah  Bahan cemplung
1. Diperlukan secukupnya Garam
1. Jangan lupa secukupnya Gula
1. Tambah  Merica secukupny
1. Siapkan  penyedap rasa
1. Diperlukan 4 lembar daun jeruk
1. Siapkan 2 daun sereh geprek
1. Harap siapkan 1/2 ruas lengkuas
1. Diperlukan 2 lembar daun salam
1. Jangan lupa 4 buah cabe hijau (boleh skip)
1. Jangan lupa 1 ikat daun kemangi
1. Dibutuhkan 1 buah daun bawang
1. Jangan lupa  Air matang




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica - Rica Kemangi Pedas Mantul:

1. Cuci bersih ayam, kemudian lumuri ayam dgn jeruk limau, beri penyedap rasa, garam, ketumbar (bubuk) dan merica (bubuk) untuk marinasi yang simpel. Diamkan dikulkas 5-10 menit. Kemudian goreng setengah matang.
1. Potong- potong bumbu halus untuk di blender/diulek sesuai selera. Kemudian tambahkan minyak, tumis bumbu hingga wangi, masukkan bumbu cemplung tadi aduk rata.
1. Kemudian masukkan ayam potong, aduk sebentar, tambahkan air secukupnya. Setelah itu tambahkan garam, gula, penyedap rasa, dan merica.
1. Tutup sebentar biarkan meresap. Masukkan daun bawang, cabe hijau, cabe rawit utuh dan kemangi aduk rata, kemudian biarkan hingga meresap dan matang.
1. Koreksi rasa, siapkan mangkok ukuran sedang kemudian sajikan 😍. siap untuk dinikmati




Demikianlah cara membuat ayam rica - rica kemangi pedas mantul yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
