---
description: "Cara singkat untuk membuat Ayam geprek ala ei minggu ini"
title: "Cara singkat untuk membuat Ayam geprek ala ei minggu ini"
slug: 125-cara-singkat-untuk-membuat-ayam-geprek-ala-ei-minggu-ini
date: 2020-09-28T12:13:54.532Z
image: https://img-global.cpcdn.com/recipes/1a6a646a7454f38e/751x532cq70/ayam-geprek-ala-ei-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1a6a646a7454f38e/751x532cq70/ayam-geprek-ala-ei-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1a6a646a7454f38e/751x532cq70/ayam-geprek-ala-ei-foto-resep-utama.jpg
author: Jay Gross
ratingvalue: 4.6
reviewcount: 46024
recipeingredient:
- "1 ekor ayam agak kecil saya potong 6"
- "1 bks bumbu la rasa ayam special"
- "500 gr terigu"
- "3 sdm tepung beras"
- "1 sdt baking soda"
- "1/2 sdt Lada halus"
- "1 sdt Garam dan bubuk kaldu"
- " Minyak utk menggoreng"
- " Sambal"
- "sesuai selera Cabe"
- " Bawang putih"
- " Garam"
- " Penyedap rasabubuk kaldu"
recipeinstructions:
- "Ayam dicuci bersih dan dilumuri bumbu larasa ayam special. Min 30 menit. Lebih lama lebih baik. Simpan di kulkas dulu smp siap mau digoreng."
- "Terigu,tepung beras,garam,lada dan bubuk kaldu juga baking soda di campur dan aduk2 sampai rata. Sengaja memang terigu agak banyak disiapkan supaya lebih gampang membaluri ayam. Terigu sisa bisa dipakai lagi dan ditambah klo mau bikin lagi."
- "Ayam yg sudah direndam bumbu satu persatu di masukkan ke campuran tepung di aduk jungkir balik (jangan di remas). Biarkan tepung menempel tanpa dipaksa. Lalu sediakan air di baskom terpisah. Kalo ada air es lebih baik. Ambil ayam tadi langsung celupkan ke air..bbrp detik saja. Langsung di ceburkan lagi le dalam campuran tepung..tebas2 ayam lalu goreng dalam minyak banyak dan panas. Setelah ayam masuk api bisa dikecilkan supaya ayam matang sempurna."
- "Untuk sambal. Cabe dan bawang putih di ulek bersama garam dan bubuk kaldu/penyedap. Setelah cukup halusnya siram dengan minyak panas ambil saja dr penggorengan ayam yg lagi di goreng."
categories:
- Recipe
tags:
- ayam
- geprek
- ala

katakunci: ayam geprek ala 
nutrition: 258 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT41M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam geprek ala ei](https://img-global.cpcdn.com/recipes/1a6a646a7454f38e/751x532cq70/ayam-geprek-ala-ei-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau renyah. Ciri khas kuliner Indonesia ayam geprek ala ei yang penuh dengan rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kedekatan keluarga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam geprek ala ei untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang bisa anda coba salah satunya ayam geprek ala ei yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam geprek ala ei tanpa harus bersusah payah.
Seperti resep Ayam geprek ala ei yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 13 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek ala ei:

1. Dibutuhkan 1 ekor ayam agak kecil saya potong 6
1. Jangan lupa 1 bks bumbu la rasa ayam special
1. Jangan lupa 500 gr terigu
1. Siapkan 3 sdm tepung beras
1. Jangan lupa 1 sdt baking soda
1. Siapkan 1/2 sdt Lada halus
1. Siapkan 1 sdt Garam dan bubuk kaldu
1. Jangan lupa  Minyak utk menggoreng
1. Dibutuhkan  Sambal
1. Tambah sesuai selera Cabe
1. Tambah  Bawang putih
1. Tambah  Garam
1. Diperlukan  Penyedap rasa/bubuk kaldu




<!--inarticleads2-->

##### Instruksi membuat  Ayam geprek ala ei:

1. Ayam dicuci bersih dan dilumuri bumbu larasa ayam special. Min 30 menit. Lebih lama lebih baik. Simpan di kulkas dulu smp siap mau digoreng.
1. Terigu,tepung beras,garam,lada dan bubuk kaldu juga baking soda di campur dan aduk2 sampai rata. Sengaja memang terigu agak banyak disiapkan supaya lebih gampang membaluri ayam. Terigu sisa bisa dipakai lagi dan ditambah klo mau bikin lagi.
1. Ayam yg sudah direndam bumbu satu persatu di masukkan ke campuran tepung di aduk jungkir balik (jangan di remas). Biarkan tepung menempel tanpa dipaksa. Lalu sediakan air di baskom terpisah. Kalo ada air es lebih baik. Ambil ayam tadi langsung celupkan ke air..bbrp detik saja. Langsung di ceburkan lagi le dalam campuran tepung..tebas2 ayam lalu goreng dalam minyak banyak dan panas. Setelah ayam masuk api bisa dikecilkan supaya ayam matang sempurna.
1. Untuk sambal. Cabe dan bawang putih di ulek bersama garam dan bubuk kaldu/penyedap. Setelah cukup halusnya siram dengan minyak panas ambil saja dr penggorengan ayam yg lagi di goreng.




Demikianlah cara membuat ayam geprek ala ei yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
