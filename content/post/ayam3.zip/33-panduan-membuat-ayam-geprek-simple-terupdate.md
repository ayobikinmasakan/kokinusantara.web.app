---
description: "Panduan membuat Ayam geprek simple terupdate"
title: "Panduan membuat Ayam geprek simple terupdate"
slug: 33-panduan-membuat-ayam-geprek-simple-terupdate
date: 2020-08-08T11:19:34.269Z
image: https://img-global.cpcdn.com/recipes/ecbd729a66b6e337/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ecbd729a66b6e337/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ecbd729a66b6e337/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
author: Landon Cook
ratingvalue: 4
reviewcount: 43623
recipeingredient:
- "5 potong ayam sesuaikan"
- " Bumbu marinasi "
- "2 sdm Kecap manis"
- "2 sdm saus tiram"
- "1 sdt ketumbar bubuk"
- "secukupnya Garam"
- "secukupnya Lada"
- " Bahan tepung crispy "
- " Terigu apa saja disesuaikan ya bnyknya"
- " Garam"
- " Lada"
- " Kaldu bubuk"
- " Ketumbar boleh skip"
- "secukupnya Siapkan air dingin kulkas diwadah"
- " Bumbu sambal geprek"
- "disesuaikan Cabe rawit"
- "3 Bawang putih"
- "1 Bawang merah"
- "secukupnya Air"
recipeinstructions:
- "Cuci bersih ayam, kemudian lumuri dengan bumbu marinasi ya diamkan di kulkas selama kurleb 15mnt saja, agar bmbunya meresap."
- "Siapkan terigu, dan bahannya campurkan dan aduk2 rata. Cukup pake terigu kering ya tidak pake adonan basah."
- "Ayam yg sudah dimarinasi masukan keterigu yang kering dan di aduk2 keatas diangkat dilumuri dengan terigu smpe keriting. Lalu dimasukan ke dalam air dingin, kemudian masukan lagi ke adonan kering sampai benar2 keriting ya. Kemudian goreng keminyak yg sudah dipanaskan, dan masak dengan api kecil, agar ayamnya matang, dan luarnya crispi. Ulangi sampai ayam nya habis."
- "Menggoreng ayamnya harus minyak yg banyak ya smpi ayamnya tenggelam."
- "Sambil menunggu ayam matang, buat sambel gepreknya..bahan boleh di blender kasar atau ulek ya. Kemudian di tumis atau dimasak beri air sedikit, garam dan kaldu bubuk, masak sampai mengeluarkan minyak ya."
- "Jadi deh siap disajikan♥️ selamat mencoba"
categories:
- Recipe
tags:
- ayam
- geprek
- simple

katakunci: ayam geprek simple 
nutrition: 149 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam geprek simple](https://img-global.cpcdn.com/recipes/ecbd729a66b6e337/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam geprek simple yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Indonesia



Kedekatan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam geprek simple untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang bisa anda buat salah satunya ayam geprek simple yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep ayam geprek simple tanpa harus bersusah payah.
Berikut ini resep Ayam geprek simple yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek simple:

1. Diperlukan 5 potong ayam (sesuaikan)
1. Siapkan  Bumbu marinasi :
1. Tambah 2 sdm Kecap manis
1. Harus ada 2 sdm saus tiram
1. Tambah 1 sdt ketumbar bubuk
1. Harus ada secukupnya Garam
1. Diperlukan secukupnya Lada
1. Tambah  Bahan tepung crispy :
1. Jangan lupa  Terigu apa saja disesuaikan ya bnyknya
1. Dibutuhkan  Garam
1. Dibutuhkan  Lada
1. Harus ada  Kaldu bubuk
1. Harus ada  Ketumbar (boleh skip)
1. Tambah secukupnya Siapkan air dingin kulkas diwadah
1. Diperlukan  Bumbu sambal geprek:
1. Harus ada disesuaikan Cabe rawit
1. Jangan lupa 3 Bawang putih
1. Tambah 1 Bawang merah
1. Siapkan secukupnya Air




<!--inarticleads2-->

##### Instruksi membuat  Ayam geprek simple:

1. Cuci bersih ayam, kemudian lumuri dengan bumbu marinasi ya diamkan di kulkas selama kurleb 15mnt saja, agar bmbunya meresap.
1. Siapkan terigu, dan bahannya campurkan dan aduk2 rata. Cukup pake terigu kering ya tidak pake adonan basah.
1. Ayam yg sudah dimarinasi masukan keterigu yang kering dan di aduk2 keatas diangkat dilumuri dengan terigu smpe keriting. Lalu dimasukan ke dalam air dingin, kemudian masukan lagi ke adonan kering sampai benar2 keriting ya. Kemudian goreng keminyak yg sudah dipanaskan, dan masak dengan api kecil, agar ayamnya matang, dan luarnya crispi. Ulangi sampai ayam nya habis.
1. Menggoreng ayamnya harus minyak yg banyak ya smpi ayamnya tenggelam.
1. Sambil menunggu ayam matang, buat sambel gepreknya..bahan boleh di blender kasar atau ulek ya. Kemudian di tumis atau dimasak beri air sedikit, garam dan kaldu bubuk, masak sampai mengeluarkan minyak ya.
1. Jadi deh siap disajikan♥️ selamat mencoba




Demikianlah cara membuat ayam geprek simple yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan teruji, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
