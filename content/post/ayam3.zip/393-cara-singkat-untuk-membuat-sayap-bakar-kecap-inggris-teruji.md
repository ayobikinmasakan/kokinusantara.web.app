---
description: "Cara singkat untuk membuat Sayap bakar kecap Inggris Teruji"
title: "Cara singkat untuk membuat Sayap bakar kecap Inggris Teruji"
slug: 393-cara-singkat-untuk-membuat-sayap-bakar-kecap-inggris-teruji
date: 2020-10-04T20:00:57.396Z
image: https://img-global.cpcdn.com/recipes/b2dd210f66f32ad8/751x532cq70/sayap-bakar-kecap-inggris-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b2dd210f66f32ad8/751x532cq70/sayap-bakar-kecap-inggris-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b2dd210f66f32ad8/751x532cq70/sayap-bakar-kecap-inggris-foto-resep-utama.jpg
author: Virgie Tran
ratingvalue: 4.9
reviewcount: 42101
recipeingredient:
- "6 potong ayam12 kg"
- "400 ml air"
- "1/2 sdm Margarin utk olesan"
- "1/2 jeruk nipisperas airnya"
- " Bumbu halus"
- "3 siung bawang putih"
- "1 ruas jari jahe"
- "1 sdt ketumbar sangrai"
- " Bumbu lainnya"
- "3 sdm kecap manis"
- "2 sdm saus tomat"
- "1 sdm kecap Inggris"
- "1 sdm kecap asin"
- "1/2 sdt lada bubuk"
- "1 sdm Gula merah"
- "Secukupnya Garamkaldu bubuk"
- " Bahan pelengkap"
- "1 iris Lengkuas tebal 12 cm geprek"
- "2 lembar Daun jeruk dirobek"
- "3 lembar Daun salam"
recipeinstructions:
- "Cuci sayap ayam, kucuri dg air jeruk lemon, supaya aroma amisnya berkurang. Biarkan bbrp saat. Cuci kembali hingga bersih.Haluskan bumbu."
- "Siapkan bumbu lainnya.Masukan sayap ayam kedalam wajan, tambahkan bumbu halus dan bumbu lainnya."
- "Tuangi air,aduk rata dan tutup wajan.Ungkep ayam dan biarkan sampe airnya menyusut, setelah menyusut matikan kompor dan sisihkan."
- "Panaskan teflon olesi sedikit margarin, lalu letakkan ayam yang sudah diungkep didalam teflon.Olesi ayam dengan bumbu sisa ungkepan yang di tambah margarin, dan oles bolak balik secara merata. Bakar sampai matang."
- "Sajikan.Plating yang seadanya trus gak punya lalapan dan sudah ditungguin ama anak2🤭🙏"
categories:
- Recipe
tags:
- sayap
- bakar
- kecap

katakunci: sayap bakar kecap 
nutrition: 180 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Dinner

---


![Sayap bakar kecap Inggris](https://img-global.cpcdn.com/recipes/b2dd210f66f32ad8/751x532cq70/sayap-bakar-kecap-inggris-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau empuk. Karasteristik kuliner Nusantara sayap bakar kecap inggris yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa didapat dengan cara mudah. Diantaranya adalah memasak Sayap bakar kecap Inggris untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang bisa anda coba salah satunya sayap bakar kecap inggris yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep sayap bakar kecap inggris tanpa harus bersusah payah.
Berikut ini resep Sayap bakar kecap Inggris yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sayap bakar kecap Inggris:

1. Harus ada 6 potong ayam(1/2 kg)
1. Tambah 400 ml air
1. Tambah 1/2 sdm Margarin utk olesan
1. Jangan lupa 1/2 jeruk nipis(peras airnya)
1. Jangan lupa  Bumbu halus:
1. Siapkan 3 siung bawang putih
1. Dibutuhkan 1 ruas jari jahe
1. Harap siapkan 1 sdt ketumbar sangrai
1. Diperlukan  Bumbu lainnya:
1. Jangan lupa 3 sdm kecap manis
1. Harap siapkan 2 sdm saus tomat
1. Siapkan 1 sdm kecap Inggris
1. Harus ada 1 sdm kecap asin
1. Jangan lupa 1/2 sdt lada bubuk
1. Harus ada 1 sdm Gula merah
1. Jangan lupa Secukupnya Garam/kaldu bubuk
1. Diperlukan  Bahan pelengkap:
1. Siapkan 1 iris Lengkuas tebal 1/2 cm (geprek)
1. Tambah 2 lembar Daun jeruk (dirobek)
1. Harus ada 3 lembar Daun salam




<!--inarticleads2-->

##### Bagaimana membuat  Sayap bakar kecap Inggris:

1. Cuci sayap ayam, kucuri dg air jeruk lemon, supaya aroma amisnya berkurang. Biarkan bbrp saat. Cuci kembali hingga bersih.Haluskan bumbu.
1. Siapkan bumbu lainnya.Masukan sayap ayam kedalam wajan, tambahkan bumbu halus dan bumbu lainnya.
1. Tuangi air,aduk rata dan tutup wajan.Ungkep ayam dan biarkan sampe airnya menyusut, setelah menyusut matikan kompor dan sisihkan.
1. Panaskan teflon olesi sedikit margarin, lalu letakkan ayam yang sudah diungkep didalam teflon.Olesi ayam dengan bumbu sisa ungkepan yang di tambah margarin, dan oles bolak balik secara merata. Bakar sampai matang.
1. Sajikan.Plating yang seadanya trus gak punya lalapan dan sudah ditungguin ama anak2🤭🙏




Demikianlah cara membuat sayap bakar kecap inggris yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
