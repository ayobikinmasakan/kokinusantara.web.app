---
description: "Resep : Ayam rica rica simple teraktual"
title: "Resep : Ayam rica rica simple teraktual"
slug: 498-resep-ayam-rica-rica-simple-teraktual
date: 2020-08-28T14:33:03.851Z
image: https://img-global.cpcdn.com/recipes/47b0ddd640ba39de/751x532cq70/ayam-rica-rica-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/47b0ddd640ba39de/751x532cq70/ayam-rica-rica-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/47b0ddd640ba39de/751x532cq70/ayam-rica-rica-simple-foto-resep-utama.jpg
author: Marc Barnes
ratingvalue: 5
reviewcount: 36073
recipeingredient:
- "1/2 kg ayam"
- " Bumbu halus "
- "3 siung bawang putih"
- "5 siung bawang merah"
- "11 buah cabe merah keriting"
- "1 ruas langkuas"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdt kerumbar"
- "1 sdt lada"
- " Bumbu iris "
- "2 btg serai"
- "5 lbr daun jeruk"
- "1 lbr daun salam"
- "1/2 jeruk lemon"
- "Secukupnya garam dan kaldu jamur"
- "1 ikat kemangi petik daunnya"
- "50 ml air"
recipeinstructions:
- "Cuci bersih ayam, baluri dengan air jeruk lemon. Diamkan sebentar lalu cuci kembali"
- "Tumis bumbu halus hingga harum, tambahkan bumbu iris aduk2 kembali masukan ayam aduk2 hingga rata beri air."
- "Tunggu ayam hingga airnya asat, beri garam dan kaldu jamur aduk2, lalu masukan daun kemangi masak hingga layu. Test rasa dan sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 299 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica rica simple](https://img-global.cpcdn.com/recipes/47b0ddd640ba39de/751x532cq70/ayam-rica-rica-simple-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica rica simple yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Indonesia

Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica. Rasa pedas, gurih dan empuk daging ayamnya terbukti sangat cocok disajikan bersama nasi dalam. Bahan bumbu ayam rica rica yang digunakan sebenarnya cukup simple dan sederhana, seperti : kunyit, jahe, serai, cabai merah, bawang putih, dan Resep rica rica sendiri sebenarnya tidak harus menggunakan bahan daging ayam saja.

Kedekatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica rica simple untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang bisa anda praktekkan salah satunya ayam rica rica simple yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep ayam rica rica simple tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica simple yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica simple:

1. Jangan lupa 1/2 kg ayam
1. Siapkan  Bumbu halus :
1. Diperlukan 3 siung bawang putih
1. Dibutuhkan 5 siung bawang merah
1. Jangan lupa 11 buah cabe merah keriting
1. Diperlukan 1 ruas langkuas
1. Harus ada 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Siapkan 1 sdt kerumbar
1. Tambah 1 sdt lada
1. Harus ada  Bumbu iris :
1. Tambah 2 btg serai
1. Tambah 5 lbr daun jeruk
1. Jangan lupa 1 lbr daun salam
1. Jangan lupa 1/2 jeruk lemon
1. Jangan lupa Secukupnya garam dan kaldu jamur
1. Dibutuhkan 1 ikat kemangi (petik daunnya)
1. Harap siapkan 50 ml air


Ayam rica-rica (Indonesian for chicken rica-rica) is an Indonesian hot and spicy chicken dish. It is made up of chicken that cooked in spicy red and green chili pepper. The origin of this dish is from Minahasan cuisine of North Sulawesi. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica simple:

1. Cuci bersih ayam, baluri dengan air jeruk lemon. Diamkan sebentar lalu cuci kembali
1. Tumis bumbu halus hingga harum, tambahkan bumbu iris aduk2 kembali masukan ayam aduk2 hingga rata beri air.
1. Tunggu ayam hingga airnya asat, beri garam dan kaldu jamur aduk2, lalu masukan daun kemangi masak hingga layu. Test rasa dan sajikan


The origin of this dish is from Minahasan cuisine of North Sulawesi. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. I love it when you guys snap a photo and tag to show me what you&#39;ve made 🙂 Simply tag me @WhatToCookToday #WhatToCookToday on Instagram and I&#39;ll be sure to stop by and take a peek for real! Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. 

Demikianlah cara membuat ayam rica rica simple yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
