---
description: "Resep : Ayam Geprek Simple Banget Teruji"
title: "Resep : Ayam Geprek Simple Banget Teruji"
slug: 165-resep-ayam-geprek-simple-banget-teruji
date: 2021-01-31T05:13:52.672Z
image: https://img-global.cpcdn.com/recipes/0b4be2c2e2c2c712/751x532cq70/ayam-geprek-simple-banget-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0b4be2c2e2c2c712/751x532cq70/ayam-geprek-simple-banget-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0b4be2c2e2c2c712/751x532cq70/ayam-geprek-simple-banget-foto-resep-utama.jpg
author: Billy Estrada
ratingvalue: 4.9
reviewcount: 26575
recipeingredient:
- "1 potong ayam bagian paha ukuran 14 kg mungkin saya pakai yg agak besar"
- "1 butir telur ayam"
- "secukupnya Tepung Kobe"
- " Bahan Sambel"
- "4 buah cabe rawit kalo suka pedes boleh ditambahkan sesuai selera"
- "3 siung bawang putih"
- "3 buah bawang merah"
- "secukupnya Garam"
- "Secukupnya Gula Pasir"
recipeinstructions:
- "Potong ayam bagian paha jadi 2 bagian"
- "Untuk bahan tepung basah, campurkan 1 butir telur ayam dan 4 sendok makan tepung kobe. Aduk rata"
- "Masukkan potongan ayam pada bahan tepung, diamkan sebentar."
- "Setelah didiamkan, celupkan ayam pada tepung kering. Kemudian, celupkan kembali ke tepung basah dan tepung kering, lalu goreng dengan minyak panas dan api sedang."
- "Untuk bahan sambel, uleg cabe rawit, bawang merah, dan bawang putih, serta garam gula pasir."
- "Panaskan sedikit minyak goreng, saya pakai minyak kelapa asli. Kemudian tuangkan pada ulekan sambel di atas."
- "Sisihkan sambel. Lalu geprek ayam yg telah matang di cobek bekas ulekan sambel."
- "Tambahkan sambel tadi di atas ayam geprek. Jangan lupa koreksi rasa."
categories:
- Recipe
tags:
- ayam
- geprek
- simple

katakunci: ayam geprek simple 
nutrition: 231 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Geprek Simple Banget](https://img-global.cpcdn.com/recipes/0b4be2c2e2c2c712/751x532cq70/ayam-geprek-simple-banget-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam geprek simple banget yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan keistimewahan yang merupakan keragaman Kita



Keharmonisan keluarga dapat didapat dengan cara simple. Diantaranya adalah memasak Ayam Geprek Simple Banget untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda contoh salah satunya ayam geprek simple banget yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep ayam geprek simple banget tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Simple Banget yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Simple Banget:

1. Diperlukan 1 potong ayam bagian paha (ukuran 1/4 kg mungkin, saya pakai yg agak besar)
1. Tambah 1 butir telur ayam
1. Dibutuhkan secukupnya Tepung Kobe
1. Harus ada  Bahan Sambel
1. Jangan lupa 4 buah cabe rawit (kalo suka pedes, boleh ditambahkan sesuai selera)
1. Tambah 3 siung bawang putih
1. Harap siapkan 3 buah bawang merah
1. Harap siapkan secukupnya Garam
1. Dibutuhkan Secukupnya Gula Pasir




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek Simple Banget:

1. Potong ayam bagian paha jadi 2 bagian
1. Untuk bahan tepung basah, campurkan 1 butir telur ayam dan 4 sendok makan tepung kobe. Aduk rata
1. Masukkan potongan ayam pada bahan tepung, diamkan sebentar.
1. Setelah didiamkan, celupkan ayam pada tepung kering. Kemudian, celupkan kembali ke tepung basah dan tepung kering, lalu goreng dengan minyak panas dan api sedang.
1. Untuk bahan sambel, uleg cabe rawit, bawang merah, dan bawang putih, serta garam gula pasir.
1. Panaskan sedikit minyak goreng, saya pakai minyak kelapa asli. Kemudian tuangkan pada ulekan sambel di atas.
1. Sisihkan sambel. Lalu geprek ayam yg telah matang di cobek bekas ulekan sambel.
1. Tambahkan sambel tadi di atas ayam geprek. Jangan lupa koreksi rasa.




Demikianlah cara membuat ayam geprek simple banget yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan cepat, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
