---
description: "Langkah menyiapakan Sayap Ayam Crispy Asam Manis minggu ini"
title: "Langkah menyiapakan Sayap Ayam Crispy Asam Manis minggu ini"
slug: 250-langkah-menyiapakan-sayap-ayam-crispy-asam-manis-minggu-ini
date: 2020-12-11T16:51:00.613Z
image: https://img-global.cpcdn.com/recipes/2658b566e90e61bf/751x532cq70/sayap-ayam-crispy-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2658b566e90e61bf/751x532cq70/sayap-ayam-crispy-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2658b566e90e61bf/751x532cq70/sayap-ayam-crispy-asam-manis-foto-resep-utama.jpg
author: Janie Soto
ratingvalue: 4
reviewcount: 31233
recipeingredient:
- "8 buah sayap ayam potong dibagi dua"
- "100 gram tepung terigu"
- " Bahan marinasi "
- "1/2 sdt air jeruk nipis"
- "1/2 sdt garam"
- "1/2 sdt merica bubuk"
- "2 siung bawang putih parut"
- "500 gram minyak untuk menggoreng"
- " Bahan saus "
- "2 siung bawang putih dicincang kasar"
- "1/2 buah bawang bombay cincang halus"
- "1 cm jahe parut"
- "1 sdm kecap manis"
- "1 sdm saus tiram"
- "50 gram saus tomat"
- "1/4 sdt garam"
- "1/4 sdt merica bubuk"
- "1 sdt gula pasir"
- "2 sdm minyak untuk menumis"
recipeinstructions:
- "Potong ayam menjadi 2 bagian, tujuannya supaya ayam lebih crispy dan proses marinasi cepat meresap. Marinasi sayap ayam selama 30 menit dengan cara campur air perasan jeruk nipis, garam, merica bubuk, dan bawang putih. Lalu baluri tepung terigu, tepuk tepuk ayam untuk membuang sisa tepung."
- "Goreng ayam dengan api sedang sampai matang, angkat, dan tiriskan."
- "Panaskan minyak, goreng kembali sayap ayam dengan api yg sangat panas goreng sampai kecokelatan dan crispy. Angkat dan tiriskan."
- "Panaskan wajan, masukan minyak untuk menumis. Tumis bawang putih, bawang bombay, dan jahe sampai harum."
- "Tambahkan kecap manis, saus tiram, saus tomat. Aduk rata. Lalu tambahkan rasa dari garam, merica bubuk, dan gula pasir. Tes rasa manis pedas, masak sampai saus mengental."
- "Masukkan sayap ayam yg sudah digoreng, aduk sampai saus menyelimuti sayap."
- "Sayap siap disajikan"
categories:
- Recipe
tags:
- sayap
- ayam
- crispy

katakunci: sayap ayam crispy 
nutrition: 170 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Lunch

---


![Sayap Ayam Crispy Asam Manis](https://img-global.cpcdn.com/recipes/2658b566e90e61bf/751x532cq70/sayap-ayam-crispy-asam-manis-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga gurih. Ciri masakan Nusantara sayap ayam crispy asam manis yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Sayap Ayam Crispy Asam Manis untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang dapat anda coba salah satunya sayap ayam crispy asam manis yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep sayap ayam crispy asam manis tanpa harus bersusah payah.
Seperti resep Sayap Ayam Crispy Asam Manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sayap Ayam Crispy Asam Manis:

1. Harap siapkan 8 buah sayap ayam potong dibagi dua
1. Dibutuhkan 100 gram tepung terigu
1. Harus ada  Bahan marinasi :
1. Jangan lupa 1/2 sdt air jeruk nipis
1. Tambah 1/2 sdt garam
1. Siapkan 1/2 sdt merica bubuk
1. Dibutuhkan 2 siung bawang putih parut
1. Harap siapkan 500 gram minyak untuk menggoreng
1. Tambah  Bahan saus :
1. Tambah 2 siung bawang putih dicincang kasar
1. Tambah 1/2 buah bawang bombay cincang halus
1. Siapkan 1 cm jahe parut
1. Dibutuhkan 1 sdm kecap manis
1. Harap siapkan 1 sdm saus tiram
1. Dibutuhkan 50 gram saus tomat
1. Harus ada 1/4 sdt garam
1. Harap siapkan 1/4 sdt merica bubuk
1. Siapkan 1 sdt gula pasir
1. Diperlukan 2 sdm minyak untuk menumis




<!--inarticleads2-->

##### Bagaimana membuat  Sayap Ayam Crispy Asam Manis:

1. Potong ayam menjadi 2 bagian, tujuannya supaya ayam lebih crispy dan proses marinasi cepat meresap. Marinasi sayap ayam selama 30 menit dengan cara campur air perasan jeruk nipis, garam, merica bubuk, dan bawang putih. Lalu baluri tepung terigu, tepuk tepuk ayam untuk membuang sisa tepung.
1. Goreng ayam dengan api sedang sampai matang, angkat, dan tiriskan.
1. Panaskan minyak, goreng kembali sayap ayam dengan api yg sangat panas goreng sampai kecokelatan dan crispy. Angkat dan tiriskan.
1. Panaskan wajan, masukan minyak untuk menumis. Tumis bawang putih, bawang bombay, dan jahe sampai harum.
1. Tambahkan kecap manis, saus tiram, saus tomat. Aduk rata. Lalu tambahkan rasa dari garam, merica bubuk, dan gula pasir. Tes rasa manis pedas, masak sampai saus mengental.
1. Masukkan sayap ayam yg sudah digoreng, aduk sampai saus menyelimuti sayap.
1. Sayap siap disajikan




Demikianlah cara membuat sayap ayam crispy asam manis yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
