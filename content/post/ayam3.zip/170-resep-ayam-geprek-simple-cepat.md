---
description: "Resep : Ayam Geprek Simple 👌 Cepat"
title: "Resep : Ayam Geprek Simple 👌 Cepat"
slug: 170-resep-ayam-geprek-simple-cepat
date: 2020-12-03T01:25:57.728Z
image: https://img-global.cpcdn.com/recipes/6c17a708044413af/751x532cq70/ayam-geprek-simple-👌-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6c17a708044413af/751x532cq70/ayam-geprek-simple-👌-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6c17a708044413af/751x532cq70/ayam-geprek-simple-👌-foto-resep-utama.jpg
author: Margaret Zimmerman
ratingvalue: 4.1
reviewcount: 48611
recipeingredient:
- "1 potong dada ayam"
- " Bahan Tepung ayam "
- " Tepung sajiku ayam kentucky"
- "5 sendok makan Tepung terigu untuk tambahan"
- " garam"
- " Royco masako"
- " Merica bubuk"
- " Bahan sambal "
- "10 cabai rawit"
- "3 cabai merah besar"
- "3 siung bawang putih"
recipeinstructions:
- "Siapkan adonan basah dan kering. Caranya campur semua tepung tambahkan garam, royco ayam, dan merica bubuk secukupnya (dikira2 saja ya garam nya) setelah tercampur, sisihkan 3 sendok makan adonan tadi dan beri air secukupnya nya jangan terlalu encer."
- "Potong2 dada ayam jadi 5 (sesuai selera) jngan terlalu besar karena setelah ditepungi ayam jadi tebal..cuci bersih ayam"
- "Panaskan minyak dalam wajan. Beri minyak banyak agar ayam terendam saat digoreng. Masukkan ayam dalam adonan basah aduk2 sampai terlumuri tepung. Lalu masukkan ke adonan kering putar2 ayam sambil dicubit2 agar tepung kriting. Pastikan ayam tertutup tepung."
- "Goreng ayam dalam minyam panas.. Setelah ayam masuk kecilkan api agar matang sempurna kurang lebih 10 menit goreng."
- "Uleg cabai, bawang tambahkan garam dan royco secukupnya... Uleg lalu siram dengan minyak panas sisa buat goreng ayam tadi.. Taruh sambal diatas ayam lalu geprek.."
- "Sajikan dengan nasi hangat dan lalapan.. 👍👌😊"
categories:
- Recipe
tags:
- ayam
- geprek
- simple

katakunci: ayam geprek simple 
nutrition: 206 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Geprek Simple 👌](https://img-global.cpcdn.com/recipes/6c17a708044413af/751x532cq70/ayam-geprek-simple-👌-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga enak. Ciri khas makanan Indonesia ayam geprek simple 👌 yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam Geprek Simple 👌 untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang bisa anda buat salah satunya ayam geprek simple 👌 yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam geprek simple 👌 tanpa harus bersusah payah.
Seperti resep Ayam Geprek Simple 👌 yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Simple 👌:

1. Diperlukan 1 potong dada ayam
1. Harap siapkan  Bahan Tepung ayam :
1. Diperlukan  Tepung sajiku ayam kentucky
1. Siapkan 5 sendok makan Tepung terigu (untuk tambahan)
1. Dibutuhkan  garam
1. Dibutuhkan  Royco /masako
1. Jangan lupa  Merica bubuk
1. Jangan lupa  Bahan sambal :
1. Harus ada 10 cabai rawit
1. Dibutuhkan 3 cabai merah besar
1. Harus ada 3 siung bawang putih




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek Simple 👌:

1. Siapkan adonan basah dan kering. Caranya campur semua tepung tambahkan garam, royco ayam, dan merica bubuk secukupnya (dikira2 saja ya garam nya) setelah tercampur, sisihkan 3 sendok makan adonan tadi dan beri air secukupnya nya jangan terlalu encer.
1. Potong2 dada ayam jadi 5 (sesuai selera) jngan terlalu besar karena setelah ditepungi ayam jadi tebal..cuci bersih ayam
1. Panaskan minyak dalam wajan. Beri minyak banyak agar ayam terendam saat digoreng. Masukkan ayam dalam adonan basah aduk2 sampai terlumuri tepung. Lalu masukkan ke adonan kering putar2 ayam sambil dicubit2 agar tepung kriting. Pastikan ayam tertutup tepung.
1. Goreng ayam dalam minyam panas.. Setelah ayam masuk kecilkan api agar matang sempurna kurang lebih 10 menit goreng.
1. Uleg cabai, bawang tambahkan garam dan royco secukupnya... Uleg lalu siram dengan minyak panas sisa buat goreng ayam tadi.. Taruh sambal diatas ayam lalu geprek..
1. Sajikan dengan nasi hangat dan lalapan.. 👍👌😊




Demikianlah cara membuat ayam geprek simple 👌 yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
