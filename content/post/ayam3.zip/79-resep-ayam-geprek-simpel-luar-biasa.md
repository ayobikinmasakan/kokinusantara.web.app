---
description: "Resep : Ayam Geprek Simpel Luar biasa"
title: "Resep : Ayam Geprek Simpel Luar biasa"
slug: 79-resep-ayam-geprek-simpel-luar-biasa
date: 2020-09-02T19:25:40.861Z
image: https://img-global.cpcdn.com/recipes/86b122188258e6bb/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/86b122188258e6bb/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/86b122188258e6bb/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg
author: Leon Bailey
ratingvalue: 4.7
reviewcount: 41598
recipeingredient:
- "1/4 kg dada ayam"
- "1 bungkus tepung bumbu Krispy sajiku"
- "3 lembar daun jeruk"
- "3 siung bawang putih"
- "1 sdt merica bubuk"
- "Secukupnya garam"
- "Secukupnya kaldu bubuk"
- "Secukupnya air"
- " Bahan sambel bawang"
- "1 siung bawang putih"
- "9 cabai rawit merah"
- "Secukupnya garam"
- "Secukupnya kaldu bubuk"
recipeinstructions:
- "Potong ayam seperti di filet, atau sesuai selera dan potong daun jeruk kecil-kecil."
- "Haluskan bawang putih, tambahkan air, lalu campurkan merica, garam, kaldu dan daun jeruk."
- "Celupkan ayam di bumbu sampai meresap sampai dalam. Kemudian balurkan di adonan tepung yang sudah dicairkan sedikit kental. Lalu goreng ayam sampai matang dengan api sedang agak kecil."
- "Haluskan bumbu sambel bawang."
- "Geprek ayam yg sudah di goreng di atas sambel bawang, sampai terkena sambalnya"
- "Sajikan."
categories:
- Recipe
tags:
- ayam
- geprek
- simpel

katakunci: ayam geprek simpel 
nutrition: 144 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Geprek Simpel](https://img-global.cpcdn.com/recipes/86b122188258e6bb/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga gurih. Ciri kuliner Nusantara ayam geprek simpel yang penuh dengan rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kehangatan rumah tangga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam Geprek Simpel untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang bisa anda praktekkan salah satunya ayam geprek simpel yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam geprek simpel tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Simpel yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Simpel:

1. Harus ada 1/4 kg dada ayam
1. Tambah 1 bungkus tepung bumbu Krispy (sajiku)
1. Harap siapkan 3 lembar daun jeruk
1. Diperlukan 3 siung bawang putih
1. Siapkan 1 sdt merica bubuk
1. Harus ada Secukupnya garam
1. Harus ada Secukupnya kaldu bubuk
1. Dibutuhkan Secukupnya air
1. Harap siapkan  Bahan sambel bawang:
1. Diperlukan 1 siung bawang putih
1. Diperlukan 9 cabai rawit merah
1. Siapkan Secukupnya garam
1. Diperlukan Secukupnya kaldu bubuk




<!--inarticleads2-->

##### Instruksi membuat  Ayam Geprek Simpel:

1. Potong ayam seperti di filet, atau sesuai selera dan potong daun jeruk kecil-kecil.
1. Haluskan bawang putih, tambahkan air, lalu campurkan merica, garam, kaldu dan daun jeruk.
1. Celupkan ayam di bumbu sampai meresap sampai dalam. Kemudian balurkan di adonan tepung yang sudah dicairkan sedikit kental. Lalu goreng ayam sampai matang dengan api sedang agak kecil.
1. Haluskan bumbu sambel bawang.
1. Geprek ayam yg sudah di goreng di atas sambel bawang, sampai terkena sambalnya
1. Sajikan.




Demikianlah cara membuat ayam geprek simpel yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
