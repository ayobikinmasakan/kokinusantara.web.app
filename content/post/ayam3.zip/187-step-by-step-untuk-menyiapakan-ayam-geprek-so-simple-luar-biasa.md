---
description: "Step-by-Step untuk menyiapakan Ayam Geprek So Simple Luar biasa"
title: "Step-by-Step untuk menyiapakan Ayam Geprek So Simple Luar biasa"
slug: 187-step-by-step-untuk-menyiapakan-ayam-geprek-so-simple-luar-biasa
date: 2020-11-21T18:42:06.251Z
image: https://img-global.cpcdn.com/recipes/dd82bfe8cd4b01ce/751x532cq70/ayam-geprek-so-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dd82bfe8cd4b01ce/751x532cq70/ayam-geprek-so-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dd82bfe8cd4b01ce/751x532cq70/ayam-geprek-so-simple-foto-resep-utama.jpg
author: Maurice Caldwell
ratingvalue: 4.6
reviewcount: 2123
recipeingredient:
- "1 kg ayam"
- "1 bks sedang tepung bumbu sajiku"
- "1 sdk teh bubuk bawang putih"
- "1 sdk teh bubuk merica"
- "100 ml air"
- " Sambal"
- "100 gr cabe rawit merah"
- "5 siung bawang putih"
- "9 siung bawang merah"
- "secukupnya Gula garam"
recipeinstructions:
- "Cuci bersih ayam, marinasi dengan garam, merica dan bubuk bawang putih. Simpan di freezer"
- "Celup ayam ke adonan basah, lalu kering (tepung sajiku only). Bolak balik ayam sambil dicubit2. Goreng dlm minyak panas dan banyak sampai kuning kecoklatan. Angkat ayam tiriskan."
- "Selagi menunggu ayam matang, kita bisa buat sambalnya. Blender semua bahan sambal, saat memblender jgn menambahkan air ya, gunakan minyak sj. Simpan dalam wadah, tambahkan Gula Garam, tes rasa. Siram sambal menggunakan minyak panas gorengan ayam"
- "Sebelum disajikan, geprek terlebih dahulu ayam. Tambahkan sambal d atasnya. Selamat mencoba.."
categories:
- Recipe
tags:
- ayam
- geprek
- so

katakunci: ayam geprek so 
nutrition: 127 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Geprek So Simple](https://img-global.cpcdn.com/recipes/dd82bfe8cd4b01ce/751x532cq70/ayam-geprek-so-simple-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang harus kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam geprek so simple yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Nusantara



Kedekatan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Geprek So Simple untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang bisa anda coba salah satunya ayam geprek so simple yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam geprek so simple tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek So Simple yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 10 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek So Simple:

1. Siapkan 1 kg ayam
1. Dibutuhkan 1 bks sedang tepung bumbu sajiku
1. Tambah 1 sdk teh bubuk bawang putih
1. Harus ada 1 sdk teh bubuk merica
1. Jangan lupa 100 ml air
1. Harus ada  Sambal
1. Tambah 100 gr cabe rawit merah
1. Dibutuhkan 5 siung bawang putih
1. Diperlukan 9 siung bawang merah
1. Harus ada secukupnya Gula garam




<!--inarticleads2-->

##### Instruksi membuat  Ayam Geprek So Simple:

1. Cuci bersih ayam, marinasi dengan garam, merica dan bubuk bawang putih. Simpan di freezer
1. Celup ayam ke adonan basah, lalu kering (tepung sajiku only). Bolak balik ayam sambil dicubit2. Goreng dlm minyak panas dan banyak sampai kuning kecoklatan. Angkat ayam tiriskan.
1. Selagi menunggu ayam matang, kita bisa buat sambalnya. Blender semua bahan sambal, saat memblender jgn menambahkan air ya, gunakan minyak sj. Simpan dalam wadah, tambahkan Gula Garam, tes rasa. Siram sambal menggunakan minyak panas gorengan ayam
1. Sebelum disajikan, geprek terlebih dahulu ayam. Tambahkan sambal d atasnya. Selamat mencoba..




Demikianlah cara membuat ayam geprek so simple yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan cepat, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
