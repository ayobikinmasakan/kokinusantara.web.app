---
description: "Resep : Ayam Geprek sederhana Homemade"
title: "Resep : Ayam Geprek sederhana Homemade"
slug: 155-resep-ayam-geprek-sederhana-homemade
date: 2021-02-02T12:11:16.504Z
image: https://img-global.cpcdn.com/recipes/b982032b4569e81c/751x532cq70/ayam-geprek-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b982032b4569e81c/751x532cq70/ayam-geprek-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b982032b4569e81c/751x532cq70/ayam-geprek-sederhana-foto-resep-utama.jpg
author: John Lindsey
ratingvalue: 4.5
reviewcount: 26132
recipeingredient:
- "1/2 ekor ayam"
- "secukupnya Kunyit bubuk"
- "2 butir Bawang putih"
- "sendok Merica ujung"
- "1 ruas jari Jahe"
- "2 buah Jeruk nipis"
- "sedikit Asam jawa"
- "secukupnya Garam"
- " Bahan sambal"
- " Cabe rawit 8 1 buah tomat cemangi secukupnya dan garam"
recipeinstructions:
- "Rebus air 1/2 ltr. lalu masukkan ayam tambahkan kunyit bubuk, jika sudah mendidih angkat tiriskan."
- "Haluskan bawang putih dan jahe lalu campurkan pada ayam tadi + garam dan merica bubuk, perasan jeruk nipis dan air asam jawa sedikit (biar warnanya merah). Remas2 agar bumbunya meresap, diamkan setengah jam lalu goreng."
- "Untuk sambal: cabe di gereng sebentar lalu tumbuk kasar, + tomat, garam, cemangi. Siap disajikan"
categories:
- Recipe
tags:
- ayam
- geprek
- sederhana

katakunci: ayam geprek sederhana 
nutrition: 237 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Geprek sederhana](https://img-global.cpcdn.com/recipes/b982032b4569e81c/751x532cq70/ayam-geprek-sederhana-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga enak. Ciri khas masakan Nusantara ayam geprek sederhana yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kehangatan rumah tangga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Geprek sederhana untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang dapat anda coba salah satunya ayam geprek sederhana yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam geprek sederhana tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek sederhana yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 10 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek sederhana:

1. Harus ada 1/2 ekor ayam
1. Siapkan secukupnya Kunyit bubuk
1. Siapkan 2 butir Bawang putih
1. Siapkan sendok Merica ujung
1. Harus ada 1 ruas jari Jahe
1. Jangan lupa 2 buah Jeruk nipis
1. Harus ada sedikit Asam jawa
1. Siapkan secukupnya Garam
1. Harap siapkan  Bahan sambal:
1. Jangan lupa  Cabe rawit 8, 1 buah tomat, cemangi secukupnya dan garam




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek sederhana:

1. Rebus air 1/2 ltr. lalu masukkan ayam tambahkan kunyit bubuk, jika sudah mendidih angkat tiriskan.
1. Haluskan bawang putih dan jahe lalu campurkan pada ayam tadi + garam dan merica bubuk, perasan jeruk nipis dan air asam jawa sedikit (biar warnanya merah). Remas2 agar bumbunya meresap, diamkan setengah jam lalu goreng.
1. Untuk sambal: cabe di gereng sebentar lalu tumbuk kasar, + tomat, garam, cemangi. Siap disajikan




Demikianlah cara membuat ayam geprek sederhana yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
