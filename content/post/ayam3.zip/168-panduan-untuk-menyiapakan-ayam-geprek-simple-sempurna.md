---
description: "Panduan untuk menyiapakan Ayam Geprek Simple Sempurna"
title: "Panduan untuk menyiapakan Ayam Geprek Simple Sempurna"
slug: 168-panduan-untuk-menyiapakan-ayam-geprek-simple-sempurna
date: 2020-12-03T00:50:40.306Z
image: https://img-global.cpcdn.com/recipes/34dbf85f758e647d/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/34dbf85f758e647d/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/34dbf85f758e647d/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
author: Theresa Green
ratingvalue: 4.3
reviewcount: 33389
recipeingredient:
- "1/2 kg ayam potong sedang"
- " Tepung bumbu sesuai selera sy pakai sajiku"
- " Bahan sambal"
- "sesuai selera Cabe rawit dan cabe merah"
- " Bawang merah bawang putih 1siung"
- "sesuai selera Terasi"
- "1 biji Tomat"
- "sesuai selera Gula garam"
- " Lalapan"
- " Mentimun"
- " Daun kemangi"
- " Minyak goreng untuk menggoreng ayam dan menumis bahan sambal"
recipeinstructions:
- "Cuci bersih ayam. Bagi adonan tepung bumbu menjadi 2, adonan basah dan kering. Masukkan ayam ke adonan basah, kemudian ke adonan kering. Ulangi beberapa kali sampai ayam tertutup tepung sempurna."
- "Panaskan minyak goreng. Kemudian goreng ayam tepung sampai matang berwarna coklat keemasan. Angkat dan tiriskan."
- "Tumis bahan sambal, cabe rawit&amp;cabe merah, bawang merah, bawang putih, dan tomat. Tunggu sampai agak layu. Kemudian angkat. Siapkan Gula Garam dan terasi diatas cobek. Lalu ulek sambel sampai halus."
- "Letakkan ayam tepung diatas sambal, kemudian geprek dan olesi sambal diatasnya. Taruh mentimun yang sudah dipotong untuk lalapan. Tak lupa daun kemangi juga. Selamat menikmati😊"
categories:
- Recipe
tags:
- ayam
- geprek
- simple

katakunci: ayam geprek simple 
nutrition: 280 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Geprek Simple](https://img-global.cpcdn.com/recipes/34dbf85f758e647d/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas dan empuk. Ciri khas makanan Nusantara ayam geprek simple yang kaya dengan rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam Geprek Simple untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang bisa anda contoh salah satunya ayam geprek simple yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam geprek simple tanpa harus bersusah payah.
Seperti resep Ayam Geprek Simple yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Simple:

1. Tambah 1/2 kg ayam potong sedang
1. Dibutuhkan  Tepung bumbu sesuai selera (sy pakai sajiku)
1. Harap siapkan  Bahan sambal
1. Diperlukan sesuai selera Cabe rawit dan cabe merah
1. Harap siapkan  Bawang merah bawang putih @1siung
1. Siapkan sesuai selera Terasi
1. Diperlukan 1 biji Tomat
1. Harus ada sesuai selera Gula garam
1. Jangan lupa  Lalapan
1. Siapkan  Mentimun
1. Jangan lupa  Daun kemangi
1. Siapkan  Minyak goreng untuk menggoreng ayam dan menumis bahan sambal




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek Simple:

1. Cuci bersih ayam. Bagi adonan tepung bumbu menjadi 2, adonan basah dan kering. Masukkan ayam ke adonan basah, kemudian ke adonan kering. Ulangi beberapa kali sampai ayam tertutup tepung sempurna.
1. Panaskan minyak goreng. Kemudian goreng ayam tepung sampai matang berwarna coklat keemasan. Angkat dan tiriskan.
1. Tumis bahan sambal, cabe rawit&amp;cabe merah, bawang merah, bawang putih, dan tomat. Tunggu sampai agak layu. Kemudian angkat. Siapkan Gula Garam dan terasi diatas cobek. Lalu ulek sambel sampai halus.
1. Letakkan ayam tepung diatas sambal, kemudian geprek dan olesi sambal diatasnya. Taruh mentimun yang sudah dipotong untuk lalapan. Tak lupa daun kemangi juga. Selamat menikmati😊




Demikianlah cara membuat ayam geprek simple yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
