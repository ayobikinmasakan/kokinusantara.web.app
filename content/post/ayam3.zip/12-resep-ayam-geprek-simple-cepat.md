---
description: "Resep : Ayam geprek simple Cepat"
title: "Resep : Ayam geprek simple Cepat"
slug: 12-resep-ayam-geprek-simple-cepat
date: 2021-01-03T21:00:22.138Z
image: https://img-global.cpcdn.com/recipes/2df5021a9ca1ba25/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2df5021a9ca1ba25/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2df5021a9ca1ba25/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
author: Amy Silva
ratingvalue: 4.2
reviewcount: 35146
recipeingredient:
- "1/4 kg daging ayam"
- "1 batang sereh geprek"
- " Tambahan"
- "10 sdm tepung terigu kalau kurang boleh tambah"
- "5 biji bawang putih"
- "1 gelas air es secukupnya"
- " Untuk sambal"
- "15-20 biji cabe rawit sesuai selera"
- "1 biji bawang putih boleh tambah sesuai selera"
- " Penyedap rasa"
- " Minyak goreng"
recipeinstructions:
- "Cuci bersih daging ayam kemudian masak setengah matang (5-10 menit) jangan lupa masukkan sereh dan penyedap rasa. Kemudian angkat dan tiriskan."
- "Haluskan bawang putih kemudian masukkan dalam wadah beserta air es. Tambahkan penyedap rasa aduk² hingga tercampur rata. Setelah itu masukkan daging ayam. Aduk lagi hingga bumbu² meresap. Diamkan selama 15 menit."
- "Sambil menunggu kita buat sambalnya. Tumbuk bawang putih dan cabe rawit. Kemudian siram minyak panas (-+ 5 sdm minyak goreng) jangan lupa penyedap rasa. Aduk². Sisihkan."
- "Di wadah lain siapkan tepung terigu."
- "Setelah cukup 15 menit. Angkat daging ayam ke wadah tepung terigu kemudian balur. Jika ingin adonannya tebal celupkan ke air rendaman tadi kemudian balur lagi. Lakukan satu persatu hingga selesai."
- "Panaskan minyak dan goreng hingga matang. Kemudian digeprek. (NB : gorengnya jangan terlalu lama supaya tidak keras)"
- "Sajikan dengan sambalnya 😍"
categories:
- Recipe
tags:
- ayam
- geprek
- simple

katakunci: ayam geprek simple 
nutrition: 252 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam geprek simple](https://img-global.cpcdn.com/recipes/2df5021a9ca1ba25/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan enak. Ciri khas masakan Indonesia ayam geprek simple yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Ayam geprek simple untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang dapat anda buat salah satunya ayam geprek simple yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam geprek simple tanpa harus bersusah payah.
Seperti resep Ayam geprek simple yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek simple:

1. Harus ada 1/4 kg daging ayam
1. Tambah 1 batang sereh (geprek)
1. Tambah  Tambahan
1. Diperlukan 10 sdm tepung terigu (kalau kurang boleh tambah)
1. Harus ada 5 biji bawang putih
1. Harap siapkan 1 gelas air es (secukupnya)
1. Diperlukan  Untuk sambal
1. Dibutuhkan 15-20 biji cabe rawit (sesuai selera)
1. Diperlukan 1 biji bawang putih (boleh tambah sesuai selera)
1. Harus ada  Penyedap rasa
1. Harus ada  Minyak goreng




<!--inarticleads2-->

##### Instruksi membuat  Ayam geprek simple:

1. Cuci bersih daging ayam kemudian masak setengah matang (5-10 menit) jangan lupa masukkan sereh dan penyedap rasa. Kemudian angkat dan tiriskan.
1. Haluskan bawang putih kemudian masukkan dalam wadah beserta air es. Tambahkan penyedap rasa aduk² hingga tercampur rata. Setelah itu masukkan daging ayam. Aduk lagi hingga bumbu² meresap. Diamkan selama 15 menit.
1. Sambil menunggu kita buat sambalnya. Tumbuk bawang putih dan cabe rawit. Kemudian siram minyak panas (-+ 5 sdm minyak goreng) jangan lupa penyedap rasa. Aduk². Sisihkan.
1. Di wadah lain siapkan tepung terigu.
1. Setelah cukup 15 menit. Angkat daging ayam ke wadah tepung terigu kemudian balur. Jika ingin adonannya tebal celupkan ke air rendaman tadi kemudian balur lagi. Lakukan satu persatu hingga selesai.
1. Panaskan minyak dan goreng hingga matang. Kemudian digeprek. (NB : gorengnya jangan terlalu lama supaya tidak keras)
1. Sajikan dengan sambalnya 😍




Demikianlah cara membuat ayam geprek simple yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan teruji, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
