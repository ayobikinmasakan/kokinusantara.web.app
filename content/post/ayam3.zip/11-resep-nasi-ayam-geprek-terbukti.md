---
description: "Resep : Nasi ayam geprek Terbukti"
title: "Resep : Nasi ayam geprek Terbukti"
slug: 11-resep-nasi-ayam-geprek-terbukti
date: 2020-10-17T19:51:14.023Z
image: https://img-global.cpcdn.com/recipes/ccb767eae4817f05/751x532cq70/nasi-ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ccb767eae4817f05/751x532cq70/nasi-ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ccb767eae4817f05/751x532cq70/nasi-ayam-geprek-foto-resep-utama.jpg
author: Katharine Rose
ratingvalue: 4.2
reviewcount: 4145
recipeingredient:
- "1/4 kilo ekor ayam"
- "500 gram tepung sajiku"
- "1 sdt merica bubuk"
- "10 cabe rawit sesuai selera"
- "3 biji cabe merah"
- "3 siung bawang merah"
- "2 siung bawang putih"
- "1 buah jeruk limau"
- "secukupnya Garam"
- " Gula secukupy"
- "secukupnya Terasi"
- "secukupnya Penyedap rasa"
recipeinstructions:
- "Potong ayam jadi brapa bagian terserah y bun mw jadi brapa potong,"
- "Cuci ayam,kalau bisa di kasih jeruk nipis byar buah ayamy hilang,"
- "Didikan air, masuksn ayam yg sudah di bersihkan tadi,bila ayamy sudah terlihat matang angkat lalu tiriskn,"
- "Siapkan Adonany GG terllu ribet y bun, pkek tepung sajiku saja simpel gitu, di bagi dua bagian yg basah sama yg kering,"
- "Celupkan ayam kedalm adonan yg kering,celupkan lgi ke adonan yg basah,"
- "Siapkan wajan,pnaskn minyak, Cemplung kn ayam goreng smpai kecoklatan triskn, sisa minyak jgan di buang Bun,goreng bumbu,bawang merah,bawang putih,cabe kecil,cabe besar, goreng smpai layu"
- "Siapkn cobek ulek bumbu yg sudah di goreng, ulek jgan terllu halus msukn ayam kecobek geprek deh,sajikan dan hidangkn"
- "Selmat mencoba 🤤"
categories:
- Recipe
tags:
- nasi
- ayam
- geprek

katakunci: nasi ayam geprek 
nutrition: 137 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Dinner

---


![Nasi ayam geprek](https://img-global.cpcdn.com/recipes/ccb767eae4817f05/751x532cq70/nasi-ayam-geprek-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan enak. Ciri khas makanan Nusantara nasi ayam geprek yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Nasi ayam geprek untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang dapat anda contoh salah satunya nasi ayam geprek yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep nasi ayam geprek tanpa harus bersusah payah.
Berikut ini resep Nasi ayam geprek yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nasi ayam geprek:

1. Dibutuhkan 1/4 kilo ekor ayam
1. Harus ada 500 gram tepung sajiku
1. Diperlukan 1 sdt merica bubuk
1. Dibutuhkan 10 cabe rawit (sesuai selera)
1. Diperlukan 3 biji cabe merah
1. Harus ada 3 siung bawang merah
1. Tambah 2 siung bawang putih
1. Diperlukan 1 buah jeruk limau
1. Siapkan secukupnya Garam
1. Dibutuhkan  Gula secukupy
1. Dibutuhkan secukupnya Terasi
1. Siapkan secukupnya Penyedap rasa




<!--inarticleads2-->

##### Langkah membuat  Nasi ayam geprek:

1. Potong ayam jadi brapa bagian terserah y bun mw jadi brapa potong,
1. Cuci ayam,kalau bisa di kasih jeruk nipis byar buah ayamy hilang,
1. Didikan air, masuksn ayam yg sudah di bersihkan tadi,bila ayamy sudah terlihat matang angkat lalu tiriskn,
1. Siapkan Adonany GG terllu ribet y bun, pkek tepung sajiku saja simpel gitu, di bagi dua bagian yg basah sama yg kering,
1. Celupkan ayam kedalm adonan yg kering,celupkan lgi ke adonan yg basah,
1. Siapkan wajan,pnaskn minyak, Cemplung kn ayam goreng smpai kecoklatan triskn, sisa minyak jgan di buang Bun,goreng bumbu,bawang merah,bawang putih,cabe kecil,cabe besar, goreng smpai layu
1. Siapkn cobek ulek bumbu yg sudah di goreng, ulek jgan terllu halus msukn ayam kecobek geprek deh,sajikan dan hidangkn
1. Selmat mencoba 🤤




Demikianlah cara membuat nasi ayam geprek yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
