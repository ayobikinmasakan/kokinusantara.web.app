---
description: "Steps untuk menyiapakan Menu diet Enak (Ayam geprek sambal kencur) terupdate"
title: "Steps untuk menyiapakan Menu diet Enak (Ayam geprek sambal kencur) terupdate"
slug: 182-steps-untuk-menyiapakan-menu-diet-enak-ayam-geprek-sambal-kencur-terupdate
date: 2020-11-02T18:11:29.319Z
image: https://img-global.cpcdn.com/recipes/8fe405fa2150e5ff/751x532cq70/menu-diet-enak-ayam-geprek-sambal-kencur-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8fe405fa2150e5ff/751x532cq70/menu-diet-enak-ayam-geprek-sambal-kencur-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8fe405fa2150e5ff/751x532cq70/menu-diet-enak-ayam-geprek-sambal-kencur-foto-resep-utama.jpg
author: Dean Rice
ratingvalue: 4.4
reviewcount: 45838
recipeingredient:
- "2 potong daging ayam"
- "4 pohon sawi hijau"
- "1 buah wortel"
- "secukupnya Lada hitam"
- "secukupnya Tepung bumbu"
- " Minyak goreng secukupnya untuk menggoreng ayam"
- " Bahan Sambal"
- "10 buah Cabe rawit"
- "3 buah tomat"
- "3 siung Bawang merah"
- "1 ruas kencur"
- "Secukupnya garam  gula"
- "Secukupnya daun kemangi"
recipeinstructions:
- "Potong wortel sebesar potongan kentang goreng. Potong sawi dengan panjang sama dengan wortel."
- "Taburi ayam yang sudah dicuci bersih dengan lada hitam, ratakan. Tambahkan tepung bumbu sedikit demi sedikit sampai semua bagian terlumuri (lapisan basah). Biarkan meresap."
- "Rebus wortel dan sawi (secara terpisah)"
- "Goreng ayam yang sudah dilumuri tepung bumbu sampai kira2 matang."
- "Selagi menggoreng ayam, kita siapkan sambal untuk nanti kita geprek ayamnya."
- "Haluskan semua bahan sambal kecuali kemangi. Setelah itu masukkan daun kemangi dan ulek perlahan. *Jangan lupa dicicipi ya bunda*"
- "Masukkan ayam goreng ke dalam sambal dan geprek (saya geprek langsung di sambal karena bisa langsung meresap dan rasanya lebih endes daripada geprek terpisah)."
- "Menu diet simple sesuai kantong siap disajikan 😉😉"
categories:
- Recipe
tags:
- menu
- diet
- enak

katakunci: menu diet enak 
nutrition: 298 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dessert

---


![Menu diet Enak (Ayam geprek sambal kencur)](https://img-global.cpcdn.com/recipes/8fe405fa2150e5ff/751x532cq70/menu-diet-enak-ayam-geprek-sambal-kencur-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti menu diet enak (ayam geprek sambal kencur) yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Nusantara



Kehangatan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Menu diet Enak (Ayam geprek sambal kencur) untuk keluarga. Momen makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda coba salah satunya menu diet enak (ayam geprek sambal kencur) yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep menu diet enak (ayam geprek sambal kencur) tanpa harus bersusah payah.
Seperti resep Menu diet Enak (Ayam geprek sambal kencur) yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Menu diet Enak (Ayam geprek sambal kencur):

1. Diperlukan 2 potong daging ayam
1. Jangan lupa 4 pohon sawi hijau
1. Jangan lupa 1 buah wortel
1. Tambah secukupnya Lada hitam
1. Dibutuhkan secukupnya Tepung bumbu
1. Harap siapkan  Minyak goreng secukupnya (untuk menggoreng ayam)
1. Jangan lupa  Bahan Sambal
1. Siapkan 10 buah Cabe rawit
1. Dibutuhkan 3 buah tomat
1. Harap siapkan 3 siung Bawang merah
1. Tambah 1 ruas kencur
1. Siapkan Secukupnya garam &amp; gula
1. Harus ada Secukupnya daun kemangi




<!--inarticleads2-->

##### Langkah membuat  Menu diet Enak (Ayam geprek sambal kencur):

1. Potong wortel sebesar potongan kentang goreng. Potong sawi dengan panjang sama dengan wortel.
1. Taburi ayam yang sudah dicuci bersih dengan lada hitam, ratakan. Tambahkan tepung bumbu sedikit demi sedikit sampai semua bagian terlumuri (lapisan basah). Biarkan meresap.
1. Rebus wortel dan sawi (secara terpisah)
1. Goreng ayam yang sudah dilumuri tepung bumbu sampai kira2 matang.
1. Selagi menggoreng ayam, kita siapkan sambal untuk nanti kita geprek ayamnya.
1. Haluskan semua bahan sambal kecuali kemangi. Setelah itu masukkan daun kemangi dan ulek perlahan. *Jangan lupa dicicipi ya bunda*
1. Masukkan ayam goreng ke dalam sambal dan geprek (saya geprek langsung di sambal karena bisa langsung meresap dan rasanya lebih endes daripada geprek terpisah).
1. Menu diet simple sesuai kantong siap disajikan 😉😉




Demikianlah cara membuat menu diet enak (ayam geprek sambal kencur) yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
