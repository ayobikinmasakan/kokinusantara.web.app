---
description: "Resep : Soto Sayap Ayam teraktual"
title: "Resep : Soto Sayap Ayam teraktual"
slug: 396-resep-soto-sayap-ayam-teraktual
date: 2020-08-16T02:13:32.027Z
image: https://img-global.cpcdn.com/recipes/8b6b6e4aa078bfa6/751x532cq70/soto-sayap-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8b6b6e4aa078bfa6/751x532cq70/soto-sayap-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8b6b6e4aa078bfa6/751x532cq70/soto-sayap-ayam-foto-resep-utama.jpg
author: Leah Zimmerman
ratingvalue: 4.1
reviewcount: 24485
recipeingredient:
- "550 gr Sayap Ayam"
- "3 helai Daun Bawang besar potong kecil"
- "3 helai Daun Seledri cincang"
- "1 batang Sereh bagi 2 memarkan"
- "5 lembar Daun Jeruk"
- "1 buah Kayu manis kecil"
- "1/2 sdt Merica  selera"
- "1 sdt garam  selera"
- "1 sdt kaldu ayam  selera"
- "1 lt air "
- "3 sdm Minyak"
- " Bahan Halus tumis terlebih dahulu bertahap"
- "13 siung Bawang Merah kecil  7 siung besar"
- "5 siung Bawang Putih"
- "5 butir Kemiri"
- "2 ruas Jahe"
- "2 ruas Kunyit jika kunyit berwarna oranye pakai 1 ruas saja"
- "1 butir Pala"
- "1 sdt Jintan"
- " Taburan"
- " Kentang goreng  Bawang goreng"
recipeinstructions:
- "Cuci bersih Sayap Ayam, sisihkan. Panaskan air (*note, disini dipakai untuk merebus Sayap terlebih dahulu, ukuran air bisa ditambah sesuai konsistensi kental tidaknya kuah), masukkan sereh, daun jeruk, dan kayu manis. Mendidih, masukkan Sayap, biarkan hingga empuk."
- "Siapkan Bahan Halus. Iris tipis jahe, kunyit. Panaskan wajan dg api kecil. Tumis bawang merah dan putih sampai harum, masukkan irisan jahe dan kunyit, lalu kemiri. Tumis hingga agak kekuningan, lalu masukkan jintan, tumis sebentar. Angkat."
- "Siapkan cobek (kalo yg mau diblender silahkan ya, mama bakal sewot kalo tau sy pake blender xixi). Siapkan merica bubuk juga pala, dan tambahkan bumbu tumisan, haluskan."
- "Panaskan wajan kembali, tumis Bahan Halus hingga harum (api kecil ya biar ga hangus). Tambahkan potongan daun bawang, tumis kembali hingga tercampur rata dan wangi."
- "Ketika Sayap sudah empuk, masukkan bahan tumisan ke dalam kuah. Aduk rata, dan tambahkan garam dan kaldu ayam sesuai selera. Tes rasa. Tunggu hingga beberapa saat. Matikan kompor."
- "Taburkan seledri cincang ke dalam kuah Soto Sayap Ayam. Sekadar opsi tambahan saja, kentang diiris tipis sekali lalu diremas pelan di larutan garam, buang airnya, goreng hingga matang. Bisa buat nemenin si Soto Sayap Ayam."
- "Dijamin soto ini meskipun bikinnya bertele tapi rasanya hmm jadi ga pengen lagi jajan soto diluar😋 #promosi 😝"
categories:
- Recipe
tags:
- soto
- sayap
- ayam

katakunci: soto sayap ayam 
nutrition: 174 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Dinner

---


![Soto Sayap Ayam](https://img-global.cpcdn.com/recipes/8b6b6e4aa078bfa6/751x532cq70/soto-sayap-ayam-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas dan renyah. Ciri khas kuliner Nusantara soto sayap ayam yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Soto Sayap Ayam untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda coba salah satunya soto sayap ayam yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep soto sayap ayam tanpa harus bersusah payah.
Berikut ini resep Soto Sayap Ayam yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Soto Sayap Ayam:

1. Siapkan 550 gr Sayap Ayam
1. Diperlukan 3 helai Daun Bawang besar, potong kecil
1. Tambah 3 helai Daun Seledri, cincang
1. Jangan lupa 1 batang Sereh, bagi 2 memarkan
1. Diperlukan 5 lembar Daun Jeruk
1. Harus ada 1 buah Kayu manis kecil
1. Dibutuhkan 1/2 sdt Merica, ± selera
1. Jangan lupa 1 sdt garam, ± selera
1. Harap siapkan 1 sdt kaldu ayam, ± selera
1. Siapkan 1 lt air *
1. Dibutuhkan 3 sdm Minyak
1. Diperlukan  Bahan Halus (tumis terlebih dahulu, bertahap)
1. Diperlukan 13 siung Bawang Merah kecil / 7 siung besar
1. Siapkan 5 siung Bawang Putih
1. Siapkan 5 butir Kemiri
1. Tambah 2 ruas Jahe
1. Tambah 2 ruas Kunyit (jika kunyit berwarna oranye pakai 1 ruas saja)
1. Siapkan 1 butir Pala
1. Tambah 1 sdt Jintan
1. Harus ada  Taburan
1. Diperlukan  Kentang goreng / Bawang goreng




<!--inarticleads2-->

##### Langkah membuat  Soto Sayap Ayam:

1. Cuci bersih Sayap Ayam, sisihkan. Panaskan air (*note, disini dipakai untuk merebus Sayap terlebih dahulu, ukuran air bisa ditambah sesuai konsistensi kental tidaknya kuah), masukkan sereh, daun jeruk, dan kayu manis. Mendidih, masukkan Sayap, biarkan hingga empuk.
1. Siapkan Bahan Halus. Iris tipis jahe, kunyit. Panaskan wajan dg api kecil. Tumis bawang merah dan putih sampai harum, masukkan irisan jahe dan kunyit, lalu kemiri. Tumis hingga agak kekuningan, lalu masukkan jintan, tumis sebentar. Angkat.
1. Siapkan cobek (kalo yg mau diblender silahkan ya, mama bakal sewot kalo tau sy pake blender xixi). Siapkan merica bubuk juga pala, dan tambahkan bumbu tumisan, haluskan.
1. Panaskan wajan kembali, tumis Bahan Halus hingga harum (api kecil ya biar ga hangus). Tambahkan potongan daun bawang, tumis kembali hingga tercampur rata dan wangi.
1. Ketika Sayap sudah empuk, masukkan bahan tumisan ke dalam kuah. Aduk rata, dan tambahkan garam dan kaldu ayam sesuai selera. Tes rasa. Tunggu hingga beberapa saat. Matikan kompor.
1. Taburkan seledri cincang ke dalam kuah Soto Sayap Ayam. Sekadar opsi tambahan saja, kentang diiris tipis sekali lalu diremas pelan di larutan garam, buang airnya, goreng hingga matang. Bisa buat nemenin si Soto Sayap Ayam.
1. Dijamin soto ini meskipun bikinnya bertele tapi rasanya hmm jadi ga pengen lagi jajan soto diluar😋 #promosi 😝




Demikianlah cara membuat soto sayap ayam yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
