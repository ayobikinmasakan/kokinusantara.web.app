---
description: "Steps membuat Ayam rica rica kemangi Luar biasa"
title: "Steps membuat Ayam rica rica kemangi Luar biasa"
slug: 489-steps-membuat-ayam-rica-rica-kemangi-luar-biasa
date: 2020-12-06T03:37:42.347Z
image: https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Miguel Smith
ratingvalue: 4.6
reviewcount: 32901
recipeingredient:
- "1 ekor ayam potong kecil"
- "6 lembar daun jeruk potong tipis2"
- "2 batang serai memarkan"
- "3 lembar daun salam"
- "2 ikat kemangi petik daunnya saja"
- "2 ruas lengkuas memarkan"
- "2 ruas jahe memarkan"
- " Garam"
- " Penyedap jamur  kaldu bubuk sesuai selera"
- "6 buah cabe rawit merah bulat boleh ditambah sesuai selera"
- " Bumbu halus"
- "20 cabe merah keriting"
- "9 cabe rawit merah"
- "8 siung bawang merah"
- "3 siung bawang putih"
- "2 ruas kunyit kupas"
recipeinstructions:
- "Cuci bersih ayam, kemudian goreng di minyak panas sampai ayam agak sedikit kecoklatan / setengah matang. Jika sudah kecoklatan, angkat dan tiriskan."
- "Tumis bumbu halus dengan api kecil hingga wangi, masukan lengkuas, jahe, daun jeruk, daun salam, dan batang serai. Tumis kembali hingga wangi."
- "Masukan ayam yang tadi sudah digoreng kedalam tumisan bumbu, masukan garam dan penyedap, aduk hingga ayam tercampur dengan bumbu cabe. Tambahkan sedikit saja air supaya lebih mudah tercampur."
- "Setelah tercampur rata, masukan cabe rawit merah bulat untuk variasi jika ingin menambah rasa pedas, tumis kembali. Setelah semua tercampur rata, masukan daun kemangi, tumis hingga agak layu. Matikan api. Rica rica siap disantap...selamat mencoba bun 🥰🥰🥰"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 107 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga enak. Ciri khas masakan Nusantara ayam rica rica kemangi yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica rica kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda coba salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Harap siapkan 1 ekor ayam, potong kecil
1. Harap siapkan 6 lembar daun jeruk, potong tipis2
1. Jangan lupa 2 batang serai, memarkan
1. Harap siapkan 3 lembar daun salam
1. Siapkan 2 ikat kemangi, petik daunnya saja
1. Diperlukan 2 ruas lengkuas, memarkan
1. Tambah 2 ruas jahe, memarkan
1. Siapkan  Garam
1. Tambah  Penyedap jamur / kaldu bubuk (sesuai selera)
1. Dibutuhkan 6 buah cabe rawit merah bulat (boleh ditambah sesuai selera)
1. Jangan lupa  Bumbu halus
1. Harap siapkan 20 cabe merah keriting
1. Diperlukan 9 cabe rawit merah
1. Diperlukan 8 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Harus ada 2 ruas kunyit, kupas




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica kemangi:

1. Cuci bersih ayam, kemudian goreng di minyak panas sampai ayam agak sedikit kecoklatan / setengah matang. Jika sudah kecoklatan, angkat dan tiriskan.
1. Tumis bumbu halus dengan api kecil hingga wangi, masukan lengkuas, jahe, daun jeruk, daun salam, dan batang serai. Tumis kembali hingga wangi.
1. Masukan ayam yang tadi sudah digoreng kedalam tumisan bumbu, masukan garam dan penyedap, aduk hingga ayam tercampur dengan bumbu cabe. Tambahkan sedikit saja air supaya lebih mudah tercampur.
1. Setelah tercampur rata, masukan cabe rawit merah bulat untuk variasi jika ingin menambah rasa pedas, tumis kembali. Setelah semua tercampur rata, masukan daun kemangi, tumis hingga agak layu. Matikan api. Rica rica siap disantap...selamat mencoba bun 🥰🥰🥰




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
