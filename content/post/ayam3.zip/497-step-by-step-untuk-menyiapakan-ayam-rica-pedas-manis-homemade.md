---
description: "Step-by-Step untuk menyiapakan Ayam rica pedas manis Homemade"
title: "Step-by-Step untuk menyiapakan Ayam rica pedas manis Homemade"
slug: 497-step-by-step-untuk-menyiapakan-ayam-rica-pedas-manis-homemade
date: 2020-11-28T03:37:49.307Z
image: https://img-global.cpcdn.com/recipes/7ce2fc9e759043c9/751x532cq70/ayam-rica-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7ce2fc9e759043c9/751x532cq70/ayam-rica-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7ce2fc9e759043c9/751x532cq70/ayam-rica-pedas-manis-foto-resep-utama.jpg
author: Dylan Tucker
ratingvalue: 5
reviewcount: 29272
recipeingredient:
- "1/2 kg ayam"
- " Bumbu halus "
- "5 siung bawang merah"
- "4 siung bawang putih"
- "6 buah cabe merah"
- "7 buah cabe rawit"
- "3 butir kemiri"
- " Bahan lainnya "
- "2 lembar daun salam"
- "2 cm lengkuas"
- "1 batang serai"
- "Secukupnya gula jawagula pasir"
- "Secukupnya garam"
- "Secukupnya kaldu jamur"
- " Minyak goreng untuk menumis"
- "Secukupnya kecap manis"
- "Secukupnya air"
recipeinstructions:
- "Cuci bersih ayam dan potong sesuai selera, siapkan bahan bumbu halus ya, bisa di blender bisa di ulek ya bun ini saya blender aja biar cepet saya kasih minyak goreng dikit saat blender"
- "Siapkan wajan beri minyak goreng kemudian tumis bumbu halus dan masukkan daun salam, lengkuas, dan serai sampai harum masukkan gula jawa, garam, kaldu jamur dan masukkan ayam beri air dan kecap manis tunggu sampai meresap"
- "Setelah air menyusut dan bumbunya seperti mengeluarkan minyak koreksi rasa dan siap dihidangkan ya bunda simpel enak"
categories:
- Recipe
tags:
- ayam
- rica
- pedas

katakunci: ayam rica pedas 
nutrition: 129 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam rica pedas manis](https://img-global.cpcdn.com/recipes/7ce2fc9e759043c9/751x532cq70/ayam-rica-pedas-manis-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan enak. Ciri khas masakan Nusantara ayam rica pedas manis yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Ayam rica pedas manis untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

Untuk bulan Ramadan tahun ini, Resep Ayam Rica Pedas Manis bisa jadi pilihan tepat untuk kamu saat berbuka puasa. Tentunya setelah kosong seharian, kita perlu berbuka puasa dengan yang ringan terlebih dahulu dan siap berpetualang lebih jauh dengan makanan lainnya. Nah, saya sudah memasak Daging Ayam menjadi Ayam Rica-Rica Pedas Manis. Kira-kira kalo Mi Fans semuanya diberikan bahan dasar Daging Ayam, mau dimasak apa?

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda praktekkan salah satunya ayam rica pedas manis yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica pedas manis tanpa harus bersusah payah.
Seperti resep Ayam rica pedas manis yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 17 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica pedas manis:

1. Dibutuhkan 1/2 kg ayam
1. Siapkan  Bumbu halus :
1. Siapkan 5 siung bawang merah
1. Harus ada 4 siung bawang putih
1. Harus ada 6 buah cabe merah
1. Tambah 7 buah cabe rawit
1. Siapkan 3 butir kemiri
1. Harus ada  Bahan lainnya :
1. Diperlukan 2 lembar daun salam
1. Siapkan 2 cm lengkuas
1. Dibutuhkan 1 batang serai
1. Siapkan Secukupnya gula jawa/gula pasir
1. Dibutuhkan Secukupnya garam
1. Harus ada Secukupnya kaldu jamur
1. Tambah  Minyak goreng untuk menumis
1. Dibutuhkan Secukupnya kecap manis
1. Jangan lupa Secukupnya air


Keunikan rasa rica rica ayam manado ini adalah rasa pedas, manis, asin, gurih bercampur dengan takaran pas, sehingga tercipta cita rasa yang sempurna. Itulah salah satu rahasia aneka macam resep masakan dari nusantara, sehingga terkenal hingga ke manca negara. Ayam Bakar Pedas Manis, Pamulang, Jawa Barat, Indonesia. Resep Ayam Rica-Rica Bumbu Pedas - Hidangan masakan Nusantara yang berasal dari Kota Manado ini sangat diminati orang Indonesia. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam rica pedas manis:

1. Cuci bersih ayam dan potong sesuai selera, siapkan bahan bumbu halus ya, bisa di blender bisa di ulek ya bun ini saya blender aja biar cepet saya kasih minyak goreng dikit saat blender
1. Siapkan wajan beri minyak goreng kemudian tumis bumbu halus dan masukkan daun salam, lengkuas, dan serai sampai harum masukkan gula jawa, garam, kaldu jamur dan masukkan ayam beri air dan kecap manis tunggu sampai meresap
1. Setelah air menyusut dan bumbunya seperti mengeluarkan minyak koreksi rasa dan siap dihidangkan ya bunda simpel enak


Ayam Bakar Pedas Manis, Pamulang, Jawa Barat, Indonesia. Resep Ayam Rica-Rica Bumbu Pedas - Hidangan masakan Nusantara yang berasal dari Kota Manado ini sangat diminati orang Indonesia. Resep Ayam Rica-Rica Kemangi. image via cookpad.com. Pedas cabe berpadu dengan daun kemangi yang wangi tampaknya menjadi. Resep ayam dengan bumbu rica-rica yang pedas bisa jadi menu spesial. 

Demikianlah cara membuat ayam rica pedas manis yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
