---
description: "Step-by-Step untuk menyiapakan Sayap ayam Bakar Kecap Luar biasa"
title: "Step-by-Step untuk menyiapakan Sayap ayam Bakar Kecap Luar biasa"
slug: 375-step-by-step-untuk-menyiapakan-sayap-ayam-bakar-kecap-luar-biasa
date: 2020-10-14T12:28:19.433Z
image: https://img-global.cpcdn.com/recipes/e91c6eb4dd37c631/751x532cq70/sayap-ayam-bakar-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e91c6eb4dd37c631/751x532cq70/sayap-ayam-bakar-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e91c6eb4dd37c631/751x532cq70/sayap-ayam-bakar-kecap-foto-resep-utama.jpg
author: Mitchell Fuller
ratingvalue: 4.4
reviewcount: 11836
recipeingredient:
- "1 kg sayap ayam 9 potong"
- "2-4 sdm air asam jawa tergantung selera"
- "2 potong serai geprak"
- "5 lbr daun salam"
- "1 sdm garam bisa kuranglebih"
- "1 sdm gula putih"
- "1 sdm gula merah"
- "10 sdm kecap manis"
- "1 sdm kaldu bubuk"
- "2 sdm air jeruk nipis"
- "2 sdm minyak goreng"
- "400 ml air"
- " Bumbu halus"
- "8 siung bawang merah"
- "3 siung bawang putih"
- "5 cm lengkuas"
- "1/2 sdt ketumbar"
- "1 ruas kunyit 2 sdm kunyit bubuk"
- "2-3 cm jahe"
recipeinstructions:
- "Bersihkan ayam. Balur dengan air jeruk nipis. Diamkan 15 menit. Setelah 15 menit, cuci kembali ayam. Ayam siap digunakan."
- "Siapkan bumbu2. Tumis bumbu halus sampai bau bawang mentah hilang. Masukkan serai dan daun salam. Tumis sebentar. Masukkan air,air asam jawa,,garam,gula putih,kaldu bubuk,gula merah. Aduk hingga mendidih. Masukkan ayam dan kecap. Ungkep ayam sampai empuk. Jangan sampai air ungkepannya kering,sisakan sedikit saja,karena air ungkepan ini akan digunakan untuk bumbu oles ayam pada waktu membakar."
- "Siapkan teflon untuk membakar. Saya tidak menambahkan/mengoles minyak pada teflon,karena dari ayam akan keluar minyak sendiri. Setelah teflon panas,bakar ayam hingga gosong-gosong sedikit sesuai selera saja. Gak usah lama,karena pada dasarnya ayam sudah matang ketika diungkep. Kita hanya mencari aroma dan visual ‘terbakar’ saja."
categories:
- Recipe
tags:
- sayap
- ayam
- bakar

katakunci: sayap ayam bakar 
nutrition: 158 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dessert

---


![Sayap ayam Bakar Kecap](https://img-global.cpcdn.com/recipes/e91c6eb4dd37c631/751x532cq70/sayap-ayam-bakar-kecap-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga gurih. Ciri khas makanan Nusantara sayap ayam bakar kecap yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Sayap ayam Bakar Kecap untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang bisa anda buat salah satunya sayap ayam bakar kecap yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep sayap ayam bakar kecap tanpa harus bersusah payah.
Seperti resep Sayap ayam Bakar Kecap yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sayap ayam Bakar Kecap:

1. Dibutuhkan 1 kg sayap ayam (9 potong)
1. Tambah 2-4 sdm air asam jawa (tergantung selera)
1. Dibutuhkan 2 potong serai (geprak)
1. Diperlukan 5 lbr daun salam
1. Dibutuhkan 1 sdm garam (bisa kurang/lebih)
1. Harus ada 1 sdm gula putih
1. Tambah 1 sdm gula merah
1. Jangan lupa 10 sdm kecap manis
1. Harap siapkan 1 sdm kaldu bubuk
1. Diperlukan 2 sdm air jeruk nipis
1. Harap siapkan 2 sdm minyak goreng
1. Siapkan 400 ml air
1. Diperlukan  Bumbu halus
1. Harap siapkan 8 siung bawang merah
1. Dibutuhkan 3 siung bawang putih
1. Harap siapkan 5 cm lengkuas
1. Siapkan 1/2 sdt ketumbar
1. Harus ada 1 ruas kunyit (2 sdm kunyit bubuk)
1. Dibutuhkan 2-3 cm jahe




<!--inarticleads2-->

##### Cara membuat  Sayap ayam Bakar Kecap:

1. Bersihkan ayam. Balur dengan air jeruk nipis. Diamkan 15 menit. Setelah 15 menit, cuci kembali ayam. Ayam siap digunakan.
1. Siapkan bumbu2. Tumis bumbu halus sampai bau bawang mentah hilang. Masukkan serai dan daun salam. Tumis sebentar. Masukkan air,air asam jawa,,garam,gula putih,kaldu bubuk,gula merah. Aduk hingga mendidih. Masukkan ayam dan kecap. Ungkep ayam sampai empuk. Jangan sampai air ungkepannya kering,sisakan sedikit saja,karena air ungkepan ini akan digunakan untuk bumbu oles ayam pada waktu membakar.
1. Siapkan teflon untuk membakar. Saya tidak menambahkan/mengoles minyak pada teflon,karena dari ayam akan keluar minyak sendiri. Setelah teflon panas,bakar ayam hingga gosong-gosong sedikit sesuai selera saja. Gak usah lama,karena pada dasarnya ayam sudah matang ketika diungkep. Kita hanya mencari aroma dan visual ‘terbakar’ saja.




Demikianlah cara membuat sayap ayam bakar kecap yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan cepat, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
