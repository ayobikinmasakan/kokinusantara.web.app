---
description: "Steps untuk membuat Ayam Geprek Sambal Bawang teraktual"
title: "Steps untuk membuat Ayam Geprek Sambal Bawang teraktual"
slug: 4-steps-untuk-membuat-ayam-geprek-sambal-bawang-teraktual
date: 2020-11-02T01:04:36.930Z
image: https://img-global.cpcdn.com/recipes/c7dd555f9d2a4fd8/751x532cq70/ayam-geprek-sambal-bawang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c7dd555f9d2a4fd8/751x532cq70/ayam-geprek-sambal-bawang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c7dd555f9d2a4fd8/751x532cq70/ayam-geprek-sambal-bawang-foto-resep-utama.jpg
author: Cornelia Alvarado
ratingvalue: 4
reviewcount: 40071
recipeingredient:
- " ayam tepung"
- "300 gr paha ayam fillet"
- "2 siung bawang putih"
- "1/2 sdm garam"
- "1/4 sdt lada"
- "6 sdm tepung terigu  sedikit garam"
- "2 sdm tepung maizena"
- " sambal bawang"
- "200 gr cabe rawit"
- "6 siung bawang putih"
- "5 lembar daun jeruk"
- "1/2 sdt garam"
- "1/4 sdt kaldu jamur  sesuai selera"
- " Minyak goreng"
recipeinstructions:
- "Biasanya sy selalu marinasi ayam dr malam hari utk diolah esok harinya. Paha ayam fillet sy potong seukuran karage, kemudian marinasi dengan bawang putih, garam, lada + sedikit air. Diamkan semalaman. (Atau 1 jam jg cukup)."
- "Pertama buat sambal dulu. Cabe rawit dan bawang putih saya potong2 dgn bantuan chopper. Kl mau diuleg jg boleh. Kemudian masukkan garam dan kaldu jamur/ penyedap. Lalu masukkan irisan daun jeruk. Aduk2 rata kemudian sisihkan dulu."
- "Balur potongan ayam yg sudah dimarinasi dgn duo tepung. Seperti biasa bikin adonan basah &amp; adonan kering. Tepung kering-basah-lalu kering. Dan goreng dalam minyak panas sampai matang. (Bisa juga pakai tepung bumbu siap pakai)"
- "Setelah selesai menggoreng ayam, tuangkan beberapa sendok minyak panas dalam sambal yg sudah dibuat tadi. Aduk2 rata lalu tes rasa."
- "Geprek ayam kemudian susun di piring. Sajikan dengan sambal bawangnya. Ini simple banget tapi rasanya juara."
- "Sambal lebihnya bisa buat makan kloter berikutnya."
categories:
- Recipe
tags:
- ayam
- geprek
- sambal

katakunci: ayam geprek sambal 
nutrition: 175 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Geprek Sambal Bawang](https://img-global.cpcdn.com/recipes/c7dd555f9d2a4fd8/751x532cq70/ayam-geprek-sambal-bawang-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam geprek sambal bawang yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Indonesia



Keharmonisan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam Geprek Sambal Bawang untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang dapat anda buat salah satunya ayam geprek sambal bawang yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep ayam geprek sambal bawang tanpa harus bersusah payah.
Seperti resep Ayam Geprek Sambal Bawang yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 14 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Sambal Bawang:

1. Harap siapkan  🍳ayam tepung;
1. Jangan lupa 300 gr paha ayam fillet
1. Harap siapkan 2 siung bawang putih
1. Diperlukan 1/2 sdm garam
1. Diperlukan 1/4 sdt lada
1. Tambah 6 sdm tepung terigu + sedikit garam
1. Diperlukan 2 sdm tepung maizena
1. Harus ada  🍳sambal bawang;
1. Jangan lupa 200 gr cabe rawit
1. Diperlukan 6 siung bawang putih
1. Jangan lupa 5 lembar daun jeruk
1. Diperlukan 1/2 sdt garam
1. Harap siapkan 1/4 sdt kaldu jamur / sesuai selera
1. Harus ada  Minyak goreng




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek Sambal Bawang:

1. Biasanya sy selalu marinasi ayam dr malam hari utk diolah esok harinya. Paha ayam fillet sy potong seukuran karage, kemudian marinasi dengan bawang putih, garam, lada + sedikit air. Diamkan semalaman. (Atau 1 jam jg cukup).
1. Pertama buat sambal dulu. Cabe rawit dan bawang putih saya potong2 dgn bantuan chopper. Kl mau diuleg jg boleh. Kemudian masukkan garam dan kaldu jamur/ penyedap. Lalu masukkan irisan daun jeruk. Aduk2 rata kemudian sisihkan dulu.
1. Balur potongan ayam yg sudah dimarinasi dgn duo tepung. Seperti biasa bikin adonan basah &amp; adonan kering. Tepung kering-basah-lalu kering. Dan goreng dalam minyak panas sampai matang. (Bisa juga pakai tepung bumbu siap pakai)
1. Setelah selesai menggoreng ayam, tuangkan beberapa sendok minyak panas dalam sambal yg sudah dibuat tadi. Aduk2 rata lalu tes rasa.
1. Geprek ayam kemudian susun di piring. Sajikan dengan sambal bawangnya. Ini simple banget tapi rasanya juara.
1. Sambal lebihnya bisa buat makan kloter berikutnya.




Demikianlah cara membuat ayam geprek sambal bawang yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan teruji, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
