---
description: "Resep : Ayam Geprek simpel Luar biasa"
title: "Resep : Ayam Geprek simpel Luar biasa"
slug: 50-resep-ayam-geprek-simpel-luar-biasa
date: 2020-08-26T23:51:17.097Z
image: https://img-global.cpcdn.com/recipes/d8e24d4e7902e6e5/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d8e24d4e7902e6e5/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d8e24d4e7902e6e5/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg
author: Jesse Swanson
ratingvalue: 5
reviewcount: 12663
recipeingredient:
- "4 potong ayam"
- "5 sdm tepung bumbu ayam krispiaq pake adonan basah aja"
- "secukupnya Air mineral"
- " Minyak goreng"
- " Bumbu halus"
- "5 siung bawang putih"
- "15 biji cabe rawit aq sukanya pedas"
- "secukupnya Garam"
- "Sejumput gula antara jari telunjuk dan jempol"
recipeinstructions:
- "Pertama cairkan tepung bumbu dengan air mineral.. Jgan terlalu encer ya...(klo aq sukanya yg kental)"
- "Panaskan minyak... (aq pakenya lumayan biar ayamnya tenggelam jdi hasilnya lebih crispy)"
- "Lalu celupkan potongan ayam kedalam adonan tepung.. Baru masukkan kewajan yg berisi minyak panas..."
- "Sambil nunggu ayamnya kita ulek bawang putih,cabe rawit, garam dan gula... Lalu beri secukupnya minyak panas yg digunakan untuk goreng ayamnya..."
- "Lalu jika ayamnya sudah matang.. Masukkan keulekan.. Lalu geprek dan aduk bersama bumbu halusnya.."
- "Siap disajikan &amp; dinikmati bersama selada &amp; mentimun lebih nikmat"
categories:
- Recipe
tags:
- ayam
- geprek
- simpel

katakunci: ayam geprek simpel 
nutrition: 211 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Geprek simpel](https://img-global.cpcdn.com/recipes/d8e24d4e7902e6e5/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan renyah. Karasteristik kuliner Indonesia ayam geprek simpel yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Geprek simpel untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang dapat anda praktekkan salah satunya ayam geprek simpel yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam geprek simpel tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek simpel yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek simpel:

1. Diperlukan 4 potong ayam
1. Harap siapkan 5 sdm tepung bumbu ayam krispi...(aq pake adonan basah aja)
1. Tambah secukupnya Air mineral
1. Diperlukan  Minyak goreng
1. Diperlukan  Bumbu halus:
1. Siapkan 5 siung bawang putih
1. Jangan lupa 15 biji cabe rawit (aq sukanya pedas)
1. Jangan lupa secukupnya Garam
1. Dibutuhkan Sejumput gula (antara jari telunjuk dan jempol)




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek simpel:

1. Pertama cairkan tepung bumbu dengan air mineral.. Jgan terlalu encer ya...(klo aq sukanya yg kental)
1. Panaskan minyak... (aq pakenya lumayan biar ayamnya tenggelam jdi hasilnya lebih crispy)
1. Lalu celupkan potongan ayam kedalam adonan tepung.. Baru masukkan kewajan yg berisi minyak panas...
1. Sambil nunggu ayamnya kita ulek bawang putih,cabe rawit, garam dan gula... Lalu beri secukupnya minyak panas yg digunakan untuk goreng ayamnya...
1. Lalu jika ayamnya sudah matang.. Masukkan keulekan.. Lalu geprek dan aduk bersama bumbu halusnya..
1. Siap disajikan &amp; dinikmati bersama selada &amp; mentimun lebih nikmat




Demikianlah cara membuat ayam geprek simpel yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
