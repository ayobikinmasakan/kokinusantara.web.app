---
description: "Langkah untuk membuat Simple Ayam Geprek Luar biasa"
title: "Langkah untuk membuat Simple Ayam Geprek Luar biasa"
slug: 78-langkah-untuk-membuat-simple-ayam-geprek-luar-biasa
date: 2020-12-09T18:49:52.371Z
image: https://img-global.cpcdn.com/recipes/4fa38d74dbb5dbc2/751x532cq70/simple-ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4fa38d74dbb5dbc2/751x532cq70/simple-ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4fa38d74dbb5dbc2/751x532cq70/simple-ayam-geprek-foto-resep-utama.jpg
author: Alan Montgomery
ratingvalue: 4.1
reviewcount: 42694
recipeingredient:
- "2 buah dada ayam fillet"
- "1 butir jeruk nipis"
- "Sedikit garam"
- " Adonan Basah"
- "2 butir telur"
- "6 sdm tepung terigu"
- "1 siung bawang putih ulek"
- "1/4 sdt lada putih"
- "2 block maggie kaldu ayam"
- " Adonan Kering"
- "8 sdm tepung terigu aku pakai cakra kembar"
- "2 sdm tepung maizena"
- "1/2 sdt baking powder"
- "1 block maggie kaldu ayam"
- "1/2 sdt garam"
- " Sambal Geprek"
- "20 buah cabe rawit"
- "3 buah cabe merah besar"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1 block maggie kaldu ayam"
- "1 sdm gula pasir"
- "100 cc air matang"
recipeinstructions:
- "Siapkan bahan, cuci bersih ayam lalu bagi menjadi 2 bagian. Marinasi dengan air jeruk nipis dan sedikit garam selama 15 menit, kemudian cuci kembali ayam dengan air. Aduk jadi satu adonan basah. Aduk adonan kering di tempat berbeda."
- "Masukkan ayam kedalam adonan basah, ratakan. Lalu masukkan ke dalam adonan kering. Ulangi proses hingga 2-3 kali hingga lapisan tepung tebal. Lalu goreng ayam dengan api kecil, hingga keemasan. Tiriskan."
- "Untuk sambal gepreknya, cincang halus bawang merah dan bawang putih, lalu tumis dengan sedikit minyak goreng."
- "Ulek cabe rawit dan cabe merah, kemudian campurkan dengan tumisan bawang merah dan putih. Ulek semua bahan, tambahkan gula dan maggie block."
- "Tumis sambal dengan sedikit minyak goreng, tambahkan air 100 cc, aduk hingga air menyusut."
- "Geprek ayam goreng lalu oleskan sambal geprek diatasnya. Sajikan dengan timun atau kemangi."
categories:
- Recipe
tags:
- simple
- ayam
- geprek

katakunci: simple ayam geprek 
nutrition: 174 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Lunch

---


![Simple Ayam Geprek](https://img-global.cpcdn.com/recipes/4fa38d74dbb5dbc2/751x532cq70/simple-ayam-geprek-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita jaga karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti simple ayam geprek yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa ciri khas yang merupakan keragaman Nusantara



Kedekatan keluarga bisa didapat dengan cara simple. Diantaranya adalah membuat makanan Simple Ayam Geprek untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang dapat anda contoh salah satunya simple ayam geprek yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep simple ayam geprek tanpa harus bersusah payah.
Seperti resep Simple Ayam Geprek yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 23 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Simple Ayam Geprek:

1. Harus ada 2 buah dada ayam fillet
1. Diperlukan 1 butir jeruk nipis
1. Tambah Sedikit garam
1. Jangan lupa  Adonan Basah
1. Harap siapkan 2 butir telur
1. Harus ada 6 sdm tepung terigu
1. Harap siapkan 1 siung bawang putih (ulek)
1. Dibutuhkan 1/4 sdt lada putih
1. Jangan lupa 2 block maggie kaldu ayam
1. Jangan lupa  Adonan Kering
1. Harap siapkan 8 sdm tepung terigu (aku pakai cakra kembar)
1. Siapkan 2 sdm tepung maizena
1. Tambah 1/2 sdt baking powder
1. Tambah 1 block maggie kaldu ayam
1. Dibutuhkan 1/2 sdt garam
1. Harus ada  Sambal Geprek
1. Dibutuhkan 20 buah cabe rawit
1. Dibutuhkan 3 buah cabe merah besar
1. Tambah 5 siung bawang merah
1. Diperlukan 3 siung bawang putih
1. Dibutuhkan 1 block maggie kaldu ayam
1. Dibutuhkan 1 sdm gula pasir
1. Diperlukan 100 cc air matang




<!--inarticleads2-->

##### Bagaimana membuat  Simple Ayam Geprek:

1. Siapkan bahan, cuci bersih ayam lalu bagi menjadi 2 bagian. Marinasi dengan air jeruk nipis dan sedikit garam selama 15 menit, kemudian cuci kembali ayam dengan air. Aduk jadi satu adonan basah. Aduk adonan kering di tempat berbeda.
1. Masukkan ayam kedalam adonan basah, ratakan. Lalu masukkan ke dalam adonan kering. Ulangi proses hingga 2-3 kali hingga lapisan tepung tebal. Lalu goreng ayam dengan api kecil, hingga keemasan. Tiriskan.
1. Untuk sambal gepreknya, cincang halus bawang merah dan bawang putih, lalu tumis dengan sedikit minyak goreng.
1. Ulek cabe rawit dan cabe merah, kemudian campurkan dengan tumisan bawang merah dan putih. Ulek semua bahan, tambahkan gula dan maggie block.
1. Tumis sambal dengan sedikit minyak goreng, tambahkan air 100 cc, aduk hingga air menyusut.
1. Geprek ayam goreng lalu oleskan sambal geprek diatasnya. Sajikan dengan timun atau kemangi.




Demikianlah cara membuat simple ayam geprek yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
