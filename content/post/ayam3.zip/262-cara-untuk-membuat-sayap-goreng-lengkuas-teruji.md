---
description: "Cara untuk membuat Sayap goreng lengkuas Teruji"
title: "Cara untuk membuat Sayap goreng lengkuas Teruji"
slug: 262-cara-untuk-membuat-sayap-goreng-lengkuas-teruji
date: 2020-10-05T09:22:36.520Z
image: https://img-global.cpcdn.com/recipes/4c63876911f80444/751x532cq70/sayap-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4c63876911f80444/751x532cq70/sayap-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4c63876911f80444/751x532cq70/sayap-goreng-lengkuas-foto-resep-utama.jpg
author: Owen Bryant
ratingvalue: 4.6
reviewcount: 30534
recipeingredient:
- "1/2 kg sayap ayam"
- " Bumbu ungkep"
- "3 siung bawang putih"
- "3 siung bawang merah"
- "2 butir kemiri"
- "secukupnya Ketumbar"
- "1 ruas jahe"
- "1 ruas kunyit"
- "2 cm kencur"
- "secukupnya Lada"
- " Sangrai semua bumbu mentah kemudian dihaluskan"
- " Daun salam dan 2cm lengkuas utuh untuk bumbu ungkep"
- " Bumbu lengkuas"
- "2 bongkol lengkuas atau 200gr lengkuas diparut"
- "8 siung bawang putih"
- "6 siung bawang merah"
- "2 butir kemiri"
- "1 cm jahe"
- "2 cm kunyit"
- " Penyedap rasa dan garam secukupnya sesuai selera "
recipeinstructions:
- "Tips memasak ayam boiler : rebus ayam yang sudah di cuci bersih hingga mendidih. Setelah itu buang airnya dan cuci dengan air mengalir. Lalu rebus lagi ayam nya hingga mendidih dan buang lagi airnya dan cuci lagi dengan air mengalir. (Merebus ayam tanpa bumbu ini dilakukan 2x untuk menghilangkan bau tidak sedap pada ayam)"
- "Masukkan bumbu ungkep yang sudah dihaluskan dan beri air secukupnya. Masak dengan sistem 7-30-5 (masak 7 menit- matikan kompor - diamkan dalam keadaan tertutup selama 30 menit - kemudian masak lagi selama 5 menit) metode ini agar ayam yang diungkep empuk dan matang sampai daging bagian dalam."
- "Haluskan bumbu lengkuas dan parut lengkuasnya. Setelah itu campur bumbu dengan lengkuas."
- "Ayam yang sudah selesai diungkep, di goreng hingga garing (biar krispi pas dimakan) 😁🥰"
- "Setelah semua ayam di goreng, tumis bumbu lengkuas dan masak hingga kering atau kecoklatan. Jangan lupa tambahkan penyedap rasa dan garam secukupnya. Setelah bumbu kering, tuang bumbu ke atas ayam yg sudah di goreng. Dan voila...sayap goreng lengkuas siap di makan dengan nasi anget 😊😘🥰. Selamat mencoba bunda 😊"
categories:
- Recipe
tags:
- sayap
- goreng
- lengkuas

katakunci: sayap goreng lengkuas 
nutrition: 222 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dinner

---


![Sayap goreng lengkuas](https://img-global.cpcdn.com/recipes/4c63876911f80444/751x532cq70/sayap-goreng-lengkuas-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti sayap goreng lengkuas yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Kita



Kehangatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Sayap goreng lengkuas untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang dapat anda coba salah satunya sayap goreng lengkuas yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep sayap goreng lengkuas tanpa harus bersusah payah.
Seperti resep Sayap goreng lengkuas yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sayap goreng lengkuas:

1. Tambah 1/2 kg sayap ayam
1. Harap siapkan  Bumbu ungkep
1. Dibutuhkan 3 siung bawang putih
1. Diperlukan 3 siung bawang merah
1. Dibutuhkan 2 butir kemiri
1. Dibutuhkan secukupnya Ketumbar
1. Harus ada 1 ruas jahe
1. Diperlukan 1 ruas kunyit
1. Siapkan 2 cm kencur
1. Dibutuhkan secukupnya Lada
1. Harus ada  Sangrai semua bumbu mentah kemudian dihaluskan
1. Dibutuhkan  Daun salam dan 2cm lengkuas utuh untuk bumbu ungkep
1. Diperlukan  Bumbu lengkuas
1. Jangan lupa 2 bongkol lengkuas atau 200gr lengkuas diparut
1. Jangan lupa 8 siung bawang putih
1. Siapkan 6 siung bawang merah
1. Harap siapkan 2 butir kemiri
1. Diperlukan 1 cm jahe
1. Harus ada 2 cm kunyit
1. Dibutuhkan  Penyedap rasa dan garam secukupnya sesuai selera 😊




<!--inarticleads2-->

##### Cara membuat  Sayap goreng lengkuas:

1. Tips memasak ayam boiler : rebus ayam yang sudah di cuci bersih hingga mendidih. Setelah itu buang airnya dan cuci dengan air mengalir. Lalu rebus lagi ayam nya hingga mendidih dan buang lagi airnya dan cuci lagi dengan air mengalir. (Merebus ayam tanpa bumbu ini dilakukan 2x untuk menghilangkan bau tidak sedap pada ayam)
1. Masukkan bumbu ungkep yang sudah dihaluskan dan beri air secukupnya. Masak dengan sistem 7-30-5 (masak 7 menit- matikan kompor - diamkan dalam keadaan tertutup selama 30 menit - kemudian masak lagi selama 5 menit) metode ini agar ayam yang diungkep empuk dan matang sampai daging bagian dalam.
1. Haluskan bumbu lengkuas dan parut lengkuasnya. Setelah itu campur bumbu dengan lengkuas.
1. Ayam yang sudah selesai diungkep, di goreng hingga garing (biar krispi pas dimakan) 😁🥰
1. Setelah semua ayam di goreng, tumis bumbu lengkuas dan masak hingga kering atau kecoklatan. Jangan lupa tambahkan penyedap rasa dan garam secukupnya. Setelah bumbu kering, tuang bumbu ke atas ayam yg sudah di goreng. Dan voila...sayap goreng lengkuas siap di makan dengan nasi anget 😊😘🥰. Selamat mencoba bunda 😊




Demikianlah cara membuat sayap goreng lengkuas yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
