---
description: "Panduan untuk membuat Sayap Ayam Asam Manis, Awet crispy nya Luar biasa"
title: "Panduan untuk membuat Sayap Ayam Asam Manis, Awet crispy nya Luar biasa"
slug: 324-panduan-untuk-membuat-sayap-ayam-asam-manis-awet-crispy-nya-luar-biasa
date: 2020-09-19T22:50:08.803Z
image: https://img-global.cpcdn.com/recipes/b6454029391fe6a3/751x532cq70/sayap-ayam-asam-manis-awet-crispy-nya-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b6454029391fe6a3/751x532cq70/sayap-ayam-asam-manis-awet-crispy-nya-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b6454029391fe6a3/751x532cq70/sayap-ayam-asam-manis-awet-crispy-nya-foto-resep-utama.jpg
author: Alma Strickland
ratingvalue: 4.1
reviewcount: 20563
recipeingredient:
- "8 buah sayap ayam potong 2 bagian"
- "100 gram tepung terigu"
- " Bahan marinasi "
- "1/2 sendok teh air jeruk nipis"
- "1/2 sendok teh garam"
- "1/2 sendok teh merica bubuk"
- "2 siung bawang putih parut"
- "500 gram minyak untuk menggoreng"
- " Bahan saus"
- "2 siung bawang putih dicincang kasar"
- "1/2 buah bawang bombai cincang halus"
- "1 cm jahe parut"
- "1 sendok makan kecap manis"
- "1 sendok makan saus tiram"
- "50 gram saus tomat"
- "1 sendok makan saus sambal saya skip"
- "1/4 sendok teh garam"
- "1/4 sendok teh merica bubuk"
- "1 sendok teh gula pasir"
- "2 sendok makan minyak untuk menumis"
recipeinstructions:
- "Potong sayap ayam menjadi 2 bagian, tujuannya supaya ayam lebih crispy dan proses marinasi cepat meresap. Marinasi sayap ayam selama 30 menit dengan campuran air jeruk nipis, garam, merica bubuk, dan bawang putih. Lalu baluri dengan terigu, tepuk2 ayam untuk membuang kelebihan sisa tepung"
- "Gunakan api sedang, goreng sayap sampai matang Angkat dan tiriskan."
- "Panaskan minyak goreng kembali dengan api yang lebih panas, goreng ayam sapai kecoklatan dan crispy, angkat dan tiriskan"
- "Panaskan wajan dan masukkan minyak untuk menumis. Tumis bawang putih, bawang bombai, dan jahe sampai harum."
- "Tambahkan kecap manis, saus tiram, saus tomat, dan saus sambal. Aduk rata. Lalu tambahkan rasa dari garam, merica bubuk, dan gula pasir. Cicipi, rasanya manis pedas, dan masak sampai saus mengental."
- "Masukkan sayap goreng. Aduk sampai saus menyelimuti sayap."
- "Sajikan dg peresan jeruk limo"
categories:
- Recipe
tags:
- sayap
- ayam
- asam

katakunci: sayap ayam asam 
nutrition: 120 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Dinner

---


![Sayap Ayam Asam Manis, Awet crispy nya](https://img-global.cpcdn.com/recipes/b6454029391fe6a3/751x532cq70/sayap-ayam-asam-manis-awet-crispy-nya-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti sayap ayam asam manis, awet crispy nya yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia

Keharmonisan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Sayap Ayam Asam Manis, Awet crispy nya untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda coba salah satunya sayap ayam asam manis, awet crispy nya yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep sayap ayam asam manis, awet crispy nya tanpa harus bersusah payah.
Berikut ini resep Sayap Ayam Asam Manis, Awet crispy nya yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sayap Ayam Asam Manis, Awet crispy nya:

1. Siapkan 8 buah sayap ayam potong 2 bagian
1. Jangan lupa 100 gram tepung terigu
1. Jangan lupa  Bahan marinasi :
1. Diperlukan 1/2 sendok teh air jeruk nipis
1. Jangan lupa 1/2 sendok teh garam
1. Tambah 1/2 sendok teh merica bubuk
1. Tambah 2 siung bawang putih parut
1. Diperlukan 500 gram minyak untuk menggoreng
1. Jangan lupa  Bahan saus:
1. Siapkan 2 siung bawang putih dicincang kasar
1. Tambah 1/2 buah bawang bombai cincang halus
1. Siapkan 1 cm jahe parut
1. Dibutuhkan 1 sendok makan kecap manis
1. Diperlukan 1 sendok makan saus tiram
1. Harus ada 50 gram saus tomat
1. Diperlukan 1 sendok makan saus sambal (saya skip)
1. Jangan lupa 1/4 sendok teh garam
1. Diperlukan 1/4 sendok teh merica bubuk
1. Siapkan 1 sendok teh gula pasir
1. Harap siapkan 2 sendok makan minyak untuk menumis




<!--inarticleads2-->

##### Cara membuat  Sayap Ayam Asam Manis, Awet crispy nya:

1. Potong sayap ayam menjadi 2 bagian, tujuannya supaya ayam lebih crispy dan proses marinasi cepat meresap. Marinasi sayap ayam selama 30 menit dengan campuran air jeruk nipis, garam, merica bubuk, dan bawang putih. Lalu baluri dengan terigu, tepuk2 ayam untuk membuang kelebihan sisa tepung
1. Gunakan api sedang, goreng sayap sampai matang Angkat dan tiriskan.
1. Panaskan minyak goreng kembali dengan api yang lebih panas, goreng ayam sapai kecoklatan dan crispy, angkat dan tiriskan
1. Panaskan wajan dan masukkan minyak untuk menumis. Tumis bawang putih, bawang bombai, dan jahe sampai harum.
1. Tambahkan kecap manis, saus tiram, saus tomat, dan saus sambal. Aduk rata. - Lalu tambahkan rasa dari garam, merica bubuk, dan gula pasir. Cicipi, rasanya manis pedas, dan masak sampai saus mengental.
1. Masukkan sayap goreng. Aduk sampai saus menyelimuti sayap.
1. Sajikan dg peresan jeruk limo




Demikianlah cara membuat sayap ayam asam manis, awet crispy nya yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan cepat, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
