---
description: "Resep : Kepala Ayam Gepuk dan Sambal Hejo teraktual"
title: "Resep : Kepala Ayam Gepuk dan Sambal Hejo teraktual"
slug: 234-resep-kepala-ayam-gepuk-dan-sambal-hejo-teraktual
date: 2020-09-12T07:34:22.699Z
image: https://img-global.cpcdn.com/recipes/6e01ea401b658705/751x532cq70/kepala-ayam-gepuk-dan-sambal-hejo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6e01ea401b658705/751x532cq70/kepala-ayam-gepuk-dan-sambal-hejo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6e01ea401b658705/751x532cq70/kepala-ayam-gepuk-dan-sambal-hejo-foto-resep-utama.jpg
author: Gilbert Copeland
ratingvalue: 4.1
reviewcount: 11306
recipeingredient:
- "1 kg ayam kepala ayam dan paha ayam"
- "200 ml air"
- "2 lembar daun salam"
- "2 cm lengkuas geprek"
- " Bumbu Halus"
- "3 cm kunyit bakar"
- "5 butir bawang merah"
- "3 siung bawang putih"
- "2 butir kemiri sangrai"
- "1/2 sdt ketumbar sangrai"
- "1 cm jahe"
- "1 sdt kaldu ayam"
- "Secukupnya garam"
- "1/2 sdt gula pasir"
- "Sedikit kaldu bubuk jika suka"
- " Bahan Sambal Hejo"
- "7 buah cabai hijau keriting"
- "7 buah cabai rawit hijau"
- "4 butir bawang merah"
- " Bahan Pencelup"
- "Secukupnya maizena"
- "Secukupnya air sisa merebus ayam"
recipeinstructions:
- "Campur air, bumbu halus, ayam, daun salam dan laos. Ungkep dengan api kecil hingga bumbu meresap dan air menyusut. (Panci untuk mengungkep ayam ditutup ya)"
- "Setelah air mulai menyusut, matikan api lalu biarkan agak dingin. Tiriskan ayam."
- "Gepuk ayam dengan ulekan hingga pipih setulang-tulangnya."
- "Campur dan aduk rata bahan pencelup hingga agak encer. (Kemarin saya tambahin sedikit air matang)"
- "Celupkan ayam yang telah digepuk ke dalam bahan pencelup lalu goreng hingga matang. Angkat tiriskan"
- "Untuk sambalnya. Rebus atau kukus cabe dan bawang merah. Angkat dan tiriskan. Uleg kasar lalu tambahkan gula pasir, garam, dan kaldu bubuk. Tumis/gongseng sebentar dengan minyak bekas menggoreng ayam. Angkat. Sambal siap disajikan."
- "Kepala ayam gepuk dan sambal hejo siap disajikan. Ayamnya kriuk garing diluar tapi empuk dalamnya. Daging yang ada di bagian leher juga jadi mudah lepas karena udah digepuk. Enak. (Ini gambar ayamnya agak kelamaan gorengnya, tapi gak yg gosong bgt, disambi-sambi sih. Yang hasil gorengnya cantik udah keburu dimakan dengan nasi hangat.hehe)"
categories:
- Recipe
tags:
- kepala
- ayam
- gepuk

katakunci: kepala ayam gepuk 
nutrition: 128 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Dinner

---


![Kepala Ayam Gepuk dan Sambal Hejo](https://img-global.cpcdn.com/recipes/6e01ea401b658705/751x532cq70/kepala-ayam-gepuk-dan-sambal-hejo-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan renyah. Ciri masakan Nusantara kepala ayam gepuk dan sambal hejo yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Kepala Ayam Gepuk dan Sambal Hejo untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda praktekkan salah satunya kepala ayam gepuk dan sambal hejo yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep kepala ayam gepuk dan sambal hejo tanpa harus bersusah payah.
Berikut ini resep Kepala Ayam Gepuk dan Sambal Hejo yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Kepala Ayam Gepuk dan Sambal Hejo:

1. Dibutuhkan 1 kg ayam (kepala ayam dan paha ayam)
1. Harap siapkan 200 ml air
1. Harap siapkan 2 lembar daun salam
1. Dibutuhkan 2 cm lengkuas, geprek
1. Harus ada  Bumbu Halus:
1. Harap siapkan 3 cm kunyit bakar
1. Dibutuhkan 5 butir bawang merah
1. Dibutuhkan 3 siung bawang putih
1. Dibutuhkan 2 butir kemiri sangrai
1. Harap siapkan 1/2 sdt ketumbar, sangrai
1. Siapkan 1 cm jahe
1. Jangan lupa 1 sdt kaldu ayam
1. Harus ada Secukupnya garam
1. Diperlukan 1/2 sdt gula pasir
1. Siapkan Sedikit kaldu bubuk jika suka
1. Siapkan  Bahan Sambal Hejo:
1. Harus ada 7 buah cabai hijau keriting
1. Siapkan 7 buah cabai rawit hijau
1. Harus ada 4 butir bawang merah
1. Jangan lupa  Bahan Pencelup:
1. Harus ada Secukupnya maizena
1. Dibutuhkan Secukupnya air sisa merebus ayam




<!--inarticleads2-->

##### Bagaimana membuat  Kepala Ayam Gepuk dan Sambal Hejo:

1. Campur air, bumbu halus, ayam, daun salam dan laos. Ungkep dengan api kecil hingga bumbu meresap dan air menyusut. (Panci untuk mengungkep ayam ditutup ya)
1. Setelah air mulai menyusut, matikan api lalu biarkan agak dingin. Tiriskan ayam.
1. Gepuk ayam dengan ulekan hingga pipih setulang-tulangnya.
1. Campur dan aduk rata bahan pencelup hingga agak encer. (Kemarin saya tambahin sedikit air matang)
1. Celupkan ayam yang telah digepuk ke dalam bahan pencelup lalu goreng hingga matang. Angkat tiriskan
1. Untuk sambalnya. Rebus atau kukus cabe dan bawang merah. Angkat dan tiriskan. Uleg kasar lalu tambahkan gula pasir, garam, dan kaldu bubuk. Tumis/gongseng sebentar dengan minyak bekas menggoreng ayam. Angkat. Sambal siap disajikan.
1. Kepala ayam gepuk dan sambal hejo siap disajikan. Ayamnya kriuk garing diluar tapi empuk dalamnya. Daging yang ada di bagian leher juga jadi mudah lepas karena udah digepuk. Enak. (Ini gambar ayamnya agak kelamaan gorengnya, tapi gak yg gosong bgt, disambi-sambi sih. Yang hasil gorengnya cantik udah keburu dimakan dengan nasi hangat.hehe)




Demikianlah cara membuat kepala ayam gepuk dan sambal hejo yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan terbukti, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
