---
description: "Resep : Ayam geprek sambal matah sederhana Terbukti"
title: "Resep : Ayam geprek sambal matah sederhana Terbukti"
slug: 154-resep-ayam-geprek-sambal-matah-sederhana-terbukti
date: 2020-09-03T03:17:00.240Z
image: https://img-global.cpcdn.com/recipes/89ad304f2b17418e/751x532cq70/ayam-geprek-sambal-matah-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/89ad304f2b17418e/751x532cq70/ayam-geprek-sambal-matah-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/89ad304f2b17418e/751x532cq70/ayam-geprek-sambal-matah-sederhana-foto-resep-utama.jpg
author: Travis Cohen
ratingvalue: 4.5
reviewcount: 17304
recipeingredient:
- "1 kg ayam jadi 8 potong"
- "1 cabe merah"
- "4 siung bawang merah"
- "1 siung bawang putih"
- "5 lembar daun jeruk purut"
- "1 batang serai"
- "10 cabe rawit"
- "Seujung jari terasi matang"
- "1 kg tepung sasa kentucky"
- "1/4 sdt garam"
- "1/2 sdt vetsin"
- "1 sdt gula"
- "1 sdm air jeruk nipis"
- "1 sdm minyak panas"
- "4 telur ayam kocok lepas"
- " Minyak untuk menggoreng"
- " Bahan ungkep ayam"
- "2 sdm knor"
- "1 sdm ketumbar"
- "2 siung bawang putih"
- "1 liter air"
recipeinstructions:
- "Bersihkan ayam dan bahan2 yang perlu di cuci bersih."
- "Haluskan bahan2 ungkep lalu tumis sebentar dan tambah air, biarkan hingga mendidih dan masukkan ayam. Diamkan 45 menit. Setelah ayam matang,angkat dan tiriskan."
- "Setelah ayam dingin. Siapkan bumbu sasa kentucky. Masukkan ayam ke bumbu sasa kentucky sambil d tekan dan merata. Kemudian masukkan ke telur kocok. Lalu masukkan kembali ke tepung sasa kentucky. Goreng dengan minyak sedang sampai matang."
- "Slice cabe rawit, cabe merah, serai, daun jeruk purut,bawang merah, bawang putih. Campur semua dan tambahkan terasi matang,garam,gula,vetsin,air jeruk nipis,minyak panas. Aduk sampai merata."
- "Geprek ayam kemudian taruh sambal matah di atasnya. Tambahkan nasi,bawang merah goreng,mentimun dan tomat. Ayam geprek sambal matah sederhana siap disajikan. Selamat mencoba..."
categories:
- Recipe
tags:
- ayam
- geprek
- sambal

katakunci: ayam geprek sambal 
nutrition: 270 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam geprek sambal matah sederhana](https://img-global.cpcdn.com/recipes/89ad304f2b17418e/751x532cq70/ayam-geprek-sambal-matah-sederhana-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau enak. Ciri khas makanan Indonesia ayam geprek sambal matah sederhana yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam geprek sambal matah sederhana untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda contoh salah satunya ayam geprek sambal matah sederhana yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep ayam geprek sambal matah sederhana tanpa harus bersusah payah.
Berikut ini resep Ayam geprek sambal matah sederhana yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 21 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam geprek sambal matah sederhana:

1. Siapkan 1 kg ayam jadi 8 potong
1. Siapkan 1 cabe merah
1. Diperlukan 4 siung bawang merah
1. Harap siapkan 1 siung bawang putih
1. Harus ada 5 lembar daun jeruk purut
1. Jangan lupa 1 batang serai
1. Harap siapkan 10 cabe rawit
1. Dibutuhkan Seujung jari terasi matang
1. Siapkan 1 kg tepung sasa kentucky
1. Harus ada 1/4 sdt garam
1. Tambah 1/2 sdt vetsin
1. Tambah 1 sdt gula
1. Siapkan 1 sdm air jeruk nipis
1. Dibutuhkan 1 sdm minyak panas
1. Harap siapkan 4 telur ayam kocok lepas
1. Harap siapkan  Minyak untuk menggoreng
1. Siapkan  Bahan ungkep ayam
1. Tambah 2 sdm knor
1. Dibutuhkan 1 sdm ketumbar
1. Jangan lupa 2 siung bawang putih
1. Dibutuhkan 1 liter air




<!--inarticleads2-->

##### Cara membuat  Ayam geprek sambal matah sederhana:

1. Bersihkan ayam dan bahan2 yang perlu di cuci bersih.
1. Haluskan bahan2 ungkep lalu tumis sebentar dan tambah air, biarkan hingga mendidih dan masukkan ayam. Diamkan 45 menit. Setelah ayam matang,angkat dan tiriskan.
1. Setelah ayam dingin. Siapkan bumbu sasa kentucky. Masukkan ayam ke bumbu sasa kentucky sambil d tekan dan merata. Kemudian masukkan ke telur kocok. Lalu masukkan kembali ke tepung sasa kentucky. Goreng dengan minyak sedang sampai matang.
1. Slice cabe rawit, cabe merah, serai, daun jeruk purut,bawang merah, bawang putih. Campur semua dan tambahkan terasi matang,garam,gula,vetsin,air jeruk nipis,minyak panas. Aduk sampai merata.
1. Geprek ayam kemudian taruh sambal matah di atasnya. Tambahkan nasi,bawang merah goreng,mentimun dan tomat. Ayam geprek sambal matah sederhana siap disajikan. Selamat mencoba...




Demikianlah cara membuat ayam geprek sambal matah sederhana yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
