---
description: "Cara singkat membuat Ayam Rica diet tanpa minyak (210 kkal/porsi) terupdate"
title: "Cara singkat membuat Ayam Rica diet tanpa minyak (210 kkal/porsi) terupdate"
slug: 487-cara-singkat-membuat-ayam-rica-diet-tanpa-minyak-210-kkal-porsi-terupdate
date: 2020-11-28T13:19:53.998Z
image: https://img-global.cpcdn.com/recipes/ab2650ede9034ded/751x532cq70/ayam-rica-diet-tanpa-minyak-210-kkalporsi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ab2650ede9034ded/751x532cq70/ayam-rica-diet-tanpa-minyak-210-kkalporsi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ab2650ede9034ded/751x532cq70/ayam-rica-diet-tanpa-minyak-210-kkalporsi-foto-resep-utama.jpg
author: Jonathan Martin
ratingvalue: 4
reviewcount: 44058
recipeingredient:
- "200 gram ayam"
- "1 batang sereh geprek"
- "1 cm jahe geprek"
- "1 cm lengkuas geprek"
- "1 lembar daun salam"
- "1 lembar daun jeruk"
- "secukupnya Kemangi"
- "100 ml air"
- "secukupnya Garam kaldu jamur"
- " Bumbu Halus"
- "2 bawang merah"
- "1 bawang putih"
- "1/2 butir kemiri"
- "1 cm kunyit"
- "sesuai selera Cabe merah keriting"
- "sesuai selera Cabe rawit"
recipeinstructions:
- "Siap kan bahan2 dan bumbu halusnya"
- "Didihkan 100 ml air diatas teflon anti lengket (ini penting karena kita menumis nggak pake minyak),, lalu tumis bumbu halus, jahe, lengkuas, sereh, daun salam dan daun jeruk dengan air hingga bau langu nya hilang, harum dan air menyusut"
- "Setelah tumisan menjadi lebih harum dan airnya berkurang, masukkan ayam, tambahkan garam dan kaldu jamur..tumis2 hingga ayam matang (tidak saya tambah air..karena ayam juga akan mengeluarkan air)"
- "Jika ayam sudah matang, cicipi rasa..keluarkan sereh, jahe, lengkuas, daun salam dan daun jeruk (optional yah..supaya lebih mudah aja makannya..hehe) lalu masukkan daun kemangi, aduk2 dan sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- diet

katakunci: ayam rica diet 
nutrition: 285 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica diet tanpa minyak (210 kkal/porsi)](https://img-global.cpcdn.com/recipes/ab2650ede9034ded/751x532cq70/ayam-rica-diet-tanpa-minyak-210-kkalporsi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga gurih. Karasteristik kuliner Indonesia ayam rica diet tanpa minyak (210 kkal/porsi) yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Rica diet tanpa minyak (210 kkal/porsi) untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda coba salah satunya ayam rica diet tanpa minyak (210 kkal/porsi) yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam rica diet tanpa minyak (210 kkal/porsi) tanpa harus bersusah payah.
Seperti resep Ayam Rica diet tanpa minyak (210 kkal/porsi) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica diet tanpa minyak (210 kkal/porsi):

1. Dibutuhkan 200 gram ayam
1. Siapkan 1 batang sereh geprek
1. Dibutuhkan 1 cm jahe geprek
1. Siapkan 1 cm lengkuas geprek
1. Diperlukan 1 lembar daun salam
1. Dibutuhkan 1 lembar daun jeruk
1. Harap siapkan secukupnya Kemangi
1. Harus ada 100 ml air
1. Harap siapkan secukupnya Garam, kaldu jamur
1. Dibutuhkan  Bumbu Halus
1. Tambah 2 bawang merah
1. Siapkan 1 bawang putih
1. Harus ada 1/2 butir kemiri
1. Dibutuhkan 1 cm kunyit
1. Dibutuhkan sesuai selera Cabe merah keriting
1. Dibutuhkan sesuai selera Cabe rawit




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica diet tanpa minyak (210 kkal/porsi):

1. Siap kan bahan2 dan bumbu halusnya
1. Didihkan 100 ml air diatas teflon anti lengket (ini penting karena kita menumis nggak pake minyak),, lalu tumis bumbu halus, jahe, lengkuas, sereh, daun salam dan daun jeruk dengan air hingga bau langu nya hilang, harum dan air menyusut
1. Setelah tumisan menjadi lebih harum dan airnya berkurang, masukkan ayam, tambahkan garam dan kaldu jamur..tumis2 hingga ayam matang (tidak saya tambah air..karena ayam juga akan mengeluarkan air)
1. Jika ayam sudah matang, cicipi rasa..keluarkan sereh, jahe, lengkuas, daun salam dan daun jeruk (optional yah..supaya lebih mudah aja makannya..hehe) lalu masukkan daun kemangi, aduk2 dan sajikan




Demikianlah cara membuat ayam rica diet tanpa minyak (210 kkal/porsi) yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
