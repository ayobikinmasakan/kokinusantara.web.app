---
description: "Resep : Ayam geprek simple minggu ini"
title: "Resep : Ayam geprek simple minggu ini"
slug: 217-resep-ayam-geprek-simple-minggu-ini
date: 2020-12-10T22:17:13.556Z
image: https://img-global.cpcdn.com/recipes/355f70a55f3f4441/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/355f70a55f3f4441/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/355f70a55f3f4441/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
author: Bryan Hammond
ratingvalue: 4.1
reviewcount: 6041
recipeingredient:
- "1/2 ekor ayam saya pakai ayam potong 6"
- " Tepung bumbu sajiku merk lain boleh"
- "1 buah telur"
- " Sambal geprek"
- "15 cabe rawit banyaknya suka2 aja"
- "4 siung bawang merah"
- "2 siung bawang putih"
- "Secukupnya gula garam penyedap optional"
- "Secukupnya air untuk tepung bumbu basah"
recipeinstructions:
- "Cuci bersih ayam, siapkan tepung bumbu kering (4 sdm tepung bumbu sajiku) dan tepung bumbu basah (campuran secukupnya air, telur, 3 sdm tepung sajiku)"
- "Masukkan ayam dalam tepung bumbu kering lalu Rendam ayam dalam tepung basah selama kurleb 10 menit (kalo saya biar bumbu nya nyatu di ayamnya)"
- "Setelah di rendam masukkan lagi ayam ke tepung kering. Goreng sampai coklat keemasan"
- "Siapkan sambal. Ulek kasar semua bumbu sambal, tambahkan gula, garam, penyedap (optional) tes rasa."
- "Masukkan ayam dalam campuran sambal sambil diulek pelan. Bisa ditambah tahu, tempe atau terong goreng buat pelengkap."
categories:
- Recipe
tags:
- ayam
- geprek
- simple

katakunci: ayam geprek simple 
nutrition: 210 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam geprek simple](https://img-global.cpcdn.com/recipes/355f70a55f3f4441/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan empuk. Ciri khas masakan Indonesia ayam geprek simple yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kehangatan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah memasak Ayam geprek simple untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang dapat anda coba salah satunya ayam geprek simple yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam geprek simple tanpa harus bersusah payah.
Seperti resep Ayam geprek simple yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam geprek simple:

1. Harap siapkan 1/2 ekor ayam (saya pakai ayam potong 6)
1. Siapkan  Tepung bumbu sajiku (merk lain boleh)
1. Tambah 1 buah telur
1. Jangan lupa  Sambal geprek
1. Harap siapkan 15 cabe rawit (banyaknya suka2 aja)
1. Harus ada 4 siung bawang merah
1. Tambah 2 siung bawang putih
1. Diperlukan Secukupnya gula, garam, penyedap (optional)
1. Dibutuhkan Secukupnya air untuk tepung bumbu basah




<!--inarticleads2-->

##### Instruksi membuat  Ayam geprek simple:

1. Cuci bersih ayam, siapkan tepung bumbu kering (4 sdm tepung bumbu sajiku) dan tepung bumbu basah (campuran secukupnya air, telur, 3 sdm tepung sajiku)
1. Masukkan ayam dalam tepung bumbu kering lalu Rendam ayam dalam tepung basah selama kurleb 10 menit (kalo saya biar bumbu nya nyatu di ayamnya)
1. Setelah di rendam masukkan lagi ayam ke tepung kering. Goreng sampai coklat keemasan
1. Siapkan sambal. Ulek kasar semua bumbu sambal, tambahkan gula, garam, penyedap (optional) tes rasa.
1. Masukkan ayam dalam campuran sambal sambil diulek pelan. Bisa ditambah tahu, tempe atau terong goreng buat pelengkap.




Demikianlah cara membuat ayam geprek simple yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat gampang dan teruji, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
