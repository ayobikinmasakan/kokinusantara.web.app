---
description: "Cara membuat Ayam geprek simple teraktual"
title: "Cara membuat Ayam geprek simple teraktual"
slug: 153-cara-membuat-ayam-geprek-simple-teraktual
date: 2020-09-30T22:07:14.860Z
image: https://img-global.cpcdn.com/recipes/de3e2aeb577bf2b8/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/de3e2aeb577bf2b8/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/de3e2aeb577bf2b8/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
author: Ricardo Morrison
ratingvalue: 4.9
reviewcount: 23914
recipeingredient:
- "1/4 kg ayam"
- "5 sdm tepung terigu"
- "1 sdm maizena"
- "1 sdm tepung kobe pedas ambil sisa yang ada di dapur"
- "1 butir telur"
- " Bumbu halus marinasi ayam"
- "4 siung bawang putih"
- "1 sdt merica butiran"
- "1 sdt garam"
- " Sambal geprek"
- "15 buah cabe rawit merah orange"
- "3 siung bawang putih goreng"
- "1/2 sdt garam"
recipeinstructions:
- "Cuci ayam sampai bersih. Kemudian marinasi dengan bumbu halus tadi (me: simpan dikulkas 5 jam)"
- "Campur tepung terigu, tepung maizena dan tepung kobe.."
- "Masukkan telur ke dalam wadah berisi ayam yang telah dimarinasi, aduk sampai merata."
- "Masukkan ayam ke dalam tepung."
- "Panaskan minyak. Setelah itu masukkan ayam dan goreng dengan api kecil (agar ayam matang sampai ke dalam)"
- "Goreng ayam sampai berubah warna menjadi kuning keemasan."
- "Ulek sambal ayam gepreknya"
- "Geprek ayam di atas sambalnya."
- "Ayam geprek siap disantap"
categories:
- Recipe
tags:
- ayam
- geprek
- simple

katakunci: ayam geprek simple 
nutrition: 286 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam geprek simple](https://img-global.cpcdn.com/recipes/de3e2aeb577bf2b8/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam geprek simple yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Indonesia



Kehangatan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam geprek simple untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi makanan yang dapat anda buat salah satunya ayam geprek simple yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam geprek simple tanpa harus bersusah payah.
Berikut ini resep Ayam geprek simple yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 13 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek simple:

1. Harus ada 1/4 kg ayam
1. Diperlukan 5 sdm tepung terigu
1. Jangan lupa 1 sdm maizena
1. Tambah 1 sdm tepung kobe pedas (ambil sisa yang ada di dapur😅)
1. Harap siapkan 1 butir telur
1. Jangan lupa  Bumbu (halus) marinasi ayam
1. Dibutuhkan 4 siung bawang putih
1. Siapkan 1 sdt merica butiran
1. Harap siapkan 1 sdt garam
1. Diperlukan  Sambal geprek
1. Harus ada 15 buah cabe rawit merah orange
1. Diperlukan 3 siung bawang putih goreng
1. Diperlukan 1/2 sdt garam




<!--inarticleads2-->

##### Instruksi membuat  Ayam geprek simple:

1. Cuci ayam sampai bersih. Kemudian marinasi dengan bumbu halus tadi (me: simpan dikulkas 5 jam)
1. Campur tepung terigu, tepung maizena dan tepung kobe..
1. Masukkan telur ke dalam wadah berisi ayam yang telah dimarinasi, aduk sampai merata.
1. Masukkan ayam ke dalam tepung.
1. Panaskan minyak. Setelah itu masukkan ayam dan goreng dengan api kecil (agar ayam matang sampai ke dalam)
1. Goreng ayam sampai berubah warna menjadi kuning keemasan.
1. Ulek sambal ayam gepreknya
1. Geprek ayam di atas sambalnya.
1. Ayam geprek siap disantap




Demikianlah cara membuat ayam geprek simple yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan teruji, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
