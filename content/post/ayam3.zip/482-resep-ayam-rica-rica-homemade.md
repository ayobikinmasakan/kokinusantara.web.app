---
description: "Resep : Ayam Rica-Rica 🌶️ Homemade"
title: "Resep : Ayam Rica-Rica 🌶️ Homemade"
slug: 482-resep-ayam-rica-rica-homemade
date: 2020-08-17T13:33:17.693Z
image: https://img-global.cpcdn.com/recipes/8e966cd1065dc3e0/751x532cq70/ayam-rica-rica-🌶️-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8e966cd1065dc3e0/751x532cq70/ayam-rica-rica-🌶️-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8e966cd1065dc3e0/751x532cq70/ayam-rica-rica-🌶️-foto-resep-utama.jpg
author: Adam Wells
ratingvalue: 4
reviewcount: 34812
recipeingredient:
- "600 gr ayam potong sesuai selera"
- "2 ikat kemangi petiki daunnya"
- "1 btg daun bawang"
- "3 lbr daun jeruk"
- "2 lbr daun salam"
- "2 btg sereh geprek"
- "2 ruas lengkuas geprek"
- "1/2 sdm kaldu bubuk"
- "2 sdt gula pasir"
- "1 sdt garam"
- "400 ml air"
- " Bumbu marinasi"
- "1 bh jeruk nipis"
- "1 sdt garam"
- "1 sdt kunyit bubuk"
- " Bumbu halus"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "3 bh kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- "12 bh cabe merah keriting"
- "10 bh cabe rawit merah"
recipeinstructions:
- "Pertama ayam saya marinasi terlebih dahulu dgn perasan air jeruk nipis, diamkan selama10 menit lalu bilas. Selanjutnya marinasi ayam dgn garam dan kunyit bubuk, aduk rata lalu diamkan selama kurleb 30 menit hingga bumbunya meresap."
- "Panaskan minyak kemudian goreng ayam hingga berwarna kecoklatan, gunakan api sedang. Angkat dan tiriskan. Sisihkan."
- "Siapkan bumbu halus kemudian tumis bumbu dengan sedikit minyak sisa menggoreng ayam. Masukkan sereh, salam, daun jeruk, dan lengkuas lalu tumis bumbu hingga harum dan matangnya tanak agar tidak mudah basi. Masukkan air lalu gula, garam, dan kaldu bubuk, aduk sebentar lalu masukkan ayam goreng."
- "Masak ayam hingga kuahnya mulai menyusut, jangan lupa koreksi rasanya. Terakhir masukkan kemangi dan daun bawang lalu aduk rata sebentar aja. Angkat dan sajikan"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 210 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica-Rica 🌶️](https://img-global.cpcdn.com/recipes/8e966cd1065dc3e0/751x532cq70/ayam-rica-rica-🌶️-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga gurih. Karasteristik makanan Indonesia ayam rica-rica 🌶️ yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-Rica 🌶️ untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda praktekkan salah satunya ayam rica-rica 🌶️ yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica-rica 🌶️ tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica 🌶️ yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 23 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica 🌶️:

1. Harap siapkan 600 gr ayam, potong sesuai selera
1. Jangan lupa 2 ikat kemangi, petiki daunnya
1. Siapkan 1 btg daun bawang
1. Diperlukan 3 lbr daun jeruk
1. Tambah 2 lbr daun salam
1. Harap siapkan 2 btg sereh, geprek
1. Jangan lupa 2 ruas lengkuas, geprek
1. Siapkan 1/2 sdm kaldu bubuk
1. Harap siapkan 2 sdt gula pasir
1. Dibutuhkan 1 sdt garam
1. Dibutuhkan 400 ml air
1. Tambah  Bumbu marinasi:
1. Harap siapkan 1 bh jeruk nipis
1. Harap siapkan 1 sdt garam
1. Diperlukan 1 sdt kunyit bubuk
1. Jangan lupa  Bumbu halus:
1. Jangan lupa 6 siung bawang merah
1. Diperlukan 4 siung bawang putih
1. Jangan lupa 3 bh kemiri
1. Diperlukan 1 ruas jahe
1. Jangan lupa 1 ruas kunyit
1. Harus ada 12 bh cabe merah keriting
1. Tambah 10 bh cabe rawit merah




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica 🌶️:

1. Pertama ayam saya marinasi terlebih dahulu dgn perasan air jeruk nipis, diamkan selama10 menit lalu bilas. Selanjutnya marinasi ayam dgn garam dan kunyit bubuk, aduk rata lalu diamkan selama kurleb 30 menit hingga bumbunya meresap.
1. Panaskan minyak kemudian goreng ayam hingga berwarna kecoklatan, gunakan api sedang. Angkat dan tiriskan. Sisihkan.
1. Siapkan bumbu halus kemudian tumis bumbu dengan sedikit minyak sisa menggoreng ayam. Masukkan sereh, salam, daun jeruk, dan lengkuas lalu tumis bumbu hingga harum dan matangnya tanak agar tidak mudah basi. Masukkan air lalu gula, garam, dan kaldu bubuk, aduk sebentar lalu masukkan ayam goreng.
1. Masak ayam hingga kuahnya mulai menyusut, jangan lupa koreksi rasanya. Terakhir masukkan kemangi dan daun bawang lalu aduk rata sebentar aja. Angkat dan sajikan




Demikianlah cara membuat ayam rica-rica 🌶️ yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
