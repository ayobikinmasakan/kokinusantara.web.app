---
description: "Resep : Ayam Geprek Sambal Kencur dan Pete Favorite"
title: "Resep : Ayam Geprek Sambal Kencur dan Pete Favorite"
slug: 148-resep-ayam-geprek-sambal-kencur-dan-pete-favorite
date: 2020-10-28T15:38:17.147Z
image: https://img-global.cpcdn.com/recipes/eaea189cbf7e0bb4/751x532cq70/ayam-geprek-sambal-kencur-dan-pete-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/eaea189cbf7e0bb4/751x532cq70/ayam-geprek-sambal-kencur-dan-pete-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/eaea189cbf7e0bb4/751x532cq70/ayam-geprek-sambal-kencur-dan-pete-foto-resep-utama.jpg
author: Susan Walker
ratingvalue: 4.9
reviewcount: 3319
recipeingredient:
- "1/2 ekor ayam kampung"
- "4 buah Cabai merah besar"
- "10 buah Cabai merah keriting"
- "4 siung Bawang merah"
- "1 siung bawang putih"
- "1 papan pete"
- "1 ruas jari kencur"
- " Penyedap rasa"
- " Gula garam"
- "sedikit Terasi"
- " Bumbu racik ayam"
recipeinstructions:
- "Cuci bersih ayam, ungkep dgn bumbu racik ayam."
- "Sambil menunggu ayam sat, rebus semua cabe merah agar lebih merah dan mudah diuleg."
- "Uleg bawang merah dan putih jg kencur, tambah cabe yg sdh direbus, uleg semuanya tambahkan penyedap rasa ayam, gula, garam sedikit jg terasi, uleg lg dan tes rasanya."
- "Goreng ayam yg sdh diungkep. Tiriskan."
- "Goreng sambal yg sudah diuleg kasar, masukan pete, oseng2 sampai wangi."
- "Taruh ayam di cobek, geprek2. Taruh sambal diatasnya lalu geprek pelan. Sajikan."
categories:
- Recipe
tags:
- ayam
- geprek
- sambal

katakunci: ayam geprek sambal 
nutrition: 239 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT42M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Geprek Sambal Kencur dan Pete](https://img-global.cpcdn.com/recipes/eaea189cbf7e0bb4/751x532cq70/ayam-geprek-sambal-kencur-dan-pete-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam geprek sambal kencur dan pete yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan keistimewahan yang merupakan keragaman Nusantara

Keharmonisan keluarga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam Geprek Sambal Kencur dan Pete untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda coba salah satunya ayam geprek sambal kencur dan pete yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam geprek sambal kencur dan pete tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Sambal Kencur dan Pete yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Sambal Kencur dan Pete:

1. Dibutuhkan 1/2 ekor ayam kampung
1. Jangan lupa 4 buah Cabai merah besar
1. Siapkan 10 buah Cabai merah keriting
1. Diperlukan 4 siung Bawang merah
1. Diperlukan 1 siung bawang putih
1. Dibutuhkan 1 papan pete
1. Harus ada 1 ruas jari kencur
1. Siapkan  Penyedap rasa
1. Jangan lupa  Gula garam
1. Tambah sedikit Terasi
1. Jangan lupa  Bumbu racik ayam




<!--inarticleads2-->

##### Instruksi membuat  Ayam Geprek Sambal Kencur dan Pete:

1. Cuci bersih ayam, ungkep dgn bumbu racik ayam.
1. Sambil menunggu ayam sat, rebus semua cabe merah agar lebih merah dan mudah diuleg.
1. Uleg bawang merah dan putih jg kencur, tambah cabe yg sdh direbus, uleg semuanya tambahkan penyedap rasa ayam, gula, garam sedikit jg terasi, uleg lg dan tes rasanya.
1. Goreng ayam yg sdh diungkep. Tiriskan.
1. Goreng sambal yg sudah diuleg kasar, masukan pete, oseng2 sampai wangi.
1. Taruh ayam di cobek, geprek2. Taruh sambal diatasnya lalu geprek pelan. Sajikan.




Demikianlah cara membuat ayam geprek sambal kencur dan pete yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
