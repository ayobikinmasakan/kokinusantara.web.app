---
description: "Panduan untuk membuat Sayap Ayam Kecap Pedas Manis Sempurna"
title: "Panduan untuk membuat Sayap Ayam Kecap Pedas Manis Sempurna"
slug: 452-panduan-untuk-membuat-sayap-ayam-kecap-pedas-manis-sempurna
date: 2021-01-18T13:09:15.056Z
image: https://img-global.cpcdn.com/recipes/df2f969877b7d170/751x532cq70/sayap-ayam-kecap-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/df2f969877b7d170/751x532cq70/sayap-ayam-kecap-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/df2f969877b7d170/751x532cq70/sayap-ayam-kecap-pedas-manis-foto-resep-utama.jpg
author: Cecilia Yates
ratingvalue: 4
reviewcount: 21167
recipeingredient:
- "1/2 kg Sayap ayam"
- "4 siung Bawang merah"
- "5 siung Bawang putih"
- "10 buah Cabe rawit merah"
- "20 buah Cabe rawit hijau"
- "1 buah Cabe hijau besar"
- "1 batang Serai"
- "3 lembar Daun jeruk"
- "3 lembar Daun salam"
- "1 ruas Jahe"
- "1 ruas Lengkuas"
- "1/2 sdm Ketumbar bubuk"
- "secukupnya Garam"
- "secukupnya Gula"
- "secukupnya Lada"
- "secukupnya Penyedap rasa"
- "secukupnya Kecap manis"
- "secukupnya Minyak goreng"
- "secukupnya Air bersih"
recipeinstructions:
- "Cuci bersih sayap ayam, siapkan 2 siung bawang putih lalu geprek dan masukkan ke air lalu rebus (bisa ditambah sedikit garam ya) ketika air sudah mendidih masukkan sayap ayam, rebus sekitar 10 menit (disini supaya sayap ayamnya benar² empuk jadi saya rebus dulu sebelum di masak)"
- "Siapkan bumbu halus, bawang merah, sisa bawang putih, cabe rawit merah dan hijau (untuk cabe rawit hijau saya pakai 20 buah karna 10 buah saya biarkan utuh dan 10 buah lagi buat di haluskan, bisa menyesuaikan ya jika suka yg lebih pedas) dan jahe, blender sampai halus (boleh juga di ulek)"
- "Untuk cabe hijau yg besar saya iris tipis dan juga lengkuas saya iris tipis supaya bisa di makan, lalu serainya jangan lupa di geprek"
- "Panaskan sedikit minyak, tumis bumbu halus dengan irisan cabe hijau, cabe yg utuh, lengkuas, daun salam, daun jeruk, dan serai, tumis hingga bumbunya harum"
- "Tambahkan sedikit air (secukupnya saja ya) lalu beri bumbu garam, gula, ketumbar bubuk, lada, penyedap rasa dan kecap manis secukupnya, koreksi rasa jika sudah sesuai masukkan sayap ayam yang sudah di rebus tadi"
- "Masak hingga airnya menyusut dengan api sedang hingga bumbu meresap ke ayam, setelah matang siap di hidangkan dengan nasi hangat"
- "Selamat mencoba 🤗🤗"
categories:
- Recipe
tags:
- sayap
- ayam
- kecap

katakunci: sayap ayam kecap 
nutrition: 126 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dinner

---


![Sayap Ayam Kecap Pedas Manis](https://img-global.cpcdn.com/recipes/df2f969877b7d170/751x532cq70/sayap-ayam-kecap-pedas-manis-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga empuk. Karasteristik kuliner Nusantara sayap ayam kecap pedas manis yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Sayap Ayam Kecap Pedas Manis untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda coba salah satunya sayap ayam kecap pedas manis yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep sayap ayam kecap pedas manis tanpa harus bersusah payah.
Berikut ini resep Sayap Ayam Kecap Pedas Manis yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sayap Ayam Kecap Pedas Manis:

1. Dibutuhkan 1/2 kg Sayap ayam
1. Tambah 4 siung Bawang merah
1. Harap siapkan 5 siung Bawang putih
1. Diperlukan 10 buah Cabe rawit merah
1. Harap siapkan 20 buah Cabe rawit hijau
1. Harap siapkan 1 buah Cabe hijau besar
1. Tambah 1 batang Serai
1. Tambah 3 lembar Daun jeruk
1. Harap siapkan 3 lembar Daun salam
1. Harus ada 1 ruas Jahe
1. Dibutuhkan 1 ruas Lengkuas
1. Harus ada 1/2 sdm Ketumbar bubuk
1. Tambah secukupnya Garam
1. Diperlukan secukupnya Gula
1. Tambah secukupnya Lada
1. Siapkan secukupnya Penyedap rasa
1. Tambah secukupnya Kecap manis
1. Harus ada secukupnya Minyak goreng
1. Harus ada secukupnya Air bersih




<!--inarticleads2-->

##### Instruksi membuat  Sayap Ayam Kecap Pedas Manis:

1. Cuci bersih sayap ayam, siapkan 2 siung bawang putih lalu geprek dan masukkan ke air lalu rebus (bisa ditambah sedikit garam ya) ketika air sudah mendidih masukkan sayap ayam, rebus sekitar 10 menit (disini supaya sayap ayamnya benar² empuk jadi saya rebus dulu sebelum di masak)
1. Siapkan bumbu halus, bawang merah, sisa bawang putih, cabe rawit merah dan hijau (untuk cabe rawit hijau saya pakai 20 buah karna 10 buah saya biarkan utuh dan 10 buah lagi buat di haluskan, bisa menyesuaikan ya jika suka yg lebih pedas) dan jahe, blender sampai halus (boleh juga di ulek)
1. Untuk cabe hijau yg besar saya iris tipis dan juga lengkuas saya iris tipis supaya bisa di makan, lalu serainya jangan lupa di geprek
1. Panaskan sedikit minyak, tumis bumbu halus dengan irisan cabe hijau, cabe yg utuh, lengkuas, daun salam, daun jeruk, dan serai, tumis hingga bumbunya harum
1. Tambahkan sedikit air (secukupnya saja ya) lalu beri bumbu garam, gula, ketumbar bubuk, lada, penyedap rasa dan kecap manis secukupnya, koreksi rasa jika sudah sesuai masukkan sayap ayam yang sudah di rebus tadi
1. Masak hingga airnya menyusut dengan api sedang hingga bumbu meresap ke ayam, setelah matang siap di hidangkan dengan nasi hangat
1. Selamat mencoba 🤗🤗




Demikianlah cara membuat sayap ayam kecap pedas manis yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
