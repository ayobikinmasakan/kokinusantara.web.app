---
description: "Cara singkat untuk membuat Ayam rica rica simpel Luar biasa"
title: "Cara singkat untuk membuat Ayam rica rica simpel Luar biasa"
slug: 486-cara-singkat-untuk-membuat-ayam-rica-rica-simpel-luar-biasa
date: 2020-09-20T14:45:42.955Z
image: https://img-global.cpcdn.com/recipes/df0ba687259b0685/751x532cq70/ayam-rica-rica-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/df0ba687259b0685/751x532cq70/ayam-rica-rica-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/df0ba687259b0685/751x532cq70/ayam-rica-rica-simpel-foto-resep-utama.jpg
author: Blake Wilkins
ratingvalue: 4.5
reviewcount: 9093
recipeingredient:
- "1/2 ekor ayam"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1/2 bawang bombai"
- "1/2 tomat"
- "9 buah cabe rawit merah tergantung selera"
- "2 lembar daun jeruk"
- "1 sachet royco disesuaikan"
- " Garam disesuaikan"
- " Marinasi ayam"
- "1/2 sdt royco"
- "1/2 sdt kunyit bubuk"
- "1/2 sdt ketumbar bubuk"
- " Garam"
recipeinstructions:
- "Cuci bersih ayam, lalu marinasi ayam dengan bumbu marinasi"
- "Setelah di marinasi 15 menit goreng ayam sampai kecoklatan"
- "Siapkan bumbu untuk rica rica, uleg kasar bawang merah, bawang putih dan cabai"
- "Setelah di uleg kasar, tumis bawang bombai sampai harum lalu masukkan bumbu, daun jeruk, dan tomat tumis hingga matang"
- "Setelah bumbu matang masukkan sedikit air, lalu tambahkan penyedap, garam, gula, cicipi rasanya jika sudah pas masukkan ayam yang sudah di goreng sebelumnya, masak hingga air kering,"
- "Ayam rica rica siap di sajikan bunda🥰🥰"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 183 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica rica simpel](https://img-global.cpcdn.com/recipes/df0ba687259b0685/751x532cq70/ayam-rica-rica-simpel-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan gurih. Ciri masakan Indonesia ayam rica rica simpel yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam rica rica simpel untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang bisa anda coba salah satunya ayam rica rica simpel yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam rica rica simpel tanpa harus bersusah payah.
Seperti resep Ayam rica rica simpel yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica simpel:

1. Harus ada 1/2 ekor ayam
1. Harus ada 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Harap siapkan 1/2 bawang bombai
1. Siapkan 1/2 tomat
1. Dibutuhkan 9 buah cabe rawit merah (tergantung selera)
1. Harus ada 2 lembar daun jeruk
1. Tambah 1 sachet royco (disesuaikan)
1. Harap siapkan  Garam (disesuaikan)
1. Diperlukan  Marinasi ayam
1. Jangan lupa 1/2 sdt royco
1. Siapkan 1/2 sdt kunyit bubuk
1. Siapkan 1/2 sdt ketumbar bubuk
1. Diperlukan  Garam




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica simpel:

1. Cuci bersih ayam, lalu marinasi ayam dengan bumbu marinasi
1. Setelah di marinasi 15 menit goreng ayam sampai kecoklatan
1. Siapkan bumbu untuk rica rica, uleg kasar bawang merah, bawang putih dan cabai
1. Setelah di uleg kasar, tumis bawang bombai sampai harum lalu masukkan bumbu, daun jeruk, dan tomat tumis hingga matang
1. Setelah bumbu matang masukkan sedikit air, lalu tambahkan penyedap, garam, gula, cicipi rasanya jika sudah pas masukkan ayam yang sudah di goreng sebelumnya, masak hingga air kering,
1. Ayam rica rica siap di sajikan bunda🥰🥰




Demikianlah cara membuat ayam rica rica simpel yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
