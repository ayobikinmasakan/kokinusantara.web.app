---
description: "Bagaimana untuk membuat Ayam geprek sambal setan terupdate"
title: "Bagaimana untuk membuat Ayam geprek sambal setan terupdate"
slug: 205-bagaimana-untuk-membuat-ayam-geprek-sambal-setan-terupdate
date: 2020-09-21T23:43:41.988Z
image: https://img-global.cpcdn.com/recipes/47e456dbcb25cba5/751x532cq70/ayam-geprek-sambal-setan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/47e456dbcb25cba5/751x532cq70/ayam-geprek-sambal-setan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/47e456dbcb25cba5/751x532cq70/ayam-geprek-sambal-setan-foto-resep-utama.jpg
author: Isabel Frazier
ratingvalue: 4.2
reviewcount: 22711
recipeingredient:
- "2 dada ayam dijadikan 4 potong"
- "1 ons tepung terigu atau bisa pakai tepung bumbu instan"
- "Secukupnya Merica "
- "secukupnya Ketumbar "
- "1 buah jeruk nipis"
- " Garam"
- " Bumbu halus"
- "5 buah bawang merah"
- "3 siung bawang putih"
- "1 ruas jari jahe"
- "1 atau 2 ruas kunyit"
- " Bahan sambal "
- "30 buah cabe setan"
- "5 buah cabe rawit hijau"
- "2 siung bawang putih"
- "1/2 buah tomat merah"
- "1/2 bungkus terasi abc"
recipeinstructions:
- "Cuci bersih ayam yg sudah dipotong 4, tusuk2 ayam supaya bumbu mudah meresap"
- "Campurkan ayam dengan bumbu halus, merica, ketumbar dan garam secukupnya lumuri perasan jeruk nipis, aduk2 (saya langsung menggunakan tangan), setelah ayam tercampur rata dengan bumbu lalu diamkan dalam kulkas kurleb 15 menit"
- "Untuk bahan tepung, karna saya tidak menggunakan tepung bumbu instan jadi saya menggunakan tepung terigu, beri garam, merica dan ketumbar, aduk rata"
- "Lalu ayam yang sudah didiamkan di kulkas tadi kita campurkan pada tepung sambil ditekan2 agar tepung menempel cantik, goreng pada minyak panas dengan api sedang (saya menggunakan panci agar ayam bisa terendam minyak dan matang merata), goreng hingga kecoklatan"
- "Cara membuat sambal setannya : ulek kasar semua bahan+terasi, bumbui garam secukupnya, lalu siramkan sedikit minyak panas sisa menggoreng ayam tadi"
- "Letakkan ayam yang sudah digoreng pada ulekan, GEPREK, pastikan ayam terlumuri dengan sambal, dan sajikan"
- "Selamat mencoba 😊"
categories:
- Recipe
tags:
- ayam
- geprek
- sambal

katakunci: ayam geprek sambal 
nutrition: 230 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam geprek sambal setan](https://img-global.cpcdn.com/recipes/47e456dbcb25cba5/751x532cq70/ayam-geprek-sambal-setan-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga renyah. Karasteristik makanan Indonesia ayam geprek sambal setan yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam geprek sambal setan untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang bisa anda contoh salah satunya ayam geprek sambal setan yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam geprek sambal setan tanpa harus bersusah payah.
Berikut ini resep Ayam geprek sambal setan yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam geprek sambal setan:

1. Diperlukan 2 dada ayam dijadikan 4 potong
1. Siapkan 1 ons tepung terigu atau bisa pakai tepung bumbu instan
1. Jangan lupa Secukupnya Merica ()
1. Siapkan secukupnya Ketumbar ()
1. Harus ada 1 buah jeruk nipis
1. Siapkan  Garam
1. Siapkan  Bumbu halus:
1. Siapkan 5 buah bawang merah
1. Dibutuhkan 3 siung bawang putih
1. Harap siapkan 1 ruas jari jahe
1. Dibutuhkan 1 atau 2 ruas kunyit
1. Jangan lupa  Bahan sambal :
1. Jangan lupa 30 buah cabe setan
1. Harap siapkan 5 buah cabe rawit hijau
1. Diperlukan 2 siung bawang putih
1. Diperlukan 1/2 buah tomat merah
1. Harus ada 1/2 bungkus terasi abc




<!--inarticleads2-->

##### Langkah membuat  Ayam geprek sambal setan:

1. Cuci bersih ayam yg sudah dipotong 4, tusuk2 ayam supaya bumbu mudah meresap
1. Campurkan ayam dengan bumbu halus, merica, ketumbar dan garam secukupnya lumuri perasan jeruk nipis, aduk2 (saya langsung menggunakan tangan), setelah ayam tercampur rata dengan bumbu lalu diamkan dalam kulkas kurleb 15 menit
1. Untuk bahan tepung, karna saya tidak menggunakan tepung bumbu instan jadi saya menggunakan tepung terigu, beri garam, merica dan ketumbar, aduk rata
1. Lalu ayam yang sudah didiamkan di kulkas tadi kita campurkan pada tepung sambil ditekan2 agar tepung menempel cantik, goreng pada minyak panas dengan api sedang (saya menggunakan panci agar ayam bisa terendam minyak dan matang merata), goreng hingga kecoklatan
1. Cara membuat sambal setannya : ulek kasar semua bahan+terasi, bumbui garam secukupnya, lalu siramkan sedikit minyak panas sisa menggoreng ayam tadi
1. Letakkan ayam yang sudah digoreng pada ulekan, GEPREK, pastikan ayam terlumuri dengan sambal, dan sajikan
1. Selamat mencoba 😊




Demikianlah cara membuat ayam geprek sambal setan yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
