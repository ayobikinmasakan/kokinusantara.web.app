---
description: "Resep : Ayam Geprek Simple #bikinramadhanberkesan Cepat"
title: "Resep : Ayam Geprek Simple #bikinramadhanberkesan Cepat"
slug: 238-resep-ayam-geprek-simple-bikinramadhanberkesan-cepat
date: 2020-10-18T05:33:22.978Z
image: https://img-global.cpcdn.com/recipes/dbfc02195c7c1ef0/751x532cq70/ayam-geprek-simple-bikinramadhanberkesan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dbfc02195c7c1ef0/751x532cq70/ayam-geprek-simple-bikinramadhanberkesan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dbfc02195c7c1ef0/751x532cq70/ayam-geprek-simple-bikinramadhanberkesan-foto-resep-utama.jpg
author: Jimmy Harmon
ratingvalue: 4.4
reviewcount: 46849
recipeingredient:
- "1/2 kg ayam"
- "2 siung bawang putih geprek"
- "1/4 kg terigu"
- "secukupnya Garam"
- "secukupnya Merica"
- " Gula pengganti penyedap rasa"
- " Minyak untuk menggoreng"
- " Sambel ulek"
- "2 cabe merah besar"
- "5 cabe rawit"
- "2 siung bawang putih"
- "1 tomat"
recipeinstructions:
- "Rebus ayam dengan bawang putih campur sejumput garam selama 25menit"
- "Sambil nunggu ayam, ulek kasar cabe merah, cabe rawit, bawang putih, tomat campur dengan dua jumput garam dan sedikit gula dan tambahkan dengan minyak panas"
- "Setelah 15 menit, tiriskan ayam. lalu buat campuran terigu, merica, garam dan gula ke dalam kantong kiloan (untuk mempermudah membalur ayam dengan terigu). Masukan ayam yang sudah ditiriskan ke dalam kantong berisi terigu lalu kocok sampai semua bagian ayam tertutupi terigu"
- "Lalu goreng ayam yang sudah di balur terigu, cukup sekitar 3-5 menit setiap sisinya. Setelah itu angkat dari minyak"
- "Lalu masukan ayam ke dalam cobek dan ditambahkan sambal sesuai dengan selera lalu penyet dengan menggunakan ulekan."
- "Enak disantap dengan nasi panas, kalau nggak tahan pedas bisa ditambahkan kecap juga. Selamat menikmati"
categories:
- Recipe
tags:
- ayam
- geprek
- simple

katakunci: ayam geprek simple 
nutrition: 213 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Geprek Simple #bikinramadhanberkesan](https://img-global.cpcdn.com/recipes/dbfc02195c7c1ef0/751x532cq70/ayam-geprek-simple-bikinramadhanberkesan-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau empuk. Karasteristik makanan Nusantara ayam geprek simple #bikinramadhanberkesan yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Geprek Simple #bikinramadhanberkesan untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda coba salah satunya ayam geprek simple #bikinramadhanberkesan yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam geprek simple #bikinramadhanberkesan tanpa harus bersusah payah.
Seperti resep Ayam Geprek Simple #bikinramadhanberkesan yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Simple #bikinramadhanberkesan:

1. Harap siapkan 1/2 kg ayam
1. Harus ada 2 siung bawang putih, geprek
1. Siapkan 1/4 kg terigu
1. Jangan lupa secukupnya Garam
1. Tambah secukupnya Merica
1. Diperlukan  Gula (pengganti penyedap rasa)
1. Harap siapkan  Minyak untuk menggoreng
1. Siapkan  Sambel ulek:
1. Tambah 2 cabe merah besar
1. Dibutuhkan 5 cabe rawit
1. Jangan lupa 2 siung bawang putih
1. Harus ada 1 tomat




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Geprek Simple #bikinramadhanberkesan:

1. Rebus ayam dengan bawang putih campur sejumput garam selama 25menit
1. Sambil nunggu ayam, ulek kasar cabe merah, cabe rawit, bawang putih, tomat campur dengan dua jumput garam dan sedikit gula dan tambahkan dengan minyak panas
1. Setelah 15 menit, tiriskan ayam. lalu buat campuran terigu, merica, garam dan gula ke dalam kantong kiloan (untuk mempermudah membalur ayam dengan terigu). Masukan ayam yang sudah ditiriskan ke dalam kantong berisi terigu lalu kocok sampai semua bagian ayam tertutupi terigu
1. Lalu goreng ayam yang sudah di balur terigu, cukup sekitar 3-5 menit setiap sisinya. Setelah itu angkat dari minyak
1. Lalu masukan ayam ke dalam cobek dan ditambahkan sambal sesuai dengan selera lalu penyet dengan menggunakan ulekan.
1. Enak disantap dengan nasi panas, kalau nggak tahan pedas bisa ditambahkan kecap juga. Selamat menikmati




Demikianlah cara membuat ayam geprek simple #bikinramadhanberkesan yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
