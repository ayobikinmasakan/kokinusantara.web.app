---
description: "Resep : Ayam rica simpel teraktual"
title: "Resep : Ayam rica simpel teraktual"
slug: 491-resep-ayam-rica-simpel-teraktual
date: 2020-10-13T10:34:57.404Z
image: https://img-global.cpcdn.com/recipes/7a9dd98dad4d4c7c/751x532cq70/ayam-rica-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7a9dd98dad4d4c7c/751x532cq70/ayam-rica-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7a9dd98dad4d4c7c/751x532cq70/ayam-rica-simpel-foto-resep-utama.jpg
author: Amy Marsh
ratingvalue: 4.4
reviewcount: 37256
recipeingredient:
- "1 ekor ayam kampung bersihkan potong2"
- "1 sdm gula pasir"
- "secukupnya Garam"
- "3 sere geprek"
- "5 daun jeruk"
- "2 daun pandan"
- "secukupnya Minyak"
- "10 butir bawang merah iris tipis2"
- "10 cabe rawit merah utuh"
- " Bumbu halus "
- "6 siung bawang putih"
- "1 ruas jari jahe"
- "Sedikit kunyit"
- "1 kemiri"
- "10 cabe merah keriting"
- "10 cabe rawit merah"
recipeinstructions:
- "Rebus ayam (me : 5-30-7), tiriskan sisihkan kaldunya"
- "Panaskan minyak, goreng ayam setengah kering"
- "Ambil kurleb 5 sdm minyak bekas menggoreng ayam, panaskan"
- "Tumis bawang merah sampai hampir matang, masukkan bumbu halus, tumis sampai harum, tambahkan sere, daun jeruk, daun pandan, cabe rawit utuh. Tambahkan gula pasir, garam."
- "Masukkan ayam, aduk rata, tambahkan air secukupnya. Masak sampai bumbu meresap dan air menyusut. Koreksi rasa."
- "Angkat, hidangkan."
categories:
- Recipe
tags:
- ayam
- rica
- simpel

katakunci: ayam rica simpel 
nutrition: 111 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica simpel](https://img-global.cpcdn.com/recipes/7a9dd98dad4d4c7c/751x532cq70/ayam-rica-simpel-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan empuk. Karasteristik makanan Nusantara ayam rica simpel yang penuh dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica simpel untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang bisa anda contoh salah satunya ayam rica simpel yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica simpel tanpa harus bersusah payah.
Berikut ini resep Ayam rica simpel yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica simpel:

1. Diperlukan 1 ekor ayam kampung, bersihkan potong2
1. Harus ada 1 sdm gula pasir
1. Harap siapkan secukupnya Garam
1. Diperlukan 3 sere, geprek
1. Siapkan 5 daun jeruk
1. Jangan lupa 2 daun pandan
1. Harap siapkan secukupnya Minyak
1. Harap siapkan 10 butir bawang merah iris tipis2
1. Tambah 10 cabe rawit merah utuh
1. Harus ada  Bumbu halus :
1. Harap siapkan 6 siung bawang putih
1. Jangan lupa 1 ruas jari jahe
1. Dibutuhkan Sedikit kunyit
1. Dibutuhkan 1 kemiri
1. Diperlukan 10 cabe merah keriting
1. Diperlukan 10 cabe rawit merah




<!--inarticleads2-->

##### Langkah membuat  Ayam rica simpel:

1. Rebus ayam (me : 5-30-7), tiriskan sisihkan kaldunya
1. Panaskan minyak, goreng ayam setengah kering
1. Ambil kurleb 5 sdm minyak bekas menggoreng ayam, panaskan
1. Tumis bawang merah sampai hampir matang, masukkan bumbu halus, tumis sampai harum, tambahkan sere, daun jeruk, daun pandan, cabe rawit utuh. Tambahkan gula pasir, garam.
1. Masukkan ayam, aduk rata, tambahkan air secukupnya. Masak sampai bumbu meresap dan air menyusut. Koreksi rasa.
1. Angkat, hidangkan.




Demikianlah cara membuat ayam rica simpel yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan teruji, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
