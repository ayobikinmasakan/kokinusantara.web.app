---
description: "Resep : Ayam Rica-rica Pedas Kemangi Favorite"
title: "Resep : Ayam Rica-rica Pedas Kemangi Favorite"
slug: 488-resep-ayam-rica-rica-pedas-kemangi-favorite
date: 2020-09-07T11:45:23.666Z
image: https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
author: Lucile Fowler
ratingvalue: 4.8
reviewcount: 27373
recipeingredient:
- "1/2 ekor ayam yg sudah direbus dan dipotong sesuai selera tanpa direbus juga boleh"
- "3 lembar daun salam"
- "3 lembar daun jeruk purut"
- "2 batang serai geprek"
- "5 cm lengkuas geprek"
- "1 genggam daunh kemangi"
- "1 lembar daun kunyit"
- "1 batang daun bawang"
- " Bumbu halus "
- "7 siung bawang merah"
- "3 siung bawang putih"
- "6 cm kunyit"
- "6 cm jahe"
- "4 butir kemiri sangrai"
- "1 sdm ketumbar sangrai"
- " Cabe rawit secukupnya bisa banyak bila mau pedes banget"
- "2 buah tomat"
- "500 ml air masak"
- " Minyak goreng utk menumis bumbu"
- "sesuai selera Garam dan penyedap rasa ayam"
recipeinstructions:
- "Siapkan semua bumbu. Ayam saya rebus sekitaran 10 menit dan tiriskan lalu potong sesuai selera. Ketumbar dan kemiri saya sangrai dan tumbuk. Kemudian bumbu halus saya blender."
- "Tumis bumbu hingga wangi dan berubah warna, masukan ayam dan aduk sebentar. Kemudian tuang air hingga menutupi ayam dan beri garam dan penyedap rasa. Aduk hingga rata dan diamkan sekitar 5 menit. Kemudian masukan kemangi, daun kunyit, dan daun bawang. Masak hingga air menyusut."
- "Masukan tomat dan aduk sebentar dan koreksi rasa. Setelah matang dan air menyusut maka ayam rica pedas kemangi siap dihidangkan."
- "Resep ini mudah banget dicobain moms. Enak deh. Dan ayam rica-rica kemangi benar nikmat dan yummy. 🥰🥰🥰🥰"
categories:
- Recipe
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 249 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica-rica Pedas Kemangi](https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan empuk. Karasteristik masakan Indonesia ayam rica-rica pedas kemangi yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-rica Pedas Kemangi untuk keluarga. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian masakan yang dapat anda contoh salah satunya ayam rica-rica pedas kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam rica-rica pedas kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Pedas Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 20 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Pedas Kemangi:

1. Jangan lupa 1/2 ekor ayam yg sudah direbus dan dipotong sesuai selera (tanpa direbus juga boleh)
1. Harus ada 3 lembar daun salam
1. Harap siapkan 3 lembar daun jeruk purut
1. Dibutuhkan 2 batang serai geprek
1. Tambah 5 cm lengkuas, geprek
1. Siapkan 1 genggam daunh kemangi
1. Dibutuhkan 1 lembar daun kunyit
1. Siapkan 1 batang daun bawang
1. Dibutuhkan  Bumbu halus :
1. Siapkan 7 siung bawang merah
1. Harus ada 3 siung bawang putih
1. Dibutuhkan 6 cm kunyit
1. Jangan lupa 6 cm jahe
1. Jangan lupa 4 butir kemiri sangrai
1. Harus ada 1 sdm ketumbar sangrai
1. Harus ada  Cabe rawit secukupnya (bisa banyak bila mau pedes banget)
1. Siapkan 2 buah tomat
1. Tambah 500 ml air masak
1. Harus ada  Minyak goreng utk menumis bumbu
1. Siapkan sesuai selera Garam dan penyedap rasa ayam




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-rica Pedas Kemangi:

1. Siapkan semua bumbu. Ayam saya rebus sekitaran 10 menit dan tiriskan lalu potong sesuai selera. Ketumbar dan kemiri saya sangrai dan tumbuk. Kemudian bumbu halus saya blender.
1. Tumis bumbu hingga wangi dan berubah warna, masukan ayam dan aduk sebentar. Kemudian tuang air hingga menutupi ayam dan beri garam dan penyedap rasa. Aduk hingga rata dan diamkan sekitar 5 menit. Kemudian masukan kemangi, daun kunyit, dan daun bawang. Masak hingga air menyusut.
1. Masukan tomat dan aduk sebentar dan koreksi rasa. Setelah matang dan air menyusut maka ayam rica pedas kemangi siap dihidangkan.
1. Resep ini mudah banget dicobain moms. Enak deh. Dan ayam rica-rica kemangi benar nikmat dan yummy. 🥰🥰🥰🥰




Demikianlah cara membuat ayam rica-rica pedas kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan teruji, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
