---
description: "Resep : Ayam Geprek top markotop Homemade"
title: "Resep : Ayam Geprek top markotop Homemade"
slug: 99-resep-ayam-geprek-top-markotop-homemade
date: 2020-09-04T02:14:24.757Z
image: https://img-global.cpcdn.com/recipes/6fda12fa65d73094/751x532cq70/ayam-geprek-top-markotop-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6fda12fa65d73094/751x532cq70/ayam-geprek-top-markotop-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6fda12fa65d73094/751x532cq70/ayam-geprek-top-markotop-foto-resep-utama.jpg
author: Belle Payne
ratingvalue: 4.5
reviewcount: 46714
recipeingredient:
- "1 kg ayam saya potong menjadi 4 bagian"
- "1 bungkus lada"
- "3 sdm terigu"
- "2 sdm maizena"
- "1 butir telur"
- "secukupnya Minyak goreng"
- " Bahan sambal"
- "2 siuang bawang merah"
- "4 siuang bawang putih"
- "secukupnya Garam"
- "secukupnya Totole"
- "10 cengek merahsesuaikan"
- "secukupnya Air"
- " Toping"
- " Lalapan"
- " Tomat"
- " Rebusan waluh"
- " Tahu tempe"
recipeinstructions:
- "Tahap 1 : Giling 2 bawang putih campurkan dengan ayam, beri sebungkus lada, totole secukupnya diamkan selama 2 jam supaya bumbu meresap (boleh dimasukkan ke kulkas)"
- "Tahap 2 &#34;membuat sambal geprek&#34;: Didihkan air, masukkan cengek merah, 2 siung bawang putih, 2 siung bawang merah (rebus kurang lebih 2 menit), boleh juga di giling mentah tapi saya rebus dulu biar ga sakit perut dan bau langu cabainya hilang 😁"
- "Tahap 3 : ✅Campurkan tepung maizena dan terigu ✅Kocok telur di wadah terpisah ✅Panaskan minyak goreng"
- "Ambil ayam yang sudah didiamkan tadi, masukkan ke dalam telur (bolak balik), lanjut masukan ke dalam tepung hingga merata."
- "Goreng hingga warna ke emasan (api kompor sedang)."
- "Setelah matang letakkan di atas sambal dan geprek...prek... Prek... Siap dihidangkan dengan lalapan sesuka hati 💙"
- "Simple tapi pak suami suka sampai minta lagi 😍 dan dikira sambal buatan saia di beli...semangat mencoba Bun 🥳"
categories:
- Recipe
tags:
- ayam
- geprek
- top

katakunci: ayam geprek top 
nutrition: 248 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Geprek top markotop](https://img-global.cpcdn.com/recipes/6fda12fa65d73094/751x532cq70/ayam-geprek-top-markotop-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam geprek top markotop yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Kita

Keharmonisan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Geprek top markotop untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang dapat anda contoh salah satunya ayam geprek top markotop yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep ayam geprek top markotop tanpa harus bersusah payah.
Seperti resep Ayam Geprek top markotop yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek top markotop:

1. Diperlukan 1 kg ayam, saya potong menjadi 4 bagian
1. Dibutuhkan 1 bungkus lada
1. Tambah 3 sdm terigu
1. Tambah 2 sdm maizena
1. Siapkan 1 butir telur
1. Jangan lupa secukupnya Minyak goreng
1. Dibutuhkan  Bahan sambal
1. Diperlukan 2 siuang bawang merah
1. Harus ada 4 siuang bawang putih
1. Jangan lupa secukupnya Garam
1. Dibutuhkan secukupnya Totole
1. Tambah 10 cengek merah/sesuaikan
1. Tambah secukupnya Air
1. Siapkan  Toping
1. Jangan lupa  Lalapan
1. Tambah  Tomat
1. Jangan lupa  Rebusan waluh
1. Harap siapkan  Tahu tempe




<!--inarticleads2-->

##### Instruksi membuat  Ayam Geprek top markotop:

1. Tahap 1 : - Giling 2 bawang putih campurkan dengan ayam, beri sebungkus lada, totole secukupnya diamkan selama 2 jam supaya bumbu meresap (boleh dimasukkan ke kulkas)
1. Tahap 2 &#34;membuat sambal geprek&#34;: Didihkan air, masukkan cengek merah, 2 siung bawang putih, 2 siung bawang merah (rebus kurang lebih 2 menit), boleh juga di giling mentah tapi saya rebus dulu biar ga sakit perut dan bau langu cabainya hilang 😁
1. Tahap 3 : ✅Campurkan tepung maizena dan terigu - ✅Kocok telur di wadah terpisah - ✅Panaskan minyak goreng
1. Ambil ayam yang sudah didiamkan tadi, masukkan ke dalam telur (bolak balik), lanjut masukan ke dalam tepung hingga merata.
1. Goreng hingga warna ke emasan (api kompor sedang).
1. Setelah matang letakkan di atas sambal dan geprek...prek... Prek... Siap dihidangkan dengan lalapan sesuka hati 💙
1. Simple tapi pak suami suka sampai minta lagi 😍 dan dikira sambal buatan saia di beli...semangat mencoba Bun 🥳




Demikianlah cara membuat ayam geprek top markotop yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
