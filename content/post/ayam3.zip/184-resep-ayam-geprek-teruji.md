---
description: "Resep : Ayam geprek Teruji"
title: "Resep : Ayam geprek Teruji"
slug: 184-resep-ayam-geprek-teruji
date: 2020-11-04T20:01:48.168Z
image: https://img-global.cpcdn.com/recipes/d5b4d3faf6b37920/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d5b4d3faf6b37920/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d5b4d3faf6b37920/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Beulah Lucas
ratingvalue: 4
reviewcount: 48725
recipeingredient:
- "6 potong ayam ukuran sedang"
- " Bumbu ayam "
- "1 sdm merica bubuk"
- "1 sdm ketumbar bubuk"
- "3 siung bawang putih"
- "secukupnya Garam"
- " Gula sesuai selera bisa juga gak usah dikasi"
- " Bumbu krispi "
- "1/4 tepung terigu"
- "1/4 sdm soda kue"
- "1 sdm lada bubuk"
- "2 sdm kaldu bubuk bisa diganti dg royco"
- " Kalau gak mau ribet bisa pakai aja tepung bumbu crispy instan"
- " Bumbu sambal"
- "20 buah cabe rawit"
- "2 buah cabe merah"
- "1 siung bawang putih yg kecil aja"
- " Gula"
- " Garam"
- " Minyak goreng"
recipeinstructions:
- "Cuci ayam sampai bersih lalu tiriskan"
- "Ulek semua bumbu ayam, lumuri ayam dengan bumbu sampai rata (bisa ditambah air sedikit supaya lebih mudah meresap), diamkan kira kira 1-2 jam"
- "Campur semua bumbu crispy"
- "Jika sudah meresap ayam siap di goreng, bagi tepung yg sudah dicampur bumbu menjadi 2 bagian, bagian kering dan basah, untuk yang basah cukup 3 sendok tepung lalu kasi air, jangan terlalu kental"
- "Gulung gulung ayam yg sudah di bumbu kedalam tepung, gulung2 sampai tebal"
- "Celupkan ayam yg sudah digulung tepung kedalam adonan basah"
- "Setelah dicelup keadonan basah gulung2 lagi ke dalam tepung, gulung2 sampai keriting"
- "Panaskan minyak lalu goreng ayam dengan api sedang"
- "Ulek semua bumbu sambal koreksi rasa, lalu tuangkan sedikit minyak panas kesambal"
- "Geprek ayam crispi lalu lumuri dengan sambal bawang"
- "Ayam geprek pedas siap dihancurkan"
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 178 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam geprek](https://img-global.cpcdn.com/recipes/d5b4d3faf6b37920/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam geprek yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa didapat dengan cara mudah. Diantaranya adalah memasak Ayam geprek untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang bisa anda buat salah satunya ayam geprek yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep ayam geprek tanpa harus bersusah payah.
Seperti resep Ayam geprek yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 11 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek:

1. Diperlukan 6 potong ayam ukuran sedang
1. Siapkan  Bumbu ayam :
1. Dibutuhkan 1 sdm merica bubuk
1. Jangan lupa 1 sdm ketumbar bubuk
1. Diperlukan 3 siung bawang putih
1. Siapkan secukupnya Garam
1. Harap siapkan  Gula sesuai selera (bisa juga gak usah dikasi)
1. Tambah  Bumbu krispi :
1. Harus ada 1/4 tepung terigu
1. Siapkan 1/4 sdm soda kue
1. Harus ada 1 sdm lada bubuk
1. Jangan lupa 2 sdm kaldu bubuk (bisa diganti dg royco)
1. Siapkan  (Kalau gak mau ribet bisa pakai aja tepung bumbu crispy instan)
1. Jangan lupa  Bumbu sambal:
1. Harap siapkan 20 buah cabe rawit
1. Diperlukan 2 buah cabe merah
1. Harus ada 1 siung bawang putih (yg kecil aja)
1. Harap siapkan  Gula
1. Dibutuhkan  Garam
1. Jangan lupa  Minyak goreng




<!--inarticleads2-->

##### Bagaimana membuat  Ayam geprek:

1. Cuci ayam sampai bersih lalu tiriskan
1. Ulek semua bumbu ayam, lumuri ayam dengan bumbu sampai rata (bisa ditambah air sedikit supaya lebih mudah meresap), diamkan kira kira 1-2 jam
1. Campur semua bumbu crispy
1. Jika sudah meresap ayam siap di goreng, bagi tepung yg sudah dicampur bumbu menjadi 2 bagian, bagian kering dan basah, untuk yang basah cukup 3 sendok tepung lalu kasi air, jangan terlalu kental
1. Gulung gulung ayam yg sudah di bumbu kedalam tepung, gulung2 sampai tebal
1. Celupkan ayam yg sudah digulung tepung kedalam adonan basah
1. Setelah dicelup keadonan basah gulung2 lagi ke dalam tepung, gulung2 sampai keriting
1. Panaskan minyak lalu goreng ayam dengan api sedang
1. Ulek semua bumbu sambal koreksi rasa, lalu tuangkan sedikit minyak panas kesambal
1. Geprek ayam crispi lalu lumuri dengan sambal bawang
1. Ayam geprek pedas siap dihancurkan




Demikianlah cara membuat ayam geprek yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan cepat, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
