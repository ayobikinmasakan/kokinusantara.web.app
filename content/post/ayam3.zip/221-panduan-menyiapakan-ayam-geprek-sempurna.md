---
description: "Panduan menyiapakan Ayam Geprek Sempurna"
title: "Panduan menyiapakan Ayam Geprek Sempurna"
slug: 221-panduan-menyiapakan-ayam-geprek-sempurna
date: 2020-10-29T17:53:39.197Z
image: https://img-global.cpcdn.com/recipes/e9b646bfc3780e50/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e9b646bfc3780e50/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e9b646bfc3780e50/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Sara Walters
ratingvalue: 4.2
reviewcount: 19530
recipeingredient:
- "1 ekor ayam potong jadi 6 atau 8 bagian sesuai selera"
- " tepung bumbu serbaguna saya pakai sasa crispy"
- "1 butir telur ayam"
- " minyak untuk menggoreng"
- " bahan sambal "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "15 buah cabe rawit sesuai selera tergantung tingkat kepedasan"
- "4 buah cabe merah keriting"
- "1/2 buah tomat"
- "secukupnya garam"
- "secukupnya ketumbar"
- "secukupnya lada bubuk"
- " kaldu bubuk opsional"
recipeinstructions:
- "Ayam goreng : buat larutan tepung bumbu dengan mencampurkan 4 sdm tepung dengan 8 sdm air dan sebutir telur ayam"
- "Tuang tepung bumbu kering di wadah lain nya"
- "Cuci bersih ayam.. setelah bersih, gulingkan ke tepung bumbu kering, lalu ke tepung bumbu basah, lanjutkan terakhir ke tepung bumbu kering."
- "Goreng ayam dalam minyak panas hingga matang..pastikan ayam matang sempurna hingga ke dalam daging nya..gunakan api sedang supaya ayam tidak mudah gosong dan bisa matang hingga bagian daging terdalam"
- "Angkat ayam goreng, tiriskan"
- "Sambal geprek : haluskan bawang merah,bawang putih, cabe-cabean, garam, kaldu bubuk,ketumbar dan lada bubuk bersamaan..boleh menggunakan blender tapi di blender kasar saja..lebih baik lagi jika diuleg."
- "Tumis sambal dengan menggunakan api kecil,koreksi rasanya"
- "Setelah sambal matang, ambil ayam goreng lalu geprek bersama dengan sambal hingga sambal meresap"
- "Sajikan dengan lalapan jika suka 😊"
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 158 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/e9b646bfc3780e50/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam geprek yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Kita



Kehangatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Geprek untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang bisa anda praktekkan salah satunya ayam geprek yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep ayam geprek tanpa harus bersusah payah.
Seperti resep Ayam Geprek yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 9 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek:

1. Harus ada 1 ekor ayam, potong jadi 6 atau 8 bagian sesuai selera
1. Siapkan  tepung bumbu serbaguna (saya pakai sasa crispy)
1. Tambah 1 butir telur ayam
1. Harus ada  minyak untuk menggoreng
1. Siapkan  bahan sambal :
1. Harap siapkan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Siapkan 15 buah cabe rawit (sesuai selera tergantung tingkat kepedasan)
1. Harus ada 4 buah cabe merah keriting
1. Tambah 1/2 buah tomat
1. Harap siapkan secukupnya garam
1. Tambah secukupnya ketumbar
1. Jangan lupa secukupnya lada bubuk
1. Jangan lupa  kaldu bubuk (opsional)




<!--inarticleads2-->

##### Instruksi membuat  Ayam Geprek:

1. Ayam goreng : buat larutan tepung bumbu dengan mencampurkan 4 sdm tepung dengan 8 sdm air dan sebutir telur ayam
1. Tuang tepung bumbu kering di wadah lain nya
1. Cuci bersih ayam.. setelah bersih, gulingkan ke tepung bumbu kering, lalu ke tepung bumbu basah, lanjutkan terakhir ke tepung bumbu kering.
1. Goreng ayam dalam minyak panas hingga matang..pastikan ayam matang sempurna hingga ke dalam daging nya..gunakan api sedang supaya ayam tidak mudah gosong dan bisa matang hingga bagian daging terdalam
1. Angkat ayam goreng, tiriskan
1. Sambal geprek : haluskan bawang merah,bawang putih, cabe-cabean, garam, kaldu bubuk,ketumbar dan lada bubuk bersamaan..boleh menggunakan blender tapi di blender kasar saja..lebih baik lagi jika diuleg.
1. Tumis sambal dengan menggunakan api kecil,koreksi rasanya
1. Setelah sambal matang, ambil ayam goreng lalu geprek bersama dengan sambal hingga sambal meresap
1. Sajikan dengan lalapan jika suka 😊




Demikianlah cara membuat ayam geprek yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
