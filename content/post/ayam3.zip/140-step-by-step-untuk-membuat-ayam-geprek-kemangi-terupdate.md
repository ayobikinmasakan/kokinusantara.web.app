---
description: "Step-by-Step untuk membuat Ayam geprek kemangi terupdate"
title: "Step-by-Step untuk membuat Ayam geprek kemangi terupdate"
slug: 140-step-by-step-untuk-membuat-ayam-geprek-kemangi-terupdate
date: 2021-01-06T20:20:02.830Z
image: https://img-global.cpcdn.com/recipes/15e1fa77bfe00cb0/751x532cq70/ayam-geprek-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/15e1fa77bfe00cb0/751x532cq70/ayam-geprek-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/15e1fa77bfe00cb0/751x532cq70/ayam-geprek-kemangi-foto-resep-utama.jpg
author: Lilly Neal
ratingvalue: 4.4
reviewcount: 38429
recipeingredient:
- "1 potong paha atas boleh bagian apa aja"
- "1 ikat kemangi"
- "2 siung bawang putih"
- "15 bh lombok rawit"
- " Tepung bumbu serba guna"
- " Air es"
- "Secukupnya gula merah garam penyedap rasa dan lada bubuk"
- " Minyak goreng"
recipeinstructions:
- "Cuci bersih ayam, kemudian beri secukupnya garam dan lada (diamkan 10menit didalam kulkas)"
- "Selagi menunggu ayam, rebus bawamg putih dan juga lombok sampe empuk."
- "Kemudian di ulek, kasih bumbu garam, penyedap rasa dan juga gula merah. Ulek sampe kalis, setelah itu masukkan kemangi yg sudah d bersihkan (ulek sebentar) terakhir guyur minyak panas."
- "Kembali ke ayam. Remas2 ayam ke dalam tepung kemudian celup ke air es dan remas2 ketepung lagi (maksudnya biar tepung hasil gorengannya kribo)"
- "Goreng diminyak yg cukup banyak (ayam sampe tenggelam) pakai api kecil biar mateng sampe ke dalam."
- "Setelah mateng, geprek ayam lalu lumuri dg sambel kemangi. Selesai ☺☺ simpel sekali."
categories:
- Recipe
tags:
- ayam
- geprek
- kemangi

katakunci: ayam geprek kemangi 
nutrition: 165 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam geprek kemangi](https://img-global.cpcdn.com/recipes/15e1fa77bfe00cb0/751x532cq70/ayam-geprek-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang harus kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam geprek kemangi yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Kita

Kedekatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam geprek kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat pecinta pedas, resep berikut wajib dicoba yah. Cara Membuat Ayam Geprek - Berbicara ayam geprek, sepertinya makanan ini sedang menjadi trend senter di bidang kuliner yang kini ngehitz di Indonesia setelah adanya Ayam Penyet beberapa waktu. Ayam geprek memang dikenal lezat, dan kamu bisa membuatnya sendiri. Ayam Geprek Kemangi - Resep Keluarga - Menu Sehari hari.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang bisa anda buat salah satunya ayam geprek kemangi yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam geprek kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam geprek kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek kemangi:

1. Siapkan 1 potong paha atas (boleh bagian apa aja)
1. Harus ada 1 ikat kemangi
1. Dibutuhkan 2 siung bawang putih
1. Jangan lupa 15 bh lombok rawit
1. Jangan lupa  Tepung bumbu serba guna
1. Diperlukan  Air es
1. Diperlukan Secukupnya gula merah, garam, penyedap rasa dan lada bubuk
1. Siapkan  Minyak goreng


Resep Ayam Geprek - Olahan ayam selalu menjadi menu favorit untuk kebanyakan orang. Ayam bisa diolah menjadi berbagai macam menu atau hidangan yang lezat sehingga tidak ada kata bosan untuk. Ayam geprek merupakan olahan masakan yang menggunakan ayam tepung sebagai bahan dasarnya. Perpaduan bumbu pada resep ayam geprek ini memberikan kelezatan yang luar biasa. 

<!--inarticleads2-->

##### Langkah membuat  Ayam geprek kemangi:

1. Cuci bersih ayam, kemudian beri secukupnya garam dan lada (diamkan 10menit didalam kulkas)
1. Selagi menunggu ayam, rebus bawamg putih dan juga lombok sampe empuk.
1. Kemudian di ulek, kasih bumbu garam, penyedap rasa dan juga gula merah. Ulek sampe kalis, setelah itu masukkan kemangi yg sudah d bersihkan (ulek sebentar) terakhir guyur minyak panas.
1. Kembali ke ayam. Remas2 ayam ke dalam tepung kemudian celup ke air es dan remas2 ketepung lagi (maksudnya biar tepung hasil gorengannya kribo)
1. Goreng diminyak yg cukup banyak (ayam sampe tenggelam) pakai api kecil biar mateng sampe ke dalam.
1. Setelah mateng, geprek ayam lalu lumuri dg sambel kemangi. Selesai ☺☺ simpel sekali.


Ayam geprek merupakan olahan masakan yang menggunakan ayam tepung sebagai bahan dasarnya. Perpaduan bumbu pada resep ayam geprek ini memberikan kelezatan yang luar biasa. Rasa, penyajian Resep ayam geprek - Ayam geprek, menjadi salah satu makanan populer dalam beberapa waktu terakhir ini. Berbisnis ayam geprek memiliki peluang bagus mengingat para milenial lebih suka. Geprek Bumbu Ayam Rebus (Lengkuas dan jahe). 

Demikianlah cara membuat ayam geprek kemangi yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
