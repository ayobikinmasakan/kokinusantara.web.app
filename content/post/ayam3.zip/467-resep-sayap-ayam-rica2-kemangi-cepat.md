---
description: "Resep : Sayap ayam rica2 kemangi Cepat"
title: "Resep : Sayap ayam rica2 kemangi Cepat"
slug: 467-resep-sayap-ayam-rica2-kemangi-cepat
date: 2020-11-24T15:50:27.088Z
image: https://img-global.cpcdn.com/recipes/76352658dda49c58/751x532cq70/sayap-ayam-rica2-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/76352658dda49c58/751x532cq70/sayap-ayam-rica2-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/76352658dda49c58/751x532cq70/sayap-ayam-rica2-kemangi-foto-resep-utama.jpg
author: Emma Aguilar
ratingvalue: 4.6
reviewcount: 4903
recipeingredient:
- "10 sayap ayam"
- "1 buah jeruk nipis"
- "3 ikat daun kemangi ambil daun nya"
- "2 batang daun bawang potong2"
- "1 buah tomat potong2"
- "4 lembar daun jeruk"
- "Seruas jshe"
- "2 batang sereh potong2"
- " Garam dan gula secukup nya"
- "1 sendok saos tiram"
- " Bumbu halus"
- "7 bawang merah"
- "5 bawang putih"
- "2 cm kunyit"
- "3 buah kemiri"
- "10 cabe merah"
- "8 cabe rawit"
recipeinstructions:
- "Cuci bersih sayap ayam,beri perasan jeruk nipis, diamkan beberapa saat, lalu cuci bersih"
- "Tumis bumbu halus,daun jeruk, jahe,sereh sampe wangi beri sedikit air,masukan ayam aduk rata lalu tutup"
- "Setelah ayam mateng beri garam,gula,saos tiram,cek rasa.lalu masukan daun bawang dan tomat masak sampe mateng,terakhir masukan daun kemangi"
- "Siap di sajikan dengan nasi"
categories:
- Recipe
tags:
- sayap
- ayam
- rica2

katakunci: sayap ayam rica2 
nutrition: 293 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Lunch

---


![Sayap ayam rica2 kemangi](https://img-global.cpcdn.com/recipes/76352658dda49c58/751x532cq70/sayap-ayam-rica2-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti sayap ayam rica2 kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Kita

Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Sayap ayam rica2 kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini!

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang dapat anda buat salah satunya sayap ayam rica2 kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep sayap ayam rica2 kemangi tanpa harus bersusah payah.
Berikut ini resep Sayap ayam rica2 kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sayap ayam rica2 kemangi:

1. Siapkan 10 sayap ayam
1. Jangan lupa 1 buah jeruk nipis
1. Siapkan 3 ikat daun kemangi ambil daun nya
1. Jangan lupa 2 batang daun bawang potong2
1. Siapkan 1 buah tomat potong2
1. Harap siapkan 4 lembar daun jeruk
1. Harus ada Seruas jshe
1. Siapkan 2 batang sereh potong2
1. Siapkan  Garam dan gula secukup nya
1. Dibutuhkan 1 sendok saos tiram
1. Siapkan  Bumbu halus
1. Siapkan 7 bawang merah
1. Jangan lupa 5 bawang putih
1. Harus ada 2 cm kunyit
1. Tambah 3 buah kemiri
1. Tambah 10 cabe merah
1. Diperlukan 8 cabe rawit


Sebenarnya, untuk membuat rica-rica ayam itu hampir sama dengan kita mengolah ayam pedas lainnya, mungkin saja jumlah bumbu yang digunakan lebih bervariasi seperti: cabai, kunyit, serai, bawang merah dan sebagainya. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat memanjakan lidah. Untuk anda yang bosan dengan masakan ayam yang itu-itu saja, anda bisa. 

<!--inarticleads2-->

##### Langkah membuat  Sayap ayam rica2 kemangi:

1. Cuci bersih sayap ayam,beri perasan jeruk nipis, diamkan beberapa saat, lalu cuci bersih
1. Tumis bumbu halus,daun jeruk, jahe,sereh sampe wangi beri sedikit air,masukan ayam aduk rata lalu tutup
1. Setelah ayam mateng beri garam,gula,saos tiram,cek rasa.lalu masukan daun bawang dan tomat masak sampe mateng,terakhir masukan daun kemangi
1. Siap di sajikan dengan nasi


Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat memanjakan lidah. Untuk anda yang bosan dengan masakan ayam yang itu-itu saja, anda bisa. Penjelasan lengkap seputar Resep Ayam Rica Rica Sederhana, Mudah, dan Praktis. Menggunakan Bumbu Pilihan dan Resep Tradisional dari Ayam rica-rica memang selalu memiliki tempat tersendiri dihati masyarakat Indonesia. Hanya dengan satu gigitan saja akan membuat semakin ketagihan. 

Demikianlah cara membuat sayap ayam rica2 kemangi yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan teruji, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
