---
description: "Resep : Sayap mercon rempah Teruji"
title: "Resep : Sayap mercon rempah Teruji"
slug: 263-resep-sayap-mercon-rempah-teruji
date: 2020-09-20T09:24:04.088Z
image: https://img-global.cpcdn.com/recipes/115e54e90531e04f/751x532cq70/sayap-mercon-rempah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/115e54e90531e04f/751x532cq70/sayap-mercon-rempah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/115e54e90531e04f/751x532cq70/sayap-mercon-rempah-foto-resep-utama.jpg
author: Lola Wallace
ratingvalue: 4
reviewcount: 24556
recipeingredient:
- "2 pasang sayap"
- "200 ml air"
- "3 sendok makan gula aren"
- "1 sendok teh garam"
- "1 sendok makan saos tiram"
- "5 lembar daun jeruk"
- "3 sendok makan minyak goreng"
- " Bumbu halus blenderulek"
- "8 siung bawang merah"
- "6 siung bawang putih"
- "1 buah cabai merah besar"
- "10 buah cabai rawit sesuai selera"
- "50 ml air"
recipeinstructions:
- "Haluskan semua bumbu"
- "Tumis bumbu halus dengan minyak goreng. Tambahkan daun jeruk. Aduk aduk hingga wangi"
- "Tambahkan gula aren, garam, dan saos tiram. Aduk rata"
- "Tambahkan ayam dan air. Aduk rata"
- "Masak hingga bumbu mengental. Koreksi rasa, jika dirasa sudah pas dan bumbu sudah mengental. Matikan api lalu sajikan"
- "Siap dinikmati"
categories:
- Recipe
tags:
- sayap
- mercon
- rempah

katakunci: sayap mercon rempah 
nutrition: 296 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Dessert

---


![Sayap mercon rempah](https://img-global.cpcdn.com/recipes/115e54e90531e04f/751x532cq70/sayap-mercon-rempah-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang harus kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti sayap mercon rempah yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan keistimewahan yang merupakan keragaman Indonesia



Kedekatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Sayap mercon rempah untuk keluarga. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda contoh salah satunya sayap mercon rempah yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep sayap mercon rempah tanpa harus bersusah payah.
Berikut ini resep Sayap mercon rempah yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sayap mercon rempah:

1. Siapkan 2 pasang sayap
1. Harus ada 200 ml air
1. Dibutuhkan 3 sendok makan gula aren
1. Tambah 1 sendok teh garam
1. Siapkan 1 sendok makan saos tiram
1. Jangan lupa 5 lembar daun jeruk
1. Harap siapkan 3 sendok makan minyak goreng
1. Dibutuhkan  Bumbu halus (blender/ulek)
1. Harap siapkan 8 siung bawang merah
1. Tambah 6 siung bawang putih
1. Dibutuhkan 1 buah cabai merah besar
1. Tambah 10 buah cabai rawit (sesuai selera)
1. Dibutuhkan 50 ml air




<!--inarticleads2-->

##### Langkah membuat  Sayap mercon rempah:

1. Haluskan semua bumbu
1. Tumis bumbu halus dengan minyak goreng. Tambahkan daun jeruk. Aduk aduk hingga wangi
1. Tambahkan gula aren, garam, dan saos tiram. Aduk rata
1. Tambahkan ayam dan air. Aduk rata
1. Masak hingga bumbu mengental. Koreksi rasa, jika dirasa sudah pas dan bumbu sudah mengental. Matikan api lalu sajikan
1. Siap dinikmati




Demikianlah cara membuat sayap mercon rempah yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
