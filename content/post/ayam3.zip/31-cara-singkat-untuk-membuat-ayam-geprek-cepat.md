---
description: "Cara singkat untuk membuat Ayam Geprek Cepat"
title: "Cara singkat untuk membuat Ayam Geprek Cepat"
slug: 31-cara-singkat-untuk-membuat-ayam-geprek-cepat
date: 2020-12-24T08:01:43.957Z
image: https://img-global.cpcdn.com/recipes/9ae27b1d4ed820d5/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9ae27b1d4ed820d5/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9ae27b1d4ed820d5/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Nannie Henderson
ratingvalue: 4.1
reviewcount: 42058
recipeingredient:
- "500 gr ayam potong"
- "1 sdm terigu"
- "500 ml minyak goreng"
- " Bahan pencelup "
- "7 sdm tepung terigu"
- "2 sdm tepung maizena"
- "2 siung bawang putih haluskan"
- "1 2 sdt garam"
- "1/2 sdt merica bubuk"
- "1/2 sdt kaldu bubuk"
- " Bahan pelapis"
- "7,5 gr terigu"
- "2 sdm tepung maizena"
- "1/2 sdt kaldu bubuk"
- " Bahan sambal"
- "15 bh cabe rawit"
- "2 siung bawang putih"
- "1/2 sdt garam"
- "1/2 sdt gula"
recipeinstructions:
- "Bersihkan ayam, potong² cuci beri 1 sdm terigu (fungsi terigu utk menghilangkan bau amis pd ayam) aduk², diamkan kurleb 10 mnt lalu bilas, tiriskan"
- "Campurkan semua bahan pencelup aduk rata, atur tingkat kekentalan adonan"
- "Celupkan ayam dlm bahan pencelup lalu diamkan dlm kulkas kurleb 30 mnt"
- "Aduk bahan pelapis, baluri ayam dgn pencelup ke bahan pelapis"
- "Goreng dlm minyak panas, angkat tiriskan"
- "Bahan sambal : celup sebentar cabe dlm air panas, segera tiriskan ulek kasar cabe, bawang, garam dan gula, lalu siram minyak panas yg sdh di panaskan terlebih dulu, cicip rasa"
- "Siapkan ayam krispy, geprek di atas sambal bawang, siap di sajikan"
- "Mudah bukan membuatnya"
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 210 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/9ae27b1d4ed820d5/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam geprek yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Kita

Keharmonisan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah memasak Ayam Geprek untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang bisa anda coba salah satunya ayam geprek yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam geprek tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek:

1. Harap siapkan 500 gr ayam potong²
1. Jangan lupa 1 sdm terigu
1. Jangan lupa 500 ml minyak goreng
1. Dibutuhkan  Bahan pencelup :
1. Diperlukan 7 sdm tepung terigu
1. Tambah 2 sdm tepung maizena
1. Tambah 2 siung bawang putih haluskan
1. Dibutuhkan 1 /2 sdt garam
1. Diperlukan 1/2 sdt merica bubuk
1. Diperlukan 1/2 sdt kaldu bubuk
1. Jangan lupa  Bahan pelapis
1. Diperlukan 7,5 gr terigu
1. Tambah 2 sdm tepung maizena
1. Siapkan 1/2 sdt kaldu bubuk
1. Jangan lupa  Bahan sambal
1. Diperlukan 15 bh cabe rawit
1. Harus ada 2 siung bawang putih
1. Jangan lupa 1/2 sdt garam
1. Tambah 1/2 sdt gula




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek:

1. Bersihkan ayam, potong² cuci beri 1 sdm terigu (fungsi terigu utk menghilangkan bau amis pd ayam) aduk², diamkan kurleb 10 mnt lalu bilas, tiriskan
1. Campurkan semua bahan pencelup aduk rata, atur tingkat kekentalan adonan
1. Celupkan ayam dlm bahan pencelup lalu diamkan dlm kulkas kurleb 30 mnt
1. Aduk bahan pelapis, baluri ayam dgn pencelup ke bahan pelapis
1. Goreng dlm minyak panas, angkat tiriskan
1. Bahan sambal : celup sebentar cabe dlm air panas, segera tiriskan ulek kasar cabe, bawang, garam dan gula, lalu siram minyak panas yg sdh di panaskan terlebih dulu, cicip rasa
1. Siapkan ayam krispy, geprek di atas sambal bawang, siap di sajikan
1. Mudah bukan membuatnya




Demikianlah cara membuat ayam geprek yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
