---
description: "Panduan menyiapakan Ayam Rica Sederhana Teruji"
title: "Panduan menyiapakan Ayam Rica Sederhana Teruji"
slug: 490-panduan-menyiapakan-ayam-rica-sederhana-teruji
date: 2020-11-16T17:02:30.859Z
image: https://img-global.cpcdn.com/recipes/87a89a806573fcbb/751x532cq70/ayam-rica-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/87a89a806573fcbb/751x532cq70/ayam-rica-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/87a89a806573fcbb/751x532cq70/ayam-rica-sederhana-foto-resep-utama.jpg
author: Mike Fox
ratingvalue: 5
reviewcount: 3833
recipeingredient:
- "500 gram ayam saya bgian sayap"
- "5 lembar daun jeruk"
- "1 lembar daun salam"
- "2 batang serai"
- "secukupnya Kunyit bubuk"
- "secukupnya Lada"
- "secukupnya Garam"
- " Air"
- " Minyak goreng"
- " Bumbu halus"
- "7 siung bawang merah"
- "4 siung bawang putih"
- "1/2 sdt ketumbar"
- " Cabe uleg kasar"
- "15-20 cabai rawit uleg kasar"
recipeinstructions:
- "Cuci bersih ayam, potong sesuai selera, sisihkan. Siapkan bumbunya."
- "Uleg bumbu halus, geprek serai. Tumis bumbu halus sampai wangi. Masukkan serai dan daun salam. Setelah layu masukkan kunyit bubuk oseng2."
- "Setelah itu masukkan ayam, oseng sebentar, lalu masukkan air, ungkep ayam sampai setengah mateng."
- "Uleg kasar cabai, cuci daun jeruk. Masukkan daun jeruk ke dalam ungkepan ayam. Masukkan cabainya. Tambah garam dan lada. Cek rasa. Biarkan ayam benar2 empuk dan air menyusut."
categories:
- Recipe
tags:
- ayam
- rica
- sederhana

katakunci: ayam rica sederhana 
nutrition: 124 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT44M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica Sederhana](https://img-global.cpcdn.com/recipes/87a89a806573fcbb/751x532cq70/ayam-rica-sederhana-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang dapat kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica sederhana yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Indonesia



Keharmonisan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Sederhana untuk keluarga. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang dapat anda contoh salah satunya ayam rica sederhana yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica sederhana tanpa harus bersusah payah.
Seperti resep Ayam Rica Sederhana yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Sederhana:

1. Jangan lupa 500 gram ayam (saya bgian sayap)
1. Jangan lupa 5 lembar daun jeruk
1. Diperlukan 1 lembar daun salam
1. Dibutuhkan 2 batang serai
1. Harus ada secukupnya Kunyit bubuk
1. Jangan lupa secukupnya Lada
1. Tambah secukupnya Garam
1. Dibutuhkan  Air
1. Diperlukan  Minyak goreng
1. Diperlukan  Bumbu halus
1. Jangan lupa 7 siung bawang merah
1. Tambah 4 siung bawang putih
1. Jangan lupa 1/2 sdt ketumbar
1. Tambah  Cabe uleg kasar
1. Harap siapkan 15-20 cabai rawit uleg kasar




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Sederhana:

1. Cuci bersih ayam, potong sesuai selera, sisihkan. Siapkan bumbunya.
1. Uleg bumbu halus, geprek serai. Tumis bumbu halus sampai wangi. Masukkan serai dan daun salam. Setelah layu masukkan kunyit bubuk oseng2.
1. Setelah itu masukkan ayam, oseng sebentar, lalu masukkan air, ungkep ayam sampai setengah mateng.
1. Uleg kasar cabai, cuci daun jeruk. Masukkan daun jeruk ke dalam ungkepan ayam. Masukkan cabainya. Tambah garam dan lada. Cek rasa. Biarkan ayam benar2 empuk dan air menyusut.




Demikianlah cara membuat ayam rica sederhana yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
