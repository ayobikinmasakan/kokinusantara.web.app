---
description: "Langkah untuk menyiapakan Ayam Geprek (nasi box simple) minggu ini"
title: "Langkah untuk menyiapakan Ayam Geprek (nasi box simple) minggu ini"
slug: 101-langkah-untuk-menyiapakan-ayam-geprek-nasi-box-simple-minggu-ini
date: 2020-10-06T17:07:42.777Z
image: https://img-global.cpcdn.com/recipes/242c5731d6f309e0/751x532cq70/ayam-geprek-nasi-box-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/242c5731d6f309e0/751x532cq70/ayam-geprek-nasi-box-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/242c5731d6f309e0/751x532cq70/ayam-geprek-nasi-box-simple-foto-resep-utama.jpg
author: Jean Morris
ratingvalue: 4.6
reviewcount: 38671
recipeingredient:
- "3 kg dada ayam fillet"
- "1 kg tepung protein tinggi"
- "8 gram lada bubuk"
- "Secukupnya penyedap rasa"
- "Secukupnya garam"
- "1 bungkus UKsedang tepung bumbu serbaguna opsional"
- "2 sdt soda kue"
- "Secukupnya bawang putih bubuk"
- " Minyak goreng"
- "6 siung bawang putih"
- " Air es"
recipeinstructions:
- "Potong tipis- tipis dada ayam, kemudian marinasi dengan bawang putih yang sudah dihaluskan dengan garam dan lada, masukkan didalam kulkas minimal 2 jam agar bumbu meresap"
- "Campur tepung, lada bubuk, bawang putih bubuk, penyedap rasa, soda kue, tepung bumbu serbaguna, garam..aduk hingga tercampur rata"
- "Ambil sedikit campuran tepung tadi, dan beri air es sucukupnya untuk bahan pencelup"
- "Panaskan minyak didalam panci, saran saya pakai panci atau wajan yang kecil agar saat menggoreng bisa tercelup minyak semua dan hasil maksimal"
- "Stlah ayam 2jam didalam kulkas dan sambil menunggu minyak panas,celupkan ayam diadonan kering dulu kemudian adonan basah kemudian kering, basah dan terakhir kering tebaskan adonan agar tepung yang tidak menempel bisa rontok dan sampai adonan terlihat keriting"
- "Goreng diminyak yang benar benar sudah panas...tunggu sampai matang...selamat mencoba"
categories:
- Recipe
tags:
- ayam
- geprek
- nasi

katakunci: ayam geprek nasi 
nutrition: 171 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Geprek (nasi box simple)](https://img-global.cpcdn.com/recipes/242c5731d6f309e0/751x532cq70/ayam-geprek-nasi-box-simple-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap daerah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam geprek (nasi box simple) yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Kita



Kehangatan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam Geprek (nasi box simple) untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda praktekkan salah satunya ayam geprek (nasi box simple) yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam geprek (nasi box simple) tanpa harus bersusah payah.
Seperti resep Ayam Geprek (nasi box simple) yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 11 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek (nasi box simple):

1. Diperlukan 3 kg dada ayam fillet
1. Siapkan 1 kg tepung protein tinggi
1. Harus ada 8 gram lada bubuk
1. Siapkan Secukupnya penyedap rasa
1. Harap siapkan Secukupnya garam
1. Diperlukan 1 bungkus (UK.sedang) tepung bumbu serbaguna (opsional)
1. Diperlukan 2 sdt soda kue
1. Harap siapkan Secukupnya bawang putih bubuk
1. Harap siapkan  Minyak goreng
1. Harus ada 6 siung bawang putih
1. Harap siapkan  Air es




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek (nasi box simple):

1. Potong tipis- tipis dada ayam, kemudian marinasi dengan bawang putih yang sudah dihaluskan dengan garam dan lada, masukkan didalam kulkas minimal 2 jam agar bumbu meresap
1. Campur tepung, lada bubuk, bawang putih bubuk, penyedap rasa, soda kue, tepung bumbu serbaguna, garam..aduk hingga tercampur rata
1. Ambil sedikit campuran tepung tadi, dan beri air es sucukupnya untuk bahan pencelup
1. Panaskan minyak didalam panci, saran saya pakai panci atau wajan yang kecil agar saat menggoreng bisa tercelup minyak semua dan hasil maksimal
1. Stlah ayam 2jam didalam kulkas dan sambil menunggu minyak panas,celupkan ayam diadonan kering dulu kemudian adonan basah kemudian kering, basah dan terakhir kering tebaskan adonan agar tepung yang tidak menempel bisa rontok dan sampai adonan terlihat keriting
1. Goreng diminyak yang benar benar sudah panas...tunggu sampai matang...selamat mencoba




Demikianlah cara membuat ayam geprek (nasi box simple) yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan cepat, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
