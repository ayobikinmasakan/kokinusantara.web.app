---
description: "Resep : Ayam Geprek Pol Pedes Luar biasa"
title: "Resep : Ayam Geprek Pol Pedes Luar biasa"
slug: 35-resep-ayam-geprek-pol-pedes-luar-biasa
date: 2021-01-13T00:35:27.765Z
image: https://img-global.cpcdn.com/recipes/7fc757ed1871e053/751x532cq70/ayam-geprek-pol-pedes-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7fc757ed1871e053/751x532cq70/ayam-geprek-pol-pedes-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7fc757ed1871e053/751x532cq70/ayam-geprek-pol-pedes-foto-resep-utama.jpg
author: Phillip Berry
ratingvalue: 4
reviewcount: 15438
recipeingredient:
- "1/4 kg ayam"
- " Bumbu ayam ungkep"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "1 batang sereh geprek"
- "3 lembar daun jeruk"
- "2 lembar daun salam"
- " Gula"
- " Garam"
- " Kaldu bubuk"
- " Ketumbar bubuk"
- " Kunyit bubuk"
- " Tepung serbaguna"
- " Sambel geprek"
- "12 buah cabe setan atau lebih"
- " Garam"
- " Penyedap"
- "1 siung bawang putih"
recipeinstructions:
- "Potong ayam kemudian cuci sampai bersih."
- "Haluskan bumbu ungkep (bawang merah, bawang putih), masukkan kedalam panci yang berisi air. Tambahkan gula garam, penyedap, sereh geprek, daun jeruk, dan salam. Aduk dan ungkep sampai meresap."
- "Setelah matang, angkat sampai agak dingin. Kemudian lumuri dengan tepung serbaguna lalu goreng."
- "Sambil nunggu ayamnya digoreng, bikin sambal gepreknya yang super gampil. Ambil cabe setan sesuai selera, bawang putih 1 siung, penyedap, dan garam. Setelah itu ulek kasar. Biar tambah mantul bisa dikasih minyak goreng bekas goreng ayam tadi 2 sendok aja."
- "Letakkan ayam diatas sambal geprek, kemudian geprek ayamnya. Sajikan dengan nasi panas.😉"
categories:
- Recipe
tags:
- ayam
- geprek
- pol

katakunci: ayam geprek pol 
nutrition: 166 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Geprek Pol Pedes](https://img-global.cpcdn.com/recipes/7fc757ed1871e053/751x532cq70/ayam-geprek-pol-pedes-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan gurih. Karasteristik masakan Nusantara ayam geprek pol pedes yang penuh dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kedekatan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Geprek Pol Pedes untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang dapat anda praktekkan salah satunya ayam geprek pol pedes yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam geprek pol pedes tanpa harus bersusah payah.
Seperti resep Ayam Geprek Pol Pedes yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Pol Pedes:

1. Harap siapkan 1/4 kg ayam
1. Tambah  Bumbu ayam ungkep
1. Diperlukan 4 siung bawang merah
1. Jangan lupa 3 siung bawang putih
1. Diperlukan 1 batang sereh, geprek
1. Harus ada 3 lembar daun jeruk
1. Dibutuhkan 2 lembar daun salam
1. Dibutuhkan  Gula
1. Harus ada  Garam
1. Diperlukan  Kaldu bubuk
1. Dibutuhkan  Ketumbar bubuk
1. Jangan lupa  Kunyit bubuk
1. Tambah  Tepung serbaguna
1. Dibutuhkan  Sambel geprek
1. Harus ada 12 buah cabe setan atau lebih
1. Diperlukan  Garam
1. Harap siapkan  Penyedap
1. Tambah 1 siung bawang putih




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek Pol Pedes:

1. Potong ayam kemudian cuci sampai bersih.
1. Haluskan bumbu ungkep (bawang merah, bawang putih), masukkan kedalam panci yang berisi air. Tambahkan gula garam, penyedap, sereh geprek, daun jeruk, dan salam. Aduk dan ungkep sampai meresap.
1. Setelah matang, angkat sampai agak dingin. Kemudian lumuri dengan tepung serbaguna lalu goreng.
1. Sambil nunggu ayamnya digoreng, bikin sambal gepreknya yang super gampil. Ambil cabe setan sesuai selera, bawang putih 1 siung, penyedap, dan garam. Setelah itu ulek kasar. Biar tambah mantul bisa dikasih minyak goreng bekas goreng ayam tadi 2 sendok aja.
1. Letakkan ayam diatas sambal geprek, kemudian geprek ayamnya. Sajikan dengan nasi panas.😉




Demikianlah cara membuat ayam geprek pol pedes yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan terbukti, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
