---
description: "Resep : Ayam Geprek Tomat Goreng Sempurna"
title: "Resep : Ayam Geprek Tomat Goreng Sempurna"
slug: 174-resep-ayam-geprek-tomat-goreng-sempurna
date: 2020-10-10T17:28:59.166Z
image: https://img-global.cpcdn.com/recipes/51bf6c5aa41957b8/751x532cq70/ayam-geprek-tomat-goreng-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/51bf6c5aa41957b8/751x532cq70/ayam-geprek-tomat-goreng-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/51bf6c5aa41957b8/751x532cq70/ayam-geprek-tomat-goreng-foto-resep-utama.jpg
author: Luke Collier
ratingvalue: 4.8
reviewcount: 49501
recipeingredient:
- "1/2 kg paha ayam cuci bersih"
- "1 buah tomat ukuran besar"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "23 biji cabai rawit"
- "2 sdm Tepung kanji"
- "4 sdm Tepung Terigu"
- "1 bungkus tepung bumbu serbaguna"
- "Secukupnya garam"
- " Minyak untuk menggoreng"
recipeinstructions:
- "Sediakan semua bahan.. Bahan tepung campurkan jdi satu dan ditambahkan sedikit garam.. Untuk paha ayam setelah dicuci bersih lumuri dengan sedikit garam.. Lalu diamkan."
- "Untuk bahan Bumbu.. Goreng terlebih dahulu.. Jadi pada saat di ulek lebih mudah dihaluskan... Setelah di goreng dan dihaluskan.. Masak bumbu sampai bner2 matang... Agar sambal tahan lama.. Usahakan pada saat menggoreng sambal jgn tambahkan minyak goreng dulu... Biarkan sampe sambelnya sedikit kering.. Barulah minyak ditambahkan secukupnya.. Masak hingga bner2 matang sempurna.."
- "Buat adonan tepung menjadi 2 bagian... Adonan basah dan adonan kering.. Lumuri ayam dengan adonan basah.. Uleni hingga semua tercampur rata.. Kemudian celupkan satu persatu ke adonan kering sambil ditekan2 dan diremas2..."
- "Karena ayam masih dlm keadaan mentah.. Tdk di rebus... Jadi pada saat menggoreng.. Usahakan minyak benar-benar panas, gunakan api kecil.. Agar tingkat kematangan ayam sempurna.. Saran : lebih baik wajan ditutup saja.. Kalau minyak yg digunakan sedikit.. Matangnya merata.."
- "Letakkan ayam pada sambel.. Lalu di geprek 2... Ayam Geprek Tomat Goreng siap di santap..."
categories:
- Recipe
tags:
- ayam
- geprek
- tomat

katakunci: ayam geprek tomat 
nutrition: 201 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Geprek Tomat Goreng](https://img-global.cpcdn.com/recipes/51bf6c5aa41957b8/751x532cq70/ayam-geprek-tomat-goreng-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam geprek tomat goreng yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia



Keharmonisan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Ayam Geprek Tomat Goreng untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang bisa anda coba salah satunya ayam geprek tomat goreng yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam geprek tomat goreng tanpa harus bersusah payah.
Seperti resep Ayam Geprek Tomat Goreng yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Tomat Goreng:

1. Siapkan 1/2 kg paha ayam, cuci bersih
1. Dibutuhkan 1 buah tomat ukuran besar
1. Tambah 6 siung bawang merah
1. Jangan lupa 4 siung bawang putih
1. Harap siapkan 23 biji cabai rawit
1. Dibutuhkan 2 sdm Tepung kanji
1. Siapkan 4 sdm Tepung Terigu
1. Dibutuhkan 1 bungkus tepung bumbu serbaguna
1. Siapkan Secukupnya garam
1. Harus ada  Minyak untuk menggoreng




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek Tomat Goreng:

1. Sediakan semua bahan.. Bahan tepung campurkan jdi satu dan ditambahkan sedikit garam.. Untuk paha ayam setelah dicuci bersih lumuri dengan sedikit garam.. Lalu diamkan.
1. Untuk bahan Bumbu.. Goreng terlebih dahulu.. Jadi pada saat di ulek lebih mudah dihaluskan... Setelah di goreng dan dihaluskan.. Masak bumbu sampai bner2 matang... Agar sambal tahan lama.. Usahakan pada saat menggoreng sambal jgn tambahkan minyak goreng dulu... Biarkan sampe sambelnya sedikit kering.. Barulah minyak ditambahkan secukupnya.. Masak hingga bner2 matang sempurna..
1. Buat adonan tepung menjadi 2 bagian... Adonan basah dan adonan kering.. Lumuri ayam dengan adonan basah.. Uleni hingga semua tercampur rata.. Kemudian celupkan satu persatu ke adonan kering sambil ditekan2 dan diremas2...
1. Karena ayam masih dlm keadaan mentah.. Tdk di rebus... Jadi pada saat menggoreng.. Usahakan minyak benar-benar panas, gunakan api kecil.. Agar tingkat kematangan ayam sempurna.. Saran : lebih baik wajan ditutup saja.. Kalau minyak yg digunakan sedikit.. Matangnya merata..
1. Letakkan ayam pada sambel.. Lalu di geprek 2... Ayam Geprek Tomat Goreng siap di santap...




Demikianlah cara membuat ayam geprek tomat goreng yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
