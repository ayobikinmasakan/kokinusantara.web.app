---
description: "Steps membuat Sayap Ayam Mercon Favorite"
title: "Steps membuat Sayap Ayam Mercon Favorite"
slug: 257-steps-membuat-sayap-ayam-mercon-favorite
date: 2020-08-24T21:54:42.801Z
image: https://img-global.cpcdn.com/recipes/d2634d568171e823/751x532cq70/sayap-ayam-mercon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d2634d568171e823/751x532cq70/sayap-ayam-mercon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d2634d568171e823/751x532cq70/sayap-ayam-mercon-foto-resep-utama.jpg
author: Eula Harrington
ratingvalue: 4.1
reviewcount: 39307
recipeingredient:
- "4 sayap ayam ungkep"
- "10 buah cabe rawit bisa disesuaikan tingkat kepedasannya"
- "5 buah cabe keriting merah"
- "8 buah bawang merah"
- "2 siung bawang putih"
- "1 buah sereh"
- "1 ruas lengkuas"
- "  200 cc air putih"
- "1 lembar daun salam"
- "2 lembar daun jeruk"
- "1/4 buah air lemon bisa diganti jeruk nipislimau"
- "1 sendok makan makan garam"
- "1 sendok makan garam gula"
- "1/2 bungkus Royco ayam disesuaikan"
recipeinstructions:
- "Goreng sayap ungkep ke dalam minyak panas sampai agak kecoklatan lalu tiriskan"
- "Haluskan cabe rawit, cabe keriting merah, bawang merah dan bawang putih (bisa diuleg/blender)"
- "Geprek lengkuas dan sereh"
- "Masukkan 3 sendok makan minyak goreng, lalu tumis bumbu halus tadi sampai harum"
- "Setelah harum, tambahkan geprekan lengkuas, sereh, daun salam dan daun jeruk"
- "Tumis hingga harum rempah-rempah mulai tercium, lalu tambahkan air dan air lemon. Setelah itu masukkan garam, gula dan royco ayam. Jangan lupa untuk selalu koreksi rasa"
- "Setelah air mendidih, masukkan sayap ayam goreng, lalu diamkan hingga air mulai surut"
- "Ketika air sudah surut dan seluruh bagian sayap ayam sudah dilumuri oleh sambal, sayap ayam bisa dapat disajikan"
categories:
- Recipe
tags:
- sayap
- ayam
- mercon

katakunci: sayap ayam mercon 
nutrition: 197 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Dinner

---


![Sayap Ayam Mercon](https://img-global.cpcdn.com/recipes/d2634d568171e823/751x532cq70/sayap-ayam-mercon-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti sayap ayam mercon yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Indonesia



Keharmonisan rumah tangga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Sayap Ayam Mercon untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang bisa anda buat salah satunya sayap ayam mercon yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep sayap ayam mercon tanpa harus bersusah payah.
Berikut ini resep Sayap Ayam Mercon yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sayap Ayam Mercon:

1. Dibutuhkan 4 sayap ayam ungkep
1. Harus ada 10 buah cabe rawit (bisa disesuaikan tingkat kepedasannya)
1. Diperlukan 5 buah cabe keriting merah
1. Harap siapkan 8 buah bawang merah
1. Jangan lupa 2 siung bawang putih
1. Siapkan 1 buah sereh
1. Harus ada 1 ruas lengkuas
1. Harap siapkan  /- 200 cc air putih
1. Tambah 1 lembar daun salam
1. Jangan lupa 2 lembar daun jeruk
1. Jangan lupa 1/4 buah air lemon (bisa diganti jeruk nipis/limau)
1. Jangan lupa 1 sendok makan makan garam
1. Harap siapkan 1 sendok makan garam gula
1. Harap siapkan 1/2 bungkus Royco ayam (disesuaikan)




<!--inarticleads2-->

##### Bagaimana membuat  Sayap Ayam Mercon:

1. Goreng sayap ungkep ke dalam minyak panas sampai agak kecoklatan lalu tiriskan
1. Haluskan cabe rawit, cabe keriting merah, bawang merah dan bawang putih (bisa diuleg/blender)
1. Geprek lengkuas dan sereh
1. Masukkan 3 sendok makan minyak goreng, lalu tumis bumbu halus tadi sampai harum
1. Setelah harum, tambahkan geprekan lengkuas, sereh, daun salam dan daun jeruk
1. Tumis hingga harum rempah-rempah mulai tercium, lalu tambahkan air dan air lemon. Setelah itu masukkan garam, gula dan royco ayam. Jangan lupa untuk selalu koreksi rasa
1. Setelah air mendidih, masukkan sayap ayam goreng, lalu diamkan hingga air mulai surut
1. Ketika air sudah surut dan seluruh bagian sayap ayam sudah dilumuri oleh sambal, sayap ayam bisa dapat disajikan




Demikianlah cara membuat sayap ayam mercon yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan terbukti, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
