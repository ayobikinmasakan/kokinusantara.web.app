---
description: "Resep : Ayam Geprek Luar biasa"
title: "Resep : Ayam Geprek Luar biasa"
slug: 44-resep-ayam-geprek-luar-biasa
date: 2020-08-14T15:02:20.244Z
image: https://img-global.cpcdn.com/recipes/227d22b51ca62dc7/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/227d22b51ca62dc7/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/227d22b51ca62dc7/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Steven Johnson
ratingvalue: 4.6
reviewcount: 6158
recipeingredient:
- "400 gram Ayam bagian dada"
- "200 gram tepung terigu"
- "50 gram Maizena"
- "1 sdm garam"
- "1 sdt lada bubuk"
- " Minyak untuk menggoreng"
- " Bahan sambal"
- "100 gram Cabe merah"
- "5 buah cabe rawit"
- "3 siung bawang putih"
- "1 sdt garam"
- "1 sdt Kaldu jamur"
recipeinstructions:
- "Potong-potong ayam tipis dan memanjang, atau sesuai selera, balur dengan sedikit lada dan garam. Diamkan 30menit."
- "Tambahkan 100gram tepung dan sedikit maizena, garam dan lada bubuk. Gaulkan merata keseluruh permukaan ayam."
- "Panaskan minyak banyak, api sedang, Sembari menunggu minyak panas, ayam akan lembab dan tepung menjadi lengket ke ayam, tambahkan sisa tepung dan maizena, aduk-aduk terus sampai semua terbalut tepung kering. Lalu angkat,sambil ditepuk-tepuk ke pinggiran wadah, lalu goreng. Untuk sisa potongan ayam kecil2, bisa disaring agar mudah digoreng, yang ini jadi favorit ana, Kriuk 2 soalnya. Sisa tepungnya jangan dibuang ya, bisa dimasukkan plastik, taruh dikulkas, kapan-kapan bisa dijadikan bahan bakwan"
- "Setelah matang, angkat, tiriskan."
- "Untuk bahan sambal, haluskan cabe merah cabe rawit bawang merah dan bawang putih."
- "Panaskan minyak, gunakan api kecil tumis bahan sambal sebentar saja. Tambahkan garam dan kaldu jamur. Aduk rata. Angkat."
- "Terakhir. Geprek sambal diatas ayam crispy. Siap disajikan."
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 242 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/227d22b51ca62dc7/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan gurih. Ciri khas masakan Indonesia ayam geprek yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan keluarga bisa didapat dengan cara simple. Diantaranya adalah memasak Ayam Geprek untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang bisa anda buat salah satunya ayam geprek yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam geprek tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek:

1. Dibutuhkan 400 gram Ayam bagian dada
1. Jangan lupa 200 gram tepung terigu
1. Dibutuhkan 50 gram Maizena
1. Harus ada 1 sdm garam
1. Tambah 1 sdt lada bubuk
1. Harus ada  Minyak untuk menggoreng
1. Harus ada  Bahan sambal
1. Diperlukan 100 gram Cabe merah
1. Siapkan 5 buah cabe rawit
1. Harus ada 3 siung bawang putih
1. Tambah 1 sdt garam
1. Harus ada 1 sdt Kaldu jamur




<!--inarticleads2-->

##### Instruksi membuat  Ayam Geprek:

1. Potong-potong ayam tipis dan memanjang, atau sesuai selera, balur dengan sedikit lada dan garam. Diamkan 30menit.
1. Tambahkan 100gram tepung dan sedikit maizena, garam dan lada bubuk. Gaulkan merata keseluruh permukaan ayam.
1. Panaskan minyak banyak, api sedang, Sembari menunggu minyak panas, ayam akan lembab dan tepung menjadi lengket ke ayam, tambahkan sisa tepung dan maizena, aduk-aduk terus sampai semua terbalut tepung kering. Lalu angkat,sambil ditepuk-tepuk ke pinggiran wadah, lalu goreng. Untuk sisa potongan ayam kecil2, bisa disaring agar mudah digoreng, yang ini jadi favorit ana, Kriuk 2 soalnya. Sisa tepungnya jangan dibuang ya, bisa dimasukkan plastik, taruh dikulkas, kapan-kapan bisa dijadikan bahan bakwan
1. Setelah matang, angkat, tiriskan.
1. Untuk bahan sambal, haluskan cabe merah cabe rawit bawang merah dan bawang putih.
1. Panaskan minyak, gunakan api kecil tumis bahan sambal sebentar saja. Tambahkan garam dan kaldu jamur. Aduk rata. Angkat.
1. Terakhir. Geprek sambal diatas ayam crispy. Siap disajikan.




Demikianlah cara membuat ayam geprek yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
