---
description: "Step-by-Step menyiapakan Ayam geprek sederhana Sempurna"
title: "Step-by-Step menyiapakan Ayam geprek sederhana Sempurna"
slug: 55-step-by-step-menyiapakan-ayam-geprek-sederhana-sempurna
date: 2020-10-07T11:46:40.680Z
image: https://img-global.cpcdn.com/recipes/ab53a29bc814fdfa/751x532cq70/ayam-geprek-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ab53a29bc814fdfa/751x532cq70/ayam-geprek-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ab53a29bc814fdfa/751x532cq70/ayam-geprek-sederhana-foto-resep-utama.jpg
author: Joe Simmons
ratingvalue: 4.9
reviewcount: 11713
recipeingredient:
- " ambil bagian dada 5"
- " Tepung bumbu sajiku"
- "5 butir Bawang merah"
- "6 siung Bawang putih"
- "6 biji Cabe tiung"
- " Garam"
- " Gula"
- " Bumbu ayam"
- "3 butir Bawang habang"
- "4 siung Bawang putih"
- " Ketumbar"
- " Kunyit"
- " Kencur"
- " Jahe"
- " Royko sapi"
recipeinstructions:
- "Bumbu ayam, bawang merah, putih, kunyit, jahe, ketumbar, kencur dihaluskan setelah itu rendam potongan dada ayam setelah dicuci bersih dan dikasih garam selama 1 jam masukan dlm lemari es"
- "Siapkan es batu masukan ayam yg sdh dibumbui kedlm es batu sambil memanaskan minyak dlm wajan"
- "Masukan ayam kedlm tepung saji ku trus celupkan lagi kees batu yg sdh ada air nya.. Kembali masukan lagi ketepung saji ku biar ayam renyah dan crispy... Langsung cemplung ya keminyak goreng"
- "Siapkan bumbu geprek"
- "Siapkan cobek masukan bawang merah 5 butir, dan putih 6 siung, ulek sebentar lalu masukan cabe sesuai selera atau level ya tambahkan royko sapi, garam, gula sesuai selera, kalau tdk suka sambal mentah bawang bisa digoreng ya kalau saya suka mentah krn aroma nya khas berasa"
- "Begitu ayam masak jng ditiriskan langsung masukan kecobek geprek ya kalau suka asem kasih perasan jeruk nipis biar segar"
categories:
- Recipe
tags:
- ayam
- geprek
- sederhana

katakunci: ayam geprek sederhana 
nutrition: 137 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam geprek sederhana](https://img-global.cpcdn.com/recipes/ab53a29bc814fdfa/751x532cq70/ayam-geprek-sederhana-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan empuk. Karasteristik makanan Nusantara ayam geprek sederhana yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam geprek sederhana untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis makanan yang dapat anda buat salah satunya ayam geprek sederhana yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep ayam geprek sederhana tanpa harus bersusah payah.
Seperti resep Ayam geprek sederhana yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek sederhana:

1. Jangan lupa  ambil bagian dada 5
1. Diperlukan  Tepung bumbu sajiku
1. Tambah 5 butir Bawang merah
1. Siapkan 6 siung Bawang putih
1. Tambah 6 biji Cabe tiung
1. Harap siapkan  Garam
1. Harap siapkan  Gula
1. Harus ada  Bumbu ayam
1. Harus ada 3 butir Bawang habang
1. Jangan lupa 4 siung Bawang putih
1. Jangan lupa  Ketumbar
1. Dibutuhkan  Kunyit
1. Dibutuhkan  Kencur
1. Dibutuhkan  Jahe
1. Harus ada  Royko sapi




<!--inarticleads2-->

##### Instruksi membuat  Ayam geprek sederhana:

1. Bumbu ayam, bawang merah, putih, kunyit, jahe, ketumbar, kencur dihaluskan setelah itu rendam potongan dada ayam setelah dicuci bersih dan dikasih garam selama 1 jam masukan dlm lemari es
1. Siapkan es batu masukan ayam yg sdh dibumbui kedlm es batu sambil memanaskan minyak dlm wajan
1. Masukan ayam kedlm tepung saji ku trus celupkan lagi kees batu yg sdh ada air nya.. Kembali masukan lagi ketepung saji ku biar ayam renyah dan crispy... Langsung cemplung ya keminyak goreng
1. Siapkan bumbu geprek
1. Siapkan cobek masukan bawang merah 5 butir, dan putih 6 siung, ulek sebentar lalu masukan cabe sesuai selera atau level ya tambahkan royko sapi, garam, gula sesuai selera, kalau tdk suka sambal mentah bawang bisa digoreng ya kalau saya suka mentah krn aroma nya khas berasa
1. Begitu ayam masak jng ditiriskan langsung masukan kecobek geprek ya kalau suka asem kasih perasan jeruk nipis biar segar




Demikianlah cara membuat ayam geprek sederhana yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
