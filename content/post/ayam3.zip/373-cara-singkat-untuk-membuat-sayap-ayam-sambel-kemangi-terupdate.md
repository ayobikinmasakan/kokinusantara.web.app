---
description: "Cara singkat untuk membuat Sayap Ayam Sambel Kemangi terupdate"
title: "Cara singkat untuk membuat Sayap Ayam Sambel Kemangi terupdate"
slug: 373-cara-singkat-untuk-membuat-sayap-ayam-sambel-kemangi-terupdate
date: 2020-08-29T07:32:02.975Z
image: https://img-global.cpcdn.com/recipes/32c2731bb45a6d78/751x532cq70/sayap-ayam-sambel-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/32c2731bb45a6d78/751x532cq70/sayap-ayam-sambel-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/32c2731bb45a6d78/751x532cq70/sayap-ayam-sambel-kemangi-foto-resep-utama.jpg
author: Claudia Pittman
ratingvalue: 4.7
reviewcount: 21314
recipeingredient:
- " Bahan Ayam Marinasi"
- "10 potong sayap ayam"
- "3 siung bawang putih"
- "1 sdt ketumbar"
- "1 sdt garam"
- "0,5 sdt penyedap rasa"
- "Secukupnya air"
- "Secukupnya minyak"
- " Bahan Sambel "
- "4 siung bawang merah"
- "3 siung bawang putih"
- "15 buah cabe rawit merah"
- "8 buah cabe kriting merah"
- "Secukupnya kemangi"
- "1,5 sdt garam"
- "1 sdt penyedap rasa"
- "0,5 sdt gula pasir  gula jawa"
- "Sedikit minyak"
recipeinstructions:
- "Cuci bersih sayap ayam. Haluskan 3 siung bawang putih dan ketumbar"
- "Siapkan panci, masukkan sayap ayam, bumbu yang udah dihaluskan, garam, penyedap rasa, dan air sampai sayap ayamnya tenggelam semua, didihkan sampai bumbu meresap ke ayam"
- "Sambil memarinasi ayam, haluskan duo bawang dan duo cabe dari bahan sambel. Ambil bagian daun kemangi saja lalu cuci bersih"
- "Jika kira kira bumbu ayam udah meresap, matikan api, lalu goreng ayam hingga kuning keemasan"
- "Sisakan sedikit minyak setelah goreng ayam, tumis bahan sambel yang udah dihaluskan. Tambahkan garam, gula, dan penyedap rasa. Tumis hingga matang dan tidak ada kandungan airnya"
- "Cek rasa. Jika rasanya udah pas, masukkam kemangi, tumis bentar langsung tambahkan ayam yang udah digoreng"
- "Aduk sampe tercampur rata. Lalu siap disajikan 😊"
categories:
- Recipe
tags:
- sayap
- ayam
- sambel

katakunci: sayap ayam sambel 
nutrition: 184 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Dinner

---


![Sayap Ayam Sambel Kemangi](https://img-global.cpcdn.com/recipes/32c2731bb45a6d78/751x532cq70/sayap-ayam-sambel-kemangi-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti sayap ayam sambel kemangi yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan keistimewahan yang merupakan keragaman Kita

Keharmonisan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Sayap Ayam Sambel Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda coba salah satunya sayap ayam sambel kemangi yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep sayap ayam sambel kemangi tanpa harus bersusah payah.
Berikut ini resep Sayap Ayam Sambel Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sayap Ayam Sambel Kemangi:

1. Dibutuhkan  Bahan Ayam Marinasi:
1. Jangan lupa 10 potong sayap ayam
1. Diperlukan 3 siung bawang putih
1. Dibutuhkan 1 sdt ketumbar
1. Tambah 1 sdt garam
1. Harap siapkan 0,5 sdt penyedap rasa
1. Siapkan Secukupnya air
1. Dibutuhkan Secukupnya minyak
1. Tambah  Bahan Sambel :
1. Harus ada 4 siung bawang merah
1. Harus ada 3 siung bawang putih
1. Siapkan 15 buah cabe rawit merah
1. Harus ada 8 buah cabe kriting merah
1. Siapkan Secukupnya kemangi
1. Jangan lupa 1,5 sdt garam
1. Harap siapkan 1 sdt penyedap rasa
1. Siapkan 0,5 sdt gula pasir / gula jawa
1. Dibutuhkan Sedikit minyak




<!--inarticleads2-->

##### Cara membuat  Sayap Ayam Sambel Kemangi:

1. Cuci bersih sayap ayam. Haluskan 3 siung bawang putih dan ketumbar
1. Siapkan panci, masukkan sayap ayam, bumbu yang udah dihaluskan, garam, penyedap rasa, dan air sampai sayap ayamnya tenggelam semua, didihkan sampai bumbu meresap ke ayam
1. Sambil memarinasi ayam, haluskan duo bawang dan duo cabe dari bahan sambel. Ambil bagian daun kemangi saja lalu cuci bersih
1. Jika kira kira bumbu ayam udah meresap, matikan api, lalu goreng ayam hingga kuning keemasan
1. Sisakan sedikit minyak setelah goreng ayam, tumis bahan sambel yang udah dihaluskan. Tambahkan garam, gula, dan penyedap rasa. Tumis hingga matang dan tidak ada kandungan airnya
1. Cek rasa. Jika rasanya udah pas, masukkam kemangi, tumis bentar langsung tambahkan ayam yang udah digoreng
1. Aduk sampe tercampur rata. Lalu siap disajikan 😊




Demikianlah cara membuat sayap ayam sambel kemangi yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
