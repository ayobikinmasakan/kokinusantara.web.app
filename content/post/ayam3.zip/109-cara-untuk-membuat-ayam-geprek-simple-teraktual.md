---
description: "Cara untuk membuat Ayam Geprek Simple teraktual"
title: "Cara untuk membuat Ayam Geprek Simple teraktual"
slug: 109-cara-untuk-membuat-ayam-geprek-simple-teraktual
date: 2020-09-17T02:25:54.236Z
image: https://img-global.cpcdn.com/recipes/95511cdb602b9032/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/95511cdb602b9032/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/95511cdb602b9032/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
author: Roxie Fitzgerald
ratingvalue: 4.7
reviewcount: 30152
recipeingredient:
- "4 ayam dada fillet"
- "1 sdt merica bubuk"
- "1 sdm garam"
- "1 sdm air jeruk nipis atau sesuai selera tergantung besarnya dada ayam"
- "secukupnya Minyak goreng"
- " Pelapis Basah "
- "2 sdm terigu"
- "50 ml air"
- "Seujung sdt garam"
- "Seujung sdt penyedap jika suka"
- "Sejumput merica"
- " Pelapis Kering "
- "150 gr Tepung terigu"
- "1-2 sdm penyedap"
- "75 gr tapioka"
- "1.5 sdt garam"
- "1 sdt merica bubuk"
- "1-2 sdt bubuk cabai atau sesuai selera"
- " Sambal"
- "4 Cabe merah"
- "Sedikit terasi"
- "1 siung Bawang putih"
- " Garam gula penyedap"
- "6 Cabe rawit"
- " Minyak panas"
- "sesuai selera Aneka sayur lalapan  timun tomat kemangi dan lainnya"
recipeinstructions:
- "Cuci bersih fillet dada ayam. Potong memanjang menjadi 2 bagian. Setiap bagiannya dibelah menjadi 2,tetapi jangan sampai putus."
- "Setelah itu, beri air jeruk nipis, garam dan merica. Balurkan sambil diremas2 secara merata. Kemudian proses marinasi /diamkan selama 1-2 jam."
- "Sementara itu siapkan bahan pelapis basah, aduk menjadi satu. Sisihkan."
- "Siapkan bahan pelapis kering, aduk rata."
- "Setelah ayam dimarinasi, kita mulai proses pelapisan. Ambil satu potong daging ayam, celupkan ke pelapis basah. Kemudian pindahkan ke mangkuk pelapis kering. Kemudian celupkan lagi ke pelapis basah, pindahkan lagi ke pelapis kering."
- "Goreng ayam dalam minyak panas, berapi sedang hingga kuning kecoklatan."
- "Cuci bersih bahan sambal dan uleg kasar. Tambahkan dengan minyak panas bekas menggoreng ayam sekitar 6 -8 sdm."
- "Penyajian : Siapkan satu bagian ayam yang sudah digoreng tadi, beri sambal sesuai selera. Kemudian di tekan-tekan menggunakan batu uleg, hingga ayam pipih dan bumbu cabai rata."
- "Siap disajikan dengan lalapan mentah dan nasi hangat. Selamat mencoba."
categories:
- Recipe
tags:
- ayam
- geprek
- simple

katakunci: ayam geprek simple 
nutrition: 300 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Geprek Simple](https://img-global.cpcdn.com/recipes/95511cdb602b9032/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau empuk. Karasteristik masakan Nusantara ayam geprek simple yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Geprek Simple untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang bisa anda buat salah satunya ayam geprek simple yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep ayam geprek simple tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Simple yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 langkah dan 26 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Simple:

1. Harap siapkan 4 ayam dada fillet
1. Tambah 1 sdt merica bubuk
1. Diperlukan 1 sdm garam
1. Harap siapkan 1 sdm air jeruk nipis atau sesuai selera tergantung besarnya dada ayam
1. Jangan lupa secukupnya Minyak goreng
1. Jangan lupa  Pelapis Basah :
1. Siapkan 2 sdm terigu
1. Harap siapkan 50 ml air
1. Jangan lupa Seujung sdt garam
1. Harap siapkan Seujung sdt penyedap jika suka
1. Siapkan Sejumput merica
1. Tambah  Pelapis Kering :
1. Tambah 150 gr Tepung terigu
1. Diperlukan 1-2 sdm penyedap
1. Tambah 75 gr tapioka
1. Tambah 1.5 sdt garam
1. Dibutuhkan 1 sdt merica bubuk
1. Tambah 1-2 sdt bubuk cabai atau sesuai selera
1. Siapkan  Sambal
1. Diperlukan 4 Cabe merah
1. Harus ada Sedikit terasi
1. Harap siapkan 1 siung Bawang putih
1. Diperlukan  Garam, gula, penyedap
1. Diperlukan 6 Cabe rawit
1. Harap siapkan  Minyak panas
1. Harap siapkan sesuai selera Aneka sayur lalapan : timun, tomat, kemangi, dan lainnya




<!--inarticleads2-->

##### Instruksi membuat  Ayam Geprek Simple:

1. Cuci bersih fillet dada ayam. Potong memanjang menjadi 2 bagian. Setiap bagiannya dibelah menjadi 2,tetapi jangan sampai putus.
1. Setelah itu, beri air jeruk nipis, garam dan merica. Balurkan sambil diremas2 secara merata. Kemudian proses marinasi /diamkan selama 1-2 jam.
1. Sementara itu siapkan bahan pelapis basah, aduk menjadi satu. Sisihkan.
1. Siapkan bahan pelapis kering, aduk rata.
1. Setelah ayam dimarinasi, kita mulai proses pelapisan. Ambil satu potong daging ayam, celupkan ke pelapis basah. Kemudian pindahkan ke mangkuk pelapis kering. Kemudian celupkan lagi ke pelapis basah, pindahkan lagi ke pelapis kering.
1. Goreng ayam dalam minyak panas, berapi sedang hingga kuning kecoklatan.
1. Cuci bersih bahan sambal dan uleg kasar. Tambahkan dengan minyak panas bekas menggoreng ayam sekitar 6 -8 sdm.
1. Penyajian : Siapkan satu bagian ayam yang sudah digoreng tadi, beri sambal sesuai selera. Kemudian di tekan-tekan menggunakan batu uleg, hingga ayam pipih dan bumbu cabai rata.
1. Siap disajikan dengan lalapan mentah dan nasi hangat. Selamat mencoba.




Demikianlah cara membuat ayam geprek simple yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan teruji, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
