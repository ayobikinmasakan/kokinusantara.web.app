---
description: "Langkah untuk membuat Ayam Geprek Lada Hitam Sambel Korek terupdate"
title: "Langkah untuk membuat Ayam Geprek Lada Hitam Sambel Korek terupdate"
slug: 30-langkah-untuk-membuat-ayam-geprek-lada-hitam-sambel-korek-terupdate
date: 2020-10-23T21:30:29.442Z
image: https://img-global.cpcdn.com/recipes/5b00a3926156f301/751x532cq70/ayam-geprek-lada-hitam-sambel-korek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5b00a3926156f301/751x532cq70/ayam-geprek-lada-hitam-sambel-korek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5b00a3926156f301/751x532cq70/ayam-geprek-lada-hitam-sambel-korek-foto-resep-utama.jpg
author: Josie Fox
ratingvalue: 4.5
reviewcount: 31983
recipeingredient:
- "4 potong daging ayam bagian apa aja sesukanya"
- " Racikan Rebusan Ayam "
- "1/2 bks bumbu tempe goreng Me Racik tempe"
- "1/2 sdt kaldu bubuk"
- "1 siung bawang putih"
- "1 sdt saos tiram Me Saori saos tiram"
- "Secukupnya air untuk merebus ayam"
- " Tepung Lumur Marinasi Ayam "
- "1/2 bks tepung bumbu serbaguna Me Sajiku pedas"
- "1/4 sdt ketumbar bubuk"
- "Secukupnya air untuk mencampur"
- " Tepung Pelapis Ayam "
- "1/2 bks tepung bumbu lada hitam Me Mamasuka krispi lada hitam"
- "1 sdm Tepung tapiokasagu"
- "1/2 sdt baking powder"
- "1 gelas air es"
- "Secukupnya minyak untuk menggoreng"
- " Sambal Korek "
- "10 biji cabe rawit merahcabe setan"
- "8 biji cabe merah keriting"
- "5 biji cabe rawit ijo opsional"
- "2 siung bawang putih"
- "Secukupnya kaldu bubuk jamurayam"
- "3 sdm minyak panas"
- " CondimentPendamping "
- "1 buah mentimun ukbesar"
- "3 buah tahu putih"
- "2 sdm tepung bumbu lada hitam Me Mamasuka krispi lada hitam"
- "Sedikit air"
- "Secukupnya minyak untuk menggoreng"
recipeinstructions:
- "Bersihkan ayam, aku pake bagian separoh dada ayam. Potong 4-5 bagian. Lumuri potongan ayam dengan bumbu racik goreng tempe hingga merata. Tambahkan air secukupnya merendam ayam. Tambahkan sedikit kaldu bubuk dan saos tiram. Aduk sejenak. Rebus ayam hingga matang dan air rebusan surut meresap ke ayam. Tiriskan."
- "Buat tepung lumur marinasi ayam. Setengah bungkus tepung bumbu serbaguna instan (aku pake tepung sajiku yg pedas) dicampur dgn sedikit ketumbar bubuk dan secukupnya air. Aduk rata. Buat agak kental. Jangan terlalu encer. Lumurkan di seluruh ayam hingga merata sampe ke sela-sela bagian ayam. Masukkan dan diamkan dlm lemari es/freezer minimal 1 jam."
- "Setelah lebih dari 1 jam dalam freezer/pendingin, keluarkan potongan2 ayam dan siapkan bahan2 lainnya untuk step selanjutnya. Siapkan bahan untuk pelapis. Segelas air es &amp; tepung bumbu sesuai selera. Kali ini aku pake yg lada hitam. Tuangkan air es dlm mangkok/piring agar lebih mudah dicelup. Siapkan tepung kering di piring lain, tambahkan sesendok tepung tapioka/sagu dan baking powder, aduk rata."
- "Ambil potongan ayam yg sudah di marinasi dalam frezeer tadi. Celupkan dan balurkan rata dengan tepung kering, lalu celupkan ke air es, baluri lagi dgn tepung kering sambil di tekan2 atau dicubit2. Jika ingin hasil yg lebih crispy dan keriting ulangi prosesnya ini hingga 3x bolak balik. Lakukan proses yg sama dgn semua potongan ayam."
- "Goreng ayam dgn cukup minyak panas dalam api stabil hingga matang coklat keemasan."
- "Siapkan condiment/pendamping hidangan. Kali ini aku pilih lalapan timun dingin segar &amp; tahu goreng. 🥒 Bersihkan mentimun, potong sesuai selera dan dinginkan di lemari es. 🍣 3 biji tahu putih potong memanjang (sesuai selera), baluri dgn adonan tepung serbaguna (aku masih pake yg lada hitam) dicampur sedikit air. Tepung basahnya ini agak kental, jangan terlalu encer. Balurkan rata ke tahu.. Memasukkan tahu gunakan sendok agar tepungnya juga ikut. Langsung di goreng hingga matang keemasan."
- "Buat sambel korek. Cuci bersih semua cabe2an dan kupas bawang putih. Potong2 kecil semuanya agar nanti lebih mudah di uleg. Goreng bawang putih dengan sedikit minyak, lalu masukkan cabe2an juga, tumis sejenak saja, segera angkat. Uleg kasar semua bahan. Tambahkan secukupnya kaldu bubuk, masukkan sedikit2. Tes rasa."
- "Setelah rasa sambel korek dirasa pas &amp; mantaps, siram sambel dgn 3 sdm minyak panas. Sambel korek siap dinikmati 😘🌶️"
- "Geprek ayam goreng tepung lada hitam dgn anak cobek dan tuangkan secukupnya sambel korek diatasnya sesuai selera. Jika ga suka langsung diatas ayam, sambel bisa di tata di sisi ayam sebagai cocolan. Tata juga pelengkap lalapan mentimun dingin segar dan tahu goreng."
- "Ayam Geprek Lada Hitam Sambel Korek sungguh menggugah selera untuk segera di santap! 😰🌶️🍗 - 🌻Unda Qy"
categories:
- Recipe
tags:
- ayam
- geprek
- lada

katakunci: ayam geprek lada 
nutrition: 291 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Geprek Lada Hitam Sambel Korek](https://img-global.cpcdn.com/recipes/5b00a3926156f301/751x532cq70/ayam-geprek-lada-hitam-sambel-korek-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang harus kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam geprek lada hitam sambel korek yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Nusantara



Kehangatan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Geprek Lada Hitam Sambel Korek untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda praktekkan salah satunya ayam geprek lada hitam sambel korek yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep ayam geprek lada hitam sambel korek tanpa harus bersusah payah.
Seperti resep Ayam Geprek Lada Hitam Sambel Korek yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 langkah dan 30 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Lada Hitam Sambel Korek:

1. Tambah 4 potong daging ayam (bagian apa aja sesukanya)
1. Harus ada  Racikan Rebusan Ayam :
1. Dibutuhkan 1/2 bks bumbu tempe goreng (Me: Racik tempe)
1. Diperlukan 1/2 sdt kaldu bubuk
1. Harus ada 1 siung bawang putih
1. Dibutuhkan 1 sdt saos tiram (Me: Saori saos tiram)
1. Diperlukan Secukupnya air untuk merebus ayam
1. Diperlukan  Tepung Lumur Marinasi Ayam :
1. Harus ada 1/2 bks tepung bumbu serbaguna (Me: Sajiku pedas)
1. Tambah 1/4 sdt ketumbar bubuk
1. Dibutuhkan Secukupnya air untuk mencampur
1. Dibutuhkan  Tepung Pelapis Ayam :
1. Harus ada 1/2 bks tepung bumbu lada hitam (Me: Mamasuka krispi lada hitam)
1. Diperlukan 1 sdm Tepung tapioka/sagu
1. Dibutuhkan 1/2 sdt baking powder
1. Jangan lupa 1 gelas air es
1. Jangan lupa Secukupnya minyak untuk menggoreng
1. Harap siapkan  Sambal Korek :
1. Harap siapkan 10 biji cabe rawit merah/cabe setan
1. Jangan lupa 8 biji cabe merah keriting
1. Diperlukan 5 biji cabe rawit ijo (opsional)
1. Tambah 2 siung bawang putih
1. Diperlukan Secukupnya kaldu bubuk (jamur/ayam)
1. Harap siapkan 3 sdm minyak panas
1. Diperlukan  Condiment/Pendamping :
1. Harus ada 1 buah mentimun (uk.besar)
1. Tambah 3 buah tahu putih
1. Tambah 2 sdm tepung bumbu lada hitam (Me: Mamasuka krispi lada hitam)
1. Jangan lupa Sedikit air
1. Harap siapkan Secukupnya minyak untuk menggoreng




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek Lada Hitam Sambel Korek:

1. Bersihkan ayam, aku pake bagian separoh dada ayam. Potong 4-5 bagian. Lumuri potongan ayam dengan bumbu racik goreng tempe hingga merata. Tambahkan air secukupnya merendam ayam. Tambahkan sedikit kaldu bubuk dan saos tiram. Aduk sejenak. Rebus ayam hingga matang dan air rebusan surut meresap ke ayam. Tiriskan.
1. Buat tepung lumur marinasi ayam. Setengah bungkus tepung bumbu serbaguna instan (aku pake tepung sajiku yg pedas) dicampur dgn sedikit ketumbar bubuk dan secukupnya air. Aduk rata. Buat agak kental. Jangan terlalu encer. Lumurkan di seluruh ayam hingga merata sampe ke sela-sela bagian ayam. Masukkan dan diamkan dlm lemari es/freezer minimal 1 jam.
1. Setelah lebih dari 1 jam dalam freezer/pendingin, keluarkan potongan2 ayam dan siapkan bahan2 lainnya untuk step selanjutnya. Siapkan bahan untuk pelapis. Segelas air es &amp; tepung bumbu sesuai selera. Kali ini aku pake yg lada hitam. Tuangkan air es dlm mangkok/piring agar lebih mudah dicelup. Siapkan tepung kering di piring lain, tambahkan sesendok tepung tapioka/sagu dan baking powder, aduk rata.
1. Ambil potongan ayam yg sudah di marinasi dalam frezeer tadi. Celupkan dan balurkan rata dengan tepung kering, lalu celupkan ke air es, baluri lagi dgn tepung kering sambil di tekan2 atau dicubit2. Jika ingin hasil yg lebih crispy dan keriting ulangi prosesnya ini hingga 3x bolak balik. Lakukan proses yg sama dgn semua potongan ayam.
1. Goreng ayam dgn cukup minyak panas dalam api stabil hingga matang coklat keemasan.
1. Siapkan condiment/pendamping hidangan. Kali ini aku pilih lalapan timun dingin segar &amp; tahu goreng. 🥒 Bersihkan mentimun, potong sesuai selera dan dinginkan di lemari es. 🍣 3 biji tahu putih potong memanjang (sesuai selera), baluri dgn adonan tepung serbaguna (aku masih pake yg lada hitam) dicampur sedikit air. Tepung basahnya ini agak kental, jangan terlalu encer. Balurkan rata ke tahu.. Memasukkan tahu gunakan sendok agar tepungnya juga ikut. Langsung di goreng hingga matang keemasan.
1. Buat sambel korek. Cuci bersih semua cabe2an dan kupas bawang putih. Potong2 kecil semuanya agar nanti lebih mudah di uleg. Goreng bawang putih dengan sedikit minyak, lalu masukkan cabe2an juga, tumis sejenak saja, segera angkat. Uleg kasar semua bahan. Tambahkan secukupnya kaldu bubuk, masukkan sedikit2. Tes rasa.
1. Setelah rasa sambel korek dirasa pas &amp; mantaps, siram sambel dgn 3 sdm minyak panas. Sambel korek siap dinikmati 😘🌶️
1. Geprek ayam goreng tepung lada hitam dgn anak cobek dan tuangkan secukupnya sambel korek diatasnya sesuai selera. Jika ga suka langsung diatas ayam, sambel bisa di tata di sisi ayam sebagai cocolan. Tata juga pelengkap lalapan mentimun dingin segar dan tahu goreng.
1. Ayam Geprek Lada Hitam Sambel Korek sungguh menggugah selera untuk segera di santap! 😰🌶️🍗 - 🌻Unda Qy




Demikianlah cara membuat ayam geprek lada hitam sambel korek yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
