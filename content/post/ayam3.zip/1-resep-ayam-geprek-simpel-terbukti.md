---
description: "Resep : Ayam Geprek Simpel Terbukti"
title: "Resep : Ayam Geprek Simpel Terbukti"
slug: 1-resep-ayam-geprek-simpel-terbukti
date: 2020-12-31T09:41:36.328Z
image: https://img-global.cpcdn.com/recipes/7be7f295af4fc1e4/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7be7f295af4fc1e4/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7be7f295af4fc1e4/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg
author: Charlie Warren
ratingvalue: 5
reviewcount: 30001
recipeingredient:
- "1/2 kg ayam"
- "secukupnya Tepung bumbu krispi pedas"
- "5 pcs Bawang putih"
- "3 pcs Cabai Besar"
- "7 pcs Cabai rawit"
- "1 bungkus Bumbu racik ayam goreng"
- " Jeruk nipis"
- "secukupnya Garam Gula Masako"
recipeinstructions:
- "Cuci ayam dengan jeruk nipis hingga bersih."
- "Masukkan air ke dalam wajan beserta ayam dan bumbu racik ayam gorengnya"
- "Aduk hingga merata. Lalu diamkan hingga meresap."
- "Setelah meresap, tiriskan ayam."
- "Siapkan 2 wadah. 1 wadah untuk tepung basah. 1 wadah untuk tepung kering."
- "Masukkan tepung bumbu krispi dan beri air sedikit (jangan terlalu cair dan jangan terlalu kental)"
- "Masukkan ayam yang sudah di goreng tadi kedalam tepung bumbu yang basah, lalu yang kering. (Ulang selama 2x atau lebih supaya kulit krispi lebih tebal)"
- "Siapkan minyak goreng. Tunggu sampai panas. Lalu masukkan ayam gorengnya hingga matang"
- "Setelah matang. Kita haluskan bawang putih, cabai besar, dan cabai rawit. Masukkan juga garam, gula dan masako"
- "Setelah sambal geprek jadi, beri sedikit minyak goreng sisa masakan."
categories:
- Recipe
tags:
- ayam
- geprek
- simpel

katakunci: ayam geprek simpel 
nutrition: 286 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Geprek Simpel](https://img-global.cpcdn.com/recipes/7be7f295af4fc1e4/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga gurih. Ciri makanan Indonesia ayam geprek simpel yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa didapat dengan cara mudah. Salah satunya adalah memasak Ayam Geprek Simpel untuk keluarga. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda praktekkan salah satunya ayam geprek simpel yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam geprek simpel tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Simpel yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 10 langkah dan 8 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Simpel:

1. Dibutuhkan 1/2 kg ayam
1. Siapkan secukupnya Tepung bumbu krispi pedas
1. Diperlukan 5 pcs Bawang putih
1. Jangan lupa 3 pcs Cabai Besar
1. Tambah 7 pcs Cabai rawit
1. Siapkan 1 bungkus Bumbu racik ayam goreng
1. Harap siapkan  Jeruk nipis
1. Dibutuhkan secukupnya Garam, Gula, Masako




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Geprek Simpel:

1. Cuci ayam dengan jeruk nipis hingga bersih.
1. Masukkan air ke dalam wajan beserta ayam dan bumbu racik ayam gorengnya
1. Aduk hingga merata. Lalu diamkan hingga meresap.
1. Setelah meresap, tiriskan ayam.
1. Siapkan 2 wadah. 1 wadah untuk tepung basah. 1 wadah untuk tepung kering.
1. Masukkan tepung bumbu krispi dan beri air sedikit (jangan terlalu cair dan jangan terlalu kental)
1. Masukkan ayam yang sudah di goreng tadi kedalam tepung bumbu yang basah, lalu yang kering. (Ulang selama 2x atau lebih supaya kulit krispi lebih tebal)
1. Siapkan minyak goreng. Tunggu sampai panas. Lalu masukkan ayam gorengnya hingga matang
1. Setelah matang. Kita haluskan bawang putih, cabai besar, dan cabai rawit. Masukkan juga garam, gula dan masako
1. Setelah sambal geprek jadi, beri sedikit minyak goreng sisa masakan.




Demikianlah cara membuat ayam geprek simpel yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
