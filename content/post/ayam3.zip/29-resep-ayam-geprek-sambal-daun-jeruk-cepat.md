---
description: "Resep : Ayam Geprek Sambal Daun Jeruk Cepat"
title: "Resep : Ayam Geprek Sambal Daun Jeruk Cepat"
slug: 29-resep-ayam-geprek-sambal-daun-jeruk-cepat
date: 2021-02-05T10:55:11.272Z
image: https://img-global.cpcdn.com/recipes/6b840c0bf64ea0c1/751x532cq70/ayam-geprek-sambal-daun-jeruk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6b840c0bf64ea0c1/751x532cq70/ayam-geprek-sambal-daun-jeruk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6b840c0bf64ea0c1/751x532cq70/ayam-geprek-sambal-daun-jeruk-foto-resep-utama.jpg
author: Travis Holmes
ratingvalue: 4.6
reviewcount: 18654
recipeingredient:
- " Bahan Ayam Goreng Tepung"
- "1/2 kg daging ayam dada"
- "2 butir telur"
- "15 sdm tepung terigu"
- "3 sdm tepung maizena"
- "1/2 sdt merica bubuk"
- "1 sdt bubuk bawang putih"
- "1 sdt garam"
- "secukupnya Minyak goreng"
- " Bumbu sambal 1 porsi"
- "2 bh cabai rawit sesuai selera"
- "1/2 siung bawang putih"
- "1 cm gula jawa secukupnya"
- "1 ruas kecil kencur"
- "2 lembar daun jeruk buang tulangnya"
- "1/4 sdt garam"
recipeinstructions:
- "Bersihkan ayam, potong-potong sesuai selera. Tiriskan. Lalu baluri ayam dengan merica bubuk, garam dan bawang putih."
- "Campurkan kedua tepung sampai rata. Kocok telur. Lalu celupkan ayam ke telur lalu ke campuran tepung (sambil ditekan-tekan/dicubit-cubit supaya merata sampai kedalam)"
- "Panaskan minyak dgn api sedang. Masukkan ayam yg telah dibaluri tepung tadi ke telur dan tepung kembali baru digoreng. (2 x dibaluri telur &amp; tepung)"
- "Setelah kuning kecoklatan, angkat ayam dan tiriskan. Bahan ayam tepung sudah jadi. Siap digeprek. Kalo gak suka pedas, ayam tepung ini sudah bisa langsung dimakan. (Kalo saya buat cemilan sambil nunggu yg lain) hehe"
- "Cuci bumbu sambal. Bakar dahulu terasi agar bau khasnya keluar. Pisahkan tulang daun jeruk dan potong kecil biar gampang diuleg."
- "Setelah sambal jadi, campurkan ayam tepung kira-kira untuk 1 porsi. Geprek/tekan-tekan ayam, jgn terlalu keras, lalu aduk/bolak-balik dgn sambal agar merata."
- "Kalau sudah rata, Ayam Geprek Sambal Daun Jeruk untuk 1 porsi siap disajikan."
categories:
- Recipe
tags:
- ayam
- geprek
- sambal

katakunci: ayam geprek sambal 
nutrition: 256 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Geprek Sambal Daun Jeruk](https://img-global.cpcdn.com/recipes/6b840c0bf64ea0c1/751x532cq70/ayam-geprek-sambal-daun-jeruk-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam geprek sambal daun jeruk yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Kita



Kedekatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah memasak Ayam Geprek Sambal Daun Jeruk untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda contoh salah satunya ayam geprek sambal daun jeruk yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep ayam geprek sambal daun jeruk tanpa harus bersusah payah.
Seperti resep Ayam Geprek Sambal Daun Jeruk yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Sambal Daun Jeruk:

1. Siapkan  Bahan Ayam Goreng Tepung
1. Harus ada 1/2 kg daging ayam (dada)
1. Harap siapkan 2 butir telur
1. Dibutuhkan 15 sdm tepung terigu
1. Harap siapkan 3 sdm tepung maizena
1. Siapkan 1/2 sdt merica bubuk
1. Tambah 1 sdt bubuk bawang putih
1. Siapkan 1 sdt garam
1. Harus ada secukupnya Minyak goreng
1. Tambah  Bumbu sambal (1 porsi)
1. Diperlukan 2 bh cabai rawit (sesuai selera)
1. Tambah 1/2 siung bawang putih
1. Tambah 1 cm gula jawa (secukupnya)
1. Jangan lupa 1 ruas kecil kencur
1. Harap siapkan 2 lembar daun jeruk (buang tulangnya)
1. Dibutuhkan 1/4 sdt garam




<!--inarticleads2-->

##### Langkah membuat  Ayam Geprek Sambal Daun Jeruk:

1. Bersihkan ayam, potong-potong sesuai selera. Tiriskan. Lalu baluri ayam dengan merica bubuk, garam dan bawang putih.
1. Campurkan kedua tepung sampai rata. Kocok telur. Lalu celupkan ayam ke telur lalu ke campuran tepung (sambil ditekan-tekan/dicubit-cubit supaya merata sampai kedalam)
1. Panaskan minyak dgn api sedang. Masukkan ayam yg telah dibaluri tepung tadi ke telur dan tepung kembali baru digoreng. (2 x dibaluri telur &amp; tepung)
1. Setelah kuning kecoklatan, angkat ayam dan tiriskan. Bahan ayam tepung sudah jadi. Siap digeprek. Kalo gak suka pedas, ayam tepung ini sudah bisa langsung dimakan. (Kalo saya buat cemilan sambil nunggu yg lain) hehe
1. Cuci bumbu sambal. Bakar dahulu terasi agar bau khasnya keluar. Pisahkan tulang daun jeruk dan potong kecil biar gampang diuleg.
1. Setelah sambal jadi, campurkan ayam tepung kira-kira untuk 1 porsi. Geprek/tekan-tekan ayam, jgn terlalu keras, lalu aduk/bolak-balik dgn sambal agar merata.
1. Kalau sudah rata, Ayam Geprek Sambal Daun Jeruk untuk 1 porsi siap disajikan.




Demikianlah cara membuat ayam geprek sambal daun jeruk yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
