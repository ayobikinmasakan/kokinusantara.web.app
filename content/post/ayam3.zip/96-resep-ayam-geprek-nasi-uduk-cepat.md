---
description: "Resep : Ayam Geprek Nasi Uduk Cepat"
title: "Resep : Ayam Geprek Nasi Uduk Cepat"
slug: 96-resep-ayam-geprek-nasi-uduk-cepat
date: 2020-12-09T22:14:13.468Z
image: https://img-global.cpcdn.com/recipes/9cec9098a5d7cd72/751x532cq70/ayam-geprek-nasi-uduk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9cec9098a5d7cd72/751x532cq70/ayam-geprek-nasi-uduk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9cec9098a5d7cd72/751x532cq70/ayam-geprek-nasi-uduk-foto-resep-utama.jpg
author: Jessie Neal
ratingvalue: 4.7
reviewcount: 13782
recipeingredient:
- "1/2 kg ayam me paha atas 3 potong"
- " bumbu halus "
- "3 siung bawang putih"
- "2 sdm ketumbar bubuk"
- "2 bh utuh kemiri"
- "1.5 sdt garam"
- "2 sdt kaldu jamur"
- "300 ml air"
- " minyak untuk menggoreng"
- " tepung pelapis"
- "5 sdm tepung terigu"
- "1/2 sdt garam"
- "200 ml air"
- " pelengkap "
- " nasi uduk"
- " lalapan"
- " terongtempetahu goreng"
- " Bahan Nasi Uduk "
- "1/2 kg beras"
- "1 bks kecil santan kara"
- "2 sdt garam"
- "2 lembar daun salam"
- " air menyesuaikan beras masing2"
recipeinstructions:
- "Siapkan magig com, cuci bersih beras, masukkan air sesuai dg beras masing2. kalau saya pakai air dg batas 1 ruas jari tengah dr permukaan beras, tambahkan santan kara, garam, daun salam. aduk sebentar, hidupkan magig com, biarkan nasi matang. :) cepat dan praktis."
- "Cuci bersih ayam. ulek atau tumbuk hingga halus bawang putih, kemiri, garam dan ketumbar."
- "Campur bumbu halus dg air dan kaldu jamur.aduk merata."
- "Kerat ayam, supaya bumbu bs merasuk. campurkan ayam dg bumbu yg sdh dcampur air td."
- "Rebus ayam dg api kecil, masak hingga ayam matang dan air menyusut."
- "Campur bahan tepung pelapis, aduk rata."
- "Panaskan minyak goreng, celup ayam yg sdh drebus td tepung pelapis. goreng hingga agak kering, kuning kecoklatan."
- "Sajikan dg pelengkap. yummy"
categories:
- Recipe
tags:
- ayam
- geprek
- nasi

katakunci: ayam geprek nasi 
nutrition: 151 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Geprek Nasi Uduk](https://img-global.cpcdn.com/recipes/9cec9098a5d7cd72/751x532cq70/ayam-geprek-nasi-uduk-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau gurih. Karasteristik masakan Indonesia ayam geprek nasi uduk yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Geprek Nasi Uduk untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang bisa anda contoh salah satunya ayam geprek nasi uduk yang merupakan makanan favorite yang simpel dengan varian sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam geprek nasi uduk tanpa harus bersusah payah.
Berikut ini resep Ayam Geprek Nasi Uduk yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 23 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Nasi Uduk:

1. Diperlukan 1/2 kg ayam, me paha atas 3 potong
1. Siapkan  bumbu halus :
1. Tambah 3 siung bawang putih
1. Jangan lupa 2 sdm ketumbar bubuk
1. Harus ada 2 bh utuh kemiri
1. Dibutuhkan 1.5 sdt garam
1. Jangan lupa 2 sdt kaldu jamur
1. Diperlukan 300 ml air
1. Tambah  minyak untuk menggoreng
1. Harap siapkan  tepung pelapis
1. Siapkan 5 sdm tepung terigu
1. Tambah 1/2 sdt garam
1. Harus ada 200 ml air
1. Dibutuhkan  pelengkap :
1. Diperlukan  nasi uduk
1. Siapkan  lalapan
1. Diperlukan  terong/tempe/tahu goreng
1. Jangan lupa  Bahan Nasi Uduk :
1. Siapkan 1/2 kg beras
1. Jangan lupa 1 bks kecil santan kara
1. Harap siapkan 2 sdt garam
1. Diperlukan 2 lembar daun salam
1. Diperlukan  air, menyesuaikan beras masing2




<!--inarticleads2-->

##### Instruksi membuat  Ayam Geprek Nasi Uduk:

1. Siapkan magig com, cuci bersih beras, masukkan air sesuai dg beras masing2. kalau saya pakai air dg batas 1 ruas jari tengah dr permukaan beras, tambahkan santan kara, garam, daun salam. aduk sebentar, hidupkan magig com, biarkan nasi matang. :) cepat dan praktis.
1. Cuci bersih ayam. ulek atau tumbuk hingga halus bawang putih, kemiri, garam dan ketumbar.
1. Campur bumbu halus dg air dan kaldu jamur.aduk merata.
1. Kerat ayam, supaya bumbu bs merasuk. campurkan ayam dg bumbu yg sdh dcampur air td.
1. Rebus ayam dg api kecil, masak hingga ayam matang dan air menyusut.
1. Campur bahan tepung pelapis, aduk rata.
1. Panaskan minyak goreng, celup ayam yg sdh drebus td tepung pelapis. goreng hingga agak kering, kuning kecoklatan.
1. Sajikan dg pelengkap. yummy




Demikianlah cara membuat ayam geprek nasi uduk yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
