---
description: "Cara singkat untuk membuat Ayam Geprek Sederhana Terbukti"
title: "Cara singkat untuk membuat Ayam Geprek Sederhana Terbukti"
slug: 219-cara-singkat-untuk-membuat-ayam-geprek-sederhana-terbukti
date: 2020-11-01T16:05:44.447Z
image: https://img-global.cpcdn.com/recipes/9d84b86c3a5d7533/751x532cq70/ayam-geprek-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9d84b86c3a5d7533/751x532cq70/ayam-geprek-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9d84b86c3a5d7533/751x532cq70/ayam-geprek-sederhana-foto-resep-utama.jpg
author: Katie Mendoza
ratingvalue: 4.2
reviewcount: 7096
recipeingredient:
- "1 Ekor Ayam Broiler Potong 12 atau 14"
- "1 buah Jeruk Nipis"
- "  Bahan untuk bumbu Ayam "
- "5 Siung Bawang Putih"
- " MericaLada Bubuk"
- "secukupnya Garam"
- "  Bahan Tepung Pelapis Campur jadi satu"
- "10 Sendok Tepung Terigu"
- "5 Sendok Tepung MaizenaTepung Beras"
- "  Bahan Sambel Geprek "
- "10 siung Bawang Putih"
- "5 buah Cabe Keriting atau sesuai selera"
- "15 buah Cabe Rawit atau sesuai selera"
recipeinstructions:
- "Cuci bersih ayam, kucurkan jeruk nipis dan diamkan 15 menit"
- "Haluskan bumbu ayam : Bawang Putih, Lada/Merica Bubuk, Garam. Lalu balurkan ke seluruh potongan ayam"
- "Simpan ayam yg sudah diberi bumbu beberapa jam (semalaman lebih bagus)"
- "Blender kasar/Ulek Kasar Baham sambal, sisihkan"
- "Keluarkan ayam yang sudah dibumbui, beri 1 telur yang sudah dikocok, lalu aduk rata"
- "Masukkan ayam kedalam adonan tepung yang sudah dicampur, sambil dicubit cubit, masukkan ke dalam adonan telur lagi, masukkan ke adonan tepung lagi, lalu goreng dalam minyak panas dan api sedang"
- "Taruh sedikit sambal di atas cobek, siram dengan sisa minyak goreng ayam tadi sedikit, taro ayam diatas nya, taruh lg sambel kemudian geprek deh pake ulekan"
- "Siap dinikmati"
- "Tambahkan lalapan biar tambah mantap"
categories:
- Recipe
tags:
- ayam
- geprek
- sederhana

katakunci: ayam geprek sederhana 
nutrition: 166 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Geprek Sederhana](https://img-global.cpcdn.com/recipes/9d84b86c3a5d7533/751x532cq70/ayam-geprek-sederhana-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau empuk. Ciri makanan Indonesia ayam geprek sederhana yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga bisa didapat dengan cara mudah. Diantaranya adalah memasak Ayam Geprek Sederhana untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang bisa anda coba salah satunya ayam geprek sederhana yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep ayam geprek sederhana tanpa harus bersusah payah.
Seperti resep Ayam Geprek Sederhana yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek Sederhana:

1. Diperlukan 1 Ekor Ayam Broiler (Potong 12 atau 14)
1. Siapkan 1 buah Jeruk Nipis
1. Tambah  ➡️ Bahan untuk bumbu Ayam :
1. Diperlukan 5 Siung Bawang Putih
1. Siapkan  Merica/Lada Bubuk
1. Siapkan secukupnya Garam
1. Jangan lupa  ➡️ Bahan Tepung Pelapis (Campur jadi satu)
1. Dibutuhkan 10 Sendok Tepung Terigu
1. Jangan lupa 5 Sendok Tepung Maizena/Tepung Beras
1. Diperlukan  ➡️ Bahan Sambel Geprek :
1. Tambah 10 siung Bawang Putih
1. Harap siapkan 5 buah Cabe Keriting (atau sesuai selera)
1. Jangan lupa 15 buah Cabe Rawit (atau sesuai selera)




<!--inarticleads2-->

##### Cara membuat  Ayam Geprek Sederhana:

1. Cuci bersih ayam, kucurkan jeruk nipis dan diamkan 15 menit
1. Haluskan bumbu ayam : Bawang Putih, Lada/Merica Bubuk, Garam. Lalu balurkan ke seluruh potongan ayam
1. Simpan ayam yg sudah diberi bumbu beberapa jam (semalaman lebih bagus)
1. Blender kasar/Ulek Kasar Baham sambal, sisihkan
1. Keluarkan ayam yang sudah dibumbui, beri 1 telur yang sudah dikocok, lalu aduk rata
1. Masukkan ayam kedalam adonan tepung yang sudah dicampur, sambil dicubit cubit, masukkan ke dalam adonan telur lagi, masukkan ke adonan tepung lagi, lalu goreng dalam minyak panas dan api sedang
1. Taruh sedikit sambal di atas cobek, siram dengan sisa minyak goreng ayam tadi sedikit, taro ayam diatas nya, taruh lg sambel kemudian geprek deh pake ulekan
1. Siap dinikmati
1. Tambahkan lalapan biar tambah mantap




Demikianlah cara membuat ayam geprek sederhana yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan teruji, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
