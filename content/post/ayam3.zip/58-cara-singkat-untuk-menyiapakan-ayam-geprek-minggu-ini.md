---
description: "Cara singkat untuk menyiapakan Ayam Geprek minggu ini"
title: "Cara singkat untuk menyiapakan Ayam Geprek minggu ini"
slug: 58-cara-singkat-untuk-menyiapakan-ayam-geprek-minggu-ini
date: 2020-11-04T17:03:45.998Z
image: https://img-global.cpcdn.com/recipes/57a908141a897920/751x532cq70/ayam-geprek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/57a908141a897920/751x532cq70/ayam-geprek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/57a908141a897920/751x532cq70/ayam-geprek-foto-resep-utama.jpg
author: Harriett Roberts
ratingvalue: 4.5
reviewcount: 3613
recipeingredient:
- "1/2 kg ayam"
- " Bumbu Marinasi "
- "secukupnya Bawang putih bubuk"
- "secukupnya Lada bubuk"
- "secukupnya Ketumbar bubuk"
- " Bahan Pencelup "
- "4 sdm tepung terigu"
- "2 sdm tepung tapioka"
- "1 sdt garam"
- " Bahan Kering "
- "1 bks tepung bumbu serbaguna"
- " Sambal Geprek "
- "10 buah cabe merah"
- "35 buah cabe rawit"
- "6 siung bawang putih"
- "secukupnya Garam"
- " Kaldu bubuk saya kaldu jamur"
- " Minyak utk menumis"
recipeinstructions:
- "Cuci ayam sampai bersih. Kemudian lumuri ayam dgn bumbu marinasi, beri air secukupnya. Rebus ayam sampai air menyusut. Sisihkan."
- "Kemudian masukkan ayam ke bahan pencelup, gulingkan ke tepung kering, masukkan lg ke pencelup guling kan lagi ke tepung kering. Kemudian goreng ayam hingga matang."
- "Cara buat sambal geprek : haluskan semua bahan, kemudian tumis sebentar, masukkan garam dan kaldu bubuk aduk rata. Matikan api. Sisihkan."
- "Geprek ayam yg sudah di goreng td, kemudian siramkan sambal geprek di atas nya. Jadi deh, mudah dan simpel."
categories:
- Recipe
tags:
- ayam
- geprek

katakunci: ayam geprek 
nutrition: 214 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Geprek](https://img-global.cpcdn.com/recipes/57a908141a897920/751x532cq70/ayam-geprek-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau gurih. Karasteristik kuliner Nusantara ayam geprek yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam Geprek untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang bisa anda coba salah satunya ayam geprek yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam geprek tanpa harus bersusah payah.
Seperti resep Ayam Geprek yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Geprek:

1. Diperlukan 1/2 kg ayam
1. Harus ada  Bumbu Marinasi :
1. Diperlukan secukupnya Bawang putih bubuk
1. Dibutuhkan secukupnya Lada bubuk
1. Harus ada secukupnya Ketumbar bubuk
1. Harus ada  Bahan Pencelup :
1. Harus ada 4 sdm tepung terigu
1. Jangan lupa 2 sdm tepung tapioka
1. Dibutuhkan 1 sdt garam
1. Diperlukan  Bahan Kering :
1. Dibutuhkan 1 bks tepung bumbu serbaguna
1. Jangan lupa  Sambal Geprek :
1. Tambah 10 buah cabe merah
1. Harus ada 35 buah cabe rawit
1. Tambah 6 siung bawang putih
1. Harus ada secukupnya Garam
1. Harus ada  Kaldu bubuk (saya kaldu jamur)
1. Dibutuhkan  Minyak utk menumis




<!--inarticleads2-->

##### Instruksi membuat  Ayam Geprek:

1. Cuci ayam sampai bersih. Kemudian lumuri ayam dgn bumbu marinasi, beri air secukupnya. Rebus ayam sampai air menyusut. Sisihkan.
1. Kemudian masukkan ayam ke bahan pencelup, gulingkan ke tepung kering, masukkan lg ke pencelup guling kan lagi ke tepung kering. Kemudian goreng ayam hingga matang.
1. Cara buat sambal geprek : haluskan semua bahan, kemudian tumis sebentar, masukkan garam dan kaldu bubuk aduk rata. Matikan api. Sisihkan.
1. Geprek ayam yg sudah di goreng td, kemudian siramkan sambal geprek di atas nya. Jadi deh, mudah dan simpel.




Demikianlah cara membuat ayam geprek yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
