---
description: "Resep : Gongso Sayap Ayam minggu ini"
title: "Resep : Gongso Sayap Ayam minggu ini"
slug: 435-resep-gongso-sayap-ayam-minggu-ini
date: 2020-12-17T05:39:31.786Z
image: https://img-global.cpcdn.com/recipes/4b644ec51826fb4b/751x532cq70/gongso-sayap-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4b644ec51826fb4b/751x532cq70/gongso-sayap-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4b644ec51826fb4b/751x532cq70/gongso-sayap-ayam-foto-resep-utama.jpg
author: Douglas Mills
ratingvalue: 4.6
reviewcount: 49330
recipeingredient:
- "6 Sayap ayam dipotong menjadi 2"
- "2 lembar daun jeruk"
- "1 batang sereh di geprek"
- "1/2 butir gula merah"
- "3 siung Bawang putih"
- "6 siung Bawang merah"
- "8 buah Cabe merah keriting"
- "3 butir Kemiri"
- "1 ruas jari Jahe"
- "Secukupnya garam"
- "Secukupnya penyedap"
- "Secukupnya air"
- " Bumbu gonggso "
- "6 siung bawang merah iris kasar"
- "10 buah cabe rawit merah"
recipeinstructions:
- "Potong sayap ayam menjadi 2 bagian. Cuci dan rendam dgn garam dan air jeruk nipis. Cuci bersih kembali. Kemudian panggang / goreng setengah matang agar tidak hancur saat dimasak dengan bumbu2. Sisihkan ayam. Aslinya sayap ayam tidak digoreng."
- "Haluskan bumbu, lalu tumis sampai keluar aroma wangi"
- "Masukkan sayap ayam aduk rata lalu tuang air. Ungkep sayap ayam sampai air menyusut atau sampai air nyemek2, jangan lupa koreksi rasanya."
- "Gongso atau tumis irisan bawang merah dan cabe rawit asal layu saja, masukkan sebagian kedalam sayap ayam lalu aduk rata. Gongso sayap ayam siap disajikan dengan ditabur sebagian bumbu gongso."
categories:
- Recipe
tags:
- gongso
- sayap
- ayam

katakunci: gongso sayap ayam 
nutrition: 172 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Dessert

---


![Gongso Sayap Ayam](https://img-global.cpcdn.com/recipes/4b644ec51826fb4b/751x532cq70/gongso-sayap-ayam-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga renyah. Ciri khas makanan Nusantara gongso sayap ayam yang penuh dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Gongso Sayap Ayam untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang dapat anda coba salah satunya gongso sayap ayam yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep gongso sayap ayam tanpa harus bersusah payah.
Seperti resep Gongso Sayap Ayam yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Gongso Sayap Ayam:

1. Siapkan 6 Sayap ayam, dipotong menjadi 2
1. Harus ada 2 lembar daun jeruk
1. Siapkan 1 batang sereh di geprek
1. Harap siapkan 1/2 butir gula merah
1. Diperlukan 3 siung Bawang putih
1. Jangan lupa 6 siung Bawang merah
1. Harap siapkan 8 buah Cabe merah keriting
1. Diperlukan 3 butir Kemiri
1. Dibutuhkan 1 ruas jari Jahe
1. Jangan lupa Secukupnya garam
1. Tambah Secukupnya penyedap
1. Diperlukan Secukupnya air
1. Harus ada  Bumbu gonggso :
1. Harap siapkan 6 siung bawang merah, iris kasar
1. Diperlukan 10 buah cabe rawit merah




<!--inarticleads2-->

##### Bagaimana membuat  Gongso Sayap Ayam:

1. Potong sayap ayam menjadi 2 bagian. Cuci dan rendam dgn garam dan air jeruk nipis. Cuci bersih kembali. Kemudian panggang / goreng setengah matang agar tidak hancur saat dimasak dengan bumbu2. Sisihkan ayam. Aslinya sayap ayam tidak digoreng.
1. Haluskan bumbu, lalu tumis sampai keluar aroma wangi
1. Masukkan sayap ayam aduk rata lalu tuang air. Ungkep sayap ayam sampai air menyusut atau sampai air nyemek2, jangan lupa koreksi rasanya.
1. Gongso atau tumis irisan bawang merah dan cabe rawit asal layu saja, masukkan sebagian kedalam sayap ayam lalu aduk rata. Gongso sayap ayam siap disajikan dengan ditabur sebagian bumbu gongso.




Demikianlah cara membuat gongso sayap ayam yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
