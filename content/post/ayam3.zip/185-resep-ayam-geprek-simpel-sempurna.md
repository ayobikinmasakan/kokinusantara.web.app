---
description: "Resep : Ayam Geprek Simpel Sempurna"
title: "Resep : Ayam Geprek Simpel Sempurna"
slug: 185-resep-ayam-geprek-simpel-sempurna
date: 2020-09-27T21:47:44.114Z
image: https://img-global.cpcdn.com/recipes/c3e4518f8604021c/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c3e4518f8604021c/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c3e4518f8604021c/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg
author: Jack Cook
ratingvalue: 4
reviewcount: 47143
recipeingredient:
- "500 gr dadapaha ayam"
- "1/2 sdt garam"
- "1/2 sdt merica bubuk"
- "1/2 bks kaldu bubuk"
- "4 siung bawang putih haluskan"
- "1 butir telur"
- "5 sendok sayur terigu"
- "1 sendok sayur maizena"
- " Sambel"
- "10 cabe rawit"
- "1 siung kecil bawang putih"
- "1 siung bawang merah"
- "Secukupnya gulagaramminyak"
recipeinstructions:
- "Bersihkan ayam, masukkan garam,merica, kaldu bubuk, bawang putih. Aduk rata, masukkan dlm kulkas,simpan 1 malam untuk digoreng besok pagi (12jam)"
- "Ambil 1 potong ayam, masukkan kedalam telur yg sudah dikocok, gulingkan kedalam campuran tepung, cubit2 ayamnya agar tepungnya keriting. Ulangi sekali lagi jika ingin hasil yg lebih tebal. Goreng dlm minyak yg sudah dipanaskan dgn api sedang agar matangnya merata hingga kedalam. Jika sudah matang, angkat dan tiriskan."
- "Sambal: goreng cabe, bawang merah dan bawang putih hingga layu, ulek kasar dgn garam dan gula. Jangan sampe halus. Siram dgn minyak panas. Siap dihidangkan dgn ayam."
- "Note: 1. potongan ayam jangan terlalu besar, susah matangnya. Nanti keduluan tepungnya yg gosong sebelum ayamnya yg matang"
- "Kalo mau lebih cepat dan praktis, ayamnya bisa diungkep dulu, bumbu bisa meresap dan dagingnya jg sudah pasti matang, gak perlu nunggu marinasi 12jam. Selain itu, waktu menggoreng ayam jg lebih cepat"
- "Kalo mau yg lebih praktis lagi, beli aja ayam crispy yg udah jadi,tinggal buat sambel di rumah. hahaha"
categories:
- Recipe
tags:
- ayam
- geprek
- simpel

katakunci: ayam geprek simpel 
nutrition: 196 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Geprek Simpel](https://img-global.cpcdn.com/recipes/c3e4518f8604021c/751x532cq70/ayam-geprek-simpel-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam geprek simpel yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan ciri khas yang merupakan keragaman Nusantara

Kedekatan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Geprek Simpel untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang dapat anda praktekkan salah satunya ayam geprek simpel yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam geprek simpel tanpa harus bersusah payah.
Seperti resep Ayam Geprek Simpel yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Simpel:

1. Diperlukan 500 gr dada/paha ayam
1. Harus ada 1/2 sdt garam
1. Harus ada 1/2 sdt merica bubuk
1. Harap siapkan 1/2 bks kaldu bubuk
1. Tambah 4 siung bawang putih, haluskan
1. Harap siapkan 1 butir telur
1. Tambah 5 sendok sayur terigu
1. Diperlukan 1 sendok sayur maizena
1. Jangan lupa  Sambel:
1. Harus ada 10 cabe rawit
1. Diperlukan 1 siung kecil bawang putih
1. Harus ada 1 siung bawang merah
1. Harap siapkan Secukupnya gula,garam,minyak




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Geprek Simpel:

1. Bersihkan ayam, masukkan garam,merica, kaldu bubuk, bawang putih. Aduk rata, masukkan dlm kulkas,simpan 1 malam untuk digoreng besok pagi (12jam)
1. Ambil 1 potong ayam, masukkan kedalam telur yg sudah dikocok, gulingkan kedalam campuran tepung, cubit2 ayamnya agar tepungnya keriting. Ulangi sekali lagi jika ingin hasil yg lebih tebal. Goreng dlm minyak yg sudah dipanaskan dgn api sedang agar matangnya merata hingga kedalam. Jika sudah matang, angkat dan tiriskan.
1. Sambal: goreng cabe, bawang merah dan bawang putih hingga layu, ulek kasar dgn garam dan gula. Jangan sampe halus. Siram dgn minyak panas. Siap dihidangkan dgn ayam.
1. Note: 1. potongan ayam jangan terlalu besar, susah matangnya. Nanti keduluan tepungnya yg gosong sebelum ayamnya yg matang
1. Kalo mau lebih cepat dan praktis, ayamnya bisa diungkep dulu, bumbu bisa meresap dan dagingnya jg sudah pasti matang, gak perlu nunggu marinasi 12jam. Selain itu, waktu menggoreng ayam jg lebih cepat
1. Kalo mau yg lebih praktis lagi, beli aja ayam crispy yg udah jadi,tinggal buat sambel di rumah. hahaha




Demikianlah cara membuat ayam geprek simpel yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
