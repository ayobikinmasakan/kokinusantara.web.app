---
description: "Resep : Ayam geprek pedas Favorite"
title: "Resep : Ayam geprek pedas Favorite"
slug: 107-resep-ayam-geprek-pedas-favorite
date: 2020-08-17T16:21:22.097Z
image: https://img-global.cpcdn.com/recipes/c44052e4c659d242/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c44052e4c659d242/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c44052e4c659d242/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg
author: Kenneth Carson
ratingvalue: 4.3
reviewcount: 34727
recipeingredient:
- "2 potong ayam"
- "5 sdm Tepung serbaguna"
- "10 Cabe rawit merah"
- "3 buah Bawang putih"
- "secukupnya Minyak"
- "secukupnya Air"
- "Sejumput garam"
recipeinstructions:
- "Cuci bersih ayam, saya disini pake yg sayap saja tp cuma bikin 2 potong, karena enakan bikin dadakan."
- "Campur 1 sdm tepung serbaguna, lalu baluri ayam ke tepung basah. Nah 4 sendok makan lg untuk tepung kering. Ulangi hingga 2 kali dan tepung menempel semua (basah,kering,basah,kering)."
- "Panaskan minyak, goreng ayam hingga meresap kedlm minyaknya. Goreng pakai api sedang"
- "Setelah ayam matang, cuci bersih cabe dan bawang putih. Goreng dgn potong2 terlebih dahulu (agar tdk meletus2)."
- "Lalu ulek cabe dan bawang putih, tambahkan garam. Lalu masukkan ayam, geprek ayam nya.. Selesai deh, mudah sekali😉"
categories:
- Recipe
tags:
- ayam
- geprek
- pedas

katakunci: ayam geprek pedas 
nutrition: 121 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam geprek pedas](https://img-global.cpcdn.com/recipes/c44052e4c659d242/751x532cq70/ayam-geprek-pedas-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang setidaknya kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam geprek pedas yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Kita



Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam geprek pedas untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda contoh salah satunya ayam geprek pedas yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam geprek pedas tanpa harus bersusah payah.
Seperti resep Ayam geprek pedas yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 7 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam geprek pedas:

1. Harap siapkan 2 potong ayam
1. Diperlukan 5 sdm Tepung serbaguna
1. Jangan lupa 10 Cabe rawit merah
1. Diperlukan 3 buah Bawang putih
1. Harap siapkan secukupnya Minyak
1. Dibutuhkan secukupnya Air
1. Siapkan Sejumput garam




<!--inarticleads2-->

##### Bagaimana membuat  Ayam geprek pedas:

1. Cuci bersih ayam, saya disini pake yg sayap saja tp cuma bikin 2 potong, karena enakan bikin dadakan.
1. Campur 1 sdm tepung serbaguna, lalu baluri ayam ke tepung basah. Nah 4 sendok makan lg untuk tepung kering. Ulangi hingga 2 kali dan tepung menempel semua (basah,kering,basah,kering).
1. Panaskan minyak, goreng ayam hingga meresap kedlm minyaknya. Goreng pakai api sedang
1. Setelah ayam matang, cuci bersih cabe dan bawang putih. Goreng dgn potong2 terlebih dahulu (agar tdk meletus2).
1. Lalu ulek cabe dan bawang putih, tambahkan garam. Lalu masukkan ayam, geprek ayam nya.. Selesai deh, mudah sekali😉




Demikianlah cara membuat ayam geprek pedas yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
