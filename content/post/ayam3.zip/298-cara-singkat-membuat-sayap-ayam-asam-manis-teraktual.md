---
description: "Cara singkat membuat Sayap Ayam Asam Manis teraktual"
title: "Cara singkat membuat Sayap Ayam Asam Manis teraktual"
slug: 298-cara-singkat-membuat-sayap-ayam-asam-manis-teraktual
date: 2020-12-26T05:24:25.975Z
image: https://img-global.cpcdn.com/recipes/867a378268f5f90b/751x532cq70/sayap-ayam-asam-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/867a378268f5f90b/751x532cq70/sayap-ayam-asam-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/867a378268f5f90b/751x532cq70/sayap-ayam-asam-manis-foto-resep-utama.jpg
author: Brian Mendez
ratingvalue: 4.9
reviewcount: 18770
recipeingredient:
- "500 g sayap ayam"
- "2 siung bawang putih haluskan"
- "1 sdt garam"
- "1 sdt merica bubuk"
- " Minyak goreng"
- " Bahan Pelapis "
- "300 g tepung terigu"
- "3 sdm tepung maizena"
- "1 sdt merica bubuk"
- "1 sdt kaldu jamur"
- " Air es utk pencelup"
- " Bahan Saus "
- "3 siung bawang putih cincang"
- "1/2 bh bawang bombay iris"
- "2 bh cabe merah keriting iris"
- "4 bh belimbing wuluh potong"
- "5 sdm saus sambal"
- "3 sdm saus tomat"
- "2 sdm saus tiram"
- "Secukupnya gula garam dan kaldu jamur"
- "500 ml air"
- "1 sdm tepung maizena encerkan dg 1 sdm air"
recipeinstructions:
- "Potong sayap ayam menjadi 2 bagian, marinasi dg bawang putih, garam dan merica bubuk. Diamkan 15 menit."
- "AYAM GORENG TEPUNG ---&gt; Campur bahan pelapis kecuali air es. Masukkan ayam, bolak balik hingga tepung menempel. Ambil sayap ayam, kibaskan dr tepung, masukkan ke dlm air es hingga terendam. Angkat dan masukkan ke dlm tepung lagi. Bolak balik hingga tepung menempel. Kibaskan ayam dr tepung lalu goreng dlm minyak panas hingga matang."
- "SAUS ASAM MANIS ---&gt; Tumis bawang putih hingga harum, tuangi air dan didihkan. Masukkan saus sambal, saus tomat, saus tiram, gula, garam, kaldu dan belimbing wuluh, didihkan lagi. Tambahkan cabe, bawang bombay dan air maizena. Aduk hingga mengental. Koreksi rasa. Angkat."
- "Tata sayap ayam goreng tepung di piring lalu siram dg saus asam manis. Sajikan. Selamat mencoba 🤗"
categories:
- Recipe
tags:
- sayap
- ayam
- asam

katakunci: sayap ayam asam 
nutrition: 215 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Lunch

---


![Sayap Ayam Asam Manis](https://img-global.cpcdn.com/recipes/867a378268f5f90b/751x532cq70/sayap-ayam-asam-manis-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang harus kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti sayap ayam asam manis yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa keistimewahan yang merupakan keragaman Kita

Kehangatan keluarga bisa didapat dengan cara mudah. Diantaranya adalah memasak Sayap Ayam Asam Manis untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

Kali ini trend makanan membuat Resep Sayap Ayam Pedas Manis nah untuk ladies yang suka dengan sayap ayam bisa coba resep ini, penasaran ? intip cara. Ayam menjadi makanan favorit semua orang. Ragam masakan nikmat olahan ayam bisa Anda temukan di berbagai restoran. Nah, ternyata membuat ayam asam manis senikmat buatan restoran tidak sulit, lho.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian masakan yang dapat anda buat salah satunya sayap ayam asam manis yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep sayap ayam asam manis tanpa harus bersusah payah.
Berikut ini resep Sayap Ayam Asam Manis yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 22 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Sayap Ayam Asam Manis:

1. Harus ada 500 g sayap ayam
1. Harus ada 2 siung bawang putih haluskan
1. Dibutuhkan 1 sdt garam
1. Siapkan 1 sdt merica bubuk
1. Siapkan  Minyak goreng
1. Diperlukan  Bahan Pelapis :
1. Harus ada 300 g tepung terigu
1. Dibutuhkan 3 sdm tepung maizena
1. Dibutuhkan 1 sdt merica bubuk
1. Harus ada 1 sdt kaldu jamur
1. Diperlukan  Air es utk pencelup
1. Jangan lupa  Bahan Saus :
1. Harus ada 3 siung bawang putih cincang
1. Tambah 1/2 bh bawang bombay iris
1. Harus ada 2 bh cabe merah keriting iris
1. Diperlukan 4 bh belimbing wuluh potong
1. Diperlukan 5 sdm saus sambal
1. Siapkan 3 sdm saus tomat
1. Jangan lupa 2 sdm saus tiram
1. Tambah Secukupnya gula, garam dan kaldu jamur
1. Dibutuhkan 500 ml air
1. Siapkan 1 sdm tepung maizena encerkan dg 1 sdm air


Anda dapat membuat sayap ayam pedas, manis, atau gurih, sesuai selera. Misalnya, Anda dapat menggunakan bumbu teriyaki, saus tomat, saus asam manis, atau arak masak untuk merendam sayap ayam. Sepiring sayap ayam yang terasa manis, pedas dan renyah membuat kami seakan kalap menyantapnya dan dalam sekejap dua puluh sayap ayam berpindah ke Selain rasa manis, pedas dan asin yang mendominasi masakan ini, ada sedikit rasa asam yang membuat saus ayam terasa unik. Rasanya gurih renyah dengan saus yang asam manis segar. 

<!--inarticleads2-->

##### Langkah membuat  Sayap Ayam Asam Manis:

1. Potong sayap ayam menjadi 2 bagian, marinasi dg bawang putih, garam dan merica bubuk. Diamkan 15 menit.
1. AYAM GORENG TEPUNG ---&gt; Campur bahan pelapis kecuali air es. Masukkan ayam, bolak balik hingga tepung menempel. Ambil sayap ayam, kibaskan dr tepung, masukkan ke dlm air es hingga terendam. Angkat dan masukkan ke dlm tepung lagi. Bolak balik hingga tepung menempel. Kibaskan ayam dr tepung lalu goreng dlm minyak panas hingga matang.
1. SAUS ASAM MANIS ---&gt; Tumis bawang putih hingga harum, tuangi air dan didihkan. Masukkan saus sambal, saus tomat, saus tiram, gula, garam, kaldu dan belimbing wuluh, didihkan lagi. Tambahkan cabe, bawang bombay dan air maizena. Aduk hingga mengental. Koreksi rasa. Angkat.
1. Tata sayap ayam goreng tepung di piring lalu siram dg saus asam manis. Sajikan. Selamat mencoba 🤗


Sepiring sayap ayam yang terasa manis, pedas dan renyah membuat kami seakan kalap menyantapnya dan dalam sekejap dua puluh sayap ayam berpindah ke Selain rasa manis, pedas dan asin yang mendominasi masakan ini, ada sedikit rasa asam yang membuat saus ayam terasa unik. Rasanya gurih renyah dengan saus yang asam manis segar. Ayam asam manis merupakan makanan khas Kanton yang sering ditemui di menu restoran china. Lumuri ayam dengan bumbu halus hingga tercampur rata. Maka saat memasak resep cumi asam manis pedas sebaiknya matangkan bumbu terlebih dahulu kemudian baru masukkan cumi ke dalamnya. 

Demikianlah cara membuat sayap ayam asam manis yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan teruji, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
