---
description: "Resep : Ayam geprek gampang Sempurna"
title: "Resep : Ayam geprek gampang Sempurna"
slug: 215-resep-ayam-geprek-gampang-sempurna
date: 2020-11-19T05:33:50.881Z
image: https://img-global.cpcdn.com/recipes/34bad3aaeababaaf/751x532cq70/ayam-geprek-gampang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/34bad3aaeababaaf/751x532cq70/ayam-geprek-gampang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/34bad3aaeababaaf/751x532cq70/ayam-geprek-gampang-foto-resep-utama.jpg
author: Lloyd Rhodes
ratingvalue: 4.7
reviewcount: 49645
recipeingredient:
- "1/4 kg ayam bagian dada"
- " Tepung bumbu aku pakai sajiku golden crispy"
- " Minyak buat goreng"
- " Air buat bikin adonan celup sekitar 100ml"
- "3 siung bawang merah"
- "2 siung bawang putih"
- "7 buah cabe rawit"
- "1 sendok teh garam"
- "1 sendok makan gula"
recipeinstructions:
- "Campur 5sendok makan tepung bumbu dengan air untuk adonan celup"
- "Fillet ayam lalu masukkan kedalam adonan celup, biarkan"
- "Sementara ayam direndam, bikin sambel dulu, haluskan bawang merah, bawang putih, cabe rawit, garam dan gula"
- "Angkat ayam dari adonan celup lalu masukkan kedalam tepung kering sampe terbalut rata, tepuk2 sedikit lalu goreng dalam minyak pakai api sedang (deep fry ya.. artinya ayam harus tenggelam, pake minyak yg banyak)"
- "Setelah matang, tirikan ayam"
- "Siramkan minyak sisa gorengan ayam sebanyak 1sendok teh kedalam sambel lalu aduk"
- "Geprek ayam lalu sajikan"
- "Kalo mau ayam digeprek sekalian sama sambelnya lebih enak (saya suka gitu)"
categories:
- Recipe
tags:
- ayam
- geprek
- gampang

katakunci: ayam geprek gampang 
nutrition: 265 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam geprek gampang](https://img-global.cpcdn.com/recipes/34bad3aaeababaaf/751x532cq70/ayam-geprek-gampang-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam geprek gampang yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa keistimewahan yang merupakan keragaman Indonesia



Kehangatan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam geprek gampang untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang dapat anda contoh salah satunya ayam geprek gampang yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam geprek gampang tanpa harus bersusah payah.
Berikut ini resep Ayam geprek gampang yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 9 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek gampang:

1. Siapkan 1/4 kg ayam (bagian dada)
1. Siapkan  Tepung bumbu (aku pakai sajiku golden crispy)
1. Siapkan  Minyak buat goreng
1. Diperlukan  Air buat bikin adonan celup (sekitar 100ml)
1. Tambah 3 siung bawang merah
1. Harus ada 2 siung bawang putih
1. Harus ada 7 buah cabe rawit
1. Jangan lupa 1 sendok teh garam
1. Jangan lupa 1 sendok makan gula




<!--inarticleads2-->

##### Cara membuat  Ayam geprek gampang:

1. Campur 5sendok makan tepung bumbu dengan air untuk adonan celup
1. Fillet ayam lalu masukkan kedalam adonan celup, biarkan
1. Sementara ayam direndam, bikin sambel dulu, haluskan bawang merah, bawang putih, cabe rawit, garam dan gula
1. Angkat ayam dari adonan celup lalu masukkan kedalam tepung kering sampe terbalut rata, tepuk2 sedikit lalu goreng dalam minyak pakai api sedang (deep fry ya.. artinya ayam harus tenggelam, pake minyak yg banyak)
1. Setelah matang, tirikan ayam
1. Siramkan minyak sisa gorengan ayam sebanyak 1sendok teh kedalam sambel lalu aduk
1. Geprek ayam lalu sajikan
1. Kalo mau ayam digeprek sekalian sama sambelnya lebih enak (saya suka gitu)




Demikianlah cara membuat ayam geprek gampang yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
