---
description: "Steps menyiapakan Ayam rica simple terupdate"
title: "Steps menyiapakan Ayam rica simple terupdate"
slug: 480-steps-menyiapakan-ayam-rica-simple-terupdate
date: 2020-10-18T15:10:03.401Z
image: https://img-global.cpcdn.com/recipes/8e809a03080b32c7/751x532cq70/ayam-rica-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8e809a03080b32c7/751x532cq70/ayam-rica-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8e809a03080b32c7/751x532cq70/ayam-rica-simple-foto-resep-utama.jpg
author: Cecelia Rios
ratingvalue: 4.1
reviewcount: 40397
recipeingredient:
- "1 ekor ayam"
- " Bumbu halus"
- "8 Bawang Merah"
- "5 Bawang Putih"
- " Jahe seruas jempol"
- " Lengkuas seruas jempol"
- "3 kemiri sangrai"
- " Bumbu kasar"
- " Cabe rawit sesuai keinginan"
- "1 batang serai iris iris"
- "3 daun jeruk buang batang tengah setelah itu iris iris"
- "2 daun salam Tidak usah diris"
- "2 Irisan buah jeruk dipakai setelah ayam matang"
- " Bahan pelengkap"
- "Sdt ladamerica bubuk"
- "Sdt ketumbar bubuk"
- "secukupnya Garam"
- "secukupnya Kecap"
- "Secukupnya gula"
- "Secukupnya air"
recipeinstructions:
- "Potong ayam menjadi kecil kecil"
- "Didihkan air, rebus ayam hingga matang dan sisihkan"
- "Panaskan minyak, Tumis bumbu iris sampai wangi dan setelah itu langsung masukan bumbu halus"
- "Semua bumbu sudah matang masukan ayam, dan masukkan bumbu pelengkap (masak ayam dengan api kecil biar bumbu meresap)"
- "Tunggu air menyusut sesuai keinginan. Tambahkan perasaan air jeruk 2 iris"
- "Cek rasa. Siap dihidangkan sama nasi hangat♥️"
categories:
- Recipe
tags:
- ayam
- rica
- simple

katakunci: ayam rica simple 
nutrition: 155 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam rica simple](https://img-global.cpcdn.com/recipes/8e809a03080b32c7/751x532cq70/ayam-rica-simple-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica simple yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa keistimewahan yang merupakan keragaman Nusantara

Keharmonisan keluarga dapat didapat dengan cara mudah. Salah satunya adalah memasak Ayam rica simple untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

Hallo semuanya kali ini aku masak &#34;Ayam rica-rica&#34; penasaran rasanya ? Lihat juga resep Ayam Rica Kemangi (resep mertua ❤) enak lainnya. Resep ayam rica-rica ini dikenal berasal dari daerah Manado, Sulawesi Utara yang memiliki cita rasa pedas Seperti pada resep-resep olahan ayam lainnya, bumbu ayam-rica-rica juga menggunakan. Bahan bumbu ayam rica rica yang digunakan sebenarnya cukup simple dan sederhana, seperti : kunyit, jahe, serai, cabai merah, bawang putih, dan beberapa bumbu lainnya.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang dapat anda praktekkan salah satunya ayam rica simple yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica simple tanpa harus bersusah payah.
Berikut ini resep Ayam rica simple yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica simple:

1. Harap siapkan 1 ekor ayam
1. Siapkan  Bumbu halus
1. Siapkan 8 Bawang Merah
1. Harus ada 5 Bawang Putih
1. Harap siapkan  Jahe (seruas jempol)
1. Harus ada  Lengkuas (seruas jempol)
1. Jangan lupa 3 kemiri sangrai
1. Siapkan  Bumbu kasar
1. Harus ada  Cabe rawit (sesuai keinginan)
1. Tambah 1 batang serai (iris iris)
1. Diperlukan 3 daun jeruk (buang batang tengah setelah itu iris iris)
1. Tambah 2 daun salam (Tidak usah diris)
1. Harus ada 2 Irisan buah jeruk (dipakai setelah ayam matang)
1. Diperlukan  Bahan pelengkap
1. Diperlukan Sdt lada/merica bubuk
1. Diperlukan Sdt ketumbar bubuk
1. Dibutuhkan secukupnya Garam
1. Diperlukan secukupnya Kecap
1. Dibutuhkan Secukupnya gula
1. Jangan lupa Secukupnya air


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas. Ayam rica-rica memang dibuat dengan menggunakan berbagai rempah-rempah yang khas Indonesia, sama seperti makanan tradisional lainnya yang kaya akan rempah-rempah. Berikut resep memasak ayam rica-rica untuk menu harian keluarga atau buka puasa. Cobalah memasaknya dengan bumbu rica-rica khas Manado. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica simple:

1. Potong ayam menjadi kecil kecil
1. Didihkan air, rebus ayam hingga matang dan sisihkan
1. Panaskan minyak, Tumis bumbu iris sampai wangi dan setelah itu langsung masukan bumbu halus
1. Semua bumbu sudah matang masukan ayam, dan masukkan bumbu pelengkap (masak ayam dengan api kecil biar bumbu meresap)
1. Tunggu air menyusut sesuai keinginan. Tambahkan perasaan air jeruk 2 iris
1. Cek rasa. Siap dihidangkan sama nasi hangat♥️


Berikut resep memasak ayam rica-rica untuk menu harian keluarga atau buka puasa. Cobalah memasaknya dengan bumbu rica-rica khas Manado. Resep Ayam Rica - Rica Pedas Enak dan Spesial Untuk Keluarga - Asal muasal dari resep ayam rica-rica ini berasal dari daerah Manado - Sul. Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. 

Demikianlah cara membuat ayam rica simple yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
