---
description: "Step-by-Step membuat Ayam Geprek Rumahan minggu ini"
title: "Step-by-Step membuat Ayam Geprek Rumahan minggu ini"
slug: 145-step-by-step-membuat-ayam-geprek-rumahan-minggu-ini
date: 2020-09-18T19:34:16.622Z
image: https://img-global.cpcdn.com/recipes/18387009341dac35/751x532cq70/ayam-geprek-rumahan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/18387009341dac35/751x532cq70/ayam-geprek-rumahan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/18387009341dac35/751x532cq70/ayam-geprek-rumahan-foto-resep-utama.jpg
author: Jimmy Henry
ratingvalue: 4.2
reviewcount: 15505
recipeingredient:
- "25 cabai pedas garuk kalau mau lebih gila tambah 10 atau lebih"
- "3 siung bawang putih"
- "1/2 sdt garam"
- "1 sdt gula"
- "1 atau 2 ayam goreng kfc pisahin sama tulang biar makannya nggak ribet ya"
recipeinstructions:
- "(bisa pakai blender atau ulekan ya, aku pakai ulekan)   tumbuk bawang hingga alus simpan ke tempat, kemudian masukkan cabai dan garam ke ulekan agar mudah nguleknya langsung campur garam ya. ulek hingga sedikit halus, biar pedasnya lebih berasa bijinya diulek sampai halus banget."
- "Masukkan gula, aduk hingga tercampur."
- "Siapkan wajan, masukkan minyak goreng dan tumis bawang putih hingga sedikit kecoklatan dan harum masukkan semua cabai dan oseng-oseng kurang lebih 1 menit."
- "Geprek ayam dan campurkan dengan osengan cabai tadi lalu tiriskan."
categories:
- Recipe
tags:
- ayam
- geprek
- rumahan

katakunci: ayam geprek rumahan 
nutrition: 288 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Geprek Rumahan](https://img-global.cpcdn.com/recipes/18387009341dac35/751x532cq70/ayam-geprek-rumahan-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau empuk. Ciri khas makanan Nusantara ayam geprek rumahan yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kehangatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam Geprek Rumahan untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang dapat anda buat salah satunya ayam geprek rumahan yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam geprek rumahan tanpa harus bersusah payah.
Seperti resep Ayam Geprek Rumahan yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Geprek Rumahan:

1. Diperlukan 25 cabai (pedas garuk, kalau mau lebih gila tambah 10 atau lebih)
1. Tambah 3 siung bawang putih
1. Diperlukan 1/2 sdt garam
1. Harus ada 1 sdt gula
1. Jangan lupa 1 atau 2 ayam goreng kfc (pisahin sama tulang biar makannya nggak ribet ya)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Geprek Rumahan:

1. (bisa pakai blender atau ulekan ya, aku pakai ulekan)  -  - tumbuk bawang hingga alus simpan ke tempat, kemudian masukkan cabai dan garam ke ulekan agar mudah nguleknya langsung campur garam ya. ulek hingga sedikit halus, biar pedasnya lebih berasa bijinya diulek sampai halus banget.
1. Masukkan gula, aduk hingga tercampur.
1. Siapkan wajan, masukkan minyak goreng dan tumis bawang putih hingga sedikit kecoklatan dan harum masukkan semua cabai dan oseng-oseng kurang lebih 1 menit.
1. Geprek ayam dan campurkan dengan osengan cabai tadi lalu tiriskan.




Demikianlah cara membuat ayam geprek rumahan yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
