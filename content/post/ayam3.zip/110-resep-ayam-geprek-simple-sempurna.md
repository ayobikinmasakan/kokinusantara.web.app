---
description: "Resep : Ayam geprek simple Sempurna"
title: "Resep : Ayam geprek simple Sempurna"
slug: 110-resep-ayam-geprek-simple-sempurna
date: 2020-11-07T06:27:51.160Z
image: https://img-global.cpcdn.com/recipes/dea5c72e399dd14e/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dea5c72e399dd14e/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dea5c72e399dd14e/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg
author: Herman Burns
ratingvalue: 4
reviewcount: 5104
recipeingredient:
- "1/4 kg dada ayam"
- "2 sch tepung sajiku"
- "Secukupnya terigu"
- "1 sch kaldu bubuk"
- " Bahan sambal"
- "15 cabe rawit"
- "2 cabe merah kriting"
- "2 bawang merah"
- "2 bawang putih"
- "1 buah tomat"
- "Secukupnya gula garam"
- " Bahan untuk ungkeb ayam"
- " Uleg kunyit ketumbar bawang merah bawang putih garam"
recipeinstructions:
- "Cuci bersih dada ayam belah sedikit lalu ungkeb dengan bumbu halus tadi tunggu beberapa menit"
- "Sambil menunggu ayam ungkeb matang, siap kan tepung sajiku campur tepung terigu beri kaldu bubuk (pisah jadi 2 ya, satunya basah satunya kering aja)"
- "Jika bumbu ayam ungkeb sudah meresap angkat dan tiris kan sebentar, lalu lumuri dengan tepung basah terus gulingkan ke tepung kering (tips: sesudah di ungkeb, biasanya saya rendam sebentar ke air es supaya daging ayam nya ga alot)"
- "Setelah itu goreng sampai warna kecoklatan jika sudah matang sisihkan dulu. Kita lanjut bikin sambal"
- "Goreng sebentar cabe tomat bawang merah bawang putih, lalu tumbuk kasar saja. Beri garam dan gula, test rasa. Setelah itu siram minyak panas supaya menetralisir rasa pedas."
- "Ambil ayam yang tadi sudah digoreng lalu tumbuk bersama sambal.. Ayam geprek siap disantap😊"
categories:
- Recipe
tags:
- ayam
- geprek
- simple

katakunci: ayam geprek simple 
nutrition: 161 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam geprek simple](https://img-global.cpcdn.com/recipes/dea5c72e399dd14e/751x532cq70/ayam-geprek-simple-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau empuk. Ciri khas makanan Nusantara ayam geprek simple yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Ayam geprek simple untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda buat salah satunya ayam geprek simple yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep ayam geprek simple tanpa harus bersusah payah.
Berikut ini resep Ayam geprek simple yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam geprek simple:

1. Diperlukan 1/4 kg dada ayam
1. Harus ada 2 sch tepung sajiku
1. Harus ada Secukupnya terigu
1. Jangan lupa 1 sch kaldu bubuk
1. Dibutuhkan  Bahan sambal
1. Harap siapkan 15 cabe rawit
1. Tambah 2 cabe merah kriting
1. Harus ada 2 bawang merah
1. Dibutuhkan 2 bawang putih
1. Tambah 1 buah tomat
1. Diperlukan Secukupnya gula, garam
1. Harus ada  Bahan untuk ungkeb ayam
1. Dibutuhkan  Uleg kunyit, ketumbar, bawang merah, bawang putih, garam




<!--inarticleads2-->

##### Cara membuat  Ayam geprek simple:

1. Cuci bersih dada ayam belah sedikit lalu ungkeb dengan bumbu halus tadi tunggu beberapa menit
1. Sambil menunggu ayam ungkeb matang, siap kan tepung sajiku campur tepung terigu beri kaldu bubuk (pisah jadi 2 ya, satunya basah satunya kering aja)
1. Jika bumbu ayam ungkeb sudah meresap angkat dan tiris kan sebentar, lalu lumuri dengan tepung basah terus gulingkan ke tepung kering (tips: sesudah di ungkeb, biasanya saya rendam sebentar ke air es supaya daging ayam nya ga alot)
1. Setelah itu goreng sampai warna kecoklatan jika sudah matang sisihkan dulu. Kita lanjut bikin sambal
1. Goreng sebentar cabe tomat bawang merah bawang putih, lalu tumbuk kasar saja. Beri garam dan gula, test rasa. Setelah itu siram minyak panas supaya menetralisir rasa pedas.
1. Ambil ayam yang tadi sudah digoreng lalu tumbuk bersama sambal.. Ayam geprek siap disantap😊




Demikianlah cara membuat ayam geprek simple yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
