---
description: "Cara singkat membuat Ayam Rica - Rica Terbukti"
title: "Cara singkat membuat Ayam Rica - Rica Terbukti"
slug: 282-cara-singkat-membuat-ayam-rica-rica-terbukti
date: 2021-02-01T04:58:30.029Z
image: https://img-global.cpcdn.com/recipes/ef371d90e966c57b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ef371d90e966c57b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ef371d90e966c57b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Curtis McGuire
ratingvalue: 4
reviewcount: 17962
recipeingredient:
- "500 gram (4 potong) ayam"
- "1 buah jeruk nipis"
- "400 ml air untuk rebusan pertama"
- "1 sdt garam"
- "1 batang serai geprek"
- "1 jempol lengkuas geprek"
- "2 jempol jahe geprek"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1 sdt kaldu jamur"
- "1 sdt garam"
- "15 gram gula merah"
- "1 ikat daun kemangi"
- "3 sdm minyak untuk menumis"
- "300 ml air"
- " Bumbu halus"
- "16 cabe rawit"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "4 biji kemiri"
- "1 telunjuk kunyit"
- "1 sdm minyak"
recipeinstructions:
- "Abis sharing sm ratu bekebon, jd pake cabe hasil bekebon🥰 lumuri ayam dengan air jeruk nipis lalu cuci bersih kemudian rebus kasih garam dan buang airnya"
- "Siapkan semua bahan dan bumbu. Blender bumbu halus, sy blender cabe setelah yg lain halus, krn biar cabe teksturnya kasar."
- "Tumis bumbu halus, daun jeruk, serei, daun salam, lengkuas, dan jahe sampai masak."
- "Lalu tambahkan ayam, aduk-aduk rata sampai tercampur. Tambahkan air, kaldu jamur, gula dan garam secukupnya. masak sampai airnya tinggal sedikit."
- "Kalau sudah sedikit airnya, masukkan kemangi.. Masak sebentar aja.. Karna nanti kemangi jadi terlalu lembek. Kemidian angkat"
- "Dan siap sajikan dengan nasi hangat😋"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 229 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica - Rica](https://img-global.cpcdn.com/recipes/ef371d90e966c57b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas atau gurih. Ciri makanan Indonesia ayam rica - rica yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah memasak Ayam Rica - Rica untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda contoh salah satunya ayam rica - rica yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica - rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica - Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica - Rica:

1. Tambah 500 gram (4 potong) ayam
1. Tambah 1 buah jeruk nipis
1. Tambah 400 ml air untuk rebusan pertama
1. Diperlukan 1 sdt garam
1. Jangan lupa 1 batang serai geprek
1. Jangan lupa 1 jempol lengkuas geprek
1. Jangan lupa 2 jempol jahe geprek
1. Harap siapkan 2 lembar daun jeruk
1. Harap siapkan 2 lembar daun salam
1. Harap siapkan 1 sdt kaldu jamur
1. Harus ada 1 sdt garam
1. Diperlukan 15 gram gula merah
1. Diperlukan 1 ikat daun kemangi
1. Harap siapkan 3 sdm minyak untuk menumis
1. Harap siapkan 300 ml air
1. Harap siapkan  Bumbu halus
1. Harap siapkan 16 cabe rawit
1. Harus ada 5 siung bawang merah
1. Siapkan 4 siung bawang putih
1. Harap siapkan 4 biji kemiri
1. Dibutuhkan 1 telunjuk kunyit
1. Siapkan 1 sdm minyak




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica - Rica:

1. Abis sharing sm ratu bekebon, jd pake cabe hasil bekebon🥰 lumuri ayam dengan air jeruk nipis lalu cuci bersih kemudian rebus kasih garam dan buang airnya
1. Siapkan semua bahan dan bumbu. Blender bumbu halus, sy blender cabe setelah yg lain halus, krn biar cabe teksturnya kasar.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam Rica - Rica">1. Tumis bumbu halus, daun jeruk, serei, daun salam, lengkuas, dan jahe sampai masak.
1. Lalu tambahkan ayam, aduk-aduk rata sampai tercampur. Tambahkan air, kaldu jamur, gula dan garam secukupnya. - masak sampai airnya tinggal sedikit.
1. Kalau sudah sedikit airnya, masukkan kemangi.. Masak sebentar aja.. Karna nanti kemangi jadi terlalu lembek. Kemidian angkat
1. Dan siap sajikan dengan nasi hangat😋




Demikianlah cara membuat ayam rica - rica yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menemukan di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
