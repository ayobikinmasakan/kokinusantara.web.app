---
description: "Cara singkat untuk menyiapakan Ayam rica2 Cepat"
title: "Cara singkat untuk menyiapakan Ayam rica2 Cepat"
slug: 474-cara-singkat-untuk-menyiapakan-ayam-rica2-cepat
date: 2020-12-31T14:43:49.260Z
image: https://img-global.cpcdn.com/recipes/2fd4bd88da492783/751x532cq70/ayam-rica2-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2fd4bd88da492783/751x532cq70/ayam-rica2-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2fd4bd88da492783/751x532cq70/ayam-rica2-foto-resep-utama.jpg
author: Francisco Harper
ratingvalue: 4.6
reviewcount: 41447
recipeingredient:
- "1 ekor ayam pejantan  ayam kampung"
- " A Bumbu blender agak kasar "
- "10 cabai keriting merah"
- "10 cabai rawit merah"
- "8 bawang merah"
- " B Bumbu ulek halus "
- "4 kemiri sangrai"
- " C Bumbu cemplung "
- "5 butir bawang merah iris tipis"
- "2 ruas jari jahe"
- "2 ruas jari lengkuas"
- "1 buah serai"
- "1 sdt kunyit bubuk agar warna lebih kinclong"
- " D Bumbu daun "
- "2 lbr daun pandan simpul"
- "5 lbr daun jeruk sobek2"
- " Bumbu penyedap  1 sdt garam 1 sdt kaldu jamur"
- "500 ml kaldu ayam atau air biasa"
- " Masukan terakhir "
- "seikat daun kemangi"
- "1 buah jeruk nipis peras airnya"
recipeinstructions:
- "Cuci hingga bersih ayam, tiriskan. Tambahkan 1 sendok teh garam dan air jeruk nipis, remas dan marinasi selama 15 menit."
- "Goreng ayam dengan sedikit minyak, hingga setengah matang / permukaan sedikit kecoklatan. Tiriskan dan sisihkan."
- "Tumis semua bahan hingga harum, Masukan ayam, aduk rata dan tambahkan 500 ml air kaldu agar ayam tidak kering. Masukan garam, kaldu jamur (gula). Masak hingga mendidih, kecilkan api masak hingga ayam matang (sekitar 20 menit). Tambahkan air jika proses masak belum selesai"
- "Sesaat sebelum matikan api, tambahkan kemangi dan air jeruk nipis. Siap dihidangkan. Jangan masak terlalu kering, sisahkan sedikit kuah agar nyemek2 istilahnya"
categories:
- Recipe
tags:
- ayam
- rica2

katakunci: ayam rica2 
nutrition: 279 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica2](https://img-global.cpcdn.com/recipes/2fd4bd88da492783/751x532cq70/ayam-rica2-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang patut kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica2 yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Indonesia

Kedekatan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam rica2 untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang dapat anda contoh salah satunya ayam rica2 yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam rica2 tanpa harus bersusah payah.
Seperti resep Ayam rica2 yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica2:

1. Harap siapkan 1 ekor ayam pejantan / ayam kampung
1. Harus ada  A. Bumbu blender agak kasar :
1. Jangan lupa 10 cabai keriting merah
1. Harus ada 10 cabai rawit merah
1. Harap siapkan 8 bawang merah
1. Harap siapkan  B. Bumbu ulek halus :
1. Dibutuhkan 4 kemiri (sangrai)
1. Diperlukan  C. Bumbu cemplung :
1. Dibutuhkan 5 butir bawang merah, iris tipis
1. Jangan lupa 2 ruas jari jahe
1. Harus ada 2 ruas jari lengkuas
1. Diperlukan 1 buah serai
1. Jangan lupa 1 sdt kunyit bubuk (agar warna lebih kinclong)
1. Jangan lupa  D. Bumbu daun :
1. Siapkan 2 lbr daun pandan, simpul
1. Diperlukan 5 lbr daun jeruk, sobek2
1. Harus ada  Bumbu penyedap : 1 sdt garam, 1 sdt kaldu jamur
1. Dibutuhkan 500 ml kaldu ayam (atau air biasa)
1. Jangan lupa  Masukan terakhir :
1. Siapkan seikat daun kemangi
1. Siapkan 1 buah jeruk nipis, peras airnya




<!--inarticleads2-->

##### Cara membuat  Ayam rica2:

1. Cuci hingga bersih ayam, tiriskan. Tambahkan 1 sendok teh garam dan air jeruk nipis, remas dan marinasi selama 15 menit.
1. Goreng ayam dengan sedikit minyak, hingga setengah matang / permukaan sedikit kecoklatan. Tiriskan dan sisihkan.
1. Tumis semua bahan hingga harum, Masukan ayam, aduk rata dan tambahkan 500 ml air kaldu agar ayam tidak kering. Masukan garam, kaldu jamur (gula). Masak hingga mendidih, kecilkan api masak hingga ayam matang (sekitar 20 menit). Tambahkan air jika proses masak belum selesai
1. Sesaat sebelum matikan api, tambahkan kemangi dan air jeruk nipis. Siap dihidangkan. Jangan masak terlalu kering, sisahkan sedikit kuah agar nyemek2 istilahnya




Demikianlah cara membuat ayam rica2 yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
