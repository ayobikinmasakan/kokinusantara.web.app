---
description: "Langkah membuat Ayam Rica ala Jawa Cepat"
title: "Langkah membuat Ayam Rica ala Jawa Cepat"
slug: 413-langkah-membuat-ayam-rica-ala-jawa-cepat
date: 2020-11-20T23:48:51.867Z
image: https://img-global.cpcdn.com/recipes/dcecd055c4a966e6/751x532cq70/ayam-rica-ala-jawa-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dcecd055c4a966e6/751x532cq70/ayam-rica-ala-jawa-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dcecd055c4a966e6/751x532cq70/ayam-rica-ala-jawa-foto-resep-utama.jpg
author: Marguerite Manning
ratingvalue: 4.4
reviewcount: 46352
recipeingredient:
- "1/2 kg ayam potongpotong kecil"
- "2 buah kentang potong 8"
- "3 lembar daun salam"
- "2 batang sereh geprek"
- "3 Sdm kecap manis"
- "3 sdm air asam jawa dari sekitar 57butir biji asam"
- " Gula dan garam"
- " Bumbu Halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "4 butir kemiri"
- "5 cabe merah keriting"
- "10 cabe rawit merah"
- "2 ruas jahe"
recipeinstructions:
- "Siapkan bumbu dan ayam, tumis bumbu hingga wangi dan matang."
- "Apabila tumisan bumbu sudah matang masukkan ayam dan kentang, aduk hingga merata. Tuang 1 gelas air matang, kecap, gula dan garam."
- "Masak hingga air surut, setelah air surut, masukkan air asam jawa, masak kembali dan koreksi rasa, setelah rasa sesuai selera, matikan kompor dan sajikan dengan nasi hangat."
categories:
- Recipe
tags:
- ayam
- rica
- ala

katakunci: ayam rica ala 
nutrition: 296 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica ala Jawa](https://img-global.cpcdn.com/recipes/dcecd055c4a966e6/751x532cq70/ayam-rica-ala-jawa-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica ala jawa yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Kedekatan rumah tangga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam Rica ala Jawa untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda buat salah satunya ayam rica ala jawa yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep ayam rica ala jawa tanpa harus bersusah payah.
Berikut ini resep Ayam Rica ala Jawa yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica ala Jawa:

1. Dibutuhkan 1/2 kg ayam (potong-potong kecil)
1. Harap siapkan 2 buah kentang potong 8
1. Diperlukan 3 lembar daun salam
1. Siapkan 2 batang sereh geprek
1. Harap siapkan 3 Sdm kecap manis
1. Harus ada 3 sdm air asam jawa (dari sekitar 5-7butir biji asam)
1. Harus ada  Gula dan garam
1. Harap siapkan  Bumbu Halus
1. Harap siapkan 6 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Siapkan 4 butir kemiri
1. Tambah 5 cabe merah keriting
1. Diperlukan 10 cabe rawit merah
1. Jangan lupa 2 ruas jahe




<!--inarticleads2-->

##### Cara membuat  Ayam Rica ala Jawa:

1. Siapkan bumbu dan ayam, tumis bumbu hingga wangi dan matang.
1. Apabila tumisan bumbu sudah matang masukkan ayam dan kentang, aduk hingga merata. Tuang 1 gelas air matang, kecap, gula dan garam.
1. Masak hingga air surut, setelah air surut, masukkan air asam jawa, masak kembali dan koreksi rasa, setelah rasa sesuai selera, matikan kompor dan sajikan dengan nasi hangat.




Demikianlah cara membuat ayam rica ala jawa yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
