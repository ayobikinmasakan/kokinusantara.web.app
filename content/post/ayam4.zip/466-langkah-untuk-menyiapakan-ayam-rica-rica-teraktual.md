---
description: "Langkah untuk menyiapakan Ayam rica rica teraktual"
title: "Langkah untuk menyiapakan Ayam rica rica teraktual"
slug: 466-langkah-untuk-menyiapakan-ayam-rica-rica-teraktual
date: 2020-12-13T08:06:41.476Z
image: https://img-global.cpcdn.com/recipes/4b765af62f6a7635/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4b765af62f6a7635/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4b765af62f6a7635/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Cory Goodman
ratingvalue: 4.2
reviewcount: 27869
recipeingredient:
- "1/2 kg ayam"
- "3 buah cabe merah besar buang bijinya"
- "5 buah cabe keriting buang bijinya"
- "5 cabe rawit"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "4 buah kemiri sangrai"
- "secukupnya Merica"
- "1/2 sdt gula pasirgaram secukupya"
- "3 sdt santan kara"
- "2 serai 1 ruas jahe 3 daun jeruk"
- " Air asem  penyedap rasa"
- " Cabe hijau potong serong"
recipeinstructions:
- "Ayam potong kecil kasih air jeruk diamkan sebentar baru cuci bersih"
- "Gongso ayam sebentar agak setengah masak angkat tiriskan"
- "Ulek bawang merah.bawang putih jahe.kemiri sangrai tambahkan cabe merah besar.cabe keriting dan cabe rawit masukkan gula dan garam ulek sampai halus"
- "Tumis bumbu sampai harum masukkan ayam serai daun jeruk tambahkan gula merah dan santan tambahkan air secukupnya"
- "Tambahkan penyedap rasa dan caba hijau"
- "Angkat.siap di sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 186 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT37M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica rica](https://img-global.cpcdn.com/recipes/4b765af62f6a7635/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga gurih. Ciri kuliner Nusantara ayam rica rica yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Resep Ayam Rica Rica Bahan: Daging Ayam Lemon juice Chicken powder Garam. Bawang merah Bawang putih Cabe Jahe Serai Daun jeruk purut Daun kucai. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica.

Kehangatan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam rica rica untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang bisa anda contoh salah satunya ayam rica rica yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam rica rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica:

1. Harap siapkan 1/2 kg ayam
1. Jangan lupa 3 buah cabe merah besar buang bijinya
1. Dibutuhkan 5 buah cabe keriting buang bijinya
1. Dibutuhkan 5 cabe rawit
1. Dibutuhkan 10 siung bawang merah
1. Jangan lupa 5 siung bawang putih
1. Diperlukan 4 buah kemiri sangrai
1. Siapkan secukupnya Merica
1. Harus ada 1/2 sdt gula pasir/garam secukupya
1. Harus ada 3 sdt santan kara
1. Tambah 2 serai. 1 ruas jahe 3 daun jeruk
1. Diperlukan  Air asem / penyedap rasa
1. Siapkan  Cabe hijau potong serong


Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. I really don&#39;t know how it was started but if you take away chili peppers from my life… I&#39;m gone! 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica:

1. Ayam potong kecil kasih air jeruk diamkan sebentar baru cuci bersih
1. Gongso ayam sebentar agak setengah masak angkat tiriskan
1. Ulek bawang merah.bawang putih jahe.kemiri sangrai tambahkan cabe merah besar.cabe keriting dan cabe rawit masukkan gula dan garam ulek sampai halus
1. Tumis bumbu sampai harum masukkan ayam serai daun jeruk tambahkan gula merah dan santan tambahkan air secukupnya
1. Tambahkan penyedap rasa dan caba hijau
1. Angkat.siap di sajikan


Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. I really don&#39;t know how it was started but if you take away chili peppers from my life… I&#39;m gone! Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. Tak hanya ayam, anda juga bisa memasak. 

Demikianlah cara membuat ayam rica rica yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan cepat, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
