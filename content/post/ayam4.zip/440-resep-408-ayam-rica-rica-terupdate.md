---
description: "Resep : 408. Ayam Rica-Rica terupdate"
title: "Resep : 408. Ayam Rica-Rica terupdate"
slug: 440-resep-408-ayam-rica-rica-terupdate
date: 2020-11-30T11:48:13.602Z
image: https://img-global.cpcdn.com/recipes/ceffcc6f9dba9dd2/751x532cq70/408-ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ceffcc6f9dba9dd2/751x532cq70/408-ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ceffcc6f9dba9dd2/751x532cq70/408-ayam-rica-rica-foto-resep-utama.jpg
author: Catherine Ingram
ratingvalue: 4.4
reviewcount: 4098
recipeingredient:
- "1/2 kg ayam potong"
- "65 ml santan instan"
- "1 batang sereh geprek"
- "1 mangkuk kecil daun kemangi"
- "1 lembar daun pandan"
- "2 lembar daun salam"
- "5 lembar daun jeruk buang tulangnya iris2 tipis"
- "1 batang daun bawang rajang kasar"
- "secukupnya Kaldu jamurgaram dan gula"
- "  Bumbu halus "
- "3 siung bawang putih"
- "5 siung bawang merah"
- "1 cm kunyit"
- "10 buah cabai rawit merah"
- "10 buah cabai merah keriting"
- "2 cm jahe"
- "2 butir kemiri"
- "2 cm lengkuas"
recipeinstructions:
- "Tumis bumbu halus, daun jeruk, daun salam, dan sereh hingga harum."
- "Masukkan ayam.. Tumis hingga berubah warna."
- "Masukkan santan, air secukupnya, kaldu jamur/garam dan gula. Biarkan mendidih. Koreksi rasa."
- "Masak hingga ayam matang dan air susut. Masukkan kemangi dan daun bawang. Aduk sebentar. Matikan kompor dan siap disajikan."
categories:
- Recipe
tags:
- 408
- ayam
- ricarica

katakunci: 408 ayam ricarica 
nutrition: 149 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Lunch

---


![408. Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/ceffcc6f9dba9dd2/751x532cq70/408-ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti 408. ayam rica-rica yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa keistimewahan yang merupakan keragaman Indonesia



Kehangatan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan 408. Ayam Rica-Rica untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang dapat anda praktekkan salah satunya 408. ayam rica-rica yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep 408. ayam rica-rica tanpa harus bersusah payah.
Seperti resep 408. Ayam Rica-Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 408. Ayam Rica-Rica:

1. Jangan lupa 1/2 kg ayam potong
1. Harus ada 65 ml santan instan
1. Jangan lupa 1 batang sereh (geprek)
1. Diperlukan 1 mangkuk kecil daun kemangi
1. Dibutuhkan 1 lembar daun pandan
1. Harus ada 2 lembar daun salam
1. Harap siapkan 5 lembar daun jeruk (buang tulangnya, iris2 tipis)
1. Dibutuhkan 1 batang daun bawang (rajang kasar)
1. Dibutuhkan secukupnya Kaldu jamur/garam dan gula
1. Tambah  💮 Bumbu halus :
1. Harus ada 3 siung bawang putih
1. Harap siapkan 5 siung bawang merah
1. Tambah 1 cm kunyit
1. Tambah 10 buah cabai rawit merah
1. Harap siapkan 10 buah cabai merah keriting
1. Tambah 2 cm jahe
1. Harap siapkan 2 butir kemiri
1. Harus ada 2 cm lengkuas




<!--inarticleads2-->

##### Langkah membuat  408. Ayam Rica-Rica:

1. Tumis bumbu halus, daun jeruk, daun salam, dan sereh hingga harum.
1. Masukkan ayam.. Tumis hingga berubah warna.
1. Masukkan santan, air secukupnya, kaldu jamur/garam dan gula. Biarkan mendidih. Koreksi rasa.
1. Masak hingga ayam matang dan air susut. Masukkan kemangi dan daun bawang. Aduk sebentar. Matikan kompor dan siap disajikan.




Demikianlah cara membuat 408. ayam rica-rica yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
