---
description: "Cara singkat membuat Ayam rica teraktual"
title: "Cara singkat membuat Ayam rica teraktual"
slug: 436-cara-singkat-membuat-ayam-rica-teraktual
date: 2020-08-18T09:53:20.780Z
image: https://img-global.cpcdn.com/recipes/d8c6b053817efed8/751x532cq70/ayam-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d8c6b053817efed8/751x532cq70/ayam-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d8c6b053817efed8/751x532cq70/ayam-rica-foto-resep-utama.jpg
author: Dean Rodriguez
ratingvalue: 4.6
reviewcount: 29261
recipeingredient:
- "1/2 ekor ayam bagian paha"
- "3 lbr daun jeruk"
- "2 lbr daun salam"
- "1 btg serai potong 3 bagian"
- "200 ml air"
- "Secukupnya gula dan garam"
- "Secukupnya minyak goreng untuk menumis"
- " Bumbu halus"
- "7 bh cabai rawit merah"
- "3 bh cabai kering"
- "3 siung bawang putih"
- "3 siung bawang merah"
- "2 bh kemiri"
- "3 cm jahe"
- "1 sdt kunyit bubuk"
recipeinstructions:
- "Tumis bumbu halus, tambahkan daun salam, daun jeruk, serai, gula dan garam"
- "Masukkan ayam, lalu tambahkan air, aduk rata, masak hingga airnya menyusut"
- "Ayam Rica siap dinikmati dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- rica

katakunci: ayam rica 
nutrition: 134 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica](https://img-global.cpcdn.com/recipes/d8c6b053817efed8/751x532cq70/ayam-rica-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan empuk. Karasteristik kuliner Indonesia ayam rica yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam rica untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang bisa anda contoh salah satunya ayam rica yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica tanpa harus bersusah payah.
Seperti resep Ayam rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica:

1. Harap siapkan 1/2 ekor ayam (bagian paha)
1. Siapkan 3 lbr daun jeruk
1. Siapkan 2 lbr daun salam
1. Dibutuhkan 1 btg serai (potong 3 bagian)
1. Harus ada 200 ml air
1. Dibutuhkan Secukupnya gula dan garam
1. Siapkan Secukupnya minyak goreng untuk menumis
1. Siapkan  Bumbu halus
1. Harus ada 7 bh cabai rawit merah
1. Dibutuhkan 3 bh cabai kering
1. Harus ada 3 siung bawang putih
1. Diperlukan 3 siung bawang merah
1. Harap siapkan 2 bh kemiri
1. Harus ada 3 cm jahe
1. Tambah 1 sdt kunyit bubuk




<!--inarticleads2-->

##### Langkah membuat  Ayam rica:

1. Tumis bumbu halus, tambahkan daun salam, daun jeruk, serai, gula dan garam
1. Masukkan ayam, lalu tambahkan air, aduk rata, masak hingga airnya menyusut
1. Ayam Rica siap dinikmati dengan nasi hangat




Demikianlah cara membuat ayam rica yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
