---
description: "Langkah untuk membuat Ayam Rica-Rica Kemangi Cepat"
title: "Langkah untuk membuat Ayam Rica-Rica Kemangi Cepat"
slug: 383-langkah-untuk-membuat-ayam-rica-rica-kemangi-cepat
date: 2020-10-18T13:19:47.550Z
image: https://img-global.cpcdn.com/recipes/11e4867b3d2ff2a5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/11e4867b3d2ff2a5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/11e4867b3d2ff2a5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Katherine Castillo
ratingvalue: 4.2
reviewcount: 13654
recipeingredient:
- "1 Ekor Ayam Anggaran 700800gr"
- "7 Cabe Rawit Utuh Untuk Dimasak Utuh2x Sama Ayamnya Nanti"
- "1 Batang Sereh"
- "2 Lembar Daun Salam"
- "3 Lembar Daun Jeruk"
- "1 Buah Jeruk Nipis"
- "Sesuai Selera Daun Kemangi"
- " Bumbu Halus"
- "10 Cabe Merah Keriting"
- "10 Cabe Rawit"
- "10 Bawang Merah"
- "5 Bawang Putih"
- "3 Kemiri"
- "2 Ruas Jari Kunyit"
- "1 Ruas Jari Jahe"
- "Secukupnya Air"
- " Seasoning"
- " Kaldu Ayam Bubuk Garam Gula Lada Sesuai Selera"
recipeinstructions:
- "Potong2x ayam sesuai selera, kalau aku ayamnya dipotong 10..."
- "Haluskan semua bahan bumbu halus, kemudian tumis sampai tanak dan bau langunya hilang. Jangan lupa masukan Sereh, Salam dan Daun Jeruknya..."
- "Setelah bumbu matang, masukan 300ml air, didihkan, kemudian masukan ayamnya..."
- "Tambahkan seasoning seperti Kaldu ayam bubuk, Garam, Lada, Gula sesuai selera, koreksi rasanya kemudian aduk rata..."
- "Masak sampai ayamnya matang dan airnya menyusut, kemudian masukan Kemanginya, aduk sebentar aja kemudian matikan apinya..."
- "Terakhir peras Air Jeruk Nipis dan aduk rata lagi, lalu Ayam Rica-ricanya siap untuk disajikan...."
- "Semoga Suka Sama Resepnya ya... Untuk Yang Recook di Instagram Jgn Lupa Hashtag #ResepDariWonderland atau Langsung aja Tag ke @dapurdiwonderland"
- "Makasih... Selamat Mencoba... 😁😁"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 202 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/11e4867b3d2ff2a5/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang dapat kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica-rica kemangi yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Nusantara

Kedekatan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Ayam Rica-Rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang bisa anda contoh salah satunya ayam rica-rica kemangi yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Kemangi:

1. Diperlukan 1 Ekor Ayam Anggaran 700-800gr
1. Harus ada 7 Cabe Rawit Utuh (Untuk Dimasak Utuh2x Sama Ayamnya Nanti)
1. Harap siapkan 1 Batang Sereh
1. Tambah 2 Lembar Daun Salam
1. Diperlukan 3 Lembar Daun Jeruk
1. Jangan lupa 1 Buah Jeruk Nipis
1. Harap siapkan Sesuai Selera Daun Kemangi
1. Dibutuhkan  Bumbu Halus
1. Dibutuhkan 10 Cabe Merah Keriting
1. Harus ada 10 Cabe Rawit
1. Siapkan 10 Bawang Merah
1. Jangan lupa 5 Bawang Putih
1. Tambah 3 Kemiri
1. Harus ada 2 Ruas Jari Kunyit
1. Harap siapkan 1 Ruas Jari Jahe
1. Dibutuhkan Secukupnya Air
1. Tambah  Seasoning
1. Harus ada  Kaldu Ayam Bubuk, Garam, Gula, Lada (Sesuai Selera)


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica Kemangi:

1. Potong2x ayam sesuai selera, kalau aku ayamnya dipotong 10...
1. Haluskan semua bahan bumbu halus, kemudian tumis sampai tanak dan bau langunya hilang. Jangan lupa masukan Sereh, Salam dan Daun Jeruknya...
1. Setelah bumbu matang, masukan 300ml air, didihkan, kemudian masukan ayamnya...
1. Tambahkan seasoning seperti Kaldu ayam bubuk, Garam, Lada, Gula sesuai selera, koreksi rasanya kemudian aduk rata...
1. Masak sampai ayamnya matang dan airnya menyusut, kemudian masukan Kemanginya, aduk sebentar aja kemudian matikan apinya...
1. Terakhir peras Air Jeruk Nipis dan aduk rata lagi, lalu Ayam Rica-ricanya siap untuk disajikan....
1. Semoga Suka Sama Resepnya ya... Untuk Yang Recook di Instagram Jgn Lupa Hashtag #ResepDariWonderland atau Langsung aja Tag ke @dapurdiwonderland
1. Makasih... Selamat Mencoba... 😁😁


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
