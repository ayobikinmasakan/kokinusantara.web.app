---
description: "Resep : Ayam rica rica kemangi teraktual"
title: "Resep : Ayam rica rica kemangi teraktual"
slug: 391-resep-ayam-rica-rica-kemangi-teraktual
date: 2020-09-05T11:21:22.263Z
image: https://img-global.cpcdn.com/recipes/c49b580a86e5e3c4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c49b580a86e5e3c4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c49b580a86e5e3c4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Lilly Schmidt
ratingvalue: 4.3
reviewcount: 17830
recipeingredient:
- "1/2 ekor ayam boiler"
- "1 ikat kemangi"
- " Bumbu semua di ulek ya kecuali lengkuas"
- "3 siung bawang putih dan 5 siung bawang merah"
- "1/2 cm jahe"
- "1/4 kunyit"
- " Lengkuas ukuran sedanggeprek"
- "25 cabe rawitsesuai selera"
- "10 cabe merahboleh lebih"
- "2 buah Tobat boleh di skip"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
recipeinstructions:
- "Potong ayam menjadi 4 bagian"
- "Didihkan air rebus ayam hingga matang (tanpa bumbu)"
- "Goreng ayam asal (jangan sampai kuning)"
- "Tumis bumbu halus,masukkan lengkuas yg sdh di geprek,daun salam,daun jeruk"
- "Tambahkan garam,royco,dan gula(masakan sy kebanyakan pake gula karena biar rasa asin,gurih nya seimbang)"
- "Masukkan ayam,tambahkan sedikit air,"
- "Air sdh mulai mengering koreksi rasa,"
- "Terakhir masukkan kemangi,yg sdh di cuci bersih."
- "Ayam rica rica siap di sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 232 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/c49b580a86e5e3c4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Nusantara

Keharmonisan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam rica rica kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang bisa anda buat salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Harus ada 1/2 ekor ayam boiler
1. Diperlukan 1 ikat kemangi,
1. Harap siapkan  Bumbu semua di ulek ya kecuali lengkuas
1. Jangan lupa 3 siung bawang putih dan 5 siung bawang merah
1. Siapkan 1/2 cm jahe,
1. Jangan lupa 1/4 kunyit
1. Siapkan  Lengkuas ukuran sedang(geprek)
1. Siapkan 25 cabe rawit(sesuai selera)
1. Harap siapkan 10 cabe merah(boleh lebih)
1. Jangan lupa 2 buah Tobat (boleh di skip)
1. Harus ada 3 lembar daun salam
1. Siapkan 3 lembar daun jeruk




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica kemangi:

1. Potong ayam menjadi 4 bagian
1. Didihkan air rebus ayam hingga matang (tanpa bumbu)
1. Goreng ayam asal (jangan sampai kuning)
1. Tumis bumbu halus,masukkan lengkuas yg sdh di geprek,daun salam,daun jeruk
1. Tambahkan garam,royco,dan gula(masakan sy kebanyakan pake gula karena biar rasa asin,gurih nya seimbang)
1. Masukkan ayam,tambahkan sedikit air,
1. Air sdh mulai mengering koreksi rasa,
1. Terakhir masukkan kemangi,yg sdh di cuci bersih.
1. Ayam rica rica siap di sajikan




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan teruji, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
