---
description: "Step-by-Step membuat Ayam Rica Rica Teruji"
title: "Step-by-Step membuat Ayam Rica Rica Teruji"
slug: 318-step-by-step-membuat-ayam-rica-rica-teruji
date: 2020-11-12T05:44:26.637Z
image: https://img-global.cpcdn.com/recipes/426cccafdb83a5c5/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/426cccafdb83a5c5/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/426cccafdb83a5c5/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Elijah Richards
ratingvalue: 4.1
reviewcount: 24578
recipeingredient:
- " Goreng ayam setengah kering bumbu dgn "
- " Ayam potong baluri kunyit bubuk air jeruk nipis  garam"
- " Bumbu halus "
- "1 ons Cabe keriting"
- "1/2 ons cabe rawit"
- "5 siung bawang merah"
- "5 siung bawang putih"
- "2 cm jahe"
- "sedikit kunyit"
- "3 butir kemiri"
- "2 cm lengkoas"
- " Bumbu kasar"
- "3 batang serai geprek"
- "1 lembar daun pandan simpul"
- "5 lembar daun salam"
- "5 lembar daun jeruk iris halus"
- "2 ikat daun kemangi petiki"
- "secukupnya garam dan penyedap rasa"
- "Secukupnya air matang"
recipeinstructions:
- "Tumis bumbu halus sampai wangi masukan daun jeruk, daun salam, daun pandan dan serai"
- "Masukan ayam yg sudah di goreng stgah kering td aduk hingga rata masukan air secukupnya."
- "Masukan garam dan penyedap secukupnya. Masak sampai ayam empuk kurang lebih stgah jam."
- "Setelah ayam empuk dan kuah mengering masukan daun kemangi dan daun bawang, aduk hingga layu. Ayam rica rica siap dihidangkan dengan nasi panas bersama lalapan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 255 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/426cccafdb83a5c5/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica rica yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara



Kehangatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Rica Rica untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda contoh salah satunya ayam rica rica yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica:

1. Harus ada  Goreng ayam setengah kering bumbu dgn :
1. Diperlukan  Ayam potong (baluri kunyit bubuk, air jeruk nipis &amp; garam)
1. Jangan lupa  Bumbu halus :
1. Siapkan 1 ons Cabe keriting
1. Jangan lupa 1/2 ons cabe rawit
1. Harus ada 5 siung bawang merah
1. Tambah 5 siung bawang putih
1. Dibutuhkan 2 cm jahe
1. Tambah sedikit kunyit
1. Harus ada 3 butir kemiri
1. Harus ada 2 cm lengkoas
1. Jangan lupa  Bumbu kasar:
1. Jangan lupa 3 batang serai geprek
1. Diperlukan 1 lembar daun pandan simpul
1. Harus ada 5 lembar daun salam
1. Harap siapkan 5 lembar daun jeruk iris halus
1. Jangan lupa 2 ikat daun kemangi, petiki
1. Diperlukan secukupnya garam dan penyedap rasa
1. Harap siapkan Secukupnya air matang




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica:

1. Tumis bumbu halus sampai wangi masukan daun jeruk, daun salam, daun pandan dan serai
1. Masukan ayam yg sudah di goreng stgah kering td aduk hingga rata masukan air secukupnya.
1. Masukan garam dan penyedap secukupnya. Masak sampai ayam empuk kurang lebih stgah jam.
1. Setelah ayam empuk dan kuah mengering masukan daun kemangi dan daun bawang, aduk hingga layu. Ayam rica rica siap dihidangkan dengan nasi panas bersama lalapan.




Demikianlah cara membuat ayam rica rica yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
