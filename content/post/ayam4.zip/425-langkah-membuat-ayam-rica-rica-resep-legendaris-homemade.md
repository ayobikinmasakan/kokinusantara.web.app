---
description: "Langkah membuat Ayam rica rica resep legendaris Homemade"
title: "Langkah membuat Ayam rica rica resep legendaris Homemade"
slug: 425-langkah-membuat-ayam-rica-rica-resep-legendaris-homemade
date: 2020-10-03T21:56:38.222Z
image: https://img-global.cpcdn.com/recipes/bbe0dac8f16feae9/751x532cq70/ayam-rica-rica-resep-legendaris-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bbe0dac8f16feae9/751x532cq70/ayam-rica-rica-resep-legendaris-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bbe0dac8f16feae9/751x532cq70/ayam-rica-rica-resep-legendaris-foto-resep-utama.jpg
author: Amy Bates
ratingvalue: 4.2
reviewcount: 33308
recipeingredient:
- "1 ekor ayam kampung"
- "1 batang sereh digeprek"
- "secukupnya Garam dan gula"
- "300 cc air"
- " Bahan yang dihaluskan"
- "8 siung bawang merah"
- "7 buah cabe merah besar buang bijinya"
- "3 buah cabe merah keriting"
- "6 buah tomat besar haluskan terpisah"
- "Sejempol jahe"
recipeinstructions:
- "Siapkan bahan bahan. Haluskan bumbu halus"
- "Tumis bawang, cabe, dan jahe yang sudah dihaluskan"
- "Setelah tumisan harum, masukkan tomat yang dihaluskan."
- "Setelah mendidih, masukkan air, garam, gula. Koreksi rasa. Lalu masukkan sereh dan ayam"
- "Diamkan dengan api kecil, aduk sesekali, biarkan sampai agak kering. Angkat dan hidangkan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 166 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam rica rica resep legendaris](https://img-global.cpcdn.com/recipes/bbe0dac8f16feae9/751x532cq70/ayam-rica-rica-resep-legendaris-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga gurih. Ciri khas masakan Nusantara ayam rica rica resep legendaris yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Resep ayam rica-rica ini dikenal berasal dari daerah Manado, Sulawesi Utara yang memiliki cita rasa pedas dan enak. Seperti pada resep-resep olahan ayam lainnya, bumbu ayam-rica-rica juga menggunakan rempah-rempah asli Indonesia. Resep Ayam Rica Rica Bahan: Daging Ayam Lemon juice Chicken powder Garam. Bawang merah Bawang putih Cabe Jahe Serai Daun jeruk purut Daun kucai.

Kehangatan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam rica rica resep legendaris untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda buat salah satunya ayam rica rica resep legendaris yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica rica resep legendaris tanpa harus bersusah payah.
Seperti resep Ayam rica rica resep legendaris yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 10 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica resep legendaris:

1. Diperlukan 1 ekor ayam kampung
1. Tambah 1 batang sereh digeprek
1. Tambah secukupnya Garam dan gula
1. Harus ada 300 cc air
1. Jangan lupa  Bahan yang dihaluskan
1. Diperlukan 8 siung bawang merah
1. Harap siapkan 7 buah cabe merah besar buang bijinya
1. Diperlukan 3 buah cabe merah keriting
1. Harus ada 6 buah tomat besar (haluskan terpisah)
1. Dibutuhkan Sejempol jahe


Cita rasa pedas menjadi ciri khas resep yang tergabung dalam masakan indonesia yang satu ini. Dengan demikian siapapun dapat mencoba membuat masakan rica rica ala manado ini. Resep Ayam Rica Rica - Kalau kita sudah mendengar kata-kata tentang bumbu rica-rica, sudah pasti pikiran kita akan tertuju pada masakan khas Manado. Lihat juga resep Ayam Rica-Rica enak lainnya. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica rica resep legendaris:

1. Siapkan bahan bahan. Haluskan bumbu halus
1. Tumis bawang, cabe, dan jahe yang sudah dihaluskan
1. Setelah tumisan harum, masukkan tomat yang dihaluskan.
1. Setelah mendidih, masukkan air, garam, gula. Koreksi rasa. Lalu masukkan sereh dan ayam
1. Diamkan dengan api kecil, aduk sesekali, biarkan sampai agak kering. Angkat dan hidangkan


Resep Ayam Rica Rica - Kalau kita sudah mendengar kata-kata tentang bumbu rica-rica, sudah pasti pikiran kita akan tertuju pada masakan khas Manado. Lihat juga resep Ayam Rica-Rica enak lainnya. Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. Tak hanya ayam, anda juga bisa memasak bebek atau telur dengan bumbu rica-rica ini. 

Demikianlah cara membuat ayam rica rica resep legendaris yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan cepat, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
