---
description: "Steps untuk menyiapakan Ayam rica rica kemangi pedas terupdate"
title: "Steps untuk menyiapakan Ayam rica rica kemangi pedas terupdate"
slug: 303-steps-untuk-menyiapakan-ayam-rica-rica-kemangi-pedas-terupdate
date: 2020-11-02T01:31:53.365Z
image: https://img-global.cpcdn.com/recipes/6dff6933be852f07/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6dff6933be852f07/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6dff6933be852f07/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
author: Edith Roberson
ratingvalue: 4.4
reviewcount: 31343
recipeingredient:
- "1 ekor ayam potong sesuai selera"
- "2 ikat kemangi petik daunnya"
- "4 btang daun bawang"
- "5 lembar daun jeruk"
- "3 btang serai geprek"
- " Garam gula dan kaldu bubuk"
- " Bumbu halus"
- "16 bawang merah"
- "8 siung bawang putih"
- "4 biji Lombok merah"
- "4 biji cabe ijo"
- "10 biji cabe keriting"
- "15 biji cabe rawit"
- "1 jari telunjuk kunyit"
- "1 jari telunjuk jahe"
- "6 butir kemiri sangrai"
- "secukupnya Air"
recipeinstructions:
- "Cuci bersih ayam(tiriskan dan sisihkan)"
- "Tumis bumbu halus sampai harum dan matang...kemudian masukkan ayam dan tambahkan sedikit air"
- "Masukkan bumbu2 kemudian koreksi rasa dan masak ayam sampai matang dan empuk"
- "Masukkan daun bawang dan kemangi aduk rata"
- "Rica rica ayam kemangi pedas pun sudah bisa disajikan😁"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 143 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica rica kemangi pedas](https://img-global.cpcdn.com/recipes/6dff6933be852f07/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan renyah. Ciri khas makanan Indonesia ayam rica rica kemangi pedas yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica rica kemangi pedas untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang bisa anda contoh salah satunya ayam rica rica kemangi pedas yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep ayam rica rica kemangi pedas tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi pedas yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi pedas:

1. Siapkan 1 ekor ayam potong sesuai selera
1. Dibutuhkan 2 ikat kemangi petik daunnya
1. Harap siapkan 4 btang daun bawang
1. Tambah 5 lembar daun jeruk
1. Tambah 3 btang serai geprek
1. Harus ada  Garam gula dan kaldu bubuk
1. Jangan lupa  Bumbu halus:
1. Siapkan 16 bawang merah
1. Dibutuhkan 8 siung bawang putih
1. Siapkan 4 biji Lombok merah
1. Siapkan 4 biji cabe ijo
1. Siapkan 10 biji cabe keriting
1. Dibutuhkan 15 biji cabe rawit
1. Tambah 1 jari telunjuk kunyit
1. Diperlukan 1 jari telunjuk jahe
1. Diperlukan 6 butir kemiri sangrai
1. Harap siapkan secukupnya Air




<!--inarticleads2-->

##### Cara membuat  Ayam rica rica kemangi pedas:

1. Cuci bersih ayam(tiriskan dan sisihkan)
1. Tumis bumbu halus sampai harum dan matang...kemudian masukkan ayam dan tambahkan sedikit air
1. Masukkan bumbu2 kemudian koreksi rasa dan masak ayam sampai matang dan empuk
1. Masukkan daun bawang dan kemangi aduk rata
1. Rica rica ayam kemangi pedas pun sudah bisa disajikan😁




Demikianlah cara membuat ayam rica rica kemangi pedas yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
