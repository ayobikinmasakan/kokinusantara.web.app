---
description: "Resep : Ayam rica kemangi Homemade"
title: "Resep : Ayam rica kemangi Homemade"
slug: 271-resep-ayam-rica-kemangi-homemade
date: 2021-01-17T21:27:17.122Z
image: https://img-global.cpcdn.com/recipes/ff594703b5ac9a60/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ff594703b5ac9a60/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ff594703b5ac9a60/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Connor Hines
ratingvalue: 4.5
reviewcount: 21362
recipeingredient:
- "1/2 kg ayam potongan paha"
- " Bumbu halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "10 buah cabai rawit"
- "1 buah cabai merah besar"
- "2 butir kemiri"
- "1 cm kunyit"
- " Bumbu cemplung"
- "1/2 ikat kemangi"
- "2 batang sereh"
- "3 lbr daun salam"
- "5 lbr daun jeruk"
- "2 cm lengkuas dikeprak"
- "2 cm jahe dikeprak"
- " Gula"
- " Garam"
- " Penyedap"
recipeinstructions:
- "Siapkan ayam yang sudah dipotong beberapa bagian. Cuci dan marinasi dengan jeruk nipis, sisihkan"
- "Siapkan bumbu halus dan bumbu cemplung"
- "Tumis bumbu halus beserta daun jeruk, sereh, salam, lengkuas dan jahe. Tumis hingga harum dan matang sempurna (biasanya minyak sudah terpisah dari bumbu)."
- "Tambahkan air secukupnya dan masukkan ayam yang telah di marinasi. Tunggu hingga mendidih dan bumbu surut kurang lebih 20 menit dengan api kecil."
- "Koreksi rasa, jika sudah pas masukkan kemangi. Bolak balik sebentar hingga kemangi layu, angkat dan siap disajikan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 226 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/ff594703b5ac9a60/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan renyah. Ciri khas makanan Indonesia ayam rica kemangi yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.


Keharmonisan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang dapat anda coba salah satunya ayam rica kemangi yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica kemangi:

1. Jangan lupa 1/2 kg ayam potongan paha
1. Dibutuhkan  Bumbu halus
1. Dibutuhkan 6 siung bawang merah
1. Tambah 3 siung bawang putih
1. Diperlukan 10 buah cabai rawit
1. Dibutuhkan 1 buah cabai merah besar
1. Dibutuhkan 2 butir kemiri
1. Harus ada 1 cm kunyit
1. Tambah  Bumbu cemplung
1. Siapkan 1/2 ikat kemangi
1. Harus ada 2 batang sereh
1. Dibutuhkan 3 lbr daun salam
1. Siapkan 5 lbr daun jeruk
1. Tambah 2 cm lengkuas dikeprak
1. Diperlukan 2 cm jahe dikeprak
1. Tambah  Gula
1. Dibutuhkan  Garam
1. Tambah  Penyedap




<!--inarticleads2-->

##### Cara membuat  Ayam rica kemangi:

1. Siapkan ayam yang sudah dipotong beberapa bagian. Cuci dan marinasi dengan jeruk nipis, sisihkan
1. Siapkan bumbu halus dan bumbu cemplung
1. Tumis bumbu halus beserta daun jeruk, sereh, salam, lengkuas dan jahe. Tumis hingga harum dan matang sempurna (biasanya minyak sudah terpisah dari bumbu).
1. Tambahkan air secukupnya dan masukkan ayam yang telah di marinasi. Tunggu hingga mendidih dan bumbu surut kurang lebih 20 menit dengan api kecil.
1. Koreksi rasa, jika sudah pas masukkan kemangi. Bolak balik sebentar hingga kemangi layu, angkat dan siap disajikan.




Demikianlah cara membuat ayam rica kemangi yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
