---
description: "Step-by-Step untuk menyiapakan Ayam madu ala korea (Dakgangjeong) Homemade"
title: "Step-by-Step untuk menyiapakan Ayam madu ala korea (Dakgangjeong) Homemade"
slug: 39-step-by-step-untuk-menyiapakan-ayam-madu-ala-korea-dakgangjeong-homemade
date: 2020-09-11T10:49:01.771Z
image: https://img-global.cpcdn.com/recipes/952cbc7476f9f8f3/751x532cq70/ayam-madu-ala-korea-dakgangjeong-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/952cbc7476f9f8f3/751x532cq70/ayam-madu-ala-korea-dakgangjeong-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/952cbc7476f9f8f3/751x532cq70/ayam-madu-ala-korea-dakgangjeong-foto-resep-utama.jpg
author: Cory Scott
ratingvalue: 4
reviewcount: 19125
recipeingredient:
- "1 kg ayam bisa campur atau fillet"
- " Bahan Marinasi"
- "4 siung bawang putih"
- "1 ruas jahe"
- "2 btr telur"
- "1 sdm garam"
- "1 sdt merica"
- "1 sdt kaldu jamur bs ganti pakai masako kurangi garamnya"
- " Cabe bubuk optional klo ingin pedas"
- " Bahan tepung"
- "8 sdm tepung terigu"
- "12 sdm tepung beras"
- "1 sdm baking powder bs di skip"
- "1 sdt kaldu ayam"
- " Cabe bubuk optional untuk selera pedas"
- " Bahan Saus"
- "1/2 bawang bombay iris tipis"
- "2 siung bawang putih cincang"
- "10 sdm air"
- "7 sdm saus tomat"
- "7 sdm saus sambal"
- "4 sdm madu"
- "1 sdm minyak wijen"
- "1 sdm mentega minyak sayur"
- " Taburan"
- "3 sdm biji wijen disangrai"
recipeinstructions:
- "Potong ayam atau fillet sesuai selera"
- "Haluskan bahan marinasi (saya pake blender telur dicampur dan dimasukan)"
- "Balurkan bahan marinasi pada ayam atau fillet, kemudian diamkan minimal 1 jam, semalaman lebih baik, lebih meresap"
- "Sementara itu siapkan bahan tepung dan saus, setelah ayam ter marinasi dg baik dan sdh didiamkan min 1 jam, kemudian kita olah"
- "Siapkan minyak goreng baru dan agak banyak di wajan, setelah panas kecilkan api, celupkan ayam ke bahan tepung sambil di tekan tekan biar nempel tepung nya kemudian goreng"
- "Setelah ayam digoreng semua, panaskan margarin di wajan anti lengket, tumis bawang bombay dan bawang putih sampai harum, masukan air, saus dan bahan lain nya untuk saus, tunggu sampai meletup letup"
- "Setelah meletup letup, masukan ayam yg sdh digoreng tadi dan aduk sampai bumbu saus merata, taburi dengan biji wijen dan ratakan (tidak usah lama lama cukup sampai merata saja)"
- "Angkat dan siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- madu
- ala

katakunci: ayam madu ala 
nutrition: 199 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam madu ala korea (Dakgangjeong)](https://img-global.cpcdn.com/recipes/952cbc7476f9f8f3/751x532cq70/ayam-madu-ala-korea-dakgangjeong-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam madu ala korea (dakgangjeong) yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan keistimewahan yang merupakan keragaman Nusantara

Kehangatan rumah tangga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam madu ala korea (Dakgangjeong) untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda coba salah satunya ayam madu ala korea (dakgangjeong) yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam madu ala korea (dakgangjeong) tanpa harus bersusah payah.
Seperti resep Ayam madu ala korea (Dakgangjeong) yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 26 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam madu ala korea (Dakgangjeong):

1. Diperlukan 1 kg ayam (bisa campur atau fillet)
1. Harus ada  Bahan Marinasi
1. Jangan lupa 4 siung bawang putih
1. Tambah 1 ruas jahe
1. Siapkan 2 btr telur
1. Diperlukan 1 sdm garam
1. Siapkan 1 sdt merica
1. Siapkan 1 sdt kaldu jamur (bs ganti pakai masako kurangi garamnya)
1. Siapkan  Cabe bubuk (optional klo ingin pedas)
1. Tambah  Bahan tepung
1. Dibutuhkan 8 sdm tepung terigu
1. Diperlukan 12 sdm tepung beras
1. Siapkan 1 sdm baking powder (bs di skip)
1. Diperlukan 1 sdt kaldu ayam
1. Harus ada  Cabe bubuk (optional untuk selera pedas)
1. Dibutuhkan  Bahan Saus
1. Jangan lupa 1/2 bawang bombay iris tipis
1. Diperlukan 2 siung bawang putih (cincang)
1. Dibutuhkan 10 sdm air
1. Harus ada 7 sdm saus tomat
1. Harap siapkan 7 sdm saus sambal
1. Harap siapkan 4 sdm madu
1. Jangan lupa 1 sdm minyak wijen
1. Jangan lupa 1 sdm mentega/ minyak sayur
1. Harap siapkan  Taburan
1. Tambah 3 sdm biji wijen (disangrai)




<!--inarticleads2-->

##### Cara membuat  Ayam madu ala korea (Dakgangjeong):

1. Potong ayam atau fillet sesuai selera
1. Haluskan bahan marinasi (saya pake blender telur dicampur dan dimasukan)
1. Balurkan bahan marinasi pada ayam atau fillet, kemudian diamkan minimal 1 jam, semalaman lebih baik, lebih meresap
1. Sementara itu siapkan bahan tepung dan saus, setelah ayam ter marinasi dg baik dan sdh didiamkan min 1 jam, kemudian kita olah
1. Siapkan minyak goreng baru dan agak banyak di wajan, setelah panas kecilkan api, celupkan ayam ke bahan tepung sambil di tekan tekan biar nempel tepung nya kemudian goreng
1. Setelah ayam digoreng semua, panaskan margarin di wajan anti lengket, tumis bawang bombay dan bawang putih sampai harum, masukan air, saus dan bahan lain nya untuk saus, tunggu sampai meletup letup
1. Setelah meletup letup, masukan ayam yg sdh digoreng tadi dan aduk sampai bumbu saus merata, taburi dengan biji wijen dan ratakan (tidak usah lama lama cukup sampai merata saja)
1. Angkat dan siap dihidangkan




Demikianlah cara membuat ayam madu ala korea (dakgangjeong) yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
