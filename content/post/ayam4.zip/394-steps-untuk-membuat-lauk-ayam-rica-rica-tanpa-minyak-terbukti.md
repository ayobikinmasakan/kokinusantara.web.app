---
description: "Steps untuk membuat Lauk : Ayam Rica-rica tanpa Minyak Terbukti"
title: "Steps untuk membuat Lauk : Ayam Rica-rica tanpa Minyak Terbukti"
slug: 394-steps-untuk-membuat-lauk-ayam-rica-rica-tanpa-minyak-terbukti
date: 2020-08-17T14:06:28.492Z
image: https://img-global.cpcdn.com/recipes/844ce0568b78fc55/751x532cq70/lauk-ayam-rica-rica-tanpa-minyak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/844ce0568b78fc55/751x532cq70/lauk-ayam-rica-rica-tanpa-minyak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/844ce0568b78fc55/751x532cq70/lauk-ayam-rica-rica-tanpa-minyak-foto-resep-utama.jpg
author: Marian French
ratingvalue: 4.8
reviewcount: 20252
recipeingredient:
- "200 gr ayam"
- "1 batang sereh geprek"
- "1 cm lengkuas"
- "1 cm jahe geprek"
- "1 lembar daun salam"
- "1 lembar daun jeruk pilih yg membentuk angka 8"
- "secukupnya Kemangi"
- "100 ml air"
- "secukupnya Kaldu jamur"
- " Bumbu Halus ditumbukdiblender"
- "2 siung bawang merah"
- "1 siung bawang putih"
- "1/2 butir kemiri"
- "1 cm kunyit"
- "sesuai selera Cabai merah keriting"
- "sesuai selera Cabai rawit"
- " Cabai perenggi 1 buah me"
recipeinstructions:
- "Masak air hingga matang menggunakan teflon anti lengket."
- "Masukkan bumbu halus, sereh, daun salam, daun jeruk, lengkuas, jahe. Masak hingga harum dan air sedikit berkurang."
- "Masukkan ayam. Aduk2. Masak hingga ayam matang (tidak perlu tambah air). Tambahkan kaldu jamur. Cek rasa. Air benar-benar mengental."
- "Masukkan daun kemangi, aduk-aduk."
- "Setelah matang, sip, dan mantap. Eh. Matikan kompor dan siap plating."
- "Santap ketika hangat. Cocok dimakan dengan nasi merah untuk diet. Pakai nasi bisa 2x makan. Makan langsung bisa langsung habis hihi."
categories:
- Recipe
tags:
- lauk
- 
- ayam

katakunci: lauk  ayam 
nutrition: 103 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Lunch

---


![Lauk : Ayam Rica-rica tanpa Minyak](https://img-global.cpcdn.com/recipes/844ce0568b78fc55/751x532cq70/lauk-ayam-rica-rica-tanpa-minyak-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti lauk : ayam rica-rica tanpa minyak yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Kita

Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Lauk : Ayam Rica-rica tanpa Minyak untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang bisa anda praktekkan salah satunya lauk : ayam rica-rica tanpa minyak yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep lauk : ayam rica-rica tanpa minyak tanpa harus bersusah payah.
Berikut ini resep Lauk : Ayam Rica-rica tanpa Minyak yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Lauk : Ayam Rica-rica tanpa Minyak:

1. Jangan lupa 200 gr ayam
1. Diperlukan 1 batang sereh (geprek)
1. Siapkan 1 cm lengkuas
1. Harus ada 1 cm jahe (geprek)
1. Dibutuhkan 1 lembar daun salam
1. Harap siapkan 1 lembar daun jeruk (pilih yg membentuk angka 8)
1. Diperlukan secukupnya Kemangi
1. Harap siapkan 100 ml air
1. Jangan lupa secukupnya Kaldu jamur
1. Harus ada  Bumbu Halus (ditumbuk/diblender)
1. Tambah 2 siung bawang merah
1. Harus ada 1 siung bawang putih
1. Harus ada 1/2 butir kemiri
1. Harus ada 1 cm kunyit
1. Siapkan sesuai selera Cabai merah keriting
1. Jangan lupa sesuai selera Cabai rawit
1. Dibutuhkan  Cabai perenggi 1 buah (me)




<!--inarticleads2-->

##### Instruksi membuat  Lauk : Ayam Rica-rica tanpa Minyak:

1. Masak air hingga matang menggunakan teflon anti lengket.
1. Masukkan bumbu halus, sereh, daun salam, daun jeruk, lengkuas, jahe. Masak hingga harum dan air sedikit berkurang.
1. Masukkan ayam. Aduk2. Masak hingga ayam matang (tidak perlu tambah air). Tambahkan kaldu jamur. Cek rasa. Air benar-benar mengental.
1. Masukkan daun kemangi, aduk-aduk.
1. Setelah matang, sip, dan mantap. Eh. Matikan kompor dan siap plating.
1. Santap ketika hangat. Cocok dimakan dengan nasi merah untuk diet. Pakai nasi bisa 2x makan. Makan langsung bisa langsung habis hihi.




Demikianlah cara membuat lauk : ayam rica-rica tanpa minyak yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan cepat, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
