---
description: "Langkah membuat Ayam rica kemangi Favorite"
title: "Langkah membuat Ayam rica kemangi Favorite"
slug: 349-langkah-membuat-ayam-rica-kemangi-favorite
date: 2021-01-24T16:14:03.146Z
image: https://img-global.cpcdn.com/recipes/72224a535d4e7bf4/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/72224a535d4e7bf4/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/72224a535d4e7bf4/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Landon Matthews
ratingvalue: 4.1
reviewcount: 25012
recipeingredient:
- "1/2 ekor ayam"
- "2 iket kemangi"
- "7 siung bawang merah"
- "3 siung bawang putih"
- "2 buah cabai merah"
- "11 buah cabai rawit  sesuai selera"
- "2 keping kemiri"
- "1/2 ruas kunyit"
- "1/2 ruas jahe"
- "1 ruas lengkuas geprek"
- "2 batang serai geprek"
- "4 lembar daun jeruk buang batang"
- "secukupnya Gula garam  penyedap rasa"
- "secukupnya Air sisa rebusan ayam  air masak ya"
recipeinstructions:
- "Potong ayam jadi beberapa bagian (sesuai selera ya ukurannya) lalu rebus sampai empuk, sisa air rebusan jgn dibuang ya buat kaldu"
- "Setelah empuk tiriskan ayam lalu goreng setengah matang ya..."
- "Ulek / blender semua bumbu kecuali lengkuas, serai dan daun jeruk yah"
- "Panaskan minyak lalu tumis bumbu yang sudah di haluskan,masukkan serai,lengkuas dan daun jeruk (robek dlu yah biar lbh wangi) aduk sampai tanak"
- "Setelah harum, masukkan air rebusan ayam secukupnya, tunggu mendidih"
- "Masukkan ayam yang sudah di goreng setengah matang tadi, beri gula,garam dan penyedap rasa secukupnya (test rasa)"
- "Ungkep sebentar smpai bumbu menyusut lalu masukkan kemangi.. Aduk sebentar lalu angkat.."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 198 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/72224a535d4e7bf4/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau enak. Ciri khas kuliner Indonesia ayam rica kemangi yang penuh dengan rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kedekatan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica kemangi untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang bisa anda contoh salah satunya ayam rica kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Harap siapkan 1/2 ekor ayam
1. Harap siapkan 2 iket kemangi
1. Tambah 7 siung bawang merah
1. Tambah 3 siung bawang putih
1. Harap siapkan 2 buah cabai merah
1. Harus ada 11 buah cabai rawit / sesuai selera
1. Dibutuhkan 2 keping kemiri
1. Harap siapkan 1/2 ruas kunyit
1. Tambah 1/2 ruas jahe
1. Jangan lupa 1 ruas lengkuas geprek
1. Tambah 2 batang serai geprek
1. Jangan lupa 4 lembar daun jeruk buang batang
1. Harus ada secukupnya Gula, garam &amp; penyedap rasa
1. Harap siapkan secukupnya Air sisa rebusan ayam / air masak ya


Perlu kamu ketahui bahwa di luar negeri mungkin daun basil sangat terkenal untuk campuran makanan. Akan tetapi, di Indonesia juga memiliki daun kemangi merupakan. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica kemangi:

1. Potong ayam jadi beberapa bagian (sesuai selera ya ukurannya) lalu rebus sampai empuk, sisa air rebusan jgn dibuang ya buat kaldu
1. Setelah empuk tiriskan ayam lalu goreng setengah matang ya...
1. Ulek / blender semua bumbu kecuali lengkuas, serai dan daun jeruk yah
1. Panaskan minyak lalu tumis bumbu yang sudah di haluskan,masukkan serai,lengkuas dan daun jeruk (robek dlu yah biar lbh wangi) aduk sampai tanak
1. Setelah harum, masukkan air rebusan ayam secukupnya, tunggu mendidih
1. Masukkan ayam yang sudah di goreng setengah matang tadi, beri gula,garam dan penyedap rasa secukupnya (test rasa)
1. Ungkep sebentar smpai bumbu menyusut lalu masukkan kemangi.. Aduk sebentar lalu angkat..


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat. 

Demikianlah cara membuat ayam rica kemangi yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan terbukti, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
