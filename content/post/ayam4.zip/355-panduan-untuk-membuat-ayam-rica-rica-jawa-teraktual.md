---
description: "Panduan untuk membuat Ayam Rica-Rica Jawa teraktual"
title: "Panduan untuk membuat Ayam Rica-Rica Jawa teraktual"
slug: 355-panduan-untuk-membuat-ayam-rica-rica-jawa-teraktual
date: 2020-09-17T22:16:04.923Z
image: https://img-global.cpcdn.com/recipes/24ba4bdceb626eca/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/24ba4bdceb626eca/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/24ba4bdceb626eca/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg
author: Martin Jordan
ratingvalue: 4.6
reviewcount: 45806
recipeingredient:
- "1 ekor ayam kampung ukuran sedang potongpotong"
- "Secukupnya air"
- "2 sdm santan instan saya skip"
- "5 sdm kecap manis"
- "1/2 sdt lada bubuk"
- "1 sdt garam atau sesuai selera"
- "1 sdt kaldu jamur atau sesuai selera"
- " Bumbu Halus "
- "15 siung bawang merah"
- "7 siung bawang putih"
- "5 butir kemiri goreng"
- "3 cm jahe"
- "2 cm kunyit"
- "4 cm kencur"
- "3 buah cabe merah"
- "Secukupnya cabe rawit kalau suka pedas"
- "Secukupnya minyak goreng untuk menghaluskan bumbu"
- " Bumbu Cemplung "
- "1 lembar daun salam"
- "5 lembar daun jeruk buang tulang daunnya"
- "3 batang serai geprek"
- "1 jempol laos geprek"
- "1/2 sdm gula merah"
recipeinstructions:
- "Haluskan bumbu halus di food chopper/processor"
- "Tumis bumbu halus dan bumbu cemplung hingga wangi dan matang"
- "Masukkan lada bubuk"
- "Masukkan kecap manis disekeliling minyak bumbu. Tunggu sampai kecap berbuih. Aduk rata"
- "Masukkan ayam. Aduk hingga rata terbalut bumbu"
- "Masukkan air, garam, santan jika pakai. Aduk rata. Kecilkan api. Masak hingga air menyusut dan bumbu meresap. Terakhir masukkan kaldu jamur. Koreksi rasa"
- "Angkat dan hidangkan bisa dengan taburan bawang goreng"
categories:
- Recipe
tags:
- ayam
- ricarica
- jawa

katakunci: ayam ricarica jawa 
nutrition: 229 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica-Rica Jawa](https://img-global.cpcdn.com/recipes/24ba4bdceb626eca/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang harus kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica-rica jawa yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Nusantara

Keharmonisan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah memasak Ayam Rica-Rica Jawa untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang dapat anda praktekkan salah satunya ayam rica-rica jawa yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica-rica jawa tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Jawa yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 23 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Jawa:

1. Harus ada 1 ekor ayam kampung ukuran sedang, potong-potong
1. Dibutuhkan Secukupnya air
1. Diperlukan 2 sdm santan instan (saya skip)
1. Harap siapkan 5 sdm kecap manis
1. Harap siapkan 1/2 sdt lada bubuk
1. Diperlukan 1 sdt garam (atau sesuai selera)
1. Diperlukan 1 sdt kaldu jamur (atau sesuai selera)
1. Harap siapkan  Bumbu Halus :
1. Tambah 15 siung bawang merah
1. Tambah 7 siung bawang putih
1. Siapkan 5 butir kemiri, goreng
1. Dibutuhkan 3 cm jahe
1. Harap siapkan 2 cm kunyit
1. Jangan lupa 4 cm kencur
1. Harap siapkan 3 buah cabe merah
1. Dibutuhkan Secukupnya cabe rawit (kalau suka pedas)
1. Diperlukan Secukupnya minyak goreng untuk menghaluskan bumbu
1. Harap siapkan  Bumbu Cemplung :
1. Dibutuhkan 1 lembar daun salam
1. Siapkan 5 lembar daun jeruk, buang tulang daunnya
1. Tambah 3 batang serai, geprek
1. Harus ada 1 jempol laos, geprek
1. Harus ada 1/2 sdm gula merah




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica Jawa:

1. Haluskan bumbu halus di food chopper/processor
1. Tumis bumbu halus dan bumbu cemplung hingga wangi dan matang
1. Masukkan lada bubuk
1. Masukkan kecap manis disekeliling minyak bumbu. Tunggu sampai kecap berbuih. Aduk rata
1. Masukkan ayam. Aduk hingga rata terbalut bumbu
1. Masukkan air, garam, santan jika pakai. Aduk rata. Kecilkan api. Masak hingga air menyusut dan bumbu meresap. Terakhir masukkan kaldu jamur. Koreksi rasa
1. Angkat dan hidangkan bisa dengan taburan bawang goreng




Demikianlah cara membuat ayam rica-rica jawa yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
