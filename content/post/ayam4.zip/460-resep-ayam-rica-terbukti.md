---
description: "Resep : Ayam Rica Terbukti"
title: "Resep : Ayam Rica Terbukti"
slug: 460-resep-ayam-rica-terbukti
date: 2020-10-22T12:39:11.198Z
image: https://img-global.cpcdn.com/recipes/bf5e9924f442e6f5/751x532cq70/ayam-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bf5e9924f442e6f5/751x532cq70/ayam-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bf5e9924f442e6f5/751x532cq70/ayam-rica-foto-resep-utama.jpg
author: Allen Jennings
ratingvalue: 4.8
reviewcount: 34204
recipeingredient:
- "1 ekor Ayam"
- "4-5 bh Lombok Besar sekitar"
- " Lombok Keriting sekitar 10 bh sy tdk pake krn mau yg tdk pedis"
- "2 btg Sere"
- "4 bj Bawang merah"
- "5 bj Bawang putih"
- "3 bj Kemiri"
- "3-4 lembar Daun jeruk"
- "1 bh Tomat"
- "3 cm Jahe sekitar"
- "2 btg Daun bawang besar"
- " Garam Gula pasir Merica TotoleMasako"
- "500 ml Air putih sekitar"
- "Sedikit minyak goreng untuk menumis"
recipeinstructions:
- "Ayam.. potong2 jadi 10-12 bagian, lalu cuci bersih. Setelah di cuci bersih, beri garam dan jeruk nipis.. biarkan sejenak sekitar 3 menit. Setelah itu cuci bersih ulang ayamnya. Sisihkan."
- "Lombok besar, Bawang Merah, Bawang Putih, Kemiri, Tomat, Jahe, Sere potong2 kasar saja lalu Chooper smua 1x.. Chooper nya jangan lama.. sebentar saja agar jadinya itu msh kasar2."
- "Daun bawang besar potong2 sekitar 1-2 cm.. semua di ambil yg bagian putih dan hijau nya. Daun Jeruk cuci bersih."
- "Siapkan wajan, beri minyak goreng.. setelah minyak panas, turunkan lombok besar dan bawang2 yg sdh di chooper kasar tadi.. aduk2 sampe wangi... turunkan daun jeruk dan daun bawang besar yg telah di potong2.. aduk rata.. beri garam sedikit aduk2 sampe wangi dan stengah kering.."
- "Kemudian turunkan ayam nya.. aduk2 sejenak lagi.. lalu beri air sekitar 500ml, beri Garam Gula Merica Totole/Masako.. masak dengan api kecil sampe ayam matang dan air agak menyusut.. SELESAI !!"
categories:
- Recipe
tags:
- ayam
- rica

katakunci: ayam rica 
nutrition: 282 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT40M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica](https://img-global.cpcdn.com/recipes/bf5e9924f442e6f5/751x532cq70/ayam-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga enak. Ciri khas makanan Indonesia ayam rica yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang dapat anda coba salah satunya ayam rica yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep ayam rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica:

1. Harap siapkan 1 ekor Ayam
1. Diperlukan 4-5 bh Lombok Besar sekitar
1. Siapkan  Lombok Keriting sekitar 10 bh (sy tdk pake krn mau yg tdk pedis)
1. Dibutuhkan 2 btg Sere
1. Diperlukan 4 bj Bawang merah
1. Harap siapkan 5 bj Bawang putih
1. Diperlukan 3 bj Kemiri
1. Jangan lupa 3-4 lembar Daun jeruk
1. Tambah 1 bh Tomat
1. Jangan lupa 3 cm Jahe sekitar
1. Jangan lupa 2 btg Daun bawang besar
1. Tambah  Garam Gula pasir Merica Totole/Masako
1. Harap siapkan 500 ml Air putih sekitar
1. Diperlukan Sedikit minyak goreng untuk menumis




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica:

1. Ayam.. potong2 jadi 10-12 bagian, lalu cuci bersih. Setelah di cuci bersih, beri garam dan jeruk nipis.. biarkan sejenak sekitar 3 menit. Setelah itu cuci bersih ulang ayamnya. Sisihkan.
1. Lombok besar, Bawang Merah, Bawang Putih, Kemiri, Tomat, Jahe, Sere potong2 kasar saja lalu Chooper smua 1x.. Chooper nya jangan lama.. sebentar saja agar jadinya itu msh kasar2.
1. Daun bawang besar potong2 sekitar 1-2 cm.. semua di ambil yg bagian putih dan hijau nya. Daun Jeruk cuci bersih.
1. Siapkan wajan, beri minyak goreng.. setelah minyak panas, turunkan lombok besar dan bawang2 yg sdh di chooper kasar tadi.. aduk2 sampe wangi... turunkan daun jeruk dan daun bawang besar yg telah di potong2.. aduk rata.. beri garam sedikit aduk2 sampe wangi dan stengah kering..
1. Kemudian turunkan ayam nya.. aduk2 sejenak lagi.. lalu beri air sekitar 500ml, beri Garam Gula Merica Totole/Masako.. masak dengan api kecil sampe ayam matang dan air agak menyusut.. SELESAI !!




Demikianlah cara membuat ayam rica yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
