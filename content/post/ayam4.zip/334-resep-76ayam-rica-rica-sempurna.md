---
description: "Resep : 76.Ayam Rica Rica Sempurna"
title: "Resep : 76.Ayam Rica Rica Sempurna"
slug: 334-resep-76ayam-rica-rica-sempurna
date: 2020-09-28T01:01:15.155Z
image: https://img-global.cpcdn.com/recipes/d182b079ee557bbd/751x532cq70/76ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d182b079ee557bbd/751x532cq70/76ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d182b079ee557bbd/751x532cq70/76ayam-rica-rica-foto-resep-utama.jpg
author: Jorge Hopkins
ratingvalue: 4
reviewcount: 22764
recipeingredient:
- "500 gram ayam"
- "1 ikat kemangi petik daunnya"
- "2 batang sere"
- "2 lembar daun salam"
- "1 lembar daun jeruk"
- "1/2 ruas jari lengkuas geprek"
- "5 buah cabe setan utuh"
- "1/2 buah jeruk nipis buat membalur ayam"
- "1 sdm garam"
- "1/2 sdt kaldu bubuk"
- "1/2 sdt gula pasir bisa diskip"
- "300 ml air"
- "2 sdm minyak goreng untuk menumis"
- " Bumbu Halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "5 buah cabe merah keriting"
- "1/2 ruas jari kunyit"
- "1 ruas jari jahe"
- "2 butir kemiri"
recipeinstructions:
- "Bersihkan ayam, lumuri jeruk nipis biarkan sebentar bilas dengan air mengalir tiriskan"
- "Cuci kemangi dan bahan2 lainnya"
- "Blender bumbu halus, pertama yang saya blend adalah kemiri dan kunyit dengan sedikit air hingga bener2 halus, saya tuang dulu ketempat lain, lanjut bawang merah, bawang putih, cabe dan jahe (me;blend kasar) tumis bumbu halus hingga harum"
- "Masukkan ayam, aduk hingga ayam berubah warna, tambahkan lengkuas geprek, sere geprek, daun salam dan daun jeruk,,, tambahkan air bumbui dengan garam, kaldu bubuk dan gula,,,"
- "Tutup ayam kecilkan api, biarkan air menyusut (jangan terlalu habis ya airnya) tes rasa bila ada yang dirasa kurang, terakhir masukkan daun kemangi,,, matikan api,,, alhamdulillaah siap jadi temen nasi hangat"
categories:
- Recipe
tags:
- 76ayam
- rica
- rica

katakunci: 76ayam rica rica 
nutrition: 103 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dinner

---


![76.Ayam Rica Rica](https://img-global.cpcdn.com/recipes/d182b079ee557bbd/751x532cq70/76ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau enak. Ciri makanan Indonesia 76.ayam rica rica yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak 76.Ayam Rica Rica untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang dapat anda contoh salah satunya 76.ayam rica rica yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep 76.ayam rica rica tanpa harus bersusah payah.
Berikut ini resep 76.Ayam Rica Rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 76.Ayam Rica Rica:

1. Diperlukan 500 gram ayam
1. Tambah 1 ikat kemangi petik daunnya
1. Diperlukan 2 batang sere
1. Jangan lupa 2 lembar daun salam
1. Diperlukan 1 lembar daun jeruk
1. Siapkan 1/2 ruas jari lengkuas geprek
1. Harus ada 5 buah cabe setan utuh
1. Jangan lupa 1/2 buah jeruk nipis buat membalur ayam
1. Diperlukan 1 sdm garam
1. Harap siapkan 1/2 sdt kaldu bubuk
1. Diperlukan 1/2 sdt gula pasir (bisa diskip)
1. Dibutuhkan 300 ml air
1. Siapkan 2 sdm minyak goreng untuk menumis
1. Harap siapkan  Bumbu Halus :
1. Diperlukan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Tambah 5 buah cabe merah keriting
1. Jangan lupa 1/2 ruas jari kunyit
1. Jangan lupa 1 ruas jari jahe
1. Jangan lupa 2 butir kemiri




<!--inarticleads2-->

##### Cara membuat  76.Ayam Rica Rica:

1. Bersihkan ayam, lumuri jeruk nipis biarkan sebentar bilas dengan air mengalir tiriskan
1. Cuci kemangi dan bahan2 lainnya
1. Blender bumbu halus, pertama yang saya blend adalah kemiri dan kunyit dengan sedikit air hingga bener2 halus, saya tuang dulu ketempat lain, lanjut bawang merah, bawang putih, cabe dan jahe (me;blend kasar) tumis bumbu halus hingga harum
1. Masukkan ayam, aduk hingga ayam berubah warna, tambahkan lengkuas geprek, sere geprek, daun salam dan daun jeruk,,, tambahkan air bumbui dengan garam, kaldu bubuk dan gula,,,
1. Tutup ayam kecilkan api, biarkan air menyusut (jangan terlalu habis ya airnya) tes rasa bila ada yang dirasa kurang, terakhir masukkan daun kemangi,,, matikan api,,, alhamdulillaah siap jadi temen nasi hangat




Demikianlah cara membuat 76.ayam rica rica yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
