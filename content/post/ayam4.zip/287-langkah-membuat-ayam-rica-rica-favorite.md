---
description: "Langkah membuat Ayam Rica-Rica Favorite"
title: "Langkah membuat Ayam Rica-Rica Favorite"
slug: 287-langkah-membuat-ayam-rica-rica-favorite
date: 2020-10-07T02:44:25.040Z
image: https://img-global.cpcdn.com/recipes/b5740a70cd6d1467/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b5740a70cd6d1467/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b5740a70cd6d1467/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Roger Welch
ratingvalue: 4.8
reviewcount: 6528
recipeingredient:
- "350 gr Sayap Ayam dipotong 2 bebas sesuai selera"
- "2 lembar Daun Salam"
- "1 batang Serai Geprek"
- "1 sdm Gula Jawa sisir halus"
- "1 sdm Kecap Manis"
- "Secukupnya Garam Lada Penyedap Rasa"
- "250 ml Air secukupnya dan minyak untuk menumis"
- " Bumbu Halus"
- "3 siung Bawang Merah"
- "2 siung Bawang Putih"
- "7 buah Cabai Merah Keriting"
- "2 buah Cabai Rawit Besar skip kalau nggak pengen terlalu pedas"
- "2 cm Kunyit"
recipeinstructions:
- "Potong ayam sesuai yang diinginkan, cuci bersih, sisihkan"
- "Cuci bersih bahan bumbu halus, haluskan (blender/uleg). Setelah halus, panaskan minyak di wajan untuk menumis, masukkan bumbu halus, daun salam, dan sereh, tumis sampai harum"
- "Setelah harum, masukkan potongan ayam ke dalam tumisan, aduk rata"
- "Tambahkan secukupnya air (sampai daging cukup terendam), garam, lada, penyedap, kecap manis dan gula jawa, aduk rata. Tutup dan biarkan sampai ayam matang dan kuah menyusut. Aduk sesekali sambil koreksi rasa"
- "Voila! Sajikan dan siap dinikmati dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 201 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/b5740a70cd6d1467/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica-rica yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Kehangatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Rica-Rica untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda contoh salah satunya ayam rica-rica yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Jangan lupa 350 gr Sayap Ayam dipotong 2 (bebas, sesuai selera)
1. Siapkan 2 lembar Daun Salam
1. Jangan lupa 1 batang Serai Geprek
1. Siapkan 1 sdm Gula Jawa (sisir halus)
1. Jangan lupa 1 sdm Kecap Manis
1. Tambah Secukupnya Garam, Lada, Penyedap Rasa
1. Dibutuhkan 250 ml Air (secukupnya) dan minyak untuk menumis
1. Harus ada  Bumbu Halus
1. Harap siapkan 3 siung Bawang Merah
1. Diperlukan 2 siung Bawang Putih
1. Jangan lupa 7 buah Cabai Merah Keriting
1. Siapkan 2 buah Cabai Rawit Besar (skip kalau nggak pengen terlalu pedas)
1. Dibutuhkan 2 cm Kunyit




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-Rica:

1. Potong ayam sesuai yang diinginkan, cuci bersih, sisihkan
1. Cuci bersih bahan bumbu halus, haluskan (blender/uleg). Setelah halus, panaskan minyak di wajan untuk menumis, masukkan bumbu halus, daun salam, dan sereh, tumis sampai harum
1. Setelah harum, masukkan potongan ayam ke dalam tumisan, aduk rata
1. Tambahkan secukupnya air (sampai daging cukup terendam), garam, lada, penyedap, kecap manis dan gula jawa, aduk rata. Tutup dan biarkan sampai ayam matang dan kuah menyusut. Aduk sesekali sambil koreksi rasa
1. Voila! Sajikan dan siap dinikmati dengan nasi hangat




Demikianlah cara membuat ayam rica-rica yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
