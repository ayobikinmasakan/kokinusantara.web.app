---
description: "Bagaimana membuat Ayam Rica Kemangi Pedas Luar biasa"
title: "Bagaimana membuat Ayam Rica Kemangi Pedas Luar biasa"
slug: 251-bagaimana-membuat-ayam-rica-kemangi-pedas-luar-biasa
date: 2021-02-03T08:50:59.680Z
image: https://img-global.cpcdn.com/recipes/c800002b655ead49/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c800002b655ead49/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c800002b655ead49/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg
author: Georgie Hines
ratingvalue: 4.3
reviewcount: 33817
recipeingredient:
- "1 ekor ayam 8 potong"
- " Bumbu Halus"
- "15 Bawang Merah"
- "8 Bawang Putih"
- "1 Kelingking Kunyit"
- "2 Jempol Jahe"
- "1 Jempol Lengkuas"
- "2 Kemiri sudah disangrai"
- " Bahan cabe"
- "8 Cabe Gendut karena kebetulan ga ada cabe keriting"
- "18 Cabe Rawit Domba sesuai selera"
- " Bahan Lainnya"
- "5 Sereh digeprek"
- "15 Lembar Daun Jeruk"
- "3 Ikat daun kemangi"
- " Garam kaldu ayam gula merica sesuai selera"
- " Jeruk lemon"
recipeinstructions:
- "Cuci bersih ayam, balurkan perasan jeruk lemon dan diamkan beberapa saat."
- "Didihkan air, rebus ayam (saya 30 menit). Siapkan bahan halus, cuci bersih kemudian blender seluruh bahan halus."
- "Angkat ayam yg sudah direbus kemudian pindahkan ke wajan dan marinasi menggunakan bumbu halus (15 menit). Nyalakan kompor, tambahkan air, minyak, sereh, daun jeruk, garam, kaldu ayam, dan merica. Tunggu sampai airnya sat."
- "Masukan bahan cabe yang telah diblender, garam, gula, kaldu ayam, dan merica. Setelah semuanya merata masukkan daun kemangi dan masak sebentar. Selesai.... aromanya wangi banget🔥🔥"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 167 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Rica Kemangi Pedas](https://img-global.cpcdn.com/recipes/c800002b655ead49/751x532cq70/ayam-rica-kemangi-pedas-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga renyah. Ciri khas makanan Nusantara ayam rica kemangi pedas yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica Kemangi Pedas untuk keluarga. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda praktekkan salah satunya ayam rica kemangi pedas yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica kemangi pedas tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi Pedas yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi Pedas:

1. Harus ada 1 ekor ayam (8 potong)
1. Harus ada  Bumbu Halus
1. Harus ada 15 Bawang Merah
1. Diperlukan 8 Bawang Putih
1. Harap siapkan 1 Kelingking Kunyit
1. Tambah 2 Jempol Jahe
1. Diperlukan 1 Jempol Lengkuas
1. Tambah 2 Kemiri (sudah disangrai)
1. Diperlukan  Bahan cabe
1. Jangan lupa 8 Cabe Gendut (karena kebetulan ga ada cabe keriting)
1. Siapkan 18 Cabe Rawit Domba (sesuai selera)
1. Dibutuhkan  Bahan Lainnya
1. Harap siapkan 5 Sereh (digeprek)
1. Jangan lupa 15 Lembar Daun Jeruk
1. Harus ada 3 Ikat daun kemangi
1. Tambah  Garam, kaldu ayam, gula, merica (sesuai selera)
1. Harap siapkan  Jeruk lemon




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Kemangi Pedas:

1. Cuci bersih ayam, balurkan perasan jeruk lemon dan diamkan beberapa saat.
1. Didihkan air, rebus ayam (saya 30 menit). Siapkan bahan halus, cuci bersih kemudian blender seluruh bahan halus.
1. Angkat ayam yg sudah direbus kemudian pindahkan ke wajan dan marinasi menggunakan bumbu halus (15 menit). Nyalakan kompor, tambahkan air, minyak, sereh, daun jeruk, garam, kaldu ayam, dan merica. Tunggu sampai airnya sat.
1. Masukan bahan cabe yang telah diblender, garam, gula, kaldu ayam, dan merica. Setelah semuanya merata masukkan daun kemangi dan masak sebentar. Selesai.... aromanya wangi banget🔥🔥




Demikianlah cara membuat ayam rica kemangi pedas yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
