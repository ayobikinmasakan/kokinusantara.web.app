---
description: "Resep : Ayam Rica Cepat"
title: "Resep : Ayam Rica Cepat"
slug: 418-resep-ayam-rica-cepat
date: 2021-01-10T21:26:08.556Z
image: https://img-global.cpcdn.com/recipes/916f0c440436f722/751x532cq70/ayam-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/916f0c440436f722/751x532cq70/ayam-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/916f0c440436f722/751x532cq70/ayam-rica-foto-resep-utama.jpg
author: Jean Griffith
ratingvalue: 4
reviewcount: 2907
recipeingredient:
- "1/2 ekor ayam potong kecil2"
- "2 bh jeruk nipis 1 bh utk merendam ayam"
- "5 lbr daun jeruk sobek2"
- "3 ikat kemangi petiki daunnya"
- "2 btg daun bawang potong2"
- "1 ruas lengkuas geprek"
- "1 lbr daun kunyit"
- "Secukupnya gula garam kaldu bubuk"
- "350 ml air"
- " Bumbu halus "
- "20 cabai merah kriting dan rawit merah selera"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "3 bj kemiri goreng"
- "1 ruas kunyit bakar"
- "1/2 ruas jahe"
- "3 btg sereh ambil bagputihnya"
recipeinstructions:
- "Bersihkan ayam rendam dengan garam dan air jeruk nipis lalu cuci bersihkan kembali. Tiriskan."
- "Tumis bumbu halus, daun jeruk, daun kunyit dan lengkuas hingga harum kemudian masuk ayam aduk rata biarkan hingga bumbu meresap lalu tuang air dan bumbu perasa, masak sampai air mendidih dan ayam matang. Masak sampai air menyusut"
- "Sesaat sebelum diangkat masukkan dan aduk rata daun bawang dan daun kemangi dan perasan air jeruk. Ayam ricarica siap dihidangkan."
categories:
- Recipe
tags:
- ayam
- rica

katakunci: ayam rica 
nutrition: 217 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica](https://img-global.cpcdn.com/recipes/916f0c440436f722/751x532cq70/ayam-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga empuk. Karasteristik makanan Indonesia ayam rica yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kehangatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Rica untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda contoh salah satunya ayam rica yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica:

1. Tambah 1/2 ekor ayam potong kecil2
1. Siapkan 2 bh jeruk nipis (1 bh utk merendam ayam)
1. Tambah 5 lbr daun jeruk sobek2
1. Diperlukan 3 ikat kemangi petiki daunnya
1. Harap siapkan 2 btg daun bawang potong2
1. Harus ada 1 ruas lengkuas geprek
1. Tambah 1 lbr daun kunyit
1. Dibutuhkan Secukupnya gula, garam, kaldu bubuk
1. Tambah 350 ml air
1. Diperlukan  Bumbu halus :
1. Siapkan 20 cabai merah kriting dan rawit merah (selera)
1. Harus ada 8 siung bawang merah
1. Diperlukan 5 siung bawang putih
1. Siapkan 3 bj kemiri goreng
1. Diperlukan 1 ruas kunyit bakar
1. Diperlukan 1/2 ruas jahe
1. Diperlukan 3 btg sereh ambil bag.putihnya




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica:

1. Bersihkan ayam rendam dengan garam dan air jeruk nipis lalu cuci bersihkan kembali. Tiriskan.
1. Tumis bumbu halus, daun jeruk, daun kunyit dan lengkuas hingga harum kemudian masuk ayam aduk rata biarkan hingga bumbu meresap lalu tuang air dan bumbu perasa, masak sampai air mendidih dan ayam matang. Masak sampai air menyusut
1. Sesaat sebelum diangkat masukkan dan aduk rata daun bawang dan daun kemangi dan perasan air jeruk. Ayam ricarica siap dihidangkan.




Demikianlah cara membuat ayam rica yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
