---
description: "Steps untuk menyiapakan Ayam rica² daun kemangi minggu ini"
title: "Steps untuk menyiapakan Ayam rica² daun kemangi minggu ini"
slug: 470-steps-untuk-menyiapakan-ayam-rica-daun-kemangi-minggu-ini
date: 2021-01-14T13:39:18.913Z
image: https://img-global.cpcdn.com/recipes/80ce77a882171fd3/751x532cq70/ayam-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/80ce77a882171fd3/751x532cq70/ayam-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/80ce77a882171fd3/751x532cq70/ayam-rica-daun-kemangi-foto-resep-utama.jpg
author: Lenora Lawrence
ratingvalue: 4.4
reviewcount: 31700
recipeingredient:
- "1 ekor ayam potong 10"
- " Bumbu ungkep "
- "1 ruas jari kunyit"
- "1 ruas jari jahe"
- "3 buat kemiri"
- "3 buah bawang merah"
- "3 buah bawang putih"
- "2 lbr sereh geprek"
- "1 buah lengkuas geprek"
- "3 buah daun salam"
- "2 buah daun jeruk sobek"
- " Bumbu halus "
- "10 buah cabe merah keriting"
- "2 buah cabe merah besar"
- "5 buah cabe rawit merah"
- "1 buah tomat"
- "3 buah bawang merah"
- "3 buah bawang putih"
- "secukupnya Garam"
- "secukupnya Gula putih"
- "3 ikat daun kemangi lebih banyak lebih nikmat"
recipeinstructions:
- "Cuci ayam hingga bersih, rebus ayam dgn bumbu ungkep. Matikan api jika sudah empuk dan air tiris."
- "Panaskan minyak goreng, tumis bumbu yang sudah dihaluskan hingga harum, tambahkan gula putih dan air sedikit lalu masukkan ayam yang sudah diungkep tadi, aduk² supaya bumbu meresap dan merata."
- "Jika air sudah tiris, tambahkan daun kemangi sambil diaduk hingga merata."
- "Koreksi rasa, matikan api. Angkat dan sajikan👌"
categories:
- Recipe
tags:
- ayam
- rica
- daun

katakunci: ayam rica daun 
nutrition: 170 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica² daun kemangi](https://img-global.cpcdn.com/recipes/80ce77a882171fd3/751x532cq70/ayam-rica-daun-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga enak. Karasteristik masakan Indonesia ayam rica² daun kemangi yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Olahan ayam dengan santan yang banyak digemari. selamat mencoba teman- teman . Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Kedekatan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam rica² daun kemangi untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang dapat anda praktekkan salah satunya ayam rica² daun kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica² daun kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica² daun kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica² daun kemangi:

1. Tambah 1 ekor ayam (potong 10)
1. Tambah  Bumbu ungkep :
1. Tambah 1 ruas jari kunyit
1. Diperlukan 1 ruas jari jahe
1. Jangan lupa 3 buat kemiri
1. Jangan lupa 3 buah bawang merah
1. Jangan lupa 3 buah bawang putih
1. Dibutuhkan 2 lbr sereh (geprek)
1. Siapkan 1 buah lengkuas (geprek)
1. Dibutuhkan 3 buah daun salam
1. Siapkan 2 buah daun jeruk (sobek²)
1. Tambah  Bumbu halus :
1. Harus ada 10 buah cabe merah keriting
1. Jangan lupa 2 buah cabe merah besar
1. Jangan lupa 5 buah cabe rawit merah
1. Tambah 1 buah tomat
1. Harus ada 3 buah bawang merah
1. Diperlukan 3 buah bawang putih
1. Harus ada secukupnya Garam
1. Tambah secukupnya Gula putih
1. Tambah 3 ikat daun kemangi (lebih banyak lebih nikmat)


Oseng Nanas Muda Sambel Nanas Ikan Lele. Laos Muda Ayam Kampung Sayur Bening Cakra Cikri. Daun Kencur Di Oseng Di Pecel Dan Goreng Obang Abing. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica² daun kemangi:

1. Cuci ayam hingga bersih, rebus ayam dgn bumbu ungkep. Matikan api jika sudah empuk dan air tiris.
1. Panaskan minyak goreng, tumis bumbu yang sudah dihaluskan hingga harum, tambahkan gula putih dan air sedikit lalu masukkan ayam yang sudah diungkep tadi, aduk² supaya bumbu meresap dan merata.
1. Jika air sudah tiris, tambahkan daun kemangi sambil diaduk hingga merata.
1. Koreksi rasa, matikan api. Angkat dan sajikan👌


Daun Kencur Di Oseng Di Pecel Dan Goreng Obang Abing. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! 

Demikianlah cara membuat ayam rica² daun kemangi yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan cepat, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
