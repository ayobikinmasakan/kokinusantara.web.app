---
description: "Cara membuat Ayam rica rica Sempurna"
title: "Cara membuat Ayam rica rica Sempurna"
slug: 254-cara-membuat-ayam-rica-rica-sempurna
date: 2020-12-20T22:11:12.004Z
image: https://img-global.cpcdn.com/recipes/711eb5e6a72697c4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/711eb5e6a72697c4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/711eb5e6a72697c4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Anne Ford
ratingvalue: 4.7
reviewcount: 13196
recipeingredient:
- "3 potong ayam 2 ati ayam dan 2 telur rebus"
- "3 ikat kemangi"
- " Bumbu"
- "5 bawang merah"
- "5 bawang putih"
- "5 cabe merah keriting"
- "5 cabe rawit"
- "2 sdm ketumbar bubuk"
- "2 sdm kunyit bubuk"
- "3 potong jahe"
- "3 lembar daun salam"
- "1/2 batang sereh"
recipeinstructions:
- "Rebus ayam dan ati hingga setengah matang dan telur"
- "Blender bumbu halus (bawang merah, bawang putih dan cabe) lalu masukan ketumbar dan kunyit bubuk"
- "Panaskan minyak, tumis bumbu halus hingga wangi, masukan daun salam, jahe dan sereh masang hingga wangi, lalu"
- "Masukkan ayam dan ati masak, tambahkan air (sesuai selera) masak 20 menit lalu masukkan telur rebus masak hingga hampir matang lalu masukkan kemangi hingga sedikit layu dan wangi lalu angkat dan sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 200 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica rica](https://img-global.cpcdn.com/recipes/711eb5e6a72697c4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica rica yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Nusantara

Kehangatan rumah tangga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica rica untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang bisa anda coba salah satunya ayam rica rica yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica:

1. Siapkan 3 potong ayam 2 ati ayam dan 2 telur rebus
1. Jangan lupa 3 ikat kemangi
1. Harap siapkan  Bumbu
1. Diperlukan 5 bawang merah
1. Siapkan 5 bawang putih
1. Diperlukan 5 cabe merah keriting
1. Tambah 5 cabe rawit
1. Siapkan 2 sdm ketumbar bubuk
1. Siapkan 2 sdm kunyit bubuk
1. Diperlukan 3 potong jahe
1. Dibutuhkan 3 lembar daun salam
1. Harus ada 1/2 batang sereh




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica:

1. Rebus ayam dan ati hingga setengah matang dan telur
1. Blender bumbu halus (bawang merah, bawang putih dan cabe) lalu masukan ketumbar dan kunyit bubuk
1. Panaskan minyak, tumis bumbu halus hingga wangi, masukan daun salam, jahe dan sereh masang hingga wangi, lalu
1. Masukkan ayam dan ati masak, tambahkan air (sesuai selera) masak 20 menit lalu masukkan telur rebus masak hingga hampir matang lalu masukkan kemangi hingga sedikit layu dan wangi lalu angkat dan sajikan




Demikianlah cara membuat ayam rica rica yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
