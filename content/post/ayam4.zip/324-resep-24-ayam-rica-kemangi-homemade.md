---
description: "Resep : 24. Ayam Rica Kemangi Homemade"
title: "Resep : 24. Ayam Rica Kemangi Homemade"
slug: 324-resep-24-ayam-rica-kemangi-homemade
date: 2020-10-11T14:21:03.619Z
image: https://img-global.cpcdn.com/recipes/92f6fd87936a00a9/751x532cq70/24-ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/92f6fd87936a00a9/751x532cq70/24-ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/92f6fd87936a00a9/751x532cq70/24-ayam-rica-kemangi-foto-resep-utama.jpg
author: Lizzie Wilkerson
ratingvalue: 4.7
reviewcount: 43096
recipeingredient:
- "1/2 kg ayam kampung muda"
- "1 papan kecil tempe"
- "Segenggam kemangi"
- " Kecap"
- " Garam"
- " Gula Kaldu jamur"
- " Air"
- " Bumbu halus "
- "3 siung bawang putih"
- "5 siung bawang merah"
- "8 buah cabe merah kriting"
- "5 buah cabe setan"
- "1 ruas jahe"
- "3 buah kemiri"
- "1 sdt ketumbar"
- "1/2 sdt merica"
- " Bumbu cemplung "
- "1 batang serai geprek"
- "1 helai daun jeruk wangi"
recipeinstructions:
- "Cuci bersih ayam lalu rebus sebentar. Setelah matang tiriskan."
- "Potong tempe sesuai selera."
- "Rebus juga bawang merah, bawang putih &amp; cabe. Setalah itu tiriskan."
- "Ulek bumbu yg direbus tadi. Tambahkan jahe, kemiri, ketumbar, &amp; merica. Ulek hingga halus."
- "Panaskan minyak, goreng tempe &amp; ayam hingga terlihat layu saja, jadi jangan lama². Tiriskan."
- "Siapkan wajan beri sedikit minyak. Tumis bumbu ulek, tambahkan juga daun jeruk &amp; serai. Tumis hingga harum. Tambahkan ir, didihkan."
- "Masukkan ayam &amp; tempe. Beri garam, gula &amp; kaldu jamur."
- "Setelah air menyusut masukkan potongan tomat, kemangi &amp; beri sedikit kecap. Koreksi rasa."
- "Biarkan sebentar, lalu mati kompor. Ayam rica kemangi siap disajikan."
categories:
- Recipe
tags:
- 24
- ayam
- rica

katakunci: 24 ayam rica 
nutrition: 238 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dessert

---


![24. Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/92f6fd87936a00a9/751x532cq70/24-ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti 24. ayam rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan ciri khas yang merupakan keragaman Nusantara



Kedekatan keluarga bisa didapat dengan cara simple. Diantaranya adalah memasak 24. Ayam Rica Kemangi untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda contoh salah satunya 24. ayam rica kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep 24. ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep 24. Ayam Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat 24. Ayam Rica Kemangi:

1. Harus ada 1/2 kg ayam kampung muda
1. Tambah 1 papan kecil tempe
1. Siapkan Segenggam kemangi
1. Diperlukan  Kecap
1. Siapkan  Garam
1. Diperlukan  Gula Kaldu jamur
1. Tambah  Air
1. Dibutuhkan  Bumbu halus :
1. Tambah 3 siung bawang putih
1. Diperlukan 5 siung bawang merah
1. Harus ada 8 buah cabe merah kriting
1. Harap siapkan 5 buah cabe setan
1. Diperlukan 1 ruas jahe
1. Siapkan 3 buah kemiri
1. Jangan lupa 1 sdt ketumbar
1. Siapkan 1/2 sdt merica
1. Tambah  Bumbu cemplung :
1. Diperlukan 1 batang serai (geprek)
1. Siapkan 1 helai daun jeruk wangi




<!--inarticleads2-->

##### Instruksi membuat  24. Ayam Rica Kemangi:

1. Cuci bersih ayam lalu rebus sebentar. Setelah matang tiriskan.
1. Potong tempe sesuai selera.
1. Rebus juga bawang merah, bawang putih &amp; cabe. Setalah itu tiriskan.
1. Ulek bumbu yg direbus tadi. Tambahkan jahe, kemiri, ketumbar, &amp; merica. Ulek hingga halus.
1. Panaskan minyak, goreng tempe &amp; ayam hingga terlihat layu saja, jadi jangan lama². Tiriskan.
1. Siapkan wajan beri sedikit minyak. Tumis bumbu ulek, tambahkan juga daun jeruk &amp; serai. Tumis hingga harum. Tambahkan ir, didihkan.
1. Masukkan ayam &amp; tempe. Beri garam, gula &amp; kaldu jamur.
1. Setelah air menyusut masukkan potongan tomat, kemangi &amp; beri sedikit kecap. Koreksi rasa.
1. Biarkan sebentar, lalu mati kompor. Ayam rica kemangi siap disajikan.




Demikianlah cara membuat 24. ayam rica kemangi yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
