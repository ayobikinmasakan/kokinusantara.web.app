---
description: "Panduan membuat (1.29) Ayam Rica Kemangi terupdate"
title: "Panduan membuat (1.29) Ayam Rica Kemangi terupdate"
slug: 315-panduan-membuat-129-ayam-rica-kemangi-terupdate
date: 2021-02-04T04:36:01.103Z
image: https://img-global.cpcdn.com/recipes/55e72c9d8e7acfb6/751x532cq70/129-ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/55e72c9d8e7acfb6/751x532cq70/129-ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/55e72c9d8e7acfb6/751x532cq70/129-ayam-rica-kemangi-foto-resep-utama.jpg
author: Evan Lowe
ratingvalue: 4
reviewcount: 22370
recipeingredient:
- "500 gr daging ayam fillet me SoesariRokerij potong dadu"
- "2 ikat kemangi petiki daunnya"
- "50 gr gula meraharen"
- "1 sdt garam sesuaikan selera"
- " Bumbu Cemplung"
- "1 batang sereh bag putih geprek"
- "5 lembar daun jeruk buang tulang daun"
- "10 buah cabe rawit"
- " Bumbu Halus"
- "8 buah cabe merah keriting"
- "2 buah cabe merah besar"
- "5 buah cabe rawit"
- "10 siung bawang merah"
- "4 buah bawang putih"
- "2 buah tomat"
- "2 sdt ketumbar sangrai"
- "2 sdm minyak"
recipeinstructions:
- "Tumis bumbu halus hingga harum"
- "Masukkan bumbu cemplung, masak hingga bumbu matang (berwarna lebih gelap dan harum)"
- "Masukkan ayam fillet + gula + garam, aduk rata, tes rasa, masak hingga bumbu meresap"
- "Matikan api, masukkan daun kemangi, aduk rata"
- "Sajikan"
- "Gula Aren yg digunakan"
categories:
- Recipe
tags:
- 129
- ayam
- rica

katakunci: 129 ayam rica 
nutrition: 228 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dessert

---


![(1.29) Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/55e72c9d8e7acfb6/751x532cq70/129-ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan renyah. Karasteristik kuliner Nusantara (1.29) ayam rica kemangi yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah memasak (1.29) Ayam Rica Kemangi untuk keluarga. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang dapat anda buat salah satunya (1.29) ayam rica kemangi yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep (1.29) ayam rica kemangi tanpa harus bersusah payah.
Seperti resep (1.29) Ayam Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat (1.29) Ayam Rica Kemangi:

1. Siapkan 500 gr daging ayam fillet (me: @SoesariRokerij), potong dadu
1. Siapkan 2 ikat kemangi, petiki daunnya
1. Diperlukan 50 gr gula merah/aren
1. Harap siapkan 1 sdt garam (sesuaikan selera)
1. Harus ada  Bumbu Cemplung:
1. Siapkan 1 batang sereh bag. putih, geprek
1. Siapkan 5 lembar daun jeruk, buang tulang daun
1. Harus ada 10 buah cabe rawit
1. Diperlukan  Bumbu Halus:
1. Siapkan 8 buah cabe merah keriting
1. Harap siapkan 2 buah cabe merah besar
1. Harus ada 5 buah cabe rawit
1. Tambah 10 siung bawang merah
1. Tambah 4 buah bawang putih
1. Siapkan 2 buah tomat
1. Harap siapkan 2 sdt ketumbar, sangrai
1. Harus ada 2 sdm minyak




<!--inarticleads2-->

##### Langkah membuat  (1.29) Ayam Rica Kemangi:

1. Tumis bumbu halus hingga harum
1. Masukkan bumbu cemplung, masak hingga bumbu matang (berwarna lebih gelap dan harum)
1. Masukkan ayam fillet + gula + garam, aduk rata, tes rasa, masak hingga bumbu meresap
1. Matikan api, masukkan daun kemangi, aduk rata
1. Sajikan
1. Gula Aren yg digunakan




Demikianlah cara membuat (1.29) ayam rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
