---
description: "Cara singkat untuk menyiapakan Ayam Rica Rica Sempurna"
title: "Cara singkat untuk menyiapakan Ayam Rica Rica Sempurna"
slug: 435-cara-singkat-untuk-menyiapakan-ayam-rica-rica-sempurna
date: 2020-09-25T14:33:54.165Z
image: https://img-global.cpcdn.com/recipes/e78721ee98a4b9be/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e78721ee98a4b9be/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e78721ee98a4b9be/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Philip Huff
ratingvalue: 4.8
reviewcount: 29365
recipeingredient:
- " Bahan Utama"
- "1 ekor Ayam"
- " Bumbu marinasi"
- " Perasan air jeruk nipis"
- "1 sdm Garam"
- "5 lembar daun jeruk diiris"
- " Bumbu uleg kasar"
- "secukupnya Cabe rawit merah"
- "secukupnya Cabe merah keriting"
- "2 buah Cabe merah besar"
- "segenggam Bawang merah"
- "segenggam Bawang putih"
- "1/2 ruas jari Jahe"
- " Bumbu kasar"
- "4 lembar daun salam"
- "2 sereh geprek"
- "1/2 tomat"
- " Tambahan"
- " Totole"
- " Garam"
- " Gula"
- " Lada"
recipeinstructions:
- "Cuci bersih ayam, dan langsung ditaburi bumbu marinasi. Tunggu 30 menit, masukin kulkas."
- "Setelah 30 menit, goreng ayam sampai matang. Jangan terlalu kering, nanti ayamnya keras. (Api wajib kecil, masukin ayam pas minyak panas banget ya)."
- "Uleg bumbu/blender kasar juga boleh. Setelah itu tumis bumbu dengan minyak sampai harum. Masukkan tomat, daun salam, sereh totole, garam, lada dan gula. Koreksi rasa"
- "Bila rasa sudah sesuai bisa masukkan ayam dan diaduk merata. Setelah rata, bisa dinikmati dengan nasi panas langsungg🤤🤤"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 174 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/e78721ee98a4b9be/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga empuk. Karasteristik kuliner Indonesia ayam rica rica yang penuh dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Rica Rica untuk keluarga. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang dapat anda buat salah satunya ayam rica rica yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep ayam rica rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica:

1. Tambah  Bahan Utama
1. Harus ada 1 ekor Ayam
1. Jangan lupa  Bumbu marinasi
1. Harap siapkan  Perasan air jeruk nipis
1. Harap siapkan 1 sdm Garam
1. Tambah 5 lembar daun jeruk diiris
1. Tambah  Bumbu uleg kasar
1. Siapkan secukupnya Cabe rawit merah
1. Siapkan secukupnya Cabe merah keriting
1. Diperlukan 2 buah Cabe merah besar
1. Diperlukan segenggam Bawang merah
1. Jangan lupa segenggam Bawang putih
1. Diperlukan 1/2 ruas jari Jahe
1. Harus ada  Bumbu kasar
1. Harus ada 4 lembar daun salam
1. Jangan lupa 2 sereh geprek
1. Dibutuhkan 1/2 tomat
1. Harus ada  Tambahan
1. Harus ada  Totole
1. Diperlukan  Garam
1. Harus ada  Gula
1. Tambah  Lada




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica:

1. Cuci bersih ayam, dan langsung ditaburi bumbu marinasi. Tunggu 30 menit, masukin kulkas.
1. Setelah 30 menit, goreng ayam sampai matang. Jangan terlalu kering, nanti ayamnya keras. (Api wajib kecil, masukin ayam pas minyak panas banget ya).
1. Uleg bumbu/blender kasar juga boleh. Setelah itu tumis bumbu dengan minyak sampai harum. Masukkan tomat, daun salam, sereh totole, garam, lada dan gula. Koreksi rasa
1. Bila rasa sudah sesuai bisa masukkan ayam dan diaduk merata. Setelah rata, bisa dinikmati dengan nasi panas langsungg🤤🤤




Demikianlah cara membuat ayam rica rica yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan cepat, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
