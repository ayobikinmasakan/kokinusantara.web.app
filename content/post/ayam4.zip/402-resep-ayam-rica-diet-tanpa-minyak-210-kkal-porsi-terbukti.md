---
description: "Resep : Ayam Rica diet tanpa minyak (210 kkal/porsi) Terbukti"
title: "Resep : Ayam Rica diet tanpa minyak (210 kkal/porsi) Terbukti"
slug: 402-resep-ayam-rica-diet-tanpa-minyak-210-kkal-porsi-terbukti
date: 2020-10-26T04:43:28.115Z
image: https://img-global.cpcdn.com/recipes/ab2650ede9034ded/751x532cq70/ayam-rica-diet-tanpa-minyak-210-kkalporsi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ab2650ede9034ded/751x532cq70/ayam-rica-diet-tanpa-minyak-210-kkalporsi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ab2650ede9034ded/751x532cq70/ayam-rica-diet-tanpa-minyak-210-kkalporsi-foto-resep-utama.jpg
author: Elmer Jackson
ratingvalue: 4.3
reviewcount: 45948
recipeingredient:
- "200 gram ayam"
- "1 batang sereh geprek"
- "1 cm jahe geprek"
- "1 cm lengkuas geprek"
- "1 lembar daun salam"
- "1 lembar daun jeruk"
- "secukupnya Kemangi"
- "100 ml air"
- "secukupnya Garam kaldu jamur"
- " Bumbu Halus"
- "2 bawang merah"
- "1 bawang putih"
- "1/2 butir kemiri"
- "1 cm kunyit"
- "sesuai selera Cabe merah keriting"
- "sesuai selera Cabe rawit"
recipeinstructions:
- "Siap kan bahan2 dan bumbu halusnya"
- "Didihkan 100 ml air diatas teflon anti lengket (ini penting karena kita menumis nggak pake minyak),, lalu tumis bumbu halus, jahe, lengkuas, sereh, daun salam dan daun jeruk dengan air hingga bau langu nya hilang, harum dan air menyusut"
- "Setelah tumisan menjadi lebih harum dan airnya berkurang, masukkan ayam, tambahkan garam dan kaldu jamur..tumis2 hingga ayam matang (tidak saya tambah air..karena ayam juga akan mengeluarkan air)"
- "Jika ayam sudah matang, cicipi rasa..keluarkan sereh, jahe, lengkuas, daun salam dan daun jeruk (optional yah..supaya lebih mudah aja makannya..hehe) lalu masukkan daun kemangi, aduk2 dan sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- diet

katakunci: ayam rica diet 
nutrition: 133 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica diet tanpa minyak (210 kkal/porsi)](https://img-global.cpcdn.com/recipes/ab2650ede9034ded/751x532cq70/ayam-rica-diet-tanpa-minyak-210-kkalporsi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan renyah. Ciri kuliner Nusantara ayam rica diet tanpa minyak (210 kkal/porsi) yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah memasak Ayam Rica diet tanpa minyak (210 kkal/porsi) untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang bisa anda praktekkan salah satunya ayam rica diet tanpa minyak (210 kkal/porsi) yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep ayam rica diet tanpa minyak (210 kkal/porsi) tanpa harus bersusah payah.
Seperti resep Ayam Rica diet tanpa minyak (210 kkal/porsi) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica diet tanpa minyak (210 kkal/porsi):

1. Dibutuhkan 200 gram ayam
1. Harus ada 1 batang sereh geprek
1. Siapkan 1 cm jahe geprek
1. Dibutuhkan 1 cm lengkuas geprek
1. Jangan lupa 1 lembar daun salam
1. Harus ada 1 lembar daun jeruk
1. Jangan lupa secukupnya Kemangi
1. Dibutuhkan 100 ml air
1. Siapkan secukupnya Garam, kaldu jamur
1. Diperlukan  Bumbu Halus
1. Diperlukan 2 bawang merah
1. Tambah 1 bawang putih
1. Harus ada 1/2 butir kemiri
1. Jangan lupa 1 cm kunyit
1. Harap siapkan sesuai selera Cabe merah keriting
1. Tambah sesuai selera Cabe rawit




<!--inarticleads2-->

##### Cara membuat  Ayam Rica diet tanpa minyak (210 kkal/porsi):

1. Siap kan bahan2 dan bumbu halusnya
1. Didihkan 100 ml air diatas teflon anti lengket (ini penting karena kita menumis nggak pake minyak),, lalu tumis bumbu halus, jahe, lengkuas, sereh, daun salam dan daun jeruk dengan air hingga bau langu nya hilang, harum dan air menyusut
1. Setelah tumisan menjadi lebih harum dan airnya berkurang, masukkan ayam, tambahkan garam dan kaldu jamur..tumis2 hingga ayam matang (tidak saya tambah air..karena ayam juga akan mengeluarkan air)
1. Jika ayam sudah matang, cicipi rasa..keluarkan sereh, jahe, lengkuas, daun salam dan daun jeruk (optional yah..supaya lebih mudah aja makannya..hehe) lalu masukkan daun kemangi, aduk2 dan sajikan




Demikianlah cara membuat ayam rica diet tanpa minyak (210 kkal/porsi) yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
