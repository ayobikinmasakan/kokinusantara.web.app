---
description: "Resep : Ayam Madu Pedas Cepat"
title: "Resep : Ayam Madu Pedas Cepat"
slug: 116-resep-ayam-madu-pedas-cepat
date: 2020-11-18T14:51:39.241Z
image: https://img-global.cpcdn.com/recipes/58723ce28e0db38b/751x532cq70/ayam-madu-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/58723ce28e0db38b/751x532cq70/ayam-madu-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/58723ce28e0db38b/751x532cq70/ayam-madu-pedas-foto-resep-utama.jpg
author: Ellen Stanley
ratingvalue: 4.8
reviewcount: 7413
recipeingredient:
- "500 gr sayap ayam"
- "1 btr jeruk nipis"
- "1/2 sdt garam"
- "1 btr bawang bombay"
- "2 siung bawang putih"
- "3 buah cabe rawit merah"
- "2 sdm saus tiram"
- "2-3 sachet madu"
- "1 btg daun bawang"
- " Pelengkap "
- " Wijen"
recipeinstructions:
- "Siapkan bahan."
- "Cuci ayam, balur jeruk nipis dan garam. Diamkan sebentar beberapa menit lalu bilas. Iris bawang, cabe dan daun bawang."
- "Goreng ayam hingga golden brown. Angkat tiriskan."
- "Tumis bawang dan cabe hingga layu. Masukkan saus tiram dan madu. Merk madu yg dipakai sesuai selera ya beb, aku pake madurasa aja. Kalo mau lebih enak lagi pake mulyeot (sirup beras dari korea)."
- "Aduk rata tumisan dan masak sebentar. Jangan lupa tes rasa. Kalau kurang asin manis bisa ditambah kaldu bubuk/kecap asin/garam/saus tiram. Kalau kurang manis bisa tambah madu/gula pasir"
- "Masukkan ayam goreng tadi, aduk rata, masukkan sebagian daun bawang iris, aduk rata. Matikan api. Sajikan dengan taburan daun bawang dan wijen"
categories:
- Recipe
tags:
- ayam
- madu
- pedas

katakunci: ayam madu pedas 
nutrition: 253 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Madu Pedas](https://img-global.cpcdn.com/recipes/58723ce28e0db38b/751x532cq70/ayam-madu-pedas-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam madu pedas yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan keistimewahan yang merupakan keragaman Nusantara

Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam Madu Pedas untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda coba salah satunya ayam madu pedas yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam madu pedas tanpa harus bersusah payah.
Seperti resep Ayam Madu Pedas yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 11 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Madu Pedas:

1. Siapkan 500 gr sayap ayam
1. Diperlukan 1 btr jeruk nipis
1. Dibutuhkan 1/2 sdt garam
1. Diperlukan 1 btr bawang bombay
1. Jangan lupa 2 siung bawang putih
1. Tambah 3 buah cabe rawit merah
1. Dibutuhkan 2 sdm saus tiram
1. Harap siapkan 2-3 sachet madu
1. Tambah 1 btg daun bawang
1. Siapkan  Pelengkap :
1. Harus ada  Wijen




<!--inarticleads2-->

##### Langkah membuat  Ayam Madu Pedas:

1. Siapkan bahan.
1. Cuci ayam, balur jeruk nipis dan garam. Diamkan sebentar beberapa menit lalu bilas. Iris bawang, cabe dan daun bawang.
1. Goreng ayam hingga golden brown. Angkat tiriskan.
1. Tumis bawang dan cabe hingga layu. Masukkan saus tiram dan madu. Merk madu yg dipakai sesuai selera ya beb, aku pake madurasa aja. Kalo mau lebih enak lagi pake mulyeot (sirup beras dari korea).
1. Aduk rata tumisan dan masak sebentar. Jangan lupa tes rasa. Kalau kurang asin manis bisa ditambah kaldu bubuk/kecap asin/garam/saus tiram. Kalau kurang manis bisa tambah madu/gula pasir
1. Masukkan ayam goreng tadi, aduk rata, masukkan sebagian daun bawang iris, aduk rata. Matikan api. Sajikan dengan taburan daun bawang dan wijen




Demikianlah cara membuat ayam madu pedas yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
