---
description: "Steps untuk menyiapakan Ayam Rica - Rica Luar biasa"
title: "Steps untuk menyiapakan Ayam Rica - Rica Luar biasa"
slug: 286-steps-untuk-menyiapakan-ayam-rica-rica-luar-biasa
date: 2021-01-14T20:56:22.509Z
image: https://img-global.cpcdn.com/recipes/65109912faf9fb59/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/65109912faf9fb59/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/65109912faf9fb59/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Eliza Conner
ratingvalue: 4.6
reviewcount: 30173
recipeingredient:
- "7 potong ayam ukuran sedang cuci bersih"
- " Bumbu ulek "
- "3 siung bawang merah"
- "10 buah cabai rawit merah"
- "2 siung bawang putih"
- "8 buah cabai merah keriting"
- "2 butir kemiri"
- "1 ruas jari kunyit"
- "1/4 buah bagian tomat"
- "1/2 sdt garam"
- " Bumbu lainnya "
- "1 batang sereh"
- "1 lembar daun jeruk"
- "1/2 buah jeruk nipis"
- "1 lembar salam"
- "1 ruas jari jahe"
- "secukupnya Kaldu jamur"
- "1/2 sdt gula pasir"
recipeinstructions:
- "Panaskan minyak goreng, goreng ayam yg sudah dicuci bersih hingga matang. Sisihkan"
- "Ulek semua bumbu halus, geprek jahe dan sereh. Sisihkan."
- "Panaskan minyak goreng kembali, tumis bumbu halus beserta jahe, sereh, salam dan daun jeruk, tumis hingga harum dan berubah warna"
- "Setelah itu masukkan kaldu jamur dan gula pasir, aduk rata"
- "Masukkan ayam yg sudah digoreng aduk kembali"
- "Beri perasan jeruk nipis dan tambahkan air secukupnya, aduk rata kembali"
- "Tutup wajan biarkan mendidih dan bumbu meresap sampai air menyusut"
- "Setelah air menyusut, aduk rata kembali, jangan lupa tes rasa, jika sudah sesuai selera, angkat dan siap disajikan. Terima kasih"
- "Selamat mencoba 😉 klo penyuka pedas dijamin nambah. Gak cukup makan 1 potong ayam.."
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 224 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica - Rica](https://img-global.cpcdn.com/recipes/65109912faf9fb59/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica - rica yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa keistimewahan yang merupakan keragaman Kita



Kehangatan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica - Rica untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda praktekkan salah satunya ayam rica - rica yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam rica - rica tanpa harus bersusah payah.
Seperti resep Ayam Rica - Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 9 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica - Rica:

1. Jangan lupa 7 potong ayam ukuran sedang, cuci bersih
1. Harap siapkan  Bumbu ulek :
1. Harap siapkan 3 siung bawang merah
1. Harap siapkan 10 buah cabai rawit merah
1. Dibutuhkan 2 siung bawang putih
1. Siapkan 8 buah cabai merah keriting
1. Harap siapkan 2 butir kemiri
1. Dibutuhkan 1 ruas jari kunyit
1. Dibutuhkan 1/4 buah bagian tomat
1. Siapkan 1/2 sdt garam
1. Siapkan  Bumbu lainnya :
1. Harus ada 1 batang sereh
1. Harap siapkan 1 lembar daun jeruk
1. Harus ada 1/2 buah jeruk nipis
1. Diperlukan 1 lembar salam
1. Jangan lupa 1 ruas jari jahe
1. Dibutuhkan secukupnya Kaldu jamur
1. Dibutuhkan 1/2 sdt gula pasir




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica - Rica:

1. Panaskan minyak goreng, goreng ayam yg sudah dicuci bersih hingga matang. Sisihkan
1. Ulek semua bumbu halus, geprek jahe dan sereh. Sisihkan.
1. Panaskan minyak goreng kembali, tumis bumbu halus beserta jahe, sereh, salam dan daun jeruk, tumis hingga harum dan berubah warna
1. Setelah itu masukkan kaldu jamur dan gula pasir, aduk rata
1. Masukkan ayam yg sudah digoreng aduk kembali
1. Beri perasan jeruk nipis dan tambahkan air secukupnya, aduk rata kembali
1. Tutup wajan biarkan mendidih dan bumbu meresap sampai air menyusut
1. Setelah air menyusut, aduk rata kembali, jangan lupa tes rasa, jika sudah sesuai selera, angkat dan siap disajikan. Terima kasih
1. Selamat mencoba 😉 klo penyuka pedas dijamin nambah. Gak cukup makan 1 potong ayam..




Demikianlah cara membuat ayam rica - rica yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
