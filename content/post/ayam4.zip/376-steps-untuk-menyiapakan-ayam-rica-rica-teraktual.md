---
description: "Steps untuk menyiapakan Ayam rica-rica teraktual"
title: "Steps untuk menyiapakan Ayam rica-rica teraktual"
slug: 376-steps-untuk-menyiapakan-ayam-rica-rica-teraktual
date: 2021-02-04T07:12:10.960Z
image: https://img-global.cpcdn.com/recipes/15c067e66b7bb173/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/15c067e66b7bb173/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/15c067e66b7bb173/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Edith Gomez
ratingvalue: 5
reviewcount: 6380
recipeingredient:
- "1/2 ekor ayam"
- "1 batang serai"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 ruas lengkuas dimemarkan"
- " Bumbu halus"
- "8 buah cabe merah"
- "10 buah cabe rawit"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "2 butir kemiri"
- " Bahan ungkep ayam bumbu racik instan"
- "1 sdt garam"
- "1 sdt gula pasir"
- "1 sdt kaldu bubukpenyedap"
- "2 ikat daun kemangi ambil daunnya"
- "500 ml air"
- " Minyak untuk goreng"
recipeinstructions:
- "Cuci bersih ayam yg telah dipotong,lalu marinasi ayam dengan bumbu racik instan diamkan selama 10-15 menit.panaskan minyak dalam wajan lalu goreng ayam hingga matang.sisihkan"
- "Panaskan sedikit minyak bekas menggoreng ayam tadi lalu tumis bumbu halus masukkan daun salam,daun jeruk,sereh,&amp; lengkuas masak hingga bumbu benar2 matang &amp; tercium harum"
- "Setelah bumbu matang masukkan ayam goreng tadi aduk rata dengan bumbu lalu tambahkan air.masak hingga air mendidih lalu beri garam,gula,&amp; kaldu bubuk/penyedap (optinal) aduk rata kembali masak hingga air menyusut dan bumbu meresap ke dalam ayam tes rasa."
- "Sesaat sebelum dimatikan kompor &amp; ayam sudah matang masukkan daun kemangi aduk2 sebentar saja agar tetap segar lalu matikan api.sajikan ayam selagi hangat bersama nasi putih hangat."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 168 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica-rica](https://img-global.cpcdn.com/recipes/15c067e66b7bb173/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica-rica yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan keistimewahan yang merupakan keragaman Nusantara

Kehangatan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam rica-rica untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda buat salah satunya ayam rica-rica yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica:

1. Harus ada 1/2 ekor ayam
1. Siapkan 1 batang serai
1. Dibutuhkan 2 lembar daun salam
1. Diperlukan 3 lembar daun jeruk
1. Siapkan 1 ruas lengkuas dimemarkan
1. Siapkan  Bumbu halus:
1. Harap siapkan 8 buah cabe merah
1. Harus ada 10 buah cabe rawit
1. Harus ada 8 siung bawang merah
1. Diperlukan 4 siung bawang putih
1. Diperlukan 1 ruas jahe
1. Diperlukan 1 ruas kunyit
1. Dibutuhkan 2 butir kemiri
1. Tambah  Bahan ungkep ayam: bumbu racik (instan)
1. Jangan lupa 1 sdt garam
1. Dibutuhkan 1 sdt gula pasir
1. Tambah 1 sdt kaldu bubuk/penyedap
1. Harus ada 2 ikat daun kemangi ambil daunnya
1. Tambah 500 ml air
1. Harus ada  Minyak untuk goreng




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica:

1. Cuci bersih ayam yg telah dipotong,lalu marinasi ayam dengan bumbu racik instan diamkan selama 10-15 menit.panaskan minyak dalam wajan lalu goreng ayam hingga matang.sisihkan
1. Panaskan sedikit minyak bekas menggoreng ayam tadi lalu tumis bumbu halus masukkan daun salam,daun jeruk,sereh,&amp; lengkuas masak hingga bumbu benar2 matang &amp; tercium harum
1. Setelah bumbu matang masukkan ayam goreng tadi aduk rata dengan bumbu lalu tambahkan air.masak hingga air mendidih lalu beri garam,gula,&amp; kaldu bubuk/penyedap (optinal) aduk rata kembali masak hingga air menyusut dan bumbu meresap ke dalam ayam tes rasa.
1. Sesaat sebelum dimatikan kompor &amp; ayam sudah matang masukkan daun kemangi aduk2 sebentar saja agar tetap segar lalu matikan api.sajikan ayam selagi hangat bersama nasi putih hangat.




Demikianlah cara membuat ayam rica-rica yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
