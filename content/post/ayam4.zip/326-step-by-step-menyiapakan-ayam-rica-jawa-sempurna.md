---
description: "Step-by-Step menyiapakan Ayam Rica Jawa Sempurna"
title: "Step-by-Step menyiapakan Ayam Rica Jawa Sempurna"
slug: 326-step-by-step-menyiapakan-ayam-rica-jawa-sempurna
date: 2020-12-23T07:48:52.934Z
image: https://img-global.cpcdn.com/recipes/2a7bb5445e3b890d/751x532cq70/ayam-rica-jawa-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2a7bb5445e3b890d/751x532cq70/ayam-rica-jawa-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2a7bb5445e3b890d/751x532cq70/ayam-rica-jawa-foto-resep-utama.jpg
author: Nora Griffin
ratingvalue: 4.8
reviewcount: 23013
recipeingredient:
- "1 kg ayam potong sesuai selera"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 batang serai"
- " Bumbu Halus "
- "7 siung bawang putih"
- "2 butir bawang merah"
- "12 cabe rawit"
- "3 cabe merah besar"
- "1/2 cm kunyit"
- "5 butir kemiri sangrai"
- "1/2 sdt ketumbar bubuk"
- "1/2 sdt merica"
- "2 sdm kecap bangau"
- "Secukupnya garam dan gula"
- "Secukupnya air"
recipeinstructions:
- "Tumis bumbu halus, daun salam, daun jeruk dgn sdkt minyak sampai harum."
- "Masukkan ayam, kecap dan air. Aduk rata. Tambahkan garam dan gula."
- "Masak ayam sampai bumbunya meresap, jika airnya kurang bisa di tambahkan (sesuaikan dengan kekentalan kuah yg diinginkan, saya lbh suka agak kering). Koreksi rasa."
- "Sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- jawa

katakunci: ayam rica jawa 
nutrition: 271 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica Jawa](https://img-global.cpcdn.com/recipes/2a7bb5445e3b890d/751x532cq70/ayam-rica-jawa-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas atau gurih. Ciri masakan Nusantara ayam rica jawa yang kaya dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Rica Jawa untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis makanan yang bisa anda coba salah satunya ayam rica jawa yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam rica jawa tanpa harus bersusah payah.
Seperti resep Ayam Rica Jawa yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Jawa:

1. Harap siapkan 1 kg ayam, potong sesuai selera
1. Diperlukan 2 lembar daun salam
1. Siapkan 2 lembar daun jeruk
1. Dibutuhkan 1 batang serai
1. Tambah  Bumbu Halus :
1. Harus ada 7 siung bawang putih
1. Harus ada 2 butir bawang merah
1. Harus ada 12 cabe rawit
1. Siapkan 3 cabe merah besar
1. Jangan lupa 1/2 cm kunyit
1. Diperlukan 5 butir kemiri, sangrai
1. Dibutuhkan 1/2 sdt ketumbar bubuk
1. Harap siapkan 1/2 sdt merica
1. Harap siapkan 2 sdm kecap bangau
1. Tambah Secukupnya garam dan gula
1. Diperlukan Secukupnya air




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Jawa:

1. Tumis bumbu halus, daun salam, daun jeruk dgn sdkt minyak sampai harum.
1. Masukkan ayam, kecap dan air. Aduk rata. Tambahkan garam dan gula.
1. Masak ayam sampai bumbunya meresap, jika airnya kurang bisa di tambahkan (sesuaikan dengan kekentalan kuah yg diinginkan, saya lbh suka agak kering). Koreksi rasa.
1. Sajikan




Demikianlah cara membuat ayam rica jawa yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan terbukti, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
