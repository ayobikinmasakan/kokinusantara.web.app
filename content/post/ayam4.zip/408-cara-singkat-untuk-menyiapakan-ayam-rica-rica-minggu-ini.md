---
description: "Cara singkat untuk menyiapakan Ayam Rica-Rica minggu ini"
title: "Cara singkat untuk menyiapakan Ayam Rica-Rica minggu ini"
slug: 408-cara-singkat-untuk-menyiapakan-ayam-rica-rica-minggu-ini
date: 2020-10-14T18:39:59.450Z
image: https://img-global.cpcdn.com/recipes/b4862b7ee93b4f8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b4862b7ee93b4f8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b4862b7ee93b4f8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Myrtle Soto
ratingvalue: 4.5
reviewcount: 49602
recipeingredient:
- "1 ekor ayam dipotong 16cuci bersihlumuri 1sdt seasalt"
- "2 buah jeruk nipisambil airnya"
- "1 ruas jahe cuci bersihmemarkan"
- "1 ikat kemangisiangi cuci bersih"
- "25 lbr daun jeruk"
- "2 lbr daun pandan ikat"
- "2 lbr daun kunyit ikat"
- "5 batang seraimemarkan"
- "1 sdt kaldu ayam non msg"
- "500 ml air"
- " BUMBU"
- "150 gram cabe merah besarbuang bijinyacuci bersih"
- "10 buah cabe rawit merah"
- "35 buah bawang merah"
- "1 ruas kunyit bakar kupas"
- "5 batang serai ambil putihnyapotong"
- "1 sdt seasalt"
recipeinstructions:
- "Cuci bersih ayam, lumuri air jeruk nipis.Masukkan kulkas sementara itu ulek kunyit,seasalt, bawang merah, serai, cabe rawit dan cabe merah."
- "Panaskan minyak tumis bumbu ulek tadi,tambahkan serai,daun kunyit,daun pandan, daun jeruk, jahe.Aduk terus hingga harum lalu masukkan ayam.Aduk terus hingga ayam berubah warna lalu tambahkan kaldu ayam dan air.Masak dengan api sedang sambil sesekali diaduk hingga air tinggal sedikit,masukkan setengah bagian daun kemangi, aduk lalu matikan api.Cicipi rasanya.Tata di piring saji lalu taburi daun kemangi.Sajikan hangat."
- "Happy Cooking."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 228 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT60M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/b4862b7ee93b4f8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga enak. Ciri khas makanan Indonesia ayam rica-rica yang penuh dengan rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kehangatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-Rica untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda praktekkan salah satunya ayam rica-rica yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica:

1. Harap siapkan 1 ekor ayam dipotong 16,cuci bersih,lumuri 1sdt seasalt
1. Siapkan 2 buah jeruk nipis,ambil airnya
1. Diperlukan 1 ruas jahe, cuci bersih,memarkan
1. Jangan lupa 1 ikat kemangi,siangi, cuci bersih
1. Jangan lupa 25 lbr daun jeruk
1. Diperlukan 2 lbr daun pandan, ikat
1. Harus ada 2 lbr daun kunyit, ikat
1. Diperlukan 5 batang serai,memarkan
1. Jangan lupa 1 sdt kaldu ayam non msg
1. Tambah 500 ml air
1. Diperlukan  BUMBU:
1. Harus ada 150 gram cabe merah besar,buang bijinya,cuci bersih
1. Dibutuhkan 10 buah cabe rawit merah
1. Dibutuhkan 35 buah bawang merah
1. Siapkan 1 ruas kunyit, bakar, kupas
1. Harap siapkan 5 batang serai, ambil putihnya,potong&#34;
1. Jangan lupa 1 sdt seasalt




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica:

1. Cuci bersih ayam, lumuri air jeruk nipis.Masukkan kulkas sementara itu ulek kunyit,seasalt, bawang merah, serai, cabe rawit dan cabe merah.
1. Panaskan minyak tumis bumbu ulek tadi,tambahkan serai,daun kunyit,daun pandan, daun jeruk, jahe.Aduk terus hingga harum lalu masukkan ayam.Aduk terus hingga ayam berubah warna lalu tambahkan kaldu ayam dan air.Masak dengan api sedang sambil sesekali diaduk hingga air tinggal sedikit,masukkan setengah bagian daun kemangi, aduk lalu matikan api.Cicipi rasanya.Tata di piring saji lalu taburi daun kemangi.Sajikan hangat.
1. Happy Cooking.




Demikianlah cara membuat ayam rica-rica yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan terbukti, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
