---
description: "Resep : Ayam Rica-rica minggu ini"
title: "Resep : Ayam Rica-rica minggu ini"
slug: 322-resep-ayam-rica-rica-minggu-ini
date: 2021-01-31T04:00:25.403Z
image: https://img-global.cpcdn.com/recipes/779190e2a85e07a9/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/779190e2a85e07a9/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/779190e2a85e07a9/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Lida Garza
ratingvalue: 4.4
reviewcount: 13928
recipeingredient:
- "6 potong ayam bersihkan"
- "2 lembar daun salam"
- "4 lembar daun jeruk"
- "2 cm lengkuas geprek"
- "2 batang serai geprek"
- "Secukupnya garam kaldu bubuk lada bubuk gula pasir"
- "Secukupnya minyak goreng untuk tumis"
- " Air bersih"
- " Bumbu Halus"
- "3 siung bawang putih"
- "6 siung bawang merah"
- "10 buah cabe keriting merah"
- "3 buah cabe rawit merah"
- "2 cm kunyit"
- "2 cm jahe"
- "3 butir kemiri"
recipeinstructions:
- "Tumis bumbu halus hingga harum.."
- "Tambahkan serai, daun salam, daun jeruk, lengkuas, tumis kembali hingga tanak"
- "Masukkan ayam, aduk hingga merata beberapa saat"
- "Tambahkan air, beri garam, kaldu bubuk, lada bubuk, gula pasir. Masak hingga air menyusut dan bumbu meresap. Koreksi rasa."
- "Sajikan.."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 114 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Rica-rica](https://img-global.cpcdn.com/recipes/779190e2a85e07a9/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau empuk. Karasteristik masakan Indonesia ayam rica-rica yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kedekatan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah memasak Ayam Rica-rica untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang dapat anda buat salah satunya ayam rica-rica yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica:

1. Jangan lupa 6 potong ayam, bersihkan
1. Dibutuhkan 2 lembar daun salam
1. Dibutuhkan 4 lembar daun jeruk
1. Diperlukan 2 cm lengkuas geprek
1. Jangan lupa 2 batang serai geprek
1. Diperlukan Secukupnya garam, kaldu bubuk, lada bubuk, gula pasir
1. Diperlukan Secukupnya minyak goreng untuk tumis
1. Harus ada  Air bersih
1. Siapkan  Bumbu Halus
1. Dibutuhkan 3 siung bawang putih
1. Diperlukan 6 siung bawang merah
1. Diperlukan 10 buah cabe keriting merah
1. Harap siapkan 3 buah cabe rawit merah
1. Harap siapkan 2 cm kunyit
1. Dibutuhkan 2 cm jahe
1. Tambah 3 butir kemiri




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-rica:

1. Tumis bumbu halus hingga harum..
1. Tambahkan serai, daun salam, daun jeruk, lengkuas, tumis kembali hingga tanak
1. Masukkan ayam, aduk hingga merata beberapa saat
1. Tambahkan air, beri garam, kaldu bubuk, lada bubuk, gula pasir. Masak hingga air menyusut dan bumbu meresap. Koreksi rasa.
1. Sajikan..




Demikianlah cara membuat ayam rica-rica yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
