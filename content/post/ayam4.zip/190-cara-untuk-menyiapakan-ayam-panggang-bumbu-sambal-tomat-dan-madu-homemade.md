---
description: "Cara untuk menyiapakan Ayam Panggang bumbu Sambal Tomat dan Madu Homemade"
title: "Cara untuk menyiapakan Ayam Panggang bumbu Sambal Tomat dan Madu Homemade"
slug: 190-cara-untuk-menyiapakan-ayam-panggang-bumbu-sambal-tomat-dan-madu-homemade
date: 2021-01-30T03:29:32.407Z
image: https://img-global.cpcdn.com/recipes/1d5ee7928bcd4335/751x532cq70/ayam-panggang-bumbu-sambal-tomat-dan-madu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1d5ee7928bcd4335/751x532cq70/ayam-panggang-bumbu-sambal-tomat-dan-madu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1d5ee7928bcd4335/751x532cq70/ayam-panggang-bumbu-sambal-tomat-dan-madu-foto-resep-utama.jpg
author: Brent Snyder
ratingvalue: 4.2
reviewcount: 5879
recipeingredient:
- "2 buah Paha atas Ayam ukuran besar"
- " Bumbu Ungkep"
- "5 butir Bawang Putih"
- "1 ruas Kunyit"
- "1 ruas Jahe"
- "1/2 ruas Lengkuas"
- "1 batang Daun bawang"
- "secukupnya Garam dan gula pasir"
- "secukupnya Air"
- " Sambal Tomat untuk marinasi"
- "5 butir Bawang merah"
- "2 butir Bawang putih"
- "4 buah Tomat"
- " Garam dan gula pasir"
- "12-15 buah Cabe merah sesuai selera"
- " Bumbu Marinasi"
- "secukupnya Madu"
- "secukupnya Kecap manis"
- " Sambal Tomat "
- " Daun Jeruk"
- " Daun KareSalam Koja"
recipeinstructions:
- "Cuci bersih bahan untuk bumbu ungkepnya lalu iris-iris"
- "Siapkan air di wajan lalu masukkan ayamnya dan bumbu ungkep tadi. Masak sampai ayam berwarna kuning dan air agak tinggal dikit (tanda bumbu meresap) •• Selagi menunggu ayam di Ungkep, kita buat sambal tomat nya dulu yuk untuk marinasi nanti ➡ rebus tomat, cabe, bawang putih, dan bawang merah. Lalu haluskan dan beri garam dan gula pasir (maap lupa ngefoto)"
- "Tiriskan ayam lalu marinasi dengan sambal tomat, kecap manis, daun jeruk, dan madu. Balik ayam lalu lakukan juga disebaliknya sama seperti tadi. Lalu tusuk-tusuk ayam dengan garpu supaya bumbu masuk kedalam"
- "Setelah selesai marinasi, simpan ayam kedalam kulkas semalaman / minimal 4 jam supaya bumbu meresap kedalam"
- "Keluarkan ayam dari kulkas lalu diamkan sebentar di suhu ruang"
- "Panaskan oven lalu pindahkan ayam ke tempat pemanggangan (me:saya beri taburan daun kare/salam koja biar lebih sedapp). Oven selama 20 menit dengan suhu 180° C"
- "Sisa bumbu marinasi yang ada di wadah tadi dikumpulkan jadi satu lalu diberi air sedikit saja (untuk proses basting/penyiraman sari)"
- "Setelah meng-oven selama 20 menit, keluarkan dari oven lalu siram dengan saus tadi. Oven kembali selama 45-60 menit an (lebih lama waktu manggang lebih enak ya)"
- "Ayam siap dihidangkan, bisa untuk lauk atau di gado gitu aja juga udah enak. Selamat mencoba 🤗"
categories:
- Recipe
tags:
- ayam
- panggang
- bumbu

katakunci: ayam panggang bumbu 
nutrition: 252 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Panggang bumbu Sambal Tomat dan Madu](https://img-global.cpcdn.com/recipes/1d5ee7928bcd4335/751x532cq70/ayam-panggang-bumbu-sambal-tomat-dan-madu-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan renyah. Ciri masakan Nusantara ayam panggang bumbu sambal tomat dan madu yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Panggang bumbu Sambal Tomat dan Madu untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang bisa anda praktekkan salah satunya ayam panggang bumbu sambal tomat dan madu yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam panggang bumbu sambal tomat dan madu tanpa harus bersusah payah.
Berikut ini resep Ayam Panggang bumbu Sambal Tomat dan Madu yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 9 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Panggang bumbu Sambal Tomat dan Madu:

1. Dibutuhkan 2 buah Paha atas Ayam (ukuran besar)
1. Harap siapkan  Bumbu Ungkep
1. Dibutuhkan 5 butir Bawang Putih
1. Harap siapkan 1 ruas Kunyit
1. Tambah 1 ruas Jahe
1. Siapkan 1/2 ruas Lengkuas
1. Jangan lupa 1 batang Daun bawang
1. Diperlukan secukupnya Garam dan gula pasir
1. Siapkan secukupnya Air
1. Dibutuhkan  Sambal Tomat (untuk marinasi)
1. Harap siapkan 5 butir Bawang merah
1. Harap siapkan 2 butir Bawang putih
1. Dibutuhkan 4 buah Tomat
1. Harus ada  Garam dan gula pasir
1. Siapkan 12-15 buah Cabe merah (sesuai selera)
1. Dibutuhkan  Bumbu Marinasi
1. Jangan lupa secukupnya Madu
1. Harap siapkan secukupnya Kecap manis
1. Harus ada  Sambal Tomat ⬆⬆
1. Jangan lupa  Daun Jeruk
1. Jangan lupa  Daun Kare/Salam Koja




<!--inarticleads2-->

##### Instruksi membuat  Ayam Panggang bumbu Sambal Tomat dan Madu:

1. Cuci bersih bahan untuk bumbu ungkepnya lalu iris-iris
1. Siapkan air di wajan lalu masukkan ayamnya dan bumbu ungkep tadi. Masak sampai ayam berwarna kuning dan air agak tinggal dikit (tanda bumbu meresap) •• Selagi menunggu ayam di Ungkep, kita buat sambal tomat nya dulu yuk untuk marinasi nanti ➡ rebus tomat, cabe, bawang putih, dan bawang merah. Lalu haluskan dan beri garam dan gula pasir (maap lupa ngefoto)
1. Tiriskan ayam lalu marinasi dengan sambal tomat, kecap manis, daun jeruk, dan madu. Balik ayam lalu lakukan juga disebaliknya sama seperti tadi. Lalu tusuk-tusuk ayam dengan garpu supaya bumbu masuk kedalam
1. Setelah selesai marinasi, simpan ayam kedalam kulkas semalaman / minimal 4 jam supaya bumbu meresap kedalam
1. Keluarkan ayam dari kulkas lalu diamkan sebentar di suhu ruang
1. Panaskan oven lalu pindahkan ayam ke tempat pemanggangan (me:saya beri taburan daun kare/salam koja biar lebih sedapp). Oven selama 20 menit dengan suhu 180° C
1. Sisa bumbu marinasi yang ada di wadah tadi dikumpulkan jadi satu lalu diberi air sedikit saja (untuk proses basting/penyiraman sari)
1. Setelah meng-oven selama 20 menit, keluarkan dari oven lalu siram dengan saus tadi. Oven kembali selama 45-60 menit an (lebih lama waktu manggang lebih enak ya)
1. Ayam siap dihidangkan, bisa untuk lauk atau di gado gitu aja juga udah enak. Selamat mencoba 🤗




Demikianlah cara membuat ayam panggang bumbu sambal tomat dan madu yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
