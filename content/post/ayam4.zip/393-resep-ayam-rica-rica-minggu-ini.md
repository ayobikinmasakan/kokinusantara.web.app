---
description: "Resep : Ayam Rica - Rica minggu ini"
title: "Resep : Ayam Rica - Rica minggu ini"
slug: 393-resep-ayam-rica-rica-minggu-ini
date: 2021-01-20T18:02:49.338Z
image: https://img-global.cpcdn.com/recipes/8f597045cc07630d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8f597045cc07630d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8f597045cc07630d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Cameron Nelson
ratingvalue: 4
reviewcount: 33450
recipeingredient:
- "1 ekor ayam kebetulan dapet tinggal bagian paha semua"
- "1/2 bawang bombay"
- "9 cabe merah keriting"
- "5 buah cabe rawit"
- "4 bawang putih"
- "9 bawang merah"
- "1/2 sendok teh Garam"
- "1/2 sendok teh kaldu jamur"
- "1/2 sendok teh Gula"
- "1 sendok makan Saus tiram"
- "2 sendok makan kecap manis"
- "1/2 ruas jahe"
- "1/2 ruas lengkuas"
- "5 lembar daun jeruk"
- "3 buah sereh iris"
recipeinstructions:
- "Cuci bersih ayam yang sudah dipotong, karena campaign dari cookpad #masaksetiapbagian ceker ayamnya tidak aku tinggal ditukang ayam. Ikut kita rebus untuk kaldu."
- "Sambil merebus ayam sebentar, blender bumbu cabe merah, 2 cabe rawit, bawang merah, bawah putih. Blender kasar ya moms. Oia moms ayamnya bisa moms goreng terlebih dahulu, atau tidak digoreng juga tidak apa-apa. Diresep ini aku goreng ayamnya setengah matang."
- "Setelah semua siap, tumis bumbu yang sudah diblender sampai harum kasih sedikit air, kemudian masukan daun jeruk, salam, lengkuas, jahe dan sereh yg diris tumis sampai harum. Kemudian masukan ayam yang sudah digoreng setengah matang."
- "Tambahakan air sedikit aja ya moms, kemudian masukan garam, gula, kaldu jamur, saus tiram dan kecap manis. Aduk sampai merata sambil diicipi. Kemudian iris 2 buah cabe rawit. Taburi diatasnya. Ayam rica-rica siap disantap dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 131 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica - Rica](https://img-global.cpcdn.com/recipes/8f597045cc07630d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan empuk. Ciri khas kuliner Nusantara ayam rica - rica yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan keluarga dapat didapat dengan cara simple. Diantaranya adalah memasak Ayam Rica - Rica untuk keluarga. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang dapat anda coba salah satunya ayam rica - rica yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam rica - rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica - Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica - Rica:

1. Siapkan 1 ekor ayam, kebetulan dapet tinggal bagian paha semua
1. Diperlukan 1/2 bawang bombay
1. Siapkan 9 cabe merah keriting
1. Jangan lupa 5 buah cabe rawit
1. Harus ada 4 bawang putih
1. Jangan lupa 9 bawang merah
1. Tambah 1/2 sendok teh Garam
1. Jangan lupa 1/2 sendok teh kaldu jamur
1. Diperlukan 1/2 sendok teh Gula
1. Tambah 1 sendok makan Saus tiram
1. Harap siapkan 2 sendok makan kecap manis
1. Harus ada 1/2 ruas jahe
1. Diperlukan 1/2 ruas lengkuas
1. Diperlukan 5 lembar daun jeruk
1. Diperlukan 3 buah sereh iris




<!--inarticleads2-->

##### Cara membuat  Ayam Rica - Rica:

1. Cuci bersih ayam yang sudah dipotong, karena campaign dari cookpad #masaksetiapbagian ceker ayamnya tidak aku tinggal ditukang ayam. Ikut kita rebus untuk kaldu.
1. Sambil merebus ayam sebentar, blender bumbu cabe merah, 2 cabe rawit, bawang merah, bawah putih. Blender kasar ya moms. Oia moms ayamnya bisa moms goreng terlebih dahulu, atau tidak digoreng juga tidak apa-apa. Diresep ini aku goreng ayamnya setengah matang.
1. Setelah semua siap, tumis bumbu yang sudah diblender sampai harum kasih sedikit air, kemudian masukan daun jeruk, salam, lengkuas, jahe dan sereh yg diris tumis sampai harum. Kemudian masukan ayam yang sudah digoreng setengah matang.
1. Tambahakan air sedikit aja ya moms, kemudian masukan garam, gula, kaldu jamur, saus tiram dan kecap manis. Aduk sampai merata sambil diicipi. Kemudian iris 2 buah cabe rawit. Taburi diatasnya. Ayam rica-rica siap disantap dengan nasi hangat




Demikianlah cara membuat ayam rica - rica yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan teruji, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
