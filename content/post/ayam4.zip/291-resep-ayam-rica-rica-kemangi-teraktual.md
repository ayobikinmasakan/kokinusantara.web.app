---
description: "Resep : Ayam Rica Rica Kemangi teraktual"
title: "Resep : Ayam Rica Rica Kemangi teraktual"
slug: 291-resep-ayam-rica-rica-kemangi-teraktual
date: 2020-10-19T00:14:08.031Z
image: https://img-global.cpcdn.com/recipes/c964aaaf094c7173/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c964aaaf094c7173/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c964aaaf094c7173/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Robert Howard
ratingvalue: 5
reviewcount: 39636
recipeingredient:
- "5 potong Ayam"
- "10 buah cabe merah"
- " Kemiri"
- "5 bawang merah"
- "3 bawang putih"
- "Seruas kunyit jahe lengkuas"
- " Sereh daun jeruk daun salam"
- " Kacang panjang opsional"
- " Kemangi"
- " Garam gula dan kaldu jamur"
recipeinstructions:
- "Haluskan bawang merah, bawang putih, cabe merah, kemiri dan kunyit. Tumis bumbunya lalu masukkan sereh, jahe, lengkuas, daun jeruk dan daun salam"
- "Setelah harum masukkan ayam aduk2 dan masukkan air (sesuaikan aja) tunggu mendidih masukkan garam, gula, kaldu jamur"
- "Masukkan kacang panjang, aduk2 koreksi rasa.. sekiranya sudah mau masak tambahkan kemangi aduk2 sebentar dan sajikan!"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 195 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT41M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/c964aaaf094c7173/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan renyah. Ciri khas masakan Indonesia ayam rica rica kemangi yang penuh dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica Rica Kemangi untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda coba salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 10 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Dibutuhkan 5 potong Ayam
1. Harap siapkan 10 buah cabe merah
1. Tambah  Kemiri
1. Tambah 5 bawang merah
1. Jangan lupa 3 bawang putih
1. Diperlukan Seruas kunyit, jahe, lengkuas
1. Dibutuhkan  Sereh, daun jeruk, daun salam
1. Harus ada  Kacang panjang (opsional)
1. Jangan lupa  Kemangi
1. Harus ada  Garam, gula, dan kaldu jamur




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica Kemangi:

1. Haluskan bawang merah, bawang putih, cabe merah, kemiri dan kunyit. Tumis bumbunya lalu masukkan sereh, jahe, lengkuas, daun jeruk dan daun salam
1. Setelah harum masukkan ayam aduk2 dan masukkan air (sesuaikan aja) tunggu mendidih masukkan garam, gula, kaldu jamur
1. Masukkan kacang panjang, aduk2 koreksi rasa.. sekiranya sudah mau masak tambahkan kemangi aduk2 sebentar dan sajikan!




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
