---
description: "Cara membuat Ayam Rica - Rica minggu ini"
title: "Cara membuat Ayam Rica - Rica minggu ini"
slug: 288-cara-membuat-ayam-rica-rica-minggu-ini
date: 2020-10-03T04:14:45.134Z
image: https://img-global.cpcdn.com/recipes/64765387baaaefbb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/64765387baaaefbb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/64765387baaaefbb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Bryan Jenkins
ratingvalue: 4.1
reviewcount: 4927
recipeingredient:
- "1 kg ayam"
- "6 batang sereh digeprek"
- "2 cm lengkuas geprek"
- "2 cm jahe geprek"
- "6 lembar daun jeruk"
- "6 lembar daun salam"
- "3 buah tomat optional"
- "1 bungkus masako"
- "secukupnya Garam"
- " Bumbu halus "
- "2 cm kunyit"
- "12 siung bawang merah"
- "6 bawang putih"
- " Cabe merah 20 biji atau sesuai selera"
- "6 butir kemiri"
- "1 bungkus ladaku blh dikurangi"
- " Ketumbar secukupnya blh pake yg halus"
- "secukupnya Daun kemangi"
- "1 buah jeruk nipis utk ayam"
- "secukupnya Gula pasir"
recipeinstructions:
- "Bersihkan dan potong ayam, kalau saya sukanya agak kecil2 supanya bumbu lebih meresap. Cuci bersih kasih garam dan jeruk nipis. Diamkan sktr 10 mnt. Lalu goreng sbntr"
- "Tumis bumbu halus sampai wangi kemudian masukkan bumbu geprek"
- "Masukkan ayam lalu beri air secukupnya. Kalau mau agak basah ksh agak byk."
- "Diamkan dgn api kecil sktr 20 mnt atau smp air menyusut, terakhir masukkan kemangi yg sdh dicuci bersih."
- "Siap disajikan"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 177 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica - Rica](https://img-global.cpcdn.com/recipes/64765387baaaefbb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan empuk. Ciri khas makanan Indonesia ayam rica - rica yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Ayam Rica - Rica untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang dapat anda buat salah satunya ayam rica - rica yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica - rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica - Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica - Rica:

1. Dibutuhkan 1 kg ayam
1. Siapkan 6 batang sereh digeprek
1. Diperlukan 2 cm lengkuas geprek
1. Tambah 2 cm jahe geprek
1. Jangan lupa 6 lembar daun jeruk
1. Tambah 6 lembar daun salam
1. Harus ada 3 buah tomat (optional)
1. Diperlukan 1 bungkus masako
1. Diperlukan secukupnya Garam
1. Diperlukan  Bumbu halus :
1. Jangan lupa 2 cm kunyit
1. Harus ada 12 siung bawang merah
1. Dibutuhkan 6 bawang putih
1. Siapkan  Cabe merah 20 biji atau sesuai selera
1. Harus ada 6 butir kemiri
1. Harus ada 1 bungkus ladaku blh dikurangi
1. Siapkan  Ketumbar secukupnya, blh pake yg halus
1. Jangan lupa secukupnya Daun kemangi
1. Harap siapkan 1 buah jeruk nipis utk ayam
1. Tambah secukupnya Gula pasir




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica - Rica:

1. Bersihkan dan potong ayam, kalau saya sukanya agak kecil2 supanya bumbu lebih meresap. Cuci bersih kasih garam dan jeruk nipis. Diamkan sktr 10 mnt. Lalu goreng sbntr
1. Tumis bumbu halus sampai wangi kemudian masukkan bumbu geprek
1. Masukkan ayam lalu beri air secukupnya. Kalau mau agak basah ksh agak byk.
1. Diamkan dgn api kecil sktr 20 mnt atau smp air menyusut, terakhir masukkan kemangi yg sdh dicuci bersih.
1. Siap disajikan




Demikianlah cara membuat ayam rica - rica yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
