---
description: "Cara singkat membuat Ayam saus Nanas Madu teraktual"
title: "Cara singkat membuat Ayam saus Nanas Madu teraktual"
slug: 115-cara-singkat-membuat-ayam-saus-nanas-madu-teraktual
date: 2020-10-10T16:14:03.886Z
image: https://img-global.cpcdn.com/recipes/8b2bca905ce1c80e/751x532cq70/ayam-saus-nanas-madu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8b2bca905ce1c80e/751x532cq70/ayam-saus-nanas-madu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8b2bca905ce1c80e/751x532cq70/ayam-saus-nanas-madu-foto-resep-utama.jpg
author: Kenneth Black
ratingvalue: 4.4
reviewcount: 11048
recipeingredient:
- "500 gram Fillet Dada Ayam"
- "1 buah nanas"
- "1 buah bawang bombay"
- "5 buah cabe merah besar"
- "5 buah cabe hijau"
- "4 siung bawang putih"
- "250 gram tepung bumbu untu ayam"
- "150 ml air"
- "1 sdm tepung maizena dilarutkan dengan 50ml air"
- "1 butit telur"
- "1 sdm merica bubuk"
- "1 sdm garam"
- " Bahan Saus"
- "3 sdm kecap asin"
- "3 sdm kecap manis"
- "2 sdm kecap inggris"
- "2 sdm saus tiram"
- "2 sdm madu"
- "1 sdm garam"
recipeinstructions:
- "Potong dada ayam ukuran dadu, tambahkan garam, merica, telur, aduk-aduk merata"
- "Siapkan tepung bumbu untuk ayam di dalam kotak makan, masukan ayam yg sudah dilumuri telur tadi sedikit demi sedikit, lalu kocok didalam tempat makan berisi tepung bumbu."
- "Panaskan minyak, lalu goreng ayam hingga kecoklatan"
- "Tumis bawang bombay, nanas, cabe merah, cabe hijau dan bawang putih yg sudah dipotong-potong hingga layu dan wangi"
- "Masukan campuran bahan saus, masak merata"
- "Tambahkan air, aduk-aduk"
- "Masukan campuran air dan maizena, masak hingga mengental"
- "Ayam saus nanas siap disajikan, kalo Kemommy suka dipisah supaya setiap mau makan tetep crispy gitu hehe, kalo mau dicampur jg boleh"
categories:
- Recipe
tags:
- ayam
- saus
- nanas

katakunci: ayam saus nanas 
nutrition: 165 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam saus Nanas Madu](https://img-global.cpcdn.com/recipes/8b2bca905ce1c80e/751x532cq70/ayam-saus-nanas-madu-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam saus nanas madu yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Kita



Kehangatan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam saus Nanas Madu untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda praktekkan salah satunya ayam saus nanas madu yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam saus nanas madu tanpa harus bersusah payah.
Berikut ini resep Ayam saus Nanas Madu yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam saus Nanas Madu:

1. Harus ada 500 gram Fillet Dada Ayam
1. Harus ada 1 buah nanas
1. Siapkan 1 buah bawang bombay
1. Jangan lupa 5 buah cabe merah besar
1. Harap siapkan 5 buah cabe hijau
1. Jangan lupa 4 siung bawang putih
1. Diperlukan 250 gram tepung bumbu untu ayam
1. Tambah 150 ml air
1. Harap siapkan 1 sdm tepung maizena dilarutkan dengan 50ml air
1. Harus ada 1 butit telur
1. Tambah 1 sdm merica bubuk
1. Harap siapkan 1 sdm garam
1. Jangan lupa  Bahan Saus
1. Diperlukan 3 sdm kecap asin
1. Jangan lupa 3 sdm kecap manis
1. Jangan lupa 2 sdm kecap inggris
1. Harus ada 2 sdm saus tiram
1. Siapkan 2 sdm madu
1. Harap siapkan 1 sdm garam




<!--inarticleads2-->

##### Bagaimana membuat  Ayam saus Nanas Madu:

1. Potong dada ayam ukuran dadu, tambahkan garam, merica, telur, aduk-aduk merata
1. Siapkan tepung bumbu untuk ayam di dalam kotak makan, masukan ayam yg sudah dilumuri telur tadi sedikit demi sedikit, lalu kocok didalam tempat makan berisi tepung bumbu.
1. Panaskan minyak, lalu goreng ayam hingga kecoklatan
1. Tumis bawang bombay, nanas, cabe merah, cabe hijau dan bawang putih yg sudah dipotong-potong hingga layu dan wangi
1. Masukan campuran bahan saus, masak merata
1. Tambahkan air, aduk-aduk
1. Masukan campuran air dan maizena, masak hingga mengental
1. Ayam saus nanas siap disajikan, kalo Kemommy suka dipisah supaya setiap mau makan tetep crispy gitu hehe, kalo mau dicampur jg boleh




Demikianlah cara membuat ayam saus nanas madu yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan teruji, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
