---
description: "Resep : Nasi Kebuli Ayam madu teraktual"
title: "Resep : Nasi Kebuli Ayam madu teraktual"
slug: 47-resep-nasi-kebuli-ayam-madu-teraktual
date: 2020-12-23T02:36:44.127Z
image: https://img-global.cpcdn.com/recipes/25f3178df53220c9/751x532cq70/nasi-kebuli-ayam-madu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/25f3178df53220c9/751x532cq70/nasi-kebuli-ayam-madu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/25f3178df53220c9/751x532cq70/nasi-kebuli-ayam-madu-foto-resep-utama.jpg
author: Mittie Haynes
ratingvalue: 4.1
reviewcount: 15848
recipeingredient:
- "500 gram Ayam"
- "500 gram Basmati"
- "5 Cengkeh"
- "6 Kapulaga"
- "5 btng kayu manis"
- "3 sendok Bumbu kebuli instan"
- " Bawang putih 8 siung cincang halus"
- " Bawang Bombay 1 buahcincang halus"
- "5 lbr Daun jeruk"
- "2 lbr Daun salam"
- " Tomat 1 buah iris jadi 4 bagian biarkan utuh"
- "7 buah Kismis"
- " Jeruk nipis"
- "6 sendok mkn Minyak goreng"
- "800 ml Air"
- " Bahan Acar"
- "2 buah Timun"
- "2 buah Wortel"
- " Bawang merah 4potong 4bagian"
- "2 Bawang putih"
- "2 Kemiri"
- "2 sdk mkn Cukak"
- " Lada bubuk sckpnya"
- "secukupnya Garam"
- " Bahan Ayam bkar"
- "2 sendok mkn Madu"
- "1 sendok mkn Kecap"
- " Bahan hiasan"
- " Timun 1 kupas hias"
- " Selada bulat potong tipis"
recipeinstructions:
- "Ayam cuci bersih dan potong kecil. Rendam dg air jeruk nipis. Ayam di masak di air mendidih pertama kali buang air rebusan. Tiriskan"
- "Rendam nasi basmati dg air. Kurang lebih 20 menit dan setelah 20 menit bilas sampai bersih."
- "Bawang putih, bawang bombai tumis sedit minyak sampai warna kecoklatan. Tambahkan sdik air.bumbu kari lada hitam, kapulaga, cengkeh daun jeruk,daun salam tomat,kayu manis aduk sampai rata beri air 800ml didihkan. Dan Masukkan Ayam tunggu sampai empuk 25 menit di tutup rapat. Sekiranya uda empuk di angkat."
- "Masukan beras basmati sisa air Ayam tadi. Dan masak api kecil dan tertutup sekiranya air uda habis aduk rata. Dan diamkan selama 30 menit nasi nasi pun matang."
- "Masak bahan acar."
- "Dan bakar Ayam dg madu kecap. Di teflon."
- "Siap di hidangkan.dan di hias suka - suka."
categories:
- Recipe
tags:
- nasi
- kebuli
- ayam

katakunci: nasi kebuli ayam 
nutrition: 176 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Lunch

---


![Nasi Kebuli Ayam madu](https://img-global.cpcdn.com/recipes/25f3178df53220c9/751x532cq70/nasi-kebuli-ayam-madu-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga gurih. Ciri makanan Nusantara nasi kebuli ayam madu yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat didapat dengan cara simple. Diantaranya adalah membuat makanan Nasi Kebuli Ayam madu untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang dapat anda coba salah satunya nasi kebuli ayam madu yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep nasi kebuli ayam madu tanpa harus bersusah payah.
Berikut ini resep Nasi Kebuli Ayam madu yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 30 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nasi Kebuli Ayam madu:

1. Siapkan 500 gram Ayam
1. Harus ada 500 gram Basmati
1. Siapkan 5 Cengkeh
1. Jangan lupa 6 Kapulaga
1. Dibutuhkan 5 btng kayu manis
1. Tambah 3 sendok Bumbu kebuli instan
1. Dibutuhkan  Bawang putih 8 siung (cincang halus)
1. Diperlukan  Bawang Bombay 1 buah(cincang halus)
1. Jangan lupa 5 lbr Daun jeruk
1. Dibutuhkan 2 lbr Daun salam
1. Tambah  Tomat 1 buah (iris jadi 4 bagian biarkan utuh
1. Tambah 7 buah Kismis
1. Harus ada  Jeruk nipis
1. Harus ada 6 sendok mkn Minyak goreng
1. Tambah 800 ml Air
1. Harus ada  Bahan Acar:
1. Siapkan 2 buah Timun
1. Tambah 2 buah Wortel
1. Tambah  Bawang merah 4(potong 4bagian)
1. Diperlukan 2 Bawang putih
1. Diperlukan 2 Kemiri
1. Harus ada 2 sdk mkn Cukak
1. Harus ada  Lada bubuk (sckpnya)
1. Harus ada secukupnya Garam
1. Dibutuhkan  Bahan Ayam bkar:
1. Jangan lupa 2 sendok mkn Madu
1. Harap siapkan 1 sendok mkn Kecap
1. Dibutuhkan  Bahan hiasan:
1. Diperlukan  Timun 1 kupas (hias)
1. Tambah  Selada bulat (potong tipis)




<!--inarticleads2-->

##### Bagaimana membuat  Nasi Kebuli Ayam madu:

1. Ayam cuci bersih dan potong kecil. Rendam dg air jeruk nipis. Ayam di masak di air mendidih pertama kali buang air rebusan. Tiriskan
1. Rendam nasi basmati dg air. Kurang lebih 20 menit dan setelah 20 menit bilas sampai bersih.
1. Bawang putih, bawang bombai tumis sedit minyak sampai warna kecoklatan. Tambahkan sdik air.bumbu kari lada hitam, kapulaga, cengkeh daun jeruk,daun salam tomat,kayu manis aduk sampai rata beri air 800ml didihkan. Dan Masukkan Ayam tunggu sampai empuk 25 menit di tutup rapat. Sekiranya uda empuk di angkat.
1. Masukan beras basmati sisa air Ayam tadi. Dan masak api kecil dan tertutup sekiranya air uda habis aduk rata. Dan diamkan selama 30 menit nasi nasi pun matang.
1. Masak bahan acar.
1. Dan bakar Ayam dg madu kecap. Di teflon.
1. Siap di hidangkan.dan di hias suka - suka.




Demikianlah cara membuat nasi kebuli ayam madu yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
