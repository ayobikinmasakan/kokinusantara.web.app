---
description: "Step-by-Step untuk menyiapakan Ayam Rica - rica (ala Mamer) Cepat"
title: "Step-by-Step untuk menyiapakan Ayam Rica - rica (ala Mamer) Cepat"
slug: 314-step-by-step-untuk-menyiapakan-ayam-rica-rica-ala-mamer-cepat
date: 2020-12-22T16:30:14.486Z
image: https://img-global.cpcdn.com/recipes/ad139867207f7863/751x532cq70/ayam-rica-rica-ala-mamer-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ad139867207f7863/751x532cq70/ayam-rica-rica-ala-mamer-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ad139867207f7863/751x532cq70/ayam-rica-rica-ala-mamer-foto-resep-utama.jpg
author: Hunter Russell
ratingvalue: 4.2
reviewcount: 8535
recipeingredient:
- "  Bahan "
- "500 gr ayam"
- "Secukupnya air jeruk nipis"
- "500 ml air secukupnya"
- "Secukupnya minyak gr utk menumis"
- "  Bumbu Cemplung "
- "3 lbr daun jeruk buang tulang daun"
- "1 lbr daun kunyit optional ikat"
- "2 lbr daun salam"
- "1 bh Sere digeprek ikat"
- "1 genggam daun kemangi"
- "  Bumbu seasoning "
- "2 sdt Secukupnya garam"
- "1 sdt Secukupnya kaldu bubuk jamurayam"
- "1/2 sdt merica putih bubuk"
- "1/2 sdt gula optional"
- "  Bumbu Halus "
- "6 bh bawang merah"
- "4 siung bawang putih"
- "5 bh kemiri disangrai"
- "10 bh cabe rawit merah sesuai selera sebagian biarkan utuh"
- "3 bh cabai merah keriting"
- "2 ruas jari kunyit"
- "2 ruas jari jahe"
- "2 ruas jari lengkuas"
recipeinstructions:
- "Cuci ayam, potong2 sesuai selera (sy potong2 kecil), lumuri dgn air jeruk nipis, remas2, diamkan sekitar 15 mnt. Kmdn cuci bersih kembali dan tiriskan."
- "Panaskan wajan, beri minyak gr secukupnya. Tumis bumbu halus hingga harum, tambahkan bumbu cemplung (daun jeruk, daun kunyit, daun salam, serai), kecuali kemangi. Masak kembali hingga matang."
- "Tambahkan ayam, aduk rata. Stlh ayam berubah warna, tuang air, bumbui garam, merica, kaldu bubuk, gula. Aduk rata &amp; masak sekitar 30 mnt dgn api kecil - sedang."
- "Setelah air menyusut dan ayam matang, masukkan daun kemangi, aduk rata, koreksi rasa. Matikan kompor."
- "Tata di piring dan siap disajikan 😉"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 171 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica - rica (ala Mamer)](https://img-global.cpcdn.com/recipes/ad139867207f7863/751x532cq70/ayam-rica-rica-ala-mamer-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau renyah. Karasteristik kuliner Nusantara ayam rica - rica (ala mamer) yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Keharmonisan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica - rica (ala Mamer) untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda coba salah satunya ayam rica - rica (ala mamer) yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep ayam rica - rica (ala mamer) tanpa harus bersusah payah.
Seperti resep Ayam Rica - rica (ala Mamer) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 25 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica - rica (ala Mamer):

1. Tambah  🌠 Bahan :
1. Siapkan 500 gr ayam
1. Tambah Secukupnya air jeruk nipis
1. Harap siapkan 500 ml air (secukupnya)
1. Tambah Secukupnya minyak gr utk menumis
1. Tambah  🌠 Bumbu Cemplung :
1. Siapkan 3 lbr daun jeruk, buang tulang daun
1. Jangan lupa 1 lbr daun kunyit (optional), ikat
1. Jangan lupa 2 lbr daun salam
1. Tambah 1 bh Sere, digeprek, ikat
1. Harus ada 1 genggam daun kemangi
1. Tambah  🌠 Bumbu (seasoning) :
1. Harap siapkan 2 sdt (Secukupnya) garam
1. Tambah 1 sdt (Secukupnya) kaldu bubuk (jamur/ayam)
1. Jangan lupa 1/2 sdt merica putih bubuk
1. Siapkan 1/2 sdt gula (optional)
1. Tambah  🌠 Bumbu Halus :
1. Diperlukan 6 bh bawang merah
1. Harap siapkan 4 siung bawang putih
1. Harap siapkan 5 bh kemiri, disangrai
1. Harap siapkan 10 bh cabe rawit merah (sesuai selera), sebagian biarkan utuh
1. Tambah 3 bh cabai merah keriting
1. Harus ada 2 ruas jari kunyit
1. Dibutuhkan 2 ruas jari jahe
1. Harus ada 2 ruas jari lengkuas




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica - rica (ala Mamer):

1. Cuci ayam, potong2 sesuai selera (sy potong2 kecil), lumuri dgn air jeruk nipis, remas2, diamkan sekitar 15 mnt. Kmdn cuci bersih kembali dan tiriskan.
1. Panaskan wajan, beri minyak gr secukupnya. Tumis bumbu halus hingga harum, tambahkan bumbu cemplung (daun jeruk, daun kunyit, daun salam, serai), kecuali kemangi. Masak kembali hingga matang.
1. Tambahkan ayam, aduk rata. Stlh ayam berubah warna, tuang air, bumbui garam, merica, kaldu bubuk, gula. Aduk rata &amp; masak sekitar 30 mnt dgn api kecil - sedang.
1. Setelah air menyusut dan ayam matang, masukkan daun kemangi, aduk rata, koreksi rasa. Matikan kompor.
1. Tata di piring dan siap disajikan 😉




Demikianlah cara membuat ayam rica - rica (ala mamer) yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan cepat, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
