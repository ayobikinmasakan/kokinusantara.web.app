---
description: "Bagaimana menyiapakan Ayam Rica Rica Favorite"
title: "Bagaimana menyiapakan Ayam Rica Rica Favorite"
slug: 292-bagaimana-menyiapakan-ayam-rica-rica-favorite
date: 2020-08-12T13:10:35.767Z
image: https://img-global.cpcdn.com/recipes/05d9e52562f3fde7/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/05d9e52562f3fde7/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/05d9e52562f3fde7/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Sarah Stone
ratingvalue: 4.8
reviewcount: 6654
recipeingredient:
- "1/2 kg ayam"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1 batang serai"
- "1 ruas lengkuas"
- "Secukupnya gula"
- "Secukupnya garam"
- "Secukupnya kaldu bubuk"
- "2 gelas air"
- "Sedikit jeruk nipis"
- " Bumbu Halus "
- "1/2 sdt kunyit bubuk"
- "5 buah cabe merah"
- "15 buah cabe rawit"
- "2 butir kemiri"
- "4 siung bawang putih"
- "8 siung bawang merah"
recipeinstructions:
- "Potong dan cuci bersih ayam. Beri perasan jeruk nipis dan garam. Lalu goreng sebentar. Haluskan bumbu dan geprek serai serta lengkuas."
- "Tumis bumbu halus masukkan serai,lengkuas,daun salam dan daun jeruk."
- "Masukkan air,kaldu bubuk,gula dan garam. Kemudian masukkan ayam goreng."
- "Biarkan masak sampai kuah menyusut. Ayam rica rica siap disajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 193 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT52M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/05d9e52562f3fde7/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica rica yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara



Keharmonisan rumah tangga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Rica Rica untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda buat salah satunya ayam rica rica yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica:

1. Jangan lupa 1/2 kg ayam
1. Harus ada 2 lembar daun jeruk
1. Harap siapkan 2 lembar daun salam
1. Tambah 1 batang serai
1. Harus ada 1 ruas lengkuas
1. Siapkan Secukupnya gula
1. Harap siapkan Secukupnya garam
1. Diperlukan Secukupnya kaldu bubuk
1. Jangan lupa 2 gelas air
1. Harap siapkan Sedikit jeruk nipis
1. Jangan lupa  Bumbu Halus :
1. Siapkan 1/2 sdt kunyit bubuk
1. Jangan lupa 5 buah cabe merah
1. Diperlukan 15 buah cabe rawit
1. Harap siapkan 2 butir kemiri
1. Siapkan 4 siung bawang putih
1. Dibutuhkan 8 siung bawang merah




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica:

1. Potong dan cuci bersih ayam. Beri perasan jeruk nipis dan garam. Lalu goreng sebentar. Haluskan bumbu dan geprek serai serta lengkuas.
1. Tumis bumbu halus masukkan serai,lengkuas,daun salam dan daun jeruk.
1. Masukkan air,kaldu bubuk,gula dan garam. Kemudian masukkan ayam goreng.
1. Biarkan masak sampai kuah menyusut. Ayam rica rica siap disajikan.




Demikianlah cara membuat ayam rica rica yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan terbukti, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
