---
description: "Panduan membuat Ayam rica kemangi Teruji"
title: "Panduan membuat Ayam rica kemangi Teruji"
slug: 430-panduan-membuat-ayam-rica-kemangi-teruji
date: 2020-11-06T07:18:02.499Z
image: https://img-global.cpcdn.com/recipes/cc6612372baee1ae/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cc6612372baee1ae/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cc6612372baee1ae/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Lulu Clayton
ratingvalue: 4
reviewcount: 32368
recipeingredient:
- "8 bh potongan ayam"
- "1/2 bt jeruk nipis"
- "1/2 sdt garam"
- " Bumbu uleg"
- "6 bh bawang merah"
- "3 bh bawang putih"
- "2 bh kemiri bakar sebentar"
- "5 bh cabe merah besar"
- "2 bh cabe rawit merah"
- "3 cm kunyit"
- " Bumbu tambahan"
- "2 bh daun salam"
- "2 cm jahe"
- "3 bh daun jeruk"
- "1 bh serai"
- "4 cm lengkuas"
- "1/2 sdt garam"
- "1/2 sdt merica"
- "1/2 sdt gula jawa"
- "1/4 sdt gula pasir"
- "1 bh daun bawang iris tipis"
- "1 genggam daun kemangi"
recipeinstructions:
- "Campur ayam dengan air jeruk nipis, cuci sebentar dan tiriskan. Tambahkan garam dan ratakan. Goreng setengah matang. Sisihkan."
- "Tumis bumbu uleg hingga wangi, tambahkan 1gelas air, masukkan jahe, serai, lengkuas, salam, daun jeruk, garam, merica, gula jawa, gula pasir hingga larut. Tambahkan ayam yang disisihkan. Tunggu agak mengental, koreksi rasa. Tambahkan sedikit air lagi, hingga semua bumbu meresap ke dalam ayam."
- "Masukkan daun bawang dan kemangi. Sebentar saja. Begitu layu, angkat dan siap dihidangkan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 213 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/cc6612372baee1ae/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang harus kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan kesan tersendiri yang merupakan keragaman Indonesia

Kedekatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam rica kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang bisa anda buat salah satunya ayam rica kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Harap siapkan 8 bh potongan ayam
1. Siapkan 1/2 bt jeruk nipis
1. Diperlukan 1/2 sdt garam
1. Harus ada  Bumbu uleg
1. Harap siapkan 6 bh bawang merah
1. Harap siapkan 3 bh bawang putih
1. Diperlukan 2 bh kemiri, bakar sebentar
1. Harap siapkan 5 bh cabe merah besar
1. Diperlukan 2 bh cabe rawit merah
1. Siapkan 3 cm kunyit
1. Diperlukan  Bumbu tambahan
1. Harus ada 2 bh daun salam
1. Harap siapkan 2 cm jahe
1. Diperlukan 3 bh daun jeruk
1. Diperlukan 1 bh serai
1. Siapkan 4 cm lengkuas
1. Siapkan 1/2 sdt garam
1. Dibutuhkan 1/2 sdt merica
1. Harap siapkan 1/2 sdt gula jawa
1. Diperlukan 1/4 sdt gula pasir
1. Harap siapkan 1 bh daun bawang iris tipis
1. Diperlukan 1 genggam daun kemangi




<!--inarticleads2-->

##### Langkah membuat  Ayam rica kemangi:

1. Campur ayam dengan air jeruk nipis, cuci sebentar dan tiriskan. Tambahkan garam dan ratakan. Goreng setengah matang. Sisihkan.
1. Tumis bumbu uleg hingga wangi, tambahkan 1gelas air, masukkan jahe, serai, lengkuas, salam, daun jeruk, garam, merica, gula jawa, gula pasir hingga larut. Tambahkan ayam yang disisihkan. Tunggu agak mengental, koreksi rasa. Tambahkan sedikit air lagi, hingga semua bumbu meresap ke dalam ayam.
1. Masukkan daun bawang dan kemangi. Sebentar saja. Begitu layu, angkat dan siap dihidangkan.




Demikianlah cara membuat ayam rica kemangi yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
