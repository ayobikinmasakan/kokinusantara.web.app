---
description: "Step-by-Step menyiapakan Ayam rica-rica pedas Teruji"
title: "Step-by-Step menyiapakan Ayam rica-rica pedas Teruji"
slug: 363-step-by-step-menyiapakan-ayam-rica-rica-pedas-teruji
date: 2020-10-31T10:42:28.495Z
image: https://img-global.cpcdn.com/recipes/f6f391e6b2cf0b5c/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f6f391e6b2cf0b5c/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f6f391e6b2cf0b5c/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
author: Vernon Maldonado
ratingvalue: 4.4
reviewcount: 4412
recipeingredient:
- "300 gram ayam saya pakai bagian sayap dan dada"
- "secukupnya perasan jeruk nipis"
- "secukupnya merica dan garam"
- " Bahan bumbu halus"
- "7 siung bawang merah ukuran besar"
- "5 siung bawang putih"
- "10 buah cabai merah keriting"
- "5 buah cabai rawit merah"
- "2 butir kemiri"
- "2 ruas jari jahe"
- "secukupnya merica"
- "secukupnya garam"
- "secukupnya gula pasir"
- "secukupnya penyedap rasa"
- " Bahan tumisan"
- "secukupnya minyak goreng"
- "1 lembar daun salam"
- "2 lembar daun jeruk"
- "2 ruas jari lengkuas"
- " Bahan tambahan"
- "irisan daun bawang"
- " bawang goreng"
recipeinstructions:
- "Lumuri ayam dengan perasan jeruk nipis, taburi garam, dan diamkan 15 menit. Lalu goreng ayam hingga berwarna kuning keemasan."
- "Haluskan semua bahan bumbu halus. Lalu tumis dengan semua bahan tumisan hingga harum. Tambahkan air, masukkan ayam goreng, aduk hingga rata. koreksi rasa."
- "Masak hingga asat dan bumbu menyerap kedalam ayam. Sajikan dengan taburan bawang goreng dan juga irisan daun bawang. Ayam rica rica pedas siap disantapp❤️✨"
categories:
- Recipe
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 123 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica-rica pedas](https://img-global.cpcdn.com/recipes/f6f391e6b2cf0b5c/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang patut kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica-rica pedas yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Indonesia

Keharmonisan rumah tangga bisa ditemukan dengan cara mudah. Salah satunya adalah memasak Ayam rica-rica pedas untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

Lihat juga resep Ayam Rica-Rica enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica. Rasa pedas, gurih dan empuk daging ayamnya terbukti sangat cocok disajikan bersama nasi dalam.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda coba salah satunya ayam rica-rica pedas yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam rica-rica pedas tanpa harus bersusah payah.
Seperti resep Ayam rica-rica pedas yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica pedas:

1. Dibutuhkan 300 gram ayam (saya pakai bagian sayap dan dada)
1. Jangan lupa secukupnya perasan jeruk nipis
1. Diperlukan secukupnya merica dan garam
1. Harus ada  Bahan bumbu halus
1. Jangan lupa 7 siung bawang merah ukuran besar
1. Tambah 5 siung bawang putih
1. Diperlukan 10 buah cabai merah keriting
1. Jangan lupa 5 buah cabai rawit merah
1. Siapkan 2 butir kemiri
1. Jangan lupa 2 ruas jari jahe
1. Harus ada secukupnya merica
1. Tambah secukupnya garam
1. Siapkan secukupnya gula pasir
1. Jangan lupa secukupnya penyedap rasa
1. Tambah  Bahan tumisan
1. Harus ada secukupnya minyak goreng
1. Diperlukan 1 lembar daun salam
1. Dibutuhkan 2 lembar daun jeruk
1. Harus ada 2 ruas jari lengkuas
1. Siapkan  Bahan tambahan
1. Siapkan irisan daun bawang
1. Jangan lupa  bawang goreng


Mukbang Ayam Rica Rica Nasi Super Pedas Nikmat Parah. Bahan bumbu ayam rica rica yang digunakan sebenarnya cukup simple dan sederhana, seperti : kunyit, jahe, serai, cabai merah, bawang putih, dan beberapa bumbu lainnya. Inilah bumbu rica rica selengkapnya. selengkapnya silahkan dilihat dalam Aplikasi resep ayam rica rica seafood berikut ini. Ayam rica-rica ini di berikan bumbu khas indonesia yang pastinya akan memberikan cita rasa yang sangat nikmat bagi penggila pedas. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica pedas:

1. Lumuri ayam dengan perasan jeruk nipis, taburi garam, dan diamkan 15 menit. Lalu goreng ayam hingga berwarna kuning keemasan.
1. Haluskan semua bahan bumbu halus. Lalu tumis dengan semua bahan tumisan hingga harum. Tambahkan air, masukkan ayam goreng, aduk hingga rata. koreksi rasa.
1. Masak hingga asat dan bumbu menyerap kedalam ayam. Sajikan dengan taburan bawang goreng dan juga irisan daun bawang. Ayam rica rica pedas siap disantapp❤️✨


Inilah bumbu rica rica selengkapnya. selengkapnya silahkan dilihat dalam Aplikasi resep ayam rica rica seafood berikut ini. Ayam rica-rica ini di berikan bumbu khas indonesia yang pastinya akan memberikan cita rasa yang sangat nikmat bagi penggila pedas. Nah buat anda yang suka sekali dengan masakan yang pedas-pedas maka resep yang satu ini adalah pilihannya. Resep Ayam Rica - Rica Pedas Enak dan Spesial Untuk Keluarga - Asal muasal dari resep ayam rica-rica ini berasal dari daerah Manado - Sulawesi Utara, hal ini dibuktikan dengan bahasa daerah meraka yang menyebut kata pedas / cabe dengan sebutan &#34;RICA&#34;, jadi inilah bukti kalau masakan ini. Sebut saja rica-rica, makanan dengan cita rasa pedas ini merupakan salah satu makanan asal Manado yang sudah melegenda di Indonesia. 

Demikianlah cara membuat ayam rica-rica pedas yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
