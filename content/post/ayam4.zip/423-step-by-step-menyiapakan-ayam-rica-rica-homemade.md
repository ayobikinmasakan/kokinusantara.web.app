---
description: "Step-by-Step menyiapakan Ayam Rica-Rica Homemade"
title: "Step-by-Step menyiapakan Ayam Rica-Rica Homemade"
slug: 423-step-by-step-menyiapakan-ayam-rica-rica-homemade
date: 2020-11-04T09:02:18.839Z
image: https://img-global.cpcdn.com/recipes/06a536e18f899955/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/06a536e18f899955/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/06a536e18f899955/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Owen Gomez
ratingvalue: 4.5
reviewcount: 13285
recipeingredient:
- "12 potong ayam"
- "1 buah jeruk nipislemon"
- "500 ml air untuk merebus ayam"
- "350 ml air"
- "10 sdm minyak goreng secukupnya untuk menggoreng bumbu"
- " Bumbu Halus "
- "15 siung bawang merah atau 12 siung ukuran besar"
- "10 siung bawang putih atau 8 siung ukuran besar"
- "4 buah kemiri sangraigoreng"
- "1 jempol kunyit"
- "1/2 jempol jahe"
- "25 buah cabe merah keriting sesuaikan selera"
- " Bumbu pelengkapbumbu Cemplung "
- "1 ikat uk sedang daun kemangi petiki"
- "4 lembar daun salam"
- "6 lembar daun jeruk"
- "1 batang sereh geprek"
- "1 jempol lengkuas geprek"
- "2 sdt garam secukupnya"
- "1 sdt kaldu bubuk"
- "4 sdt gula pasir secukupnya"
recipeinstructions:
- "Siapkan bahan dan bumbu. Cuci ayam sampai bersih, lumuri dengan air jeruk nipis. Diamkan ±10 menit. Lalu bilas lagi sampai bersih. Rebus ayam ± 15 menit saja sampai keluar buih/busa kotornya. siram dengan air bersih, lalu tiriskan. Sisihkan."
- "Siapkan bumbu. Ulek/blender semua bumbu halus. (Lupa photo setelah dihaluskan 🙏)."
- "Siapkan wajan untuk memasak. Panaskan minyak. Tumis bumbu halus bersama daun salam, daun jeruk, sereh dan lengkuas sampai harum dan agak kering. Kemudian masukkan ayam aduk rata sampai terlumuri bumbu, masak ± 2 menit."
- "Tambahkan air. Beri garam, kaldu bubuk dan gula pasir. Aduk rata. Masak sampai ayam ½ matang dan kuah setengah menyusut. Kemudian masukkan daun kemangi, aduk rata. Masak lagi sampai ayam empuk."
- "Setelah kuah menyusut dan mengental cicipi dan koreksi rasa. Jika dirasa ayamnya masih kurang empuk, boleh tambahkan lagi air secukupnya. Masak kembali sampai ayam empuk. Setelah ayam matang / empuk dan kuah mengental, rasa pun sudah pas matikan api."
- "Ayam Rica-Rica siap dihidangkan dengan menu lainnya 🤩."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 113 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/06a536e18f899955/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas dan enak. Ciri kuliner Indonesia ayam rica-rica yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam Rica-Rica untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda contoh salah satunya ayam rica-rica yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Diperlukan 12 potong ayam
1. Harap siapkan 1 buah jeruk nipis/lemon
1. Siapkan 500 ml air untuk merebus ayam
1. Harus ada 350 ml air
1. Diperlukan 10 sdm minyak goreng (secukupnya) untuk menggoreng bumbu
1. Diperlukan  ✓Bumbu Halus :
1. Harap siapkan 15 siung bawang merah (atau 12 siung ukuran besar)
1. Harus ada 10 siung bawang putih (atau 8 siung ukuran besar)
1. Siapkan 4 buah kemiri sangrai/goreng
1. Dibutuhkan 1 jempol kunyit
1. Diperlukan 1/2 jempol jahe
1. Tambah 25 buah cabe merah keriting (sesuaikan selera)
1. Dibutuhkan  ✓Bumbu pelengkap/bumbu Cemplung :
1. Siapkan 1 ikat uk. sedang daun kemangi, petiki
1. Siapkan 4 lembar daun salam
1. Harap siapkan 6 lembar daun jeruk
1. Siapkan 1 batang sereh, geprek
1. Tambah 1 jempol lengkuas, geprek
1. Harap siapkan 2 sdt garam (secukupnya)
1. Harus ada 1 sdt kaldu bubuk
1. Jangan lupa 4 sdt gula pasir (secukupnya)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica:

1. Siapkan bahan dan bumbu. Cuci ayam sampai bersih, lumuri dengan air jeruk nipis. Diamkan ±10 menit. Lalu bilas lagi sampai bersih. Rebus ayam ± 15 menit saja sampai keluar buih/busa kotornya. siram dengan air bersih, lalu tiriskan. Sisihkan.
1. Siapkan bumbu. Ulek/blender semua bumbu halus. (Lupa photo setelah dihaluskan 🙏).
1. Siapkan wajan untuk memasak. Panaskan minyak. Tumis bumbu halus bersama daun salam, daun jeruk, sereh dan lengkuas sampai harum dan agak kering. Kemudian masukkan ayam aduk rata sampai terlumuri bumbu, masak ± 2 menit.
1. Tambahkan air. Beri garam, kaldu bubuk dan gula pasir. Aduk rata. Masak sampai ayam ½ matang dan kuah setengah menyusut. Kemudian masukkan daun kemangi, aduk rata. Masak lagi sampai ayam empuk.
1. Setelah kuah menyusut dan mengental cicipi dan koreksi rasa. Jika dirasa ayamnya masih kurang empuk, boleh tambahkan lagi air secukupnya. Masak kembali sampai ayam empuk. Setelah ayam matang / empuk dan kuah mengental, rasa pun sudah pas matikan api.
1. Ayam Rica-Rica siap dihidangkan dengan menu lainnya 🤩.




Demikianlah cara membuat ayam rica-rica yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan cepat, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
