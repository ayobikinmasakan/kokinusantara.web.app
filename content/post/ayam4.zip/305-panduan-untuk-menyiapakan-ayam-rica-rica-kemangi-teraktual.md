---
description: "Panduan untuk menyiapakan Ayam Rica-rica Kemangi teraktual"
title: "Panduan untuk menyiapakan Ayam Rica-rica Kemangi teraktual"
slug: 305-panduan-untuk-menyiapakan-ayam-rica-rica-kemangi-teraktual
date: 2021-02-07T07:30:26.706Z
image: https://img-global.cpcdn.com/recipes/f0b137ae18b5a89e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f0b137ae18b5a89e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f0b137ae18b5a89e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Manuel Reeves
ratingvalue: 4.6
reviewcount: 32136
recipeingredient:
- "1/2 kg Ayam Potong"
- "1/2 potong jeruk nipis"
- " bumbu halus"
- "3 buah bawang putih"
- "5 buah bawang merah"
- "5 buah cabe merah besar"
- "10 buah cabe rawit kecil sesuai selera"
- "1/2 cm jahe"
- "Sedikit kunyit"
- "3 buah kemiri"
- " bahan tumis"
- "secukupnya Garam"
- "secukupnya Gula"
- " Penyedap rasa"
- "4 lembar daun jeruk"
- "2 buah sereh digeprek"
- "1/2 ruas lengkuas"
- "2 lembar daun salam"
- "1 ikat daun kemangi"
recipeinstructions:
- "Cuci bersih ayam, kemudian lumuri ayam dengan jeruk nipis. Diamkan selama 5-10 menit.kemudian goreng setengah matang."
- "Blender semua bumbu halus, kemudian tambahan minyak, tumis bumbu hingga wangi.masukkan bahan tumis, aduk rata hingga bumbu matang pekat."
- "Kemudian masukkan ayam potong, aduk sebentar. Tambahkan air secukupnya. Setelah itu tambahkan gula, garam dan penyedap rasa."
- "Tutup sebentar biarkan meresap. Setelah meresap koreksi rasa, matikan kompor dan masukkan daun kemangi."
- "Siap untuk dinikmati..."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 152 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/f0b137ae18b5a89e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Kedekatan rumah tangga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica-rica Kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Kemangi:

1. Diperlukan 1/2 kg Ayam Potong
1. Tambah 1/2 potong jeruk nipis
1. Diperlukan  bumbu halus
1. Siapkan 3 buah bawang putih
1. Tambah 5 buah bawang merah
1. Tambah 5 buah cabe merah besar
1. Dibutuhkan 10 buah cabe rawit kecil (sesuai selera)
1. Siapkan 1/2 cm jahe
1. Siapkan Sedikit kunyit
1. Siapkan 3 buah kemiri
1. Siapkan  bahan tumis
1. Harus ada secukupnya Garam
1. Harap siapkan secukupnya Gula
1. Siapkan  Penyedap rasa
1. Harap siapkan 4 lembar daun jeruk
1. Harus ada 2 buah sereh (digeprek)
1. Dibutuhkan 1/2 ruas lengkuas
1. Jangan lupa 2 lembar daun salam
1. Harus ada 1 ikat daun kemangi




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-rica Kemangi:

1. Cuci bersih ayam, kemudian lumuri ayam dengan jeruk nipis. Diamkan selama 5-10 menit.kemudian goreng setengah matang.
1. Blender semua bumbu halus, kemudian tambahan minyak, tumis bumbu hingga wangi.masukkan bahan tumis, aduk rata hingga bumbu matang pekat.
1. Kemudian masukkan ayam potong, aduk sebentar. Tambahkan air secukupnya. Setelah itu tambahkan gula, garam dan penyedap rasa.
1. Tutup sebentar biarkan meresap. Setelah meresap koreksi rasa, matikan kompor dan masukkan daun kemangi.
1. Siap untuk dinikmati...




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
