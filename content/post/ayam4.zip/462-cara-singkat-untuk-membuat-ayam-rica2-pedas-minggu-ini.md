---
description: "Cara singkat untuk membuat Ayam rica2 pedas minggu ini"
title: "Cara singkat untuk membuat Ayam rica2 pedas minggu ini"
slug: 462-cara-singkat-untuk-membuat-ayam-rica2-pedas-minggu-ini
date: 2020-12-17T00:02:39.098Z
image: https://img-global.cpcdn.com/recipes/e42be5946ab7b9df/751x532cq70/ayam-rica2-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e42be5946ab7b9df/751x532cq70/ayam-rica2-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e42be5946ab7b9df/751x532cq70/ayam-rica2-pedas-foto-resep-utama.jpg
author: Marian Rodriguez
ratingvalue: 4.4
reviewcount: 4335
recipeingredient:
- "1/2 kg ayam potong2"
- " Bumbu halus"
- "5 siung bamer"
- "4 siung baput"
- "6 buah cabemerah"
- "9 buah cabai rawit"
- "3 butir kemiri sangrai"
- "1 ruas jahe"
- " Bumbu tambahan cemplung"
- "2 ruas serai"
- "3 lbr daun salam"
- "1 ruas lengkuas"
- "10 buh cabai rawit"
- "1 ikat kemangi"
- "Secukupnya garam"
- "Secukupnya gula pasir"
- "Secukupnya penyedap"
- "1 gelas belimbing air"
- "3 SDM kecp manis"
recipeinstructions:
- "Potong2 ayam cuci bersih dan rebus sebentar dengan daun salam. Setelah di rebus kemudin tiriskan dan goreng sebentar saja supaya layu dan ga amis."
- "Tumis bumbu halus hingga harum, masukan daun salam,sereh,lengkuas aduk2 hingga harum kemudian masukan 1 gelas air dan jika sudah mendidih masukan ayam."
- "Aduk2 hingga rata, msukan garam,penyedap,gula,dan kecap aduk2 hingga bumbu meresap."
- "Koreksi rasa jika bumbu sudah benar2 tinggal sedikit masukan kemangi dan aduk2 sebentar kemudian angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica2
- pedas

katakunci: ayam rica2 pedas 
nutrition: 184 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT31M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica2 pedas](https://img-global.cpcdn.com/recipes/e42be5946ab7b9df/751x532cq70/ayam-rica2-pedas-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau renyah. Ciri makanan Nusantara ayam rica2 pedas yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kehangatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam rica2 pedas untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda buat salah satunya ayam rica2 pedas yang merupakan makanan terkenal yang simpel dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam rica2 pedas tanpa harus bersusah payah.
Berikut ini resep Ayam rica2 pedas yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica2 pedas:

1. Harus ada 1/2 kg ayam potong2
1. Jangan lupa  Bumbu halus
1. Diperlukan 5 siung bamer
1. Dibutuhkan 4 siung baput
1. Harap siapkan 6 buah cabemerah
1. Harap siapkan 9 buah cabai rawit
1. Dibutuhkan 3 butir kemiri sangrai
1. Harap siapkan 1 ruas jahe
1. Diperlukan  Bumbu tambahan (cemplung)
1. Siapkan 2 ruas serai
1. Diperlukan 3 lbr daun salam
1. Dibutuhkan 1 ruas lengkuas
1. Diperlukan 10 buh cabai rawit
1. Tambah 1 ikat kemangi
1. Diperlukan Secukupnya garam
1. Harap siapkan Secukupnya gula pasir
1. Diperlukan Secukupnya penyedap
1. Tambah 1 gelas belimbing air
1. Harap siapkan 3 SDM kecp manis




<!--inarticleads2-->

##### Cara membuat  Ayam rica2 pedas:

1. Potong2 ayam cuci bersih dan rebus sebentar dengan daun salam. Setelah di rebus kemudin tiriskan dan goreng sebentar saja supaya layu dan ga amis.
1. Tumis bumbu halus hingga harum, masukan daun salam,sereh,lengkuas aduk2 hingga harum kemudian masukan 1 gelas air dan jika sudah mendidih masukan ayam.
1. Aduk2 hingga rata, msukan garam,penyedap,gula,dan kecap aduk2 hingga bumbu meresap.
1. Koreksi rasa jika bumbu sudah benar2 tinggal sedikit masukan kemangi dan aduk2 sebentar kemudian angkat dan sajikan.




Demikianlah cara membuat ayam rica2 pedas yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
