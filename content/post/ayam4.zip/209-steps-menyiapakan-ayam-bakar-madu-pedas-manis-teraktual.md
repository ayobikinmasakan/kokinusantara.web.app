---
description: "Steps menyiapakan Ayam Bakar Madu pedas manis teraktual"
title: "Steps menyiapakan Ayam Bakar Madu pedas manis teraktual"
slug: 209-steps-menyiapakan-ayam-bakar-madu-pedas-manis-teraktual
date: 2020-12-18T16:59:59.123Z
image: https://img-global.cpcdn.com/recipes/b21ca26d4c4e28e8/751x532cq70/ayam-bakar-madu-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b21ca26d4c4e28e8/751x532cq70/ayam-bakar-madu-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b21ca26d4c4e28e8/751x532cq70/ayam-bakar-madu-pedas-manis-foto-resep-utama.jpg
author: Jose Jefferson
ratingvalue: 4.8
reviewcount: 28114
recipeingredient:
- "1 kg ayam"
- " Bahan lalapan"
- "2 buah tomat potong potong"
- "2 buah timun potong potong"
- "Secukupnya daun singkong rebus"
- " Bumbu halus"
- "6 siung bawang putih"
- "8 siung bawang merah"
- "3 butir kemiri"
- "1 sdt ketumbar"
- "1/2 sdt lada"
- "2 ruas kunyit"
- "2 ruas jahe"
- "1/3 sdt jinten"
- "1 sdt kaldu jamurkaldu bubuk"
- "1 sdt garam"
- "5 buah cabe merah kriting"
- "3 buah cabe rawit setan"
- " Bumbu lainnya"
- "2 batok kecil gula jawa"
- "1 liter santan"
- "1 batang serai geprak"
- "2 ruas lengkuas geprak"
- "3 lembar daun salam"
- "1 lembar daun jeruk"
- "3 sdm kecap manis"
- "3 sdm madu"
- " Bumbu olesan"
- "5 sdm kecap manis atau secukupnya"
- "1 sdm saus tiram"
- "3 sdm madu"
recipeinstructions:
- "Rebus ayam buang air berlemaknya"
- "Siapkan bumbu bumbu"
- "Haluskan bahan bumbu halusnya"
- "Tuang bumbu halus kedalam ayam yang telah di rebus dan dibuang airnya, disusul dengan bumbu lainnya serta santan"
- "Ungkep ayam hingga bumbu meresap dan agak asat airnya"
- "Siapkan bumbu olesan, dan siapkan juga alat bakarannya (saya memakai wajan disco), lalu olesi ayam yang telah diungkep dengan bumbu oles hingga merata, kemudian bakar hingga kecoklatan, ulangi 2 kali mengolesi dengan bumbu olesnya"
- "Sajikan dengan lalapan pada piring saji"
categories:
- Recipe
tags:
- ayam
- bakar
- madu

katakunci: ayam bakar madu 
nutrition: 120 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Bakar Madu pedas manis](https://img-global.cpcdn.com/recipes/b21ca26d4c4e28e8/751x532cq70/ayam-bakar-madu-pedas-manis-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang harus kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam bakar madu pedas manis yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara

Kedekatan keluarga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Bakar Madu pedas manis untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang dapat anda contoh salah satunya ayam bakar madu pedas manis yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep ayam bakar madu pedas manis tanpa harus bersusah payah.
Berikut ini resep Ayam Bakar Madu pedas manis yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 31 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Bakar Madu pedas manis:

1. Siapkan 1 kg ayam
1. Harap siapkan  Bahan lalapan:
1. Siapkan 2 buah tomat potong potong
1. Siapkan 2 buah timun potong potong
1. Harap siapkan Secukupnya daun singkong rebus
1. Siapkan  Bumbu halus:
1. Harap siapkan 6 siung bawang putih
1. Tambah 8 siung bawang merah
1. Diperlukan 3 butir kemiri
1. Tambah 1 sdt ketumbar
1. Diperlukan 1/2 sdt lada
1. Dibutuhkan 2 ruas kunyit
1. Jangan lupa 2 ruas jahe
1. Harap siapkan 1/3 sdt jinten
1. Dibutuhkan 1 sdt kaldu jamur/kaldu bubuk
1. Dibutuhkan 1 sdt garam
1. Tambah 5 buah cabe merah kriting
1. Siapkan 3 buah cabe rawit setan
1. Harap siapkan  Bumbu lainnya:
1. Diperlukan 2 batok kecil gula jawa
1. Tambah 1 liter santan
1. Siapkan 1 batang serai geprak
1. Dibutuhkan 2 ruas lengkuas geprak
1. Harus ada 3 lembar daun salam
1. Jangan lupa 1 lembar daun jeruk
1. Siapkan 3 sdm kecap manis
1. Dibutuhkan 3 sdm madu
1. Siapkan  Bumbu olesan:
1. Diperlukan 5 sdm kecap manis atau secukupnya
1. Dibutuhkan 1 sdm saus tiram
1. Siapkan 3 sdm madu




<!--inarticleads2-->

##### Cara membuat  Ayam Bakar Madu pedas manis:

1. Rebus ayam buang air berlemaknya
1. Siapkan bumbu bumbu
1. Haluskan bahan bumbu halusnya
1. Tuang bumbu halus kedalam ayam yang telah di rebus dan dibuang airnya, disusul dengan bumbu lainnya serta santan
1. Ungkep ayam hingga bumbu meresap dan agak asat airnya
1. Siapkan bumbu olesan, dan siapkan juga alat bakarannya (saya memakai wajan disco), lalu olesi ayam yang telah diungkep dengan bumbu oles hingga merata, kemudian bakar hingga kecoklatan, ulangi 2 kali mengolesi dengan bumbu olesnya
1. Sajikan dengan lalapan pada piring saji




Demikianlah cara membuat ayam bakar madu pedas manis yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan teruji, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
