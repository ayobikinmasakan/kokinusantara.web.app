---
description: "Resep : Ayam rica-rica Luar biasa"
title: "Resep : Ayam rica-rica Luar biasa"
slug: 356-resep-ayam-rica-rica-luar-biasa
date: 2020-08-08T20:17:59.456Z
image: https://img-global.cpcdn.com/recipes/d1173918d1cfab57/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d1173918d1cfab57/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d1173918d1cfab57/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Bryan Burns
ratingvalue: 4.6
reviewcount: 30984
recipeingredient:
- "1/2 kg ayam potong kecil"
- " Bumbu halus"
- "5 buah cabe merah"
- "5 buah cabe rawit merah"
- "8 siung bawang merah"
- "2 siung bawang putih"
- "1 ruas jari jahe"
- "1 ruas jari kunyit"
- "5 buah kemiri"
- "1 ruas jari lengkuas"
- "1/2 batang serehputihnya saja"
- "1/2 sdt ketumbar bubuk"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1 ikat daun kemangi"
recipeinstructions:
- "Rebus ayam terlebih dahulu"
- "Tumis bumbu halus hingga harum, masukkan daun jeruk dan salam"
- "Masukkan ayam dan beri sedikit air, masukkan garam, gula, penyedap rasa,, masak hingga air agak menyusut"
- "Koreksi rasa,, masukkan daun kemangi dan matang"
- "Siapkan dengan nasi hangat👍"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 212 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica-rica](https://img-global.cpcdn.com/recipes/d1173918d1cfab57/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau renyah. Ciri khas masakan Nusantara ayam rica-rica yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam rica-rica untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang bisa anda coba salah satunya ayam rica-rica yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica:

1. Diperlukan 1/2 kg ayam potong kecil
1. Tambah  Bumbu halus:
1. Siapkan 5 buah cabe merah
1. Siapkan 5 buah cabe rawit merah
1. Jangan lupa 8 siung bawang merah
1. Dibutuhkan 2 siung bawang putih
1. Jangan lupa 1 ruas jari jahe
1. Tambah 1 ruas jari kunyit
1. Jangan lupa 5 buah kemiri
1. Tambah 1 ruas jari lengkuas
1. Jangan lupa 1/2 batang sereh(putihnya saja)
1. Dibutuhkan 1/2 sdt ketumbar bubuk
1. Dibutuhkan 2 lembar daun jeruk
1. Tambah 2 lembar daun salam
1. Siapkan 1 ikat daun kemangi




<!--inarticleads2-->

##### Cara membuat  Ayam rica-rica:

1. Rebus ayam terlebih dahulu
1. Tumis bumbu halus hingga harum, masukkan daun jeruk dan salam
1. Masukkan ayam dan beri sedikit air, masukkan garam, gula, penyedap rasa,, masak hingga air agak menyusut
1. Koreksi rasa,, masukkan daun kemangi dan matang
1. Siapkan dengan nasi hangat👍




Demikianlah cara membuat ayam rica-rica yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan cepat, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
