---
description: "Cara menyiapakan Ayam rica rica kemangi Sempurna"
title: "Cara menyiapakan Ayam rica rica kemangi Sempurna"
slug: 343-cara-menyiapakan-ayam-rica-rica-kemangi-sempurna
date: 2021-01-24T15:26:54.083Z
image: https://img-global.cpcdn.com/recipes/95350e31e400a2fc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/95350e31e400a2fc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/95350e31e400a2fc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Allen Walters
ratingvalue: 5
reviewcount: 13958
recipeingredient:
- "1 kg ayam"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "20 buah cabe rawit"
- "8 buah cabe merah"
- "2 lbr daun salam"
- "1 Batang sereh"
- "2 sdm kunyit bubuk"
- "1 ruas laos"
- "5 bh kemiri"
- "1 ikat daun kemangi"
- " Gula garam penyedap rasa"
recipeinstructions:
- "Potong ayam menjadi beberapa bagian, cuci bersih lalu digoreng garing"
- "Haluskan bumbu : 6 siung bawang merah 4 siung bawang putih, 5 buah kemiri"
- "8 buah cabe merah, 20 buah cabe rawit, 1 ruas lengkuas, 2 sdm kunyit bubuk"
- "Tumis bumbu kedalam minyak panas"
- "Masukkan daun salam dan sereh tambahkan air"
- "Masukkan ayam yg sdh digoreng tambahkan gula garam dan penyedap rasa"
- "Masak hingga tanak, lalu masukkan kemangi saat akan diangkat dari kompor"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 129 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/95350e31e400a2fc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga empuk. Ciri khas makanan Nusantara ayam rica rica kemangi yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kehangatan keluarga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica rica kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda buat salah satunya ayam rica rica kemangi yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Harap siapkan 1 kg ayam
1. Harus ada 6 siung bawang merah,
1. Harus ada 4 siung bawang putih,
1. Jangan lupa 20 buah cabe rawit,
1. Harap siapkan 8 buah cabe merah,
1. Dibutuhkan 2 lbr daun salam,
1. Dibutuhkan 1 Batang sereh
1. Tambah 2 sdm kunyit bubuk,
1. Harap siapkan 1 ruas laos,
1. Harus ada 5 bh kemiri
1. Siapkan 1 ikat daun kemangi
1. Dibutuhkan  Gula garam penyedap rasa




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica kemangi:

1. Potong ayam menjadi beberapa bagian, cuci bersih lalu digoreng garing
1. Haluskan bumbu : 6 siung bawang merah 4 siung bawang putih, 5 buah kemiri
1. 8 buah cabe merah, 20 buah cabe rawit, 1 ruas lengkuas, 2 sdm kunyit bubuk
1. Tumis bumbu kedalam minyak panas
1. Masukkan daun salam dan sereh tambahkan air
1. Masukkan ayam yg sdh digoreng tambahkan gula garam dan penyedap rasa
1. Masak hingga tanak, lalu masukkan kemangi saat akan diangkat dari kompor




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan cepat, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
