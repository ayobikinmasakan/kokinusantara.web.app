---
description: "Resep : Ayam goreng madu ala korea (dak kangjeong) Luar biasa"
title: "Resep : Ayam goreng madu ala korea (dak kangjeong) Luar biasa"
slug: 63-resep-ayam-goreng-madu-ala-korea-dak-kangjeong-luar-biasa
date: 2020-08-31T13:08:17.868Z
image: https://img-global.cpcdn.com/recipes/8c34cd723f5bfd9c/751x532cq70/ayam-goreng-madu-ala-korea-dak-kangjeong-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8c34cd723f5bfd9c/751x532cq70/ayam-goreng-madu-ala-korea-dak-kangjeong-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8c34cd723f5bfd9c/751x532cq70/ayam-goreng-madu-ala-korea-dak-kangjeong-foto-resep-utama.jpg
author: Alex Patton
ratingvalue: 4.9
reviewcount: 28449
recipeingredient:
- "4 potong ayam"
- "1 bungkus tepung bumbu serbaguna ukuran sedang"
- " Wijen sangrai untuk taburan"
- " Minyak goreng"
- " Bahan saus madu"
- "2 sdm madu"
- "2 sdm saus tomat"
- "2 sdm saus sambal"
- "1 sdm saus tiram"
- "1 sdt air perasan jeruk nipis"
- "1 sdm cabai bubuk"
- "2 sdm gula pasir"
- "1 sdt merica bubuk"
- "1 sdt garam"
- " Bumbu halus"
- "1 jempol jahe"
- "3 siung bawang putih"
recipeinstructions:
- "Cuci bersih ayam kemudian tiriskan. Baluri ayam dengan tepung bumbu serbaguna kemudian celupkan ke adonan basah tepung kemudian lapisi kembali dengan adonan kering tepung"
- "Panaskan minyak goreng agak banyak. Goreng ayam sampe matang. Tiriskan dan sisihkan"
- "Masukan semua bahan saus madu dan bumbu halus ke dalam wajan. Tambahkan sedikit air. Aduk rata hingga mengental"
- "Masukan ayam goreng ke dalam bahan saus madu. Aduk hingga rata. Sajikan dengan taburan wijen sangrai"
categories:
- Recipe
tags:
- ayam
- goreng
- madu

katakunci: ayam goreng madu 
nutrition: 228 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam goreng madu ala korea (dak kangjeong)](https://img-global.cpcdn.com/recipes/8c34cd723f5bfd9c/751x532cq70/ayam-goreng-madu-ala-korea-dak-kangjeong-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan empuk. Ciri khas makanan Indonesia ayam goreng madu ala korea (dak kangjeong) yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.


Keharmonisan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Ayam goreng madu ala korea (dak kangjeong) untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian masakan yang bisa anda coba salah satunya ayam goreng madu ala korea (dak kangjeong) yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep ayam goreng madu ala korea (dak kangjeong) tanpa harus bersusah payah.
Seperti resep Ayam goreng madu ala korea (dak kangjeong) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam goreng madu ala korea (dak kangjeong):

1. Tambah 4 potong ayam
1. Harus ada 1 bungkus tepung bumbu serbaguna ukuran sedang
1. Tambah  Wijen sangrai untuk taburan
1. Tambah  Minyak goreng
1. Diperlukan  Bahan saus madu:
1. Harap siapkan 2 sdm madu
1. Jangan lupa 2 sdm saus tomat
1. Harus ada 2 sdm saus sambal
1. Siapkan 1 sdm saus tiram
1. Harap siapkan 1 sdt air perasan jeruk nipis
1. Jangan lupa 1 sdm cabai bubuk
1. Diperlukan 2 sdm gula pasir
1. Diperlukan 1 sdt merica bubuk
1. Diperlukan 1 sdt garam
1. Diperlukan  Bumbu halus:
1. Dibutuhkan 1 jempol jahe
1. Siapkan 3 siung bawang putih




<!--inarticleads2-->

##### Langkah membuat  Ayam goreng madu ala korea (dak kangjeong):

1. Cuci bersih ayam kemudian tiriskan. Baluri ayam dengan tepung bumbu serbaguna kemudian celupkan ke adonan basah tepung kemudian lapisi kembali dengan adonan kering tepung
1. Panaskan minyak goreng agak banyak. Goreng ayam sampe matang. Tiriskan dan sisihkan
1. Masukan semua bahan saus madu dan bumbu halus ke dalam wajan. Tambahkan sedikit air. Aduk rata hingga mengental
1. Masukan ayam goreng ke dalam bahan saus madu. Aduk hingga rata. Sajikan dengan taburan wijen sangrai




Demikianlah cara membuat ayam goreng madu ala korea (dak kangjeong) yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan teruji, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
