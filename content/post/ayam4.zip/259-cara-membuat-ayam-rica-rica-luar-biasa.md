---
description: "Cara membuat Ayam Rica Rica Luar biasa"
title: "Cara membuat Ayam Rica Rica Luar biasa"
slug: 259-cara-membuat-ayam-rica-rica-luar-biasa
date: 2020-12-05T20:30:26.584Z
image: https://img-global.cpcdn.com/recipes/01a5bc743c21332f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/01a5bc743c21332f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/01a5bc743c21332f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Lewis Gutierrez
ratingvalue: 4.9
reviewcount: 2765
recipeingredient:
- "1 ekor ayam"
- "7 ikat daun kemangi"
- "Potong kasar "
- " Lengkuas 1 yang besar"
- " Jahe 2 ruas"
- "4 buah Kemiri"
- " Sereh secukupnya makin banyak makin enak  potong halus"
- "15 buah bawang merah"
- "10 buah bawang putih"
- " Daun jeruk secukupnya potong lurus kecil kecil"
- " Cabe rawit hijau kl yang suka pedas ulek kasar"
recipeinstructions:
- "Cuci ayam dan beri sedikit jeruk nipis (biar amisnya hilang)"
- "Bersihkan bahan-bahan yang akan dipotong kasar"
- "Untuk sereh dan daun jeruk potongnya seperti ini ya"
- "Tumis semua bahan kasar sampai wangi"
- "Setelah wangi, masukkan ayam dan aduk rata.. kemudian tambahkan air dan garam."
- "Jangan lupa ditutup, biar ayam empuk.."
- "Koreksi rasa."
- "Apabila ayam sudah empuk dan air sudah menyusut. Taburi dengan daun kemangi. Tunggu sebentar, angkat lalu sajikan.."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 250 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/01a5bc743c21332f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan gurih. Ciri khas masakan Indonesia ayam rica rica yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Resep Ayam Rica Rica Bahan: Daging Ayam Lemon juice Chicken powder Garam. Bawang merah Bawang putih Cabe Jahe Serai Daun jeruk purut Daun kucai. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica.

Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Ayam Rica Rica untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang dapat anda coba salah satunya ayam rica rica yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 11 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica:

1. Tambah 1 ekor ayam
1. Tambah 7 ikat daun kemangi
1. Harus ada Potong kasar :
1. Tambah  Lengkuas (1 yang besar)
1. Dibutuhkan  Jahe (2 ruas)
1. Harus ada 4 buah Kemiri
1. Siapkan  Sereh (secukupnya) makin banyak, makin enak 😉, potong halus
1. Siapkan 15 buah bawang merah
1. Jangan lupa 10 buah bawang putih
1. Harus ada  Daun jeruk (secukupnya) potong lurus kecil kecil
1. Harap siapkan  Cabe rawit hijau (kl yang suka pedas), ulek kasar


Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. I really don&#39;t know how it was started but if you take away chili peppers from my life… I&#39;m gone! 

<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica:

1. Cuci ayam dan beri sedikit jeruk nipis (biar amisnya hilang)
1. Bersihkan bahan-bahan yang akan dipotong kasar
1. Untuk sereh dan daun jeruk potongnya seperti ini ya
1. Tumis semua bahan kasar sampai wangi
1. Setelah wangi, masukkan ayam dan aduk rata.. kemudian tambahkan air dan garam.
1. Jangan lupa ditutup, biar ayam empuk..
1. Koreksi rasa.
1. Apabila ayam sudah empuk dan air sudah menyusut. Taburi dengan daun kemangi. Tunggu sebentar, angkat lalu sajikan..


Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. I really don&#39;t know how it was started but if you take away chili peppers from my life… I&#39;m gone! Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. Tak hanya ayam, anda juga bisa memasak. 

Demikianlah cara membuat ayam rica rica yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
