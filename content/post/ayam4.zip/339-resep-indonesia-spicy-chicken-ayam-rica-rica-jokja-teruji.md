---
description: "Resep : Indonesia Spicy Chicken (ayam rica rica Jokja) Teruji"
title: "Resep : Indonesia Spicy Chicken (ayam rica rica Jokja) Teruji"
slug: 339-resep-indonesia-spicy-chicken-ayam-rica-rica-jokja-teruji
date: 2020-11-05T10:27:05.788Z
image: https://img-global.cpcdn.com/recipes/04d8e0d6e888aa95/751x532cq70/indonesia-spicy-chicken-ayam-rica-rica-jokja-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/04d8e0d6e888aa95/751x532cq70/indonesia-spicy-chicken-ayam-rica-rica-jokja-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/04d8e0d6e888aa95/751x532cq70/indonesia-spicy-chicken-ayam-rica-rica-jokja-foto-resep-utama.jpg
author: Olivia Murray
ratingvalue: 4.7
reviewcount: 16319
recipeingredient:
- "3/4 kilos chicken me  chicken wing cut in two pieces"
- " White cabbage optional"
- " Tomato optional"
- " Sweet soy sauce"
- "500 ml water"
- " Spice paste"
- "10 cloves garlic crushed"
- "1/3 UK Union"
- "1/2 tsp ground corriender"
- "1 tsp table salt"
- "1/2 ground white pepper"
- "1/2 tsp ground tumeric"
- "5 kemiri nutsroaster"
- "1 tbsp palm sugar sliced"
- "10 red birds eye chili"
- "1 tbsp cooking oil"
recipeinstructions:
- "Put altogether the sauce ingredients in mortal and pestle until smoth"
- "Heat 1 tbsp cooking oil in a wok over medium heat and saute the spice paste until fragrant"
- "Add chicken wings, water and bring to boil and cover with lid."
- "Add sweet soy sauce and simmer for about 40-60 mins until chicken wings are cooked and spice sauce thickened"
- "You can add vegetables : white cabbage and tomato"
- "Dish out and serve immediately whilst hot."
categories:
- Recipe
tags:
- indonesia
- spicy
- chicken

katakunci: indonesia spicy chicken 
nutrition: 228 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Dinner

---


![Indonesia Spicy Chicken (ayam rica rica Jokja)](https://img-global.cpcdn.com/recipes/04d8e0d6e888aa95/751x532cq70/indonesia-spicy-chicken-ayam-rica-rica-jokja-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti indonesia spicy chicken (ayam rica rica jokja) yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Kita

Kedekatan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Indonesia Spicy Chicken (ayam rica rica Jokja) untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang dapat anda coba salah satunya indonesia spicy chicken (ayam rica rica jokja) yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep indonesia spicy chicken (ayam rica rica jokja) tanpa harus bersusah payah.
Berikut ini resep Indonesia Spicy Chicken (ayam rica rica Jokja) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Indonesia Spicy Chicken (ayam rica rica Jokja):

1. Jangan lupa 3/4 kilos chicken (me : chicken wing, cut in two pieces)
1. Tambah  White cabbage (optional)
1. Harap siapkan  Tomato (optional)
1. Dibutuhkan  Sweet soy sauce
1. Tambah 500 ml water
1. Dibutuhkan  Spice paste
1. Jangan lupa 10 cloves garlic, crushed
1. Jangan lupa 1/3 UK Union
1. Tambah 1/2 tsp ground corriender
1. Diperlukan 1 tsp table salt
1. Siapkan 1/2 ground white pepper
1. Dibutuhkan 1/2 tsp ground tumeric
1. Dibutuhkan 5 kemiri nuts,roaster
1. Siapkan 1 tbsp palm sugar, sliced
1. Jangan lupa 10 red bird&#39;s eye chili
1. Jangan lupa 1 tbsp cooking oil




<!--inarticleads2-->

##### Cara membuat  Indonesia Spicy Chicken (ayam rica rica Jokja):

1. Put altogether the sauce ingredients in mortal and pestle until smoth
1. Heat 1 tbsp cooking oil in a wok over medium heat and saute the spice paste until fragrant
1. Add chicken wings, water and bring to boil and cover with lid.
1. Add sweet soy sauce and simmer for about 40-60 mins until chicken wings are cooked and spice sauce thickened
1. You can add vegetables : white cabbage and tomato
1. Dish out and serve immediately whilst hot.




Demikianlah cara membuat indonesia spicy chicken (ayam rica rica jokja) yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
