---
description: "Resep : Ayam Bekakak Bakar Madu Cepat"
title: "Resep : Ayam Bekakak Bakar Madu Cepat"
slug: 215-resep-ayam-bekakak-bakar-madu-cepat
date: 2020-09-04T09:59:33.693Z
image: https://img-global.cpcdn.com/recipes/49d4881abe717e8d/751x532cq70/ayam-bekakak-bakar-madu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/49d4881abe717e8d/751x532cq70/ayam-bekakak-bakar-madu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/49d4881abe717e8d/751x532cq70/ayam-bekakak-bakar-madu-foto-resep-utama.jpg
author: Derrick Gibbs
ratingvalue: 4.9
reviewcount: 25934
recipeingredient:
- "1 ekor ayam ukuran kecil belah bagian dada dan perut jgn putus"
- "1 buah jeruk nipis ambil airnya"
- "2 sdt garam"
- "1 ruas jari lengkuas geprek"
- "1 ruas jari jahe geprek"
- "1 batang sereh geprek"
- "2 lembar daun salam"
- "1 lembar daun jeruk"
- "1,5 liter air"
- " Bumbu halus "
- "4 siung bawang putih"
- "8 siung bawang merah"
- "2 butir kemiri"
- "1 ruas jari kunyit"
- "1/2 sdt ketumbar bubuk"
- "1/2 sdt merica bubuk"
- "3 sdt garam"
- " Bahan olesan "
- "2 sdm kecap manis"
- "2 sdm madu"
recipeinstructions:
- "Cuci bersih ayam, lalu lumuri dengan air jeruk nipis dan garam. Diamkan kurleb 15 menit. Cuci kembali."
- "Masukkan ayam ke dalam panci. Campurkan dengan bumbu halus, jahe, lengkuas, sereh, daun salam dan daun jeruk. Beri air dan ungkep ayam hingga airnya tersisa setengahnya. Matikan api."
- "Tiriskan ayam, bakar di atas teflon sambil diolesi bahan olesan."
- "Balik ayam, bakar lagi sambil diolesi bahan olesan. Bakar hingga ayam berwarna kecoklatan. Angkat."
categories:
- Recipe
tags:
- ayam
- bekakak
- bakar

katakunci: ayam bekakak bakar 
nutrition: 169 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Bekakak Bakar Madu](https://img-global.cpcdn.com/recipes/49d4881abe717e8d/751x532cq70/ayam-bekakak-bakar-madu-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan renyah. Ciri khas kuliner Nusantara ayam bekakak bakar madu yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Ayam Bekakak Bakar Madu untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda buat salah satunya ayam bekakak bakar madu yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam bekakak bakar madu tanpa harus bersusah payah.
Seperti resep Ayam Bekakak Bakar Madu yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 20 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Bekakak Bakar Madu:

1. Harap siapkan 1 ekor ayam ukuran kecil, belah bagian dada dan perut, jgn putus
1. Tambah 1 buah jeruk nipis, ambil airnya
1. Diperlukan 2 sdt garam
1. Harus ada 1 ruas jari lengkuas, geprek
1. Dibutuhkan 1 ruas jari jahe, geprek
1. Harus ada 1 batang sereh, geprek
1. Harap siapkan 2 lembar daun salam
1. Jangan lupa 1 lembar daun jeruk
1. Tambah 1,5 liter air
1. Harap siapkan  Bumbu halus :
1. Jangan lupa 4 siung bawang putih
1. Siapkan 8 siung bawang merah
1. Siapkan 2 butir kemiri
1. Jangan lupa 1 ruas jari kunyit
1. Siapkan 1/2 sdt ketumbar bubuk
1. Diperlukan 1/2 sdt merica bubuk
1. Tambah 3 sdt garam
1. Harus ada  Bahan olesan :
1. Diperlukan 2 sdm kecap manis
1. Jangan lupa 2 sdm madu




<!--inarticleads2-->

##### Instruksi membuat  Ayam Bekakak Bakar Madu:

1. Cuci bersih ayam, lalu lumuri dengan air jeruk nipis dan garam. Diamkan kurleb 15 menit. Cuci kembali.
1. Masukkan ayam ke dalam panci. Campurkan dengan bumbu halus, jahe, lengkuas, sereh, daun salam dan daun jeruk. Beri air dan ungkep ayam hingga airnya tersisa setengahnya. Matikan api.
1. Tiriskan ayam, bakar di atas teflon sambil diolesi bahan olesan.
1. Balik ayam, bakar lagi sambil diolesi bahan olesan. Bakar hingga ayam berwarna kecoklatan. Angkat.




Demikianlah cara membuat ayam bekakak bakar madu yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
