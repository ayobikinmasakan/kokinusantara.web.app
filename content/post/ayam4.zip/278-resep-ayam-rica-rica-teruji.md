---
description: "Resep : Ayam Rica-rica Teruji"
title: "Resep : Ayam Rica-rica Teruji"
slug: 278-resep-ayam-rica-rica-teruji
date: 2020-12-29T08:20:07.762Z
image: https://img-global.cpcdn.com/recipes/bf29900c88c973fb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bf29900c88c973fb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bf29900c88c973fb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Sean Ruiz
ratingvalue: 5
reviewcount: 36221
recipeingredient:
- "5 potong ayam ukuran besar bisa 1 ekor ayam ukuran sedang"
- "2 daun salam"
- "6 daun jeruk"
- "1 Serai"
- "2 ruas lengkuas geprek"
- "1 ruas jahe geprek"
- "2 ikat kemangi"
- "1 sdm gula merah"
- "Secukupnya garam kaldu bubuk"
- " Bumbu Halus"
- "4 siung bawang putih"
- "10 siung bawang merah"
- "80 gram cabe kriting"
- "2 kemiri sangrai"
- "1 ruas kunyit"
recipeinstructions:
- "Tumis bumbu halus hingga harum. Masukkan jahe, lengkuas, daun jeruk, daun salam dan serai. Aduk2 hingga harum."
- "Masukkan ayam ke dalam tumisan bumbu. Biarkan beberapa saat. Aduk2. Masukkan air kedalamnya. Masukkan garam, gula merah dan kaldu bubuk."
- "Masak hingga bumbu meresap dan air menyusut. Koreksi rasa. Masukkan daun kemangi, aduk sebentar dan matikan api. Segera pindahkan ke wadah saji. Ayam rica2 siap dinikmati."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 124 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica-rica](https://img-global.cpcdn.com/recipes/bf29900c88c973fb/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang dapat kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica-rica yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan kesan tersendiri yang merupakan keragaman Kita



Keharmonisan keluarga bisa ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-rica untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang dapat anda coba salah satunya ayam rica-rica yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica:

1. Jangan lupa 5 potong ayam ukuran besar (bisa 1 ekor ayam ukuran sedang)
1. Tambah 2 daun salam
1. Harus ada 6 daun jeruk
1. Siapkan 1 Serai
1. Siapkan 2 ruas lengkuas geprek
1. Tambah 1 ruas jahe geprek
1. Tambah 2 ikat kemangi
1. Dibutuhkan 1 sdm gula merah
1. Harus ada Secukupnya garam, kaldu bubuk
1. Tambah  Bumbu Halus
1. Harap siapkan 4 siung bawang putih
1. Harus ada 10 siung bawang merah
1. Diperlukan 80 gram cabe kriting
1. Tambah 2 kemiri sangrai
1. Diperlukan 1 ruas kunyit




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-rica:

1. Tumis bumbu halus hingga harum. Masukkan jahe, lengkuas, daun jeruk, daun salam dan serai. Aduk2 hingga harum.
1. Masukkan ayam ke dalam tumisan bumbu. Biarkan beberapa saat. Aduk2. Masukkan air kedalamnya. Masukkan garam, gula merah dan kaldu bubuk.
1. Masak hingga bumbu meresap dan air menyusut. Koreksi rasa. Masukkan daun kemangi, aduk sebentar dan matikan api. Segera pindahkan ke wadah saji. Ayam rica2 siap dinikmati.




Demikianlah cara membuat ayam rica-rica yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan cepat, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
