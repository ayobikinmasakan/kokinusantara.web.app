---
description: "Panduan membuat Ayam Rica-Rica teraktual"
title: "Panduan membuat Ayam Rica-Rica teraktual"
slug: 357-panduan-membuat-ayam-rica-rica-teraktual
date: 2020-09-15T04:06:14.417Z
image: https://img-global.cpcdn.com/recipes/f2825427bf778195/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f2825427bf778195/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f2825427bf778195/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Donald Brady
ratingvalue: 4.6
reviewcount: 43401
recipeingredient:
- "10 potong ayam yang sudah di cuci bersih dan di beri jeruk nipis diamkan 2030 menit"
- "3 lembar daun jeruk"
- "1 lembar daun kunyit iris"
- "1 batang sere geprek atau iris bagian putihnya saja"
- "Seruas lengkuas di geprek"
- "1 buah tomat iris"
- "1 batang daun bawang iris"
- "1 buah jeruk nipis"
- " Minyak untuk menumis"
- "secukupnya Air"
- "secukupnya Garam"
- "secukupnya Kaldu jamur"
- " Bumbu halus"
- "11 buah cabe merah boleh di tambah atau dikurangi sesuai selera"
- "15 cabe buah rawit boleh di tambah atau di kurangi sesuai selera"
- "9 siung bawang merah"
- "3 siung bawang putih"
- "3 butir kemiri"
- "Seruas jahe"
- "1/2 ruas kunyit"
recipeinstructions:
- "Cuci bersih ayam yang sudah di lumuri jeruk nipis"
- "Panaskan minyak, masukkan bumbu halus tumis sampai wangi lalu tambahkan daun jeruk, sere dan lengkuas."
- "Lalu masukkan ayam aduk rata, tambahkan air secukupnya dengan menggunakan api kecil. Masukkan daun kunyit aduk rata."
- "Setelah air menyusut tambahkan garam dan kaldu jamur, dan tambahkan daun bawang serta tomat. Aduk hingga rata. Sajikan dan selamat menikmati ya.."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 118 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/f2825427bf778195/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica-rica yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa ciri khas yang merupakan keragaman Nusantara



Kedekatan keluarga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica-Rica untuk keluarga. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda praktekkan salah satunya ayam rica-rica yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Jangan lupa 10 potong ayam yang sudah di cuci bersih dan di beri jeruk nipis diamkan 20-30 menit
1. Harap siapkan 3 lembar daun jeruk
1. Harap siapkan 1 lembar daun kunyit iris
1. Tambah 1 batang sere geprek atau iris bagian putihnya saja
1. Diperlukan Seruas lengkuas di geprek
1. Jangan lupa 1 buah tomat iris
1. Harap siapkan 1 batang daun bawang iris
1. Harap siapkan 1 buah jeruk nipis
1. Jangan lupa  Minyak untuk menumis
1. Harap siapkan secukupnya Air
1. Siapkan secukupnya Garam
1. Harus ada secukupnya Kaldu jamur
1. Siapkan  Bumbu halus
1. Siapkan 11 buah cabe merah boleh di tambah atau dikurangi sesuai selera
1. Harap siapkan 15 cabe buah rawit boleh di tambah atau di kurangi sesuai selera
1. Tambah 9 siung bawang merah
1. Dibutuhkan 3 siung bawang putih
1. Harus ada 3 butir kemiri
1. Harap siapkan Seruas jahe
1. Tambah 1/2 ruas kunyit




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-Rica:

1. Cuci bersih ayam yang sudah di lumuri jeruk nipis
1. Panaskan minyak, masukkan bumbu halus tumis sampai wangi lalu tambahkan daun jeruk, sere dan lengkuas.
1. Lalu masukkan ayam aduk rata, tambahkan air secukupnya dengan menggunakan api kecil. Masukkan daun kunyit aduk rata.
1. Setelah air menyusut tambahkan garam dan kaldu jamur, dan tambahkan daun bawang serta tomat. Aduk hingga rata. Sajikan dan selamat menikmati ya..




Demikianlah cara membuat ayam rica-rica yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat gampang dan terbukti, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
