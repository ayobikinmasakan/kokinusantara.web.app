---
description: "Resep : Ayam rica-rica Manado teraktual"
title: "Resep : Ayam rica-rica Manado teraktual"
slug: 421-resep-ayam-rica-rica-manado-teraktual
date: 2020-09-26T11:43:38.269Z
image: https://img-global.cpcdn.com/recipes/5cb28d28296f7bed/751x532cq70/ayam-rica-rica-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5cb28d28296f7bed/751x532cq70/ayam-rica-rica-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5cb28d28296f7bed/751x532cq70/ayam-rica-rica-manado-foto-resep-utama.jpg
author: Myrtie Casey
ratingvalue: 5
reviewcount: 42321
recipeingredient:
- "1 ekor ayam"
- " bumbu halus "
- "1 ons cabe merah keriting"
- "10 buah cabe rawit merah"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "3 butir kemiri"
- "1 ruas lengkuas"
- " bumbu cemplung "
- "3 batang sereh geprek"
- "1 ikat daun pandan ikat simpul"
- "5 lembar daun salam"
- "5 lembar daun jeruk iris"
- "2 batang daun bawang iris"
- "1 ikat kemangi"
- "secukupnya Garam gula dan kaldu jamur"
recipeinstructions:
- "Cuci bersih ayam. Lumuri kunyit bubuk, air jeruk nipis dan garam. Diamkan 10 menit. Goreng setengah mateng. Sisihkan"
- "Siapkan bumbu halus dan bumbu cemplung"
- "Tumis bumbu halus. Kemudian masukkan bumbu cemplung. Masukkan ayam, beri sedikit air. Koreksi rasa"
- "Masak hingga air menyusut. Siap disajikan 😅"
categories:
- Recipe
tags:
- ayam
- ricarica
- manado

katakunci: ayam ricarica manado 
nutrition: 289 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica-rica Manado](https://img-global.cpcdn.com/recipes/5cb28d28296f7bed/751x532cq70/ayam-rica-rica-manado-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga gurih. Ciri khas makanan Nusantara ayam rica-rica manado yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Rica-rica dalam bahasa Manado (Sulawesi Utara) berarti pedas atau cabe. dalam proses masaknya beraneka ragam. Masakan kali ini dengan menambah daun kemangi. Ayam rica-rica is specialty chicken dish from the city of Manado in Indonesia North Sulawesi. Rica means chili in North Sulawesi language, so ayam rica-rica translates to chicken with chili sauce.

Keharmonisan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica-rica Manado untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang bisa anda buat salah satunya ayam rica-rica manado yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica-rica manado tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica Manado yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica Manado:

1. Jangan lupa 1 ekor ayam
1. Harus ada  🌻bumbu halus :
1. Dibutuhkan 1 ons cabe merah keriting
1. Tambah 10 buah cabe rawit merah
1. Dibutuhkan 6 siung bawang merah
1. Harap siapkan 4 siung bawang putih
1. Diperlukan 1 ruas jahe
1. Harap siapkan 1 ruas kunyit
1. Harus ada 3 butir kemiri
1. Jangan lupa 1 ruas lengkuas
1. Dibutuhkan  🌻bumbu cemplung :
1. Diperlukan 3 batang sereh (geprek)
1. Dibutuhkan 1 ikat daun pandan (ikat simpul)
1. Harus ada 5 lembar daun salam
1. Dibutuhkan 5 lembar daun jeruk (iris)
1. Jangan lupa 2 batang daun bawang (iris)
1. Diperlukan 1 ikat kemangi
1. Tambah secukupnya Garam, gula dan kaldu jamur


Resep rica rica sendiri sebenarnya tidak harus menggunakan bahan daging ayam saja. Cita rasa pedas menjadi ciri khas resep yang tergabung dalam masakan indonesia yang satu ini. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. I really don&#39;t know how it was started but if you take away chili peppers from my life… Ayam means chicken and rica means hot spicy. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica-rica Manado:

1. Cuci bersih ayam. Lumuri kunyit bubuk, air jeruk nipis dan garam. Diamkan 10 menit. Goreng setengah mateng. Sisihkan
1. Siapkan bumbu halus dan bumbu cemplung
1. Tumis bumbu halus. Kemudian masukkan bumbu cemplung. Masukkan ayam, beri sedikit air. Koreksi rasa
1. Masak hingga air menyusut. Siap disajikan 😅


Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. I really don&#39;t know how it was started but if you take away chili peppers from my life… Ayam means chicken and rica means hot spicy. Ayam rica rica is originated in the city of Manado in the island of Sulawesi. Resep Mukbang Ayam Rica Asli Manado. Resep Ayam Rica Rica Asli Pedagang. sobat dapur. 

Demikianlah cara membuat ayam rica-rica manado yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
