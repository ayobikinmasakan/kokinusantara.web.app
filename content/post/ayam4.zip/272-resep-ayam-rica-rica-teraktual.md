---
description: "Resep : Ayam Rica-Rica teraktual"
title: "Resep : Ayam Rica-Rica teraktual"
slug: 272-resep-ayam-rica-rica-teraktual
date: 2021-01-07T17:27:56.542Z
image: https://img-global.cpcdn.com/recipes/a7378a7593d5548d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a7378a7593d5548d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a7378a7593d5548d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Elijah Anderson
ratingvalue: 4
reviewcount: 18949
recipeingredient:
- "400 g ayam potong jadi 6"
- "1 ruas jahe digeprek"
- "1 sdm gula merah sisir saya pake gula merah cair"
- "1 sdm kecap manis"
- "1/2 sdt merica bubuk"
- "1 sdt garam"
- "1/2 sdt kaldu bubuk organik"
- "3 sdm minyak goreng untuk menumis"
- "Secukupnya air"
- " Bumbu Halus"
- "4 siung bawang merah"
- "3 siung bawang putih"
- "6 buah cabe keriting merah"
- "2 buah cabe setan boleh diskip jika tidak suka terlalu pedas"
- "2 cm kunyit kupas kulitnya"
- "50 ml air"
- " Bahan Cemplung"
- "3 cm lengkuas digeprek"
- "1 batang serai digeprak"
- "2 lembar daun salam"
recipeinstructions:
- "Cuci bersih ayam. Rebus ayam bersama air dan jahe. Buangi gumpalan keruh yang ada dipermukaan air saat merebus ayam. Rebus sampai setengah matang (ini saya lakukan karena ayamnya dari freezer/tidak fresh, jika ayamnya fresh bisa direndam perasan jeruk nipis kemudian lanjutkan ke langkah no. 2). Matikan api kompor, kemudian buang jahenya. Sisihkan!"
- "Cuci bersih semua bahan bumbu halus, kecuali air. Potong-potong, kemudian haluskan dengan blender bersama air."
- "Siapkan bahan cemplung. Panaskan minyak goreng. Masukkan bumbu halus. Tumis sampai air susut dan baunya harum. Masukkan bumbu cemplung."
- "Masukkan ayamnya. Aduk sebentar, kemudian tambahkan air kaldu rebusan ayam sampai ayamnya terendam semua. Tambahkan gula merah dan kecap manis."
- "Masak sampai airnya agak susut dan bumbu meresap ke ayam. Matikan api kompor. Pindahkan ke wadah dan siap disajikan. Selamat mencoba 😉🥰"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 235 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/a7378a7593d5548d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan gurih. Ciri makanan Nusantara ayam rica-rica yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica-Rica untuk keluarga. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang bisa anda buat salah satunya ayam rica-rica yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Diperlukan 400 g ayam (potong jadi 6)
1. Harus ada 1 ruas jahe (digeprek)
1. Diperlukan 1 sdm gula merah sisir (saya pake gula merah cair)
1. Diperlukan 1 sdm kecap manis
1. Tambah 1/2 sdt merica bubuk
1. Jangan lupa 1 sdt garam
1. Tambah 1/2 sdt kaldu bubuk organik
1. Jangan lupa 3 sdm minyak goreng untuk menumis
1. Dibutuhkan Secukupnya air
1. Tambah  Bumbu Halus:
1. Harus ada 4 siung bawang merah
1. Diperlukan 3 siung bawang putih
1. Siapkan 6 buah cabe keriting merah
1. Siapkan 2 buah cabe setan (boleh diskip jika tidak suka terlalu pedas)
1. Diperlukan 2 cm kunyit (kupas kulitnya)
1. Diperlukan 50 ml air
1. Jangan lupa  Bahan Cemplung:
1. Dibutuhkan 3 cm lengkuas (digeprek)
1. Harap siapkan 1 batang serai (digeprak)
1. Diperlukan 2 lembar daun salam




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-Rica:

1. Cuci bersih ayam. Rebus ayam bersama air dan jahe. Buangi gumpalan keruh yang ada dipermukaan air saat merebus ayam. Rebus sampai setengah matang (ini saya lakukan karena ayamnya dari freezer/tidak fresh, jika ayamnya fresh bisa direndam perasan jeruk nipis kemudian lanjutkan ke langkah no. 2). Matikan api kompor, kemudian buang jahenya. Sisihkan!
1. Cuci bersih semua bahan bumbu halus, kecuali air. Potong-potong, kemudian haluskan dengan blender bersama air.
1. Siapkan bahan cemplung. Panaskan minyak goreng. Masukkan bumbu halus. Tumis sampai air susut dan baunya harum. Masukkan bumbu cemplung.
1. Masukkan ayamnya. Aduk sebentar, kemudian tambahkan air kaldu rebusan ayam sampai ayamnya terendam semua. Tambahkan gula merah dan kecap manis.
1. Masak sampai airnya agak susut dan bumbu meresap ke ayam. Matikan api kompor. Pindahkan ke wadah dan siap disajikan. Selamat mencoba 😉🥰




Demikianlah cara membuat ayam rica-rica yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
