---
description: "Steps membuat Ayam Rica teraktual"
title: "Steps membuat Ayam Rica teraktual"
slug: 379-steps-membuat-ayam-rica-teraktual
date: 2020-09-01T14:10:28.146Z
image: https://img-global.cpcdn.com/recipes/ae991bfbd9128cf6/751x532cq70/ayam-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ae991bfbd9128cf6/751x532cq70/ayam-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ae991bfbd9128cf6/751x532cq70/ayam-rica-foto-resep-utama.jpg
author: Bruce Scott
ratingvalue: 4.6
reviewcount: 38603
recipeingredient:
- "1/2 ayam potong potong cuci"
- " Bumbu halus"
- "4 kemiri"
- "2 bawang putih"
- "8 bawang merah sy gapake habis"
- "1/2 bawang bombay"
- "1 ruas jahe"
- " Cabai"
- " Bumbu lain"
- "2 daun salam"
- "5 daun jeruk buang tulangnya"
- "3 cm kunyit"
- " Lengkuas geprek"
- " Serai geprek"
- " Cabai rawit pedas gelondongan"
- " Mrica bubuk"
- " Royco Kaldu ayam bubuk"
- "Secukupnya garam"
- "1 sdt gula jawa pasir"
- " Daun bawang Onclang"
- "Segenggam daun kemangi"
- " Brambang goreng"
recipeinstructions:
- "Haluskan bumbu halus, tumis beserta daun jeruk serai lengkuas, masukkan ayam dan 1 gelas air. Oya cabainya sy terakhir krn masak buat sikecil jg."
- "Masukkan kaldu bubuk garam mrica, gula masak hingga agak susut airnya, tambahkan ulegan cabai dan cabai glondongan, aduk hingga menyusut airnya. Cek rasa, (disini sy sisihkan buat sikecil yg ga pedes dan sy tambahkan santan untuk sikecil)."
- "Beri 1 sdm minyak, potongan daun bawang+ kemangi, aduk rata, segera matikan kompor."
- "Sajikan dgn taburan bawang merah goreng."
categories:
- Recipe
tags:
- ayam
- rica

katakunci: ayam rica 
nutrition: 211 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica](https://img-global.cpcdn.com/recipes/ae991bfbd9128cf6/751x532cq70/ayam-rica-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan renyah. Ciri masakan Indonesia ayam rica yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang bisa anda contoh salah satunya ayam rica yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica tanpa harus bersusah payah.
Seperti resep Ayam Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica:

1. Jangan lupa 1/2 ayam, potong potong cuci
1. Tambah  Bumbu halus
1. Siapkan 4 kemiri
1. Tambah 2 bawang putih
1. Diperlukan 8 bawang merah (sy gapake habis😂)
1. Siapkan 1/2 bawang bombay
1. Harus ada 1 ruas jahe
1. Jangan lupa  Cabai
1. Jangan lupa  Bumbu lain
1. Harus ada 2 daun salam
1. Diperlukan 5 daun jeruk buang tulangnya
1. Harap siapkan 3 cm kunyit
1. Jangan lupa  Lengkuas, geprek
1. Diperlukan  Serai, geprek
1. Diperlukan  Cabai rawit pedas gelondongan
1. Dibutuhkan  Mrica bubuk
1. Siapkan  Royco/ Kaldu ayam bubuk
1. Dibutuhkan Secukupnya garam
1. Jangan lupa 1 sdt gula jawa/ pasir
1. Dibutuhkan  Daun bawang/ Onclang
1. Dibutuhkan Segenggam daun kemangi
1. Dibutuhkan  Brambang goreng




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica:

1. Haluskan bumbu halus, tumis beserta daun jeruk serai lengkuas, masukkan ayam dan 1 gelas air. Oya cabainya sy terakhir krn masak buat sikecil jg.
1. Masukkan kaldu bubuk garam mrica, gula masak hingga agak susut airnya, tambahkan ulegan cabai dan cabai glondongan, aduk hingga menyusut airnya. Cek rasa, (disini sy sisihkan buat sikecil yg ga pedes dan sy tambahkan santan untuk sikecil).
1. Beri 1 sdm minyak, potongan daun bawang+ kemangi, aduk rata, segera matikan kompor.
1. Sajikan dgn taburan bawang merah goreng.




Demikianlah cara membuat ayam rica yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
