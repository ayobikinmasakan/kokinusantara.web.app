---
description: "Steps menyiapakan Ayam rica rica kemangi Terbukti"
title: "Steps menyiapakan Ayam rica rica kemangi Terbukti"
slug: 433-steps-menyiapakan-ayam-rica-rica-kemangi-terbukti
date: 2020-11-07T02:29:50.910Z
image: https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Adrian Murphy
ratingvalue: 4.9
reviewcount: 23325
recipeingredient:
- "1 ekor ayam potong kecil"
- "6 lembar daun jeruk potong tipis2"
- "2 batang serai memarkan"
- "3 lembar daun salam"
- "2 ikat kemangi petik daunnya saja"
- "2 ruas lengkuas memarkan"
- "2 ruas jahe memarkan"
- " Garam"
- " Penyedap jamur  kaldu bubuk sesuai selera"
- "6 buah cabe rawit merah bulat boleh ditambah sesuai selera"
- " Bumbu halus"
- "20 cabe merah keriting"
- "9 cabe rawit merah"
- "8 siung bawang merah"
- "3 siung bawang putih"
- "2 ruas kunyit kupas"
recipeinstructions:
- "Cuci bersih ayam, kemudian goreng di minyak panas sampai ayam agak sedikit kecoklatan / setengah matang. Jika sudah kecoklatan, angkat dan tiriskan."
- "Tumis bumbu halus dengan api kecil hingga wangi, masukan lengkuas, jahe, daun jeruk, daun salam, dan batang serai. Tumis kembali hingga wangi."
- "Masukan ayam yang tadi sudah digoreng kedalam tumisan bumbu, masukan garam dan penyedap, aduk hingga ayam tercampur dengan bumbu cabe. Tambahkan sedikit saja air supaya lebih mudah tercampur."
- "Setelah tercampur rata, masukan cabe rawit merah bulat untuk variasi jika ingin menambah rasa pedas, tumis kembali. Setelah semua tercampur rata, masukan daun kemangi, tumis hingga agak layu. Matikan api. Rica rica siap disantap...selamat mencoba bun 🥰🥰🥰"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 129 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT45M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/8c99fc0d70f44364/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga empuk. Ciri khas masakan Indonesia ayam rica rica kemangi yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Keharmonisan keluarga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam rica rica kemangi untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang dapat anda coba salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Harap siapkan 1 ekor ayam, potong kecil
1. Harap siapkan 6 lembar daun jeruk, potong tipis2
1. Siapkan 2 batang serai, memarkan
1. Dibutuhkan 3 lembar daun salam
1. Harap siapkan 2 ikat kemangi, petik daunnya saja
1. Jangan lupa 2 ruas lengkuas, memarkan
1. Harap siapkan 2 ruas jahe, memarkan
1. Harap siapkan  Garam
1. Harap siapkan  Penyedap jamur / kaldu bubuk (sesuai selera)
1. Siapkan 6 buah cabe rawit merah bulat (boleh ditambah sesuai selera)
1. Tambah  Bumbu halus
1. Dibutuhkan 20 cabe merah keriting
1. Tambah 9 cabe rawit merah
1. Harap siapkan 8 siung bawang merah
1. Jangan lupa 3 siung bawang putih
1. Harus ada 2 ruas kunyit, kupas




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi:

1. Cuci bersih ayam, kemudian goreng di minyak panas sampai ayam agak sedikit kecoklatan / setengah matang. Jika sudah kecoklatan, angkat dan tiriskan.
1. Tumis bumbu halus dengan api kecil hingga wangi, masukan lengkuas, jahe, daun jeruk, daun salam, dan batang serai. Tumis kembali hingga wangi.
1. Masukan ayam yang tadi sudah digoreng kedalam tumisan bumbu, masukan garam dan penyedap, aduk hingga ayam tercampur dengan bumbu cabe. Tambahkan sedikit saja air supaya lebih mudah tercampur.
1. Setelah tercampur rata, masukan cabe rawit merah bulat untuk variasi jika ingin menambah rasa pedas, tumis kembali. Setelah semua tercampur rata, masukan daun kemangi, tumis hingga agak layu. Matikan api. Rica rica siap disantap...selamat mencoba bun 🥰🥰🥰




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
