---
description: "Bagaimana untuk menyiapakan Ayam Rica- Rica Cepat"
title: "Bagaimana untuk menyiapakan Ayam Rica- Rica Cepat"
slug: 465-bagaimana-untuk-menyiapakan-ayam-rica-rica-cepat
date: 2020-11-04T02:53:22.246Z
image: https://img-global.cpcdn.com/recipes/61b2712829cafe6f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/61b2712829cafe6f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/61b2712829cafe6f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Herbert Schmidt
ratingvalue: 4.6
reviewcount: 2226
recipeingredient:
- "1/2 ekor ayam"
- "1 buah tomat potong kecil"
- "1/2 siung bawang bombay rajang"
- "2 siung bawang putih rajang"
- "1 batang daun bawang iris tipis"
- "20 buah cabai rawit merah iris tipis"
- "2 sdm saos sambal"
- "2 sdm saos tomat"
- "2 sdm saos tiram"
- "2 sdm kecap manis"
- "1/2 sdt ketumbar"
- "1/2 sdt garam"
- "1/2 sdt gula"
- "1 buah jeruk nipis"
- " minyak untuk menggoreng"
- "50 ml air"
- " Bumbu marinasi"
- "2 sdm kecap manis"
- "1 sdt kaldu bubuk"
- "1 sdt merica"
recipeinstructions:
- "Potong ayam kecil2, cuci bersih lumuri dengan jeruk nipis, rendam selama 5-10 menit, cuci kembali, masukkan bumbu marinasi simpan selama 30 menit."
- "Goreng matang ayam, sisihkan"
- "Tumis bawang bombay, bawang putih, daun bawang, tomat dan cabai hingga setengah matang lalu masukkan saos tiram, saos sambal, saos tomat, kecap manis, ketumbar, gula dan garam, aduk rata."
- "Masukkan ayam, tambahkan air, masak hingga bumbu meresap dengan kekentalan yang diinginkan, cek rasa, angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 240 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica- Rica](https://img-global.cpcdn.com/recipes/61b2712829cafe6f/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau enak. Ciri khas masakan Indonesia ayam rica- rica yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam Rica- Rica untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang dapat anda coba salah satunya ayam rica- rica yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan cepat menemukan resep ayam rica- rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica- Rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica- Rica:

1. Harap siapkan 1/2 ekor ayam
1. Harap siapkan 1 buah tomat, potong kecil
1. Tambah 1/2 siung bawang bombay, rajang
1. Jangan lupa 2 siung bawang putih rajang
1. Jangan lupa 1 batang daun bawang, iris tipis
1. Harus ada 20 buah cabai rawit merah, iris tipis
1. Jangan lupa 2 sdm saos sambal
1. Harus ada 2 sdm saos tomat
1. Harus ada 2 sdm saos tiram
1. Jangan lupa 2 sdm kecap manis
1. Jangan lupa 1/2 sdt ketumbar
1. Dibutuhkan 1/2 sdt garam
1. Tambah 1/2 sdt gula
1. Harap siapkan 1 buah jeruk nipis
1. Harap siapkan  minyak untuk menggoreng
1. Diperlukan 50 ml air
1. Tambah  Bumbu marinasi
1. Harus ada 2 sdm kecap manis
1. Harus ada 1 sdt kaldu bubuk
1. Diperlukan 1 sdt merica




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica- Rica:

1. Potong ayam kecil2, cuci bersih lumuri dengan jeruk nipis, rendam selama 5-10 menit, cuci kembali, masukkan bumbu marinasi simpan selama 30 menit.
1. Goreng matang ayam, sisihkan
1. Tumis bawang bombay, bawang putih, daun bawang, tomat dan cabai hingga setengah matang lalu masukkan saos tiram, saos sambal, saos tomat, kecap manis, ketumbar, gula dan garam, aduk rata.
1. Masukkan ayam, tambahkan air, masak hingga bumbu meresap dengan kekentalan yang diinginkan, cek rasa, angkat dan sajikan.




Demikianlah cara membuat ayam rica- rica yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
