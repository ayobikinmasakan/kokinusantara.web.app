---
description: "Resep : Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo Teruji"
title: "Resep : Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo Teruji"
slug: 275-resep-ayam-rica-rica-daun-kemangi-masakanindo-teruji
date: 2020-11-05T07:55:53.737Z
image: https://img-global.cpcdn.com/recipes/55574b38704c0a24/751x532cq70/ayam-rica-rica-daun-kemangi-🇮🇩-masakanindo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/55574b38704c0a24/751x532cq70/ayam-rica-rica-daun-kemangi-🇮🇩-masakanindo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/55574b38704c0a24/751x532cq70/ayam-rica-rica-daun-kemangi-🇮🇩-masakanindo-foto-resep-utama.jpg
author: Chris Ruiz
ratingvalue: 4.2
reviewcount: 46785
recipeingredient:
- "300 gr dada ayam dapat 5 potong"
- " Bumbu halus"
- "6 siung bawang merah"
- "2 siung bawang putih"
- "10 buah cabe merah keriting"
- "5 buah cabe rawit merah"
- "2 butir kemiri"
- "1 ruas kunyit"
- "1 ruas jahe aku skip"
- " Bahan tumis"
- "1 batang serai geprek"
- "5 lembar daun jeruk"
- "1 ruas lengkuas"
- "Secukupnya air matang"
- "1 ikat kemangi boleh lebih"
- "1 lembar daun bawang iris"
- "1 sdm gula merah"
- "1 sdt kaldu jamur"
- "1 sdt gula garam sesuaikan ya"
recipeinstructions:
- "Rebus ayam / goreng. Kalau mau mentahan, direbus bersamaan dengan bumbu tumis juga bisa. Kalo aku direbus dulu😉"
- "Blender bahan Bumbu Halus"
- "Panaskan minyak. Tumis Bahan tumis. Lalu tuang Bumbu halus. Masak bersamaan hingga harum, tambahkan sedikit air, gula merah, garam dan penyedap."
- "Masukkan ayam dan daun kemangi. Aduk2 hingga tercampur semua. Tambahkan daun bawang iris. Aduk rata, masak hingga air surut."
- "Test rasa. Kalau kurang, tambah gula garam ya."
- "Siap dihidangkan🥰 medok banget warnanya btw. Tapi pedesnya gak seberapa. Karena aku banyakin cabe keriting, bukan rawitnya."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 161 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo](https://img-global.cpcdn.com/recipes/55574b38704c0a24/751x532cq70/ayam-rica-rica-daun-kemangi-🇮🇩-masakanindo-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica rica daun kemangi 🇮🇩 #masakanindo yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia



Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang dapat anda contoh salah satunya ayam rica rica daun kemangi 🇮🇩 #masakanindo yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam rica rica daun kemangi 🇮🇩 #masakanindo tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo:

1. Diperlukan 300 gr dada ayam (dapat 5 potong)
1. Harap siapkan  Bumbu halus
1. Jangan lupa 6 siung bawang merah
1. Jangan lupa 2 siung bawang putih
1. Tambah 10 buah cabe merah keriting
1. Siapkan 5 buah cabe rawit merah
1. Harap siapkan 2 butir kemiri
1. Dibutuhkan 1 ruas kunyit
1. Harus ada 1 ruas jahe (aku skip)
1. Jangan lupa  Bahan tumis
1. Harus ada 1 batang serai (geprek)
1. Harus ada 5 lembar daun jeruk
1. Siapkan 1 ruas lengkuas
1. Harap siapkan Secukupnya air matang
1. Dibutuhkan 1 ikat kemangi (boleh lebih)
1. Diperlukan 1 lembar daun bawang iris
1. Dibutuhkan 1 sdm gula merah
1. Siapkan 1 sdt kaldu jamur
1. Tambah 1 sdt gula garam (sesuaikan ya)




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica Daun Kemangi 🇮🇩 #masakanindo:

1. Rebus ayam / goreng. Kalau mau mentahan, direbus bersamaan dengan bumbu tumis juga bisa. Kalo aku direbus dulu😉
1. Blender bahan Bumbu Halus
1. Panaskan minyak. Tumis Bahan tumis. Lalu tuang Bumbu halus. Masak bersamaan hingga harum, tambahkan sedikit air, gula merah, garam dan penyedap.
1. Masukkan ayam dan daun kemangi. Aduk2 hingga tercampur semua. Tambahkan daun bawang iris. Aduk rata, masak hingga air surut.
1. Test rasa. Kalau kurang, tambah gula garam ya.
1. Siap dihidangkan🥰 medok banget warnanya btw. Tapi pedesnya gak seberapa. Karena aku banyakin cabe keriting, bukan rawitnya.




Demikianlah cara membuat ayam rica rica daun kemangi 🇮🇩 #masakanindo yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat gampang dan cepat, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
