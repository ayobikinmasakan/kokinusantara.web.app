---
description: "Cara singkat menyiapakan Opor Ayam Teruji"
title: "Cara singkat menyiapakan Opor Ayam Teruji"
slug: 490-cara-singkat-menyiapakan-opor-ayam-teruji
date: 2021-01-11T07:46:02.249Z
image: https://img-global.cpcdn.com/recipes/e9e03cb65f4ff80f/751x532cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e9e03cb65f4ff80f/751x532cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e9e03cb65f4ff80f/751x532cq70/opor-ayam-foto-resep-utama.jpg
author: Lewis Reeves
ratingvalue: 4
reviewcount: 43354
recipeingredient:
- "1/2 ekor ayam broiler potong potong cuci"
- "1 Santan Kara"
- " Kaldu ayam garam 1 sdt gula pasir merah"
- " Bawang merah goreng untuk taburan"
- " Bumbu halus"
- "4 siung bawang putih"
- "6 siung bawang merah"
- "1 sdm ketumbar bs diganti 1 sdt ketumbar bubuk"
- "5 cm ruas kunyit"
- "1/2 sdt jinten"
- "4 kemiri sangrai"
- "Secukupnya merica bubuk"
- " Bumbu lain"
- "4 daun jeruk buang tulangnya"
- "3 daun salam"
- "Seruas lengkuas geprek"
- "1 batang serai geprek"
recipeinstructions:
- "Rebus ayam sebentar saja, buang airnya. kembali rebus air di panci masukkan ayam td. Banyaknya kuah rebusan sesuai selera ya bun, mau dibikin kuah kental atau encer..kl sy suka yg berkuah banyak.."
- "Haluskan bumbu halus, tumis bumbu halus dengan bumbu lainnya."
- "Masukkan tumisan bumbu ke rebusan ayam,masukkan kaldu ayam merica bubuk, garam sedikit gula jawa/pasir. Masak hingga meletup."
- "Masukkan santan kara, sambil terus diaduk agar santan tdk pecah, aduk hingga matang, cek rasa."
- "Opor siap disajikan dengan taburan bawang goreng."
categories:
- Recipe
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 138 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT56M"
recipeyield: "4"
recipecategory: Lunch

---


![Opor Ayam](https://img-global.cpcdn.com/recipes/e9e03cb65f4ff80f/751x532cq70/opor-ayam-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita jaga karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti opor ayam yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Indonesia



Kedekatan keluarga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Opor Ayam untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda buat salah satunya opor ayam yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep opor ayam tanpa harus bersusah payah.
Berikut ini resep Opor Ayam yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Opor Ayam:

1. Tambah 1/2 ekor ayam broiler potong potong cuci
1. Diperlukan 1 Santan Kara
1. Harus ada  Kaldu ayam, garam, 1 sdt gula pasir/ merah
1. Jangan lupa  Bawang merah goreng untuk taburan
1. Dibutuhkan  Bumbu halus
1. Dibutuhkan 4 siung bawang putih
1. Siapkan 6 siung bawang merah
1. Diperlukan 1 sdm ketumbar (bs diganti 1 sdt ketumbar bubuk)
1. Harap siapkan 5 cm ruas kunyit
1. Harus ada 1/2 sdt jinten
1. Diperlukan 4 kemiri sangrai
1. Harus ada Secukupnya merica bubuk
1. Jangan lupa  Bumbu lain
1. Harap siapkan 4 daun jeruk buang tulangnya
1. Siapkan 3 daun salam
1. Jangan lupa Seruas lengkuas, geprek
1. Harus ada 1 batang serai, geprek




<!--inarticleads2-->

##### Cara membuat  Opor Ayam:

1. Rebus ayam sebentar saja, buang airnya. kembali rebus air di panci masukkan ayam td. Banyaknya kuah rebusan sesuai selera ya bun, mau dibikin kuah kental atau encer..kl sy suka yg berkuah banyak..
1. Haluskan bumbu halus, tumis bumbu halus dengan bumbu lainnya.
1. Masukkan tumisan bumbu ke rebusan ayam,masukkan kaldu ayam merica bubuk, garam sedikit gula jawa/pasir. Masak hingga meletup.
1. Masukkan santan kara, sambil terus diaduk agar santan tdk pecah, aduk hingga matang, cek rasa.
1. Opor siap disajikan dengan taburan bawang goreng.




Demikianlah cara membuat opor ayam yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep rahasia yang sangat simple dan teruji, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
