---
description: "Langkah membuat Ayam rica rica kemangi Cepat"
title: "Langkah membuat Ayam rica rica kemangi Cepat"
slug: 377-langkah-membuat-ayam-rica-rica-kemangi-cepat
date: 2020-12-26T08:21:33.946Z
image: https://img-global.cpcdn.com/recipes/fb922f84ed590e1c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fb922f84ed590e1c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fb922f84ed590e1c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Johanna Olson
ratingvalue: 4.2
reviewcount: 23835
recipeingredient:
- "1 ekor ayamsaya pakai paha semua"
- "1 sdt garam"
- "1 1/2 sdm air jeruk nipis"
- " Bumbu halus"
- "10 butir bawang merah"
- "5 siung bawang putih"
- "15 cabai merah"
- "7 cabai rawit"
- "2 cm jahe"
- "1 buah tomat"
- " Bahan yang di cemplung"
- "2 batang serai ambil putihnya memarkan"
- "1 batang serai ambil putihnya iris tipis"
- "6 daun jeruk buang tulangnya robek kasar"
- "1 ikat kemangi petikin daun nya"
- "1/2 sdt garam"
- "1/2 sdt gula"
- "1/2 sdt kaldu jamur"
- "Sedikit air"
recipeinstructions:
- "Ayam, potong menjadi 10 bagian. Cuci bersih ayam. Tusuk2 ayam dengan garpu, agar bumbu lebih meresap. Lumuri dengan garam dan jeruk nipis. Diamkan selama 20 menit. Bilas. Lalu goreng ayam, sampai matang, jgn kering ya. Sisihkan"
- "Panaskan minyak, tumis bumbu halus, sampai matang dan harum.Masukkan bumbu cemplung"
- "Lalu masukkan ayam aduk rata. Tambahkan air dan gula pasir. Masak sampai semua bumbu mengental, masukkan kemangi, biarkan bumbu meresap. Matikan api"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 239 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/fb922f84ed590e1c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang dapat kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica rica kemangi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia

Kehangatan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica rica kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang dapat anda contoh salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Jangan lupa 1 ekor ayam*saya pakai paha semua
1. Harus ada 1 sdt garam
1. Jangan lupa 1 1/2 sdm air jeruk nipis
1. Dibutuhkan  Bumbu halus
1. Jangan lupa 10 butir bawang merah
1. Dibutuhkan 5 siung bawang putih
1. Jangan lupa 15 cabai merah
1. Dibutuhkan 7 cabai rawit
1. Diperlukan 2 cm jahe
1. Harap siapkan 1 buah tomat
1. Diperlukan  Bahan yang di cemplung
1. Dibutuhkan 2 batang serai ambil putihnya, memarkan
1. Siapkan 1 batang serai, ambil putihnya iris tipis
1. Siapkan 6 daun jeruk, buang tulangnya robek kasar
1. Tambah 1 ikat kemangi, petikin daun nya
1. Siapkan 1/2 sdt garam
1. Jangan lupa 1/2 sdt gula
1. Diperlukan 1/2 sdt kaldu jamur
1. Harap siapkan Sedikit air




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi:

1. Ayam, potong menjadi 10 bagian. Cuci bersih ayam. Tusuk2 ayam dengan garpu, agar bumbu lebih meresap. Lumuri dengan garam dan jeruk nipis. Diamkan selama 20 menit. Bilas. Lalu goreng ayam, sampai matang, jgn kering ya. Sisihkan
1. Panaskan minyak, tumis bumbu halus, sampai matang dan harum.Masukkan bumbu cemplung
1. Lalu masukkan ayam aduk rata. Tambahkan air dan gula pasir. Masak sampai semua bumbu mengental, masukkan kemangi, biarkan bumbu meresap. Matikan api




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
