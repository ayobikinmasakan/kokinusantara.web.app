---
description: "Cara singkat untuk menyiapakan Ayam Rica Rica Kemangi Luar biasa"
title: "Cara singkat untuk menyiapakan Ayam Rica Rica Kemangi Luar biasa"
slug: 333-cara-singkat-untuk-menyiapakan-ayam-rica-rica-kemangi-luar-biasa
date: 2020-12-10T01:56:03.474Z
image: https://img-global.cpcdn.com/recipes/5709beb1e5fe12a9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5709beb1e5fe12a9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5709beb1e5fe12a9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Sarah Rice
ratingvalue: 5
reviewcount: 42572
recipeingredient:
- "8 potong ayam"
- " Jeruk nipis"
- " Garam"
- " Gula"
- " Lada"
- " Kaldu jamur non msg"
- "2 Sereh geprek"
- "2 cm Laos geprek"
- "2 ikat Kemangi petiki"
- "4 bh Daun jeruk sobek"
- "2 lbr Daun salam"
- " Minyak goreng"
- " Air"
- " Bumbu halus "
- "5 siung Bawang merah"
- "3 siung bawang putih"
- "2 cm Kunyit"
- "2 cm jahe"
- "2 butir kemiri"
- "8 bh cabe merah keriting"
- "5 bh rawit merah"
recipeinstructions:
- "Cuci bersih ayam, marinasi dg air jeruk nipis. Bilas. Pisahkan."
- "Tumis bumbu halus dg minyak goreng bersama sereh, laos, daun jeruk, daun salam hingga wangi"
- "Setelah wangi, masukkan ayam. Aduk rata bolak balik. Biarkan meresap. Lalu tambahkan air secukupnya. Sy kira2 2 gelas air."
- "Tambahkan garam, gula, lada, kaldu jamur. Aduk rata. Biarkan kuah menyusut dan mengental. Pastikan ayam matang."
- "Sesaat sblm diangkat masukkan kemangi. Lalu matikan api. Siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 256 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/5709beb1e5fe12a9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau enak. Karasteristik kuliner Indonesia ayam rica rica kemangi yang penuh dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Ayam Rica Rica Kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang bisa anda contoh salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Diperlukan 8 potong ayam
1. Harap siapkan  Jeruk nipis
1. Harus ada  Garam
1. Jangan lupa  Gula
1. Tambah  Lada
1. Jangan lupa  Kaldu jamur non msg
1. Harap siapkan 2 Sereh, geprek
1. Dibutuhkan 2 cm Laos, geprek
1. Dibutuhkan 2 ikat Kemangi, petiki
1. Diperlukan 4 bh Daun jeruk, sobek
1. Dibutuhkan 2 lbr Daun salam
1. Jangan lupa  Minyak goreng
1. Tambah  Air
1. Diperlukan  Bumbu halus :
1. Siapkan 5 siung Bawang merah
1. Harap siapkan 3 siung bawang putih
1. Diperlukan 2 cm Kunyit
1. Jangan lupa 2 cm jahe
1. Siapkan 2 butir kemiri
1. Harus ada 8 bh cabe merah keriting
1. Dibutuhkan 5 bh rawit merah




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica Kemangi:

1. Cuci bersih ayam, marinasi dg air jeruk nipis. Bilas. Pisahkan.
1. Tumis bumbu halus dg minyak goreng bersama sereh, laos, daun jeruk, daun salam hingga wangi
1. Setelah wangi, masukkan ayam. Aduk rata bolak balik. Biarkan meresap. Lalu tambahkan air secukupnya. Sy kira2 2 gelas air.
1. Tambahkan garam, gula, lada, kaldu jamur. Aduk rata. Biarkan kuah menyusut dan mengental. Pastikan ayam matang.
1. Sesaat sblm diangkat masukkan kemangi. Lalu matikan api. Siap dihidangkan




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
