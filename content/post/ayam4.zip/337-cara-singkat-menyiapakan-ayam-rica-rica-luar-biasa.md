---
description: "Cara singkat menyiapakan Ayam Rica-Rica Luar biasa"
title: "Cara singkat menyiapakan Ayam Rica-Rica Luar biasa"
slug: 337-cara-singkat-menyiapakan-ayam-rica-rica-luar-biasa
date: 2021-01-16T20:23:27.735Z
image: https://img-global.cpcdn.com/recipes/ad978b01f8e440c9/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ad978b01f8e440c9/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ad978b01f8e440c9/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Jordan McCormick
ratingvalue: 4.8
reviewcount: 46273
recipeingredient:
- "500 gr ayam bagian paha dan sayap"
- "1 buah sereh geprek"
- "2 cm lengkuas geprek"
- "3 lembar daun salam"
- "2 sdt garam"
- "1/2 sdt gula"
- "2 sdt kaldu jamur"
- "secukupnya Minyak"
- "secukupnya Air"
- " Bumbu Halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "5 buah cabe merah"
- "15 buah cabe rawit"
- "2 cm kunyit"
- "2 cm jahe"
- "2 butir kemiri"
- " Tambahan "
- "1 ikat kemangi dipetik daunnya"
recipeinstructions:
- "Potong ayam sesuai selera, kucuri dengan jeruk kunci/nipis sekitar 10 menit, lalu rebus hingga empuk"
- "Goreng ayam setengah matang, lalu tiriskan"
- "Tumis bumbu halus hingga harum, masukkan sereh, lengkuas, daun salam, garam, gula, kaldu jamur"
- "Masukkan ayam, masak hingga meresap lalu tambahkan kemangi, aduk dan tes rasa"
- "Angkat dan sajikan selagi hangat, bumbu khas nusantara maknyos 😄"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 123 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/ad978b01f8e440c9/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis dan enak. Ciri khas kuliner Indonesia ayam rica-rica yang kaya dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam Rica-Rica untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang bisa anda contoh salah satunya ayam rica-rica yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Dibutuhkan 500 gr ayam (bagian paha dan sayap)
1. Jangan lupa 1 buah sereh, geprek
1. Tambah 2 cm lengkuas, geprek
1. Diperlukan 3 lembar daun salam
1. Harap siapkan 2 sdt garam
1. Harap siapkan 1/2 sdt gula
1. Siapkan 2 sdt kaldu jamur
1. Diperlukan secukupnya Minyak
1. Siapkan secukupnya Air
1. Diperlukan  Bumbu Halus :
1. Dibutuhkan 5 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Dibutuhkan 5 buah cabe merah
1. Jangan lupa 15 buah cabe rawit
1. Jangan lupa 2 cm kunyit
1. Harap siapkan 2 cm jahe
1. Diperlukan 2 butir kemiri
1. Diperlukan  Tambahan :
1. Tambah 1 ikat kemangi, dipetik daunnya




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-Rica:

1. Potong ayam sesuai selera, kucuri dengan jeruk kunci/nipis sekitar 10 menit, lalu rebus hingga empuk
1. Goreng ayam setengah matang, lalu tiriskan
1. Tumis bumbu halus hingga harum, masukkan sereh, lengkuas, daun salam, garam, gula, kaldu jamur
1. Masukkan ayam, masak hingga meresap lalu tambahkan kemangi, aduk dan tes rasa
1. Angkat dan sajikan selagi hangat, bumbu khas nusantara maknyos 😄




Demikianlah cara membuat ayam rica-rica yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
