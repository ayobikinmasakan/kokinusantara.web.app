---
description: "Resep : Ayam Rica -Rica[woku] manado Luar biasa"
title: "Resep : Ayam Rica -Rica[woku] manado Luar biasa"
slug: 473-resep-ayam-rica-ricawoku-manado-luar-biasa
date: 2020-12-16T18:36:10.547Z
image: https://img-global.cpcdn.com/recipes/d775172bb1db4686/751x532cq70/ayam-rica-ricawoku-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d775172bb1db4686/751x532cq70/ayam-rica-ricawoku-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d775172bb1db4686/751x532cq70/ayam-rica-ricawoku-manado-foto-resep-utama.jpg
author: Emilie Figueroa
ratingvalue: 4.4
reviewcount: 44026
recipeingredient:
- "300 gr ayam potong sesuai selera saya potong kecil kecil"
- "Secukupnya minyak goreng untuk menumis"
- "500 ml air"
- " Bumbu yg di haluskan"
- "7 buah cabe merah"
- "9 buah cabe rawit merah"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "2 butir kemiri"
- "1 ruas jempol jahe"
- "1/2 ruas jempol kunyit"
- "Secukupnya garamgula dan kaldu jamur"
- " Bumbu cemplung"
- "1 batang sereh"
- "4 lembar daun jeruk"
- "1 lembar daun salam"
- "2 genggam daun kemangi"
- "1/2 potong tomat hijau"
- "1/2 potong tomat merah"
- "3 lembar daun bawang iris kecilkecil"
- " Bumbu marinasi ayam"
- "Secukupnya garam"
- "Secukupnya kunyit bubuk"
- "Secukupnya bawang putih bubuk"
- "Secukupnya merica bubuk"
recipeinstructions:
- "Cuci bersih ayam kemudian bumbuin dg bumbu marinasi kemudian diamkan sekitar 10-15 menit,setelah itu goreng ayam sebentar hingga setengah matang angkat dan sisishkan"
- "Kemudian ulek bumbu yg di haluskan, bisa juga menggunakan blender(saya pake ulekan)"
- "Masukan minyak goreng kedalam wajan tunggu hingga minyak panas,kemudian masukan bumbu halus tadi beserta daun jeruk,sereh,daun salam,tunggu sampai matang dan wangi"
- "Kemudian setelah bumbu halus matang,masukan ayam aduk hingga rata,kemudian masukan air,tunggu hingga kuah mendididh,kemudian masukan garam,gula dan kaldu jamur"
- "Setelah air agak menyusut masukan daun kemangi,dan tomat kemudian masukan daun bawang,"
- "Kemudian tes rasa,dan biarkan sampai air agak mengering,Dan ayam benar2 matang,setelah matang angkat dan sajikan,"
categories:
- Recipe
tags:
- ayam
- rica
- ricawoku

katakunci: ayam rica ricawoku 
nutrition: 180 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica -Rica[woku] manado](https://img-global.cpcdn.com/recipes/d775172bb1db4686/751x532cq70/ayam-rica-ricawoku-manado-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau empuk. Karasteristik kuliner Nusantara ayam rica -rica[woku] manado yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Ayam Rica -Rica[woku] manado untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang bisa anda coba salah satunya ayam rica -rica[woku] manado yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam rica -rica[woku] manado tanpa harus bersusah payah.
Seperti resep Ayam Rica -Rica[woku] manado yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 25 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica -Rica[woku] manado:

1. Tambah 300 gr ayam potong sesuai selera (saya potong kecil- kecil)
1. Harus ada Secukupnya minyak goreng untuk menumis
1. Siapkan 500 ml air
1. Siapkan  Bumbu yg di haluskan
1. Diperlukan 7 buah cabe merah
1. Dibutuhkan 9 buah cabe rawit merah
1. Siapkan 6 siung bawang merah
1. Harap siapkan 4 siung bawang putih
1. Diperlukan 2 butir kemiri
1. Dibutuhkan 1 ruas jempol jahe
1. Jangan lupa 1/2 ruas jempol kunyit
1. Diperlukan Secukupnya garam,gula dan kaldu jamur
1. Tambah  Bumbu cemplung
1. Jangan lupa 1 batang sereh
1. Harus ada 4 lembar daun jeruk
1. Dibutuhkan 1 lembar daun salam
1. Diperlukan 2 genggam daun kemangi
1. Jangan lupa 1/2 potong tomat hijau
1. Dibutuhkan 1/2 potong tomat merah
1. Harus ada 3 lembar daun bawang iris kecil-kecil
1. Jangan lupa  Bumbu marinasi ayam
1. Siapkan Secukupnya garam
1. Tambah Secukupnya kunyit bubuk
1. Diperlukan Secukupnya bawang putih bubuk
1. Diperlukan Secukupnya merica bubuk




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica -Rica[woku] manado:

1. Cuci bersih ayam kemudian bumbuin dg bumbu marinasi kemudian diamkan sekitar 10-15 menit,setelah itu goreng ayam sebentar hingga setengah matang angkat dan sisishkan
1. Kemudian ulek bumbu yg di haluskan, bisa juga menggunakan blender(saya pake ulekan)
1. Masukan minyak goreng kedalam wajan tunggu hingga minyak panas,kemudian masukan bumbu halus tadi beserta daun jeruk,sereh,daun salam,tunggu sampai matang dan wangi
1. Kemudian setelah bumbu halus matang,masukan ayam aduk hingga rata,kemudian masukan air,tunggu hingga kuah mendididh,kemudian masukan garam,gula dan kaldu jamur
1. Setelah air agak menyusut masukan daun kemangi,dan tomat kemudian masukan daun bawang,
1. Kemudian tes rasa,dan biarkan sampai air agak mengering,Dan ayam benar2 matang,setelah matang angkat dan sajikan,




Demikianlah cara membuat ayam rica -rica[woku] manado yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan cepat, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
