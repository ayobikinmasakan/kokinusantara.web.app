---
description: "Bagaimana membuat Ayam Rica-Rica Favorite"
title: "Bagaimana membuat Ayam Rica-Rica Favorite"
slug: 312-bagaimana-membuat-ayam-rica-rica-favorite
date: 2020-12-17T04:44:40.079Z
image: https://img-global.cpcdn.com/recipes/f8b2751fa1272277/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f8b2751fa1272277/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f8b2751fa1272277/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Stephen Kelley
ratingvalue: 4
reviewcount: 7707
recipeingredient:
- "500 gr ayam baluri jeruk nipis 15 menit cuci bersih"
- "  bumbu halus "
- "7 siung bawang merah"
- "4 siung bawang putih"
- "15 buah cabai rawit merah 5 buah masukkan utuh"
- "5 buah cabai keriting"
- "2 ruas jahe  3cm"
- "2 butir kemiri"
- "  bahan lain "
- "1 bungkus penyedap rasa"
- "1/2 sdt gula"
- "1/2 sdt lada bubuk"
- "1/2 sdt ketumbar bubuk"
- "1/2 sdt kunyit bubuk"
- "1 batang serai geprek"
- "1 ruas lengkuas  3cm geprek"
- "2 lembar daun jeruk"
- "400 ml air"
recipeinstructions:
- "Siapkan bahan"
- "Tumis bumbu halus, lalu masukkan serai, lengkuas dan daun jeruk. Tumis lagi hingga harum (beri sedikit air agar bumbu lebih tanak). Masukkan ayam, aduk hingga tercampur rata. Masak di api tinggi selama 1 menit sehingga ayam berubah warna"
- "Lalu beri air, penyedap, gula, lada, ketumbar &amp; kunyit bubuk. Aduk rata biarkan hingga mendidih (jangan lupa tes rasa). Masak hingga air habis (sambil sesekali di aduk)"
- "Angkat dan sajikan"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 107 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/f8b2751fa1272277/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan enak. Ciri khas makanan Indonesia ayam rica-rica yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-Rica untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang dapat anda praktekkan salah satunya ayam rica-rica yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Dibutuhkan 500 gr ayam (baluri jeruk nipis 15 menit, cuci bersih)
1. Jangan lupa  🥥 bumbu halus :
1. Diperlukan 7 siung bawang merah
1. Dibutuhkan 4 siung bawang putih
1. Diperlukan 15 buah cabai rawit merah (5 buah masukkan utuh)
1. Dibutuhkan 5 buah cabai keriting
1. Tambah 2 ruas jahe ± 3cm
1. Harap siapkan 2 butir kemiri
1. Harap siapkan  🥥 bahan lain :
1. Harus ada 1 bungkus penyedap rasa
1. Siapkan 1/2 sdt gula
1. Siapkan 1/2 sdt lada bubuk
1. Dibutuhkan 1/2 sdt ketumbar bubuk
1. Diperlukan 1/2 sdt kunyit bubuk
1. Dibutuhkan 1 batang serai (geprek)
1. Jangan lupa 1 ruas lengkuas ± 3cm (geprek)
1. Diperlukan 2 lembar daun jeruk
1. Siapkan 400 ml air




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica:

1. Siapkan bahan
1. Tumis bumbu halus, lalu masukkan serai, lengkuas dan daun jeruk. Tumis lagi hingga harum (beri sedikit air agar bumbu lebih tanak). Masukkan ayam, aduk hingga tercampur rata. Masak di api tinggi selama 1 menit sehingga ayam berubah warna
1. Lalu beri air, penyedap, gula, lada, ketumbar &amp; kunyit bubuk. Aduk rata biarkan hingga mendidih (jangan lupa tes rasa). Masak hingga air habis (sambil sesekali di aduk)
1. Angkat dan sajikan




Demikianlah cara membuat ayam rica-rica yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
