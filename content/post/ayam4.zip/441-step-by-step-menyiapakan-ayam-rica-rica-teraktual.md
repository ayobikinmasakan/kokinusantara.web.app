---
description: "Step-by-Step menyiapakan Ayam Rica-rica teraktual"
title: "Step-by-Step menyiapakan Ayam Rica-rica teraktual"
slug: 441-step-by-step-menyiapakan-ayam-rica-rica-teraktual
date: 2020-10-10T09:42:40.328Z
image: https://img-global.cpcdn.com/recipes/d7127792a8b5fc4d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d7127792a8b5fc4d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d7127792a8b5fc4d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Bryan Maxwell
ratingvalue: 4.7
reviewcount: 45324
recipeingredient:
- "5 potong ayam"
- "secukupnya Daun kemangi"
- " Bumbu halus"
- "3 siung bawang merah"
- "2 siung bawang putih"
- "sesuai selera Cabe rawit merah"
- "1 lembar daun salam"
- "1 batang serai"
- "Seruas jahe"
- "2 lembar daun jeruk"
- "secukupnya Air"
- "secukupnya Garam kaldu jamur gula"
recipeinstructions:
- "Cuci bersih ayam yg sudah dipotong, beri perasan jeruk nipis, diamkan 15menit, cuci kembali ayam hingga bersih"
- "Ulek kasar bawang merah, bawang putih, cabe."
- "Panaskan minyak tumis bumbu yg sudah di ulek, masukan daun salam, daun jeruk, jahe, sereh, tumis hingga harum, masukan ayam, beri air secukupnya, masukan gula, garam, kaldu jamur secukupnya, masak hingga ayam matang, saat air sudah mulai asat masukan daun kemangi, aduk2, cek rasa, sajikan"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 221 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica-rica](https://img-global.cpcdn.com/recipes/d7127792a8b5fc4d/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga empuk. Ciri masakan Nusantara ayam rica-rica yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-rica untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda contoh salah satunya ayam rica-rica yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica:

1. Siapkan 5 potong ayam
1. Diperlukan secukupnya Daun kemangi
1. Tambah  Bumbu halus
1. Harap siapkan 3 siung bawang merah
1. Tambah 2 siung bawang putih
1. Siapkan sesuai selera Cabe rawit merah
1. Siapkan 1 lembar daun salam
1. Jangan lupa 1 batang serai
1. Diperlukan Seruas jahe
1. Siapkan 2 lembar daun jeruk
1. Dibutuhkan secukupnya Air
1. Diperlukan secukupnya Garam, kaldu jamur, gula




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-rica:

1. Cuci bersih ayam yg sudah dipotong, beri perasan jeruk nipis, diamkan 15menit, cuci kembali ayam hingga bersih
1. Ulek kasar bawang merah, bawang putih, cabe.
1. Panaskan minyak tumis bumbu yg sudah di ulek, masukan daun salam, daun jeruk, jahe, sereh, tumis hingga harum, masukan ayam, beri air secukupnya, masukan gula, garam, kaldu jamur secukupnya, masak hingga ayam matang, saat air sudah mulai asat masukan daun kemangi, aduk2, cek rasa, sajikan




Demikianlah cara membuat ayam rica-rica yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan cepat, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
