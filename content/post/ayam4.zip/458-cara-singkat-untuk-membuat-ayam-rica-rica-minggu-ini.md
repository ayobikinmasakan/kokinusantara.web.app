---
description: "Cara singkat untuk membuat Ayam Rica-Rica minggu ini"
title: "Cara singkat untuk membuat Ayam Rica-Rica minggu ini"
slug: 458-cara-singkat-untuk-membuat-ayam-rica-rica-minggu-ini
date: 2021-01-26T03:31:46.077Z
image: https://img-global.cpcdn.com/recipes/782ee8a5ce9660b2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/782ee8a5ce9660b2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/782ee8a5ce9660b2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: May Singleton
ratingvalue: 4
reviewcount: 47265
recipeingredient:
- "200 gram Dada Ayam"
- "Secukupnya Kunyit Bubuk"
- "Secukupnya Air Jeruk Nipis"
- "Secukupnya Garam"
- "5 buah Cabe Merah Keriting"
- "5 buah Cabe Rawit Merah"
- "3 siung Bawang Merah"
- "2 siung Bawang Putih"
- "1 cm Jahe"
- "1 cm Kunyit"
- "2 butir Kemiri"
- "2 cm Lengkuas"
- "3 batang Serai Geprek"
- "1 lembar Daun Pandan"
- "2 lembar Daun Salam"
- "2 lembar Daun Jeruk"
- "Secukupnya Gula Pasir"
- "Secukupnya Kaldu Ayam Bubuk Me Royco Ayam"
- "Secukupnya Minyak Goreng"
- "Secukupnya Air"
recipeinstructions:
- "Cuci bersih ayam dengan air mengalir, tiriskan, potong dadu. Baluri dengan kunyit bubuk, air jeruk nipis, dan garam. Diamkan selama 15 menit."
- "Panaskan minyak goreng, goreng ayam hingga setengah matang."
- "Blender kasar cabe merah keriting, cabe rawit merah, bawang merah, bawang putih, jahe, kunyit, kemiri, dan lengkuas dengan menambahkan sedikit minyak."
- "Tumis bumbu halus hingga matang dan harum. Kemudian tambahkan serai, daun pandan, daun salam, dan daun jeruk. Tumis kembali hingga layu. Masukkan ayam kemudian tumis kembali hingga matang."
- "Tambahkan sedikit air, garam, gula pasir, dan kaldu ayam bubuk. Koreksi rasa. Sisihkan."
- "Ayam rica-rica siap untuk dihidangkan."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 205 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/782ee8a5ce9660b2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan empuk. Ciri khas makanan Indonesia ayam rica-rica yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan keluarga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam Rica-Rica untuk keluarga. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang bisa anda praktekkan salah satunya ayam rica-rica yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Siapkan 200 gram Dada Ayam
1. Dibutuhkan Secukupnya Kunyit Bubuk
1. Harap siapkan Secukupnya Air Jeruk Nipis
1. Harus ada Secukupnya Garam
1. Tambah 5 buah Cabe Merah Keriting
1. Jangan lupa 5 buah Cabe Rawit Merah
1. Diperlukan 3 siung Bawang Merah
1. Diperlukan 2 siung Bawang Putih
1. Siapkan 1 cm Jahe
1. Siapkan 1 cm Kunyit
1. Siapkan 2 butir Kemiri
1. Dibutuhkan 2 cm Lengkuas
1. Tambah 3 batang Serai Geprek
1. Tambah 1 lembar Daun Pandan
1. Harus ada 2 lembar Daun Salam
1. Harus ada 2 lembar Daun Jeruk
1. Tambah Secukupnya Gula Pasir
1. Siapkan Secukupnya Kaldu Ayam Bubuk (Me: Royco Ayam)
1. Harap siapkan Secukupnya Minyak Goreng
1. Siapkan Secukupnya Air




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica:

1. Cuci bersih ayam dengan air mengalir, tiriskan, potong dadu. Baluri dengan kunyit bubuk, air jeruk nipis, dan garam. Diamkan selama 15 menit.
1. Panaskan minyak goreng, goreng ayam hingga setengah matang.
1. Blender kasar cabe merah keriting, cabe rawit merah, bawang merah, bawang putih, jahe, kunyit, kemiri, dan lengkuas dengan menambahkan sedikit minyak.
1. Tumis bumbu halus hingga matang dan harum. Kemudian tambahkan serai, daun pandan, daun salam, dan daun jeruk. Tumis kembali hingga layu. Masukkan ayam kemudian tumis kembali hingga matang.
1. Tambahkan sedikit air, garam, gula pasir, dan kaldu ayam bubuk. Koreksi rasa. Sisihkan.
1. Ayam rica-rica siap untuk dihidangkan.




Demikianlah cara membuat ayam rica-rica yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan terbukti, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
