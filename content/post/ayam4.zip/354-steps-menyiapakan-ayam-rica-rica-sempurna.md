---
description: "Steps menyiapakan Ayam Rica Rica Sempurna"
title: "Steps menyiapakan Ayam Rica Rica Sempurna"
slug: 354-steps-menyiapakan-ayam-rica-rica-sempurna
date: 2020-10-25T12:52:21.673Z
image: https://img-global.cpcdn.com/recipes/db61ba5def712174/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/db61ba5def712174/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/db61ba5def712174/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Alan Cooper
ratingvalue: 4.3
reviewcount: 31598
recipeingredient:
- "1 kg ayam saya 750 gram potong potong"
- "1 jeruk nipisambil airnya"
- "1 ikat kemangi saya ganti daun melinjo"
- "1 ikat daun bawang saya 2 batangiris"
- "7 cabe rawit utuh tambahan saya"
- "2 sereh geprek"
- "1 ruas jari lengkuasgeprek"
- "Secukupnya garam"
- "Secukupnya penyedap rasa"
- "Secukupnya gula pasir"
- " Bumbu Halus"
- "20 cabe rawit 5 cabe merah saya 10 cabe rawit"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "2 kemiri"
- "2 ruas jari jahe"
- "2 ruas jari kunyit"
- "1/2 ruas jari lengkuas"
- "2 sereh"
recipeinstructions:
- "Siapakan bahan, Potong ayam sesuai selera lalu bersihkan dan beri air perasan jeruk nipis diamkan 10 menit, sisihkan."
- "Tumis Bumbu halus, lengkuas dan sereh sampai harum. Kemudian masukan ayam, oseng hingga tercampur rata lalu tambahkan air 1 gelas, tambahkan penyedap rasa, tutup wajan dan masak hingga air susut setengah."
- "Masukkan daun melinjo, tutup kembali sebentar. Terakhir masukkan daun bawang, cabe,garam dan gula, masak hingga air menyusut. Koreksi rasa dan angkat"
- "Sajikan dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 102 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/db61ba5def712174/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica rica yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Nusantara



Keharmonisan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam Rica Rica untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang dapat anda praktekkan salah satunya ayam rica rica yang merupakan makanan favorite yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica:

1. Tambah 1 kg ayam, saya 750 gram (potong potong)
1. Tambah 1 jeruk nipis-ambil airnya
1. Harus ada 1 ikat kemangi (saya ganti daun melinjo)
1. Jangan lupa 1 ikat daun bawang (saya 2 batang)-iris
1. Diperlukan 7 cabe rawit utuh (tambahan saya)
1. Jangan lupa 2 sereh -geprek
1. Diperlukan 1 ruas jari lengkuas-geprek
1. Harus ada Secukupnya garam
1. Tambah Secukupnya penyedap rasa
1. Jangan lupa Secukupnya gula pasir
1. Tambah  Bumbu Halus:
1. Tambah 20 cabe rawit 5 cabe merah (saya 10 cabe rawit)
1. Harap siapkan 8 siung bawang merah
1. Diperlukan 5 siung bawang putih
1. Diperlukan 2 kemiri
1. Diperlukan 2 ruas jari jahe
1. Harus ada 2 ruas jari kunyit
1. Siapkan 1/2 ruas jari lengkuas
1. Tambah 2 sereh




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica:

1. Siapakan bahan, Potong ayam sesuai selera lalu bersihkan dan beri air perasan jeruk nipis diamkan 10 menit, sisihkan.
1. Tumis Bumbu halus, lengkuas dan sereh sampai harum. Kemudian masukan ayam, oseng hingga tercampur rata lalu tambahkan air 1 gelas, tambahkan penyedap rasa, tutup wajan dan masak hingga air susut setengah.
1. Masukkan daun melinjo, tutup kembali sebentar. Terakhir masukkan daun bawang, cabe,garam dan gula, masak hingga air menyusut. Koreksi rasa dan angkat
1. Sajikan dengan nasi hangat




Demikianlah cara membuat ayam rica rica yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
