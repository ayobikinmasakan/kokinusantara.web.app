---
description: "Resep : Ayam Rica Rica tanpa Kemangi teraktual"
title: "Resep : Ayam Rica Rica tanpa Kemangi teraktual"
slug: 240-resep-ayam-rica-rica-tanpa-kemangi-teraktual
date: 2020-08-19T23:13:17.496Z
image: https://img-global.cpcdn.com/recipes/51e8b54fa4f8fb9a/751x532cq70/ayam-rica-rica-tanpa-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/51e8b54fa4f8fb9a/751x532cq70/ayam-rica-rica-tanpa-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/51e8b54fa4f8fb9a/751x532cq70/ayam-rica-rica-tanpa-kemangi-foto-resep-utama.jpg
author: Sarah McDonald
ratingvalue: 4.1
reviewcount: 42567
recipeingredient:
- "1/2 ekor Ayam"
- "1 batang Daun bawang potong kecilkecil"
- "secukupnya Gula sesuai selera"
- "secukupnya Garam  sesuai selera"
- "1 batang Sereh Digeprek"
- "secukupnya Minyak untuk goreng"
- "secukupnya Air"
- " Bumbu halus"
- "4 buah Kemiri"
- "1 ruas kunyit"
- "15 buah cabai rawit"
- "2 buah cabai merah besar"
- "5 siung bawang merah"
- "3 siung bawang putih"
recipeinstructions:
- "Haluskan semua bumbu halus di ulek/blender kasar, saat blender dikasih air sedikit."
- "Cuci ayam lalu taro di wadah,Balurin ayam sedikit garam dan perasan air lemon (tunggu 5 menit an)"
- "Panas kan minyak secukupnya dengan api sedang"
- "Jika minyak sudah cukup panas, tumis bumbu halus yang sudah di ulek/blender dan masukin Sereh yang sudah di geprek. Tumis sampai harum."
- "Jika sudah harum masukin ayamnya dan dimasak sampai setengah matang (luarnya berubah warna putih) agar bumbunya juga meresap ke dalam ayam."
- "Kalau udah setengah matang ayamnya, masukin air secukupnya sampai ayam terendam."
- "Aduk agar bumbunya tidak gosong lalu ditutup pancinya agar air nya cepet surut."
- "Jika sudah sedikit surut airnya,masukin gula dan garam secukupnya (sesuai selera)"
- "Di aduk dan ditutup lagi pancinya (dilakukan berulang sampai airnya surut mengental) jangan sampai surut banget tapi yaa bund biar ada bumbunya lebih mantep."
- "Ayamnya sudah matang taburin daun bawang lalu matiin kompornya dan aduk sekali lagi."
- "Koreksi rasanya jika sudah pas bisa langsung disajikan Ayamnya bundd.."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 168 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica Rica tanpa Kemangi](https://img-global.cpcdn.com/recipes/51e8b54fa4f8fb9a/751x532cq70/ayam-rica-rica-tanpa-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau gurih. Ciri khas kuliner Nusantara ayam rica rica tanpa kemangi yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam Rica Rica tanpa Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi makanan yang dapat anda buat salah satunya ayam rica rica tanpa kemangi yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica rica tanpa kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica tanpa Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 11 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica tanpa Kemangi:

1. Diperlukan 1/2 ekor Ayam
1. Tambah 1 batang Daun bawang potong kecil-kecil
1. Dibutuhkan secukupnya Gula (sesuai selera)
1. Tambah secukupnya Garam  (sesuai selera)
1. Diperlukan 1 batang Sereh (Digeprek)
1. Harus ada secukupnya Minyak untuk goreng
1. Diperlukan secukupnya Air
1. Jangan lupa  Bumbu halus
1. Tambah 4 buah Kemiri
1. Siapkan 1 ruas kunyit
1. Dibutuhkan 15 buah cabai rawit
1. Dibutuhkan 2 buah cabai merah besar
1. Harap siapkan 5 siung bawang merah
1. Harap siapkan 3 siung bawang putih




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica tanpa Kemangi:

1. Haluskan semua bumbu halus di ulek/blender kasar, saat blender dikasih air sedikit.
1. Cuci ayam lalu taro di wadah,Balurin ayam sedikit garam dan perasan air lemon (tunggu 5 menit an)
1. Panas kan minyak secukupnya dengan api sedang
1. Jika minyak sudah cukup panas, tumis bumbu halus yang sudah di ulek/blender dan masukin Sereh yang sudah di geprek. Tumis sampai harum.
1. Jika sudah harum masukin ayamnya dan dimasak sampai setengah matang (luarnya berubah warna putih) agar bumbunya juga meresap ke dalam ayam.
1. Kalau udah setengah matang ayamnya, masukin air secukupnya sampai ayam terendam.
1. Aduk agar bumbunya tidak gosong lalu ditutup pancinya agar air nya cepet surut.
1. Jika sudah sedikit surut airnya,masukin gula dan garam secukupnya (sesuai selera)
1. Di aduk dan ditutup lagi pancinya (dilakukan berulang sampai airnya surut mengental) jangan sampai surut banget tapi yaa bund biar ada bumbunya lebih mantep.
1. Ayamnya sudah matang taburin daun bawang lalu matiin kompornya dan aduk sekali lagi.
1. Koreksi rasanya jika sudah pas bisa langsung disajikan Ayamnya bundd..




Demikianlah cara membuat ayam rica rica tanpa kemangi yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
