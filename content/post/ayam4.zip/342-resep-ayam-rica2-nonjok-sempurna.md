---
description: "Resep : Ayam rica2 nonjok Sempurna"
title: "Resep : Ayam rica2 nonjok Sempurna"
slug: 342-resep-ayam-rica2-nonjok-sempurna
date: 2020-08-25T12:59:33.121Z
image: https://img-global.cpcdn.com/recipes/d4bd489156f8d0d0/751x532cq70/ayam-rica2-nonjok-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d4bd489156f8d0d0/751x532cq70/ayam-rica2-nonjok-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d4bd489156f8d0d0/751x532cq70/ayam-rica2-nonjok-foto-resep-utama.jpg
author: Flora Horton
ratingvalue: 4
reviewcount: 46452
recipeingredient:
- "1 kg ayam"
- "7 butir Bawang merah"
- "5 siung Bawang putih"
- "1/4 kg Cabe setan"
- " Cabe besar 5 aja"
- "5 butir Kemiri"
- "secukupnya Kunyitjahelaos"
- " Daun salamdaun jeruk"
- " Sere"
- " Ketumbarmerica"
- " Daun kemangi"
recipeinstructions:
- "Potong ayam menjadi Beberapa bagian, lalu Cuci Bersih sisihkan"
- "Blander semua Bumbu, kecuali daun jeruk,sere,salam Laos dan kemangi"
- "Lalu setelah bumbu dihaluskan, tulus sampai bumbu Terasa wangi dan sedap,setelah tu masukan Laos yg sudah digeprek, dan daun jeruk, daun salam.. Kemudian setelah matang, masukan Ayam aduk2 sampai tercampur rata,kemudian Beri air dan tutup.."
- "Setelah setengah matang, masuk ana sere, tapi sebelumnya iris2 dulu ya si sere kecil2 aja.. Masak hingga matang,, setelah dirasa matang.. Masukan daun kemangi dan siap dihidangkan. Selamat mencoba.."
categories:
- Recipe
tags:
- ayam
- rica2
- nonjok

katakunci: ayam rica2 nonjok 
nutrition: 199 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam rica2 nonjok](https://img-global.cpcdn.com/recipes/d4bd489156f8d0d0/751x532cq70/ayam-rica2-nonjok-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang harus kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica2 nonjok yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan keistimewahan yang merupakan keragaman Nusantara



Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam rica2 nonjok untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda contoh salah satunya ayam rica2 nonjok yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica2 nonjok tanpa harus bersusah payah.
Berikut ini resep Ayam rica2 nonjok yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica2 nonjok:

1. Diperlukan 1 kg ayam
1. Harus ada 7 butir Bawang merah
1. Tambah 5 siung Bawang putih
1. Jangan lupa 1/4 kg Cabe setan
1. Jangan lupa  Cabe besar 5 aja
1. Tambah 5 butir Kemiri
1. Dibutuhkan secukupnya Kunyit,jahe,laos
1. Diperlukan  Daun salam,daun jeruk
1. Diperlukan  Sere
1. Dibutuhkan  Ketumbar,merica
1. Diperlukan  Daun kemangi




<!--inarticleads2-->

##### Langkah membuat  Ayam rica2 nonjok:

1. Potong ayam menjadi Beberapa bagian, lalu Cuci Bersih sisihkan
1. Blander semua Bumbu, kecuali daun jeruk,sere,salam Laos dan kemangi
1. Lalu setelah bumbu dihaluskan, tulus sampai bumbu Terasa wangi dan sedap,setelah tu masukan Laos yg sudah digeprek, dan daun jeruk, daun salam.. Kemudian setelah matang, masukan Ayam aduk2 sampai tercampur rata,kemudian Beri air dan tutup..
1. Setelah setengah matang, masuk ana sere, tapi sebelumnya iris2 dulu ya si sere kecil2 aja.. Masak hingga matang,, setelah dirasa matang.. Masukan daun kemangi dan siap dihidangkan. Selamat mencoba..




Demikianlah cara membuat ayam rica2 nonjok yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
