---
description: "Resep : Ayam rica kemangi Sempurna"
title: "Resep : Ayam rica kemangi Sempurna"
slug: 263-resep-ayam-rica-kemangi-sempurna
date: 2020-09-05T10:34:36.252Z
image: https://img-global.cpcdn.com/recipes/7969cf0328000380/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7969cf0328000380/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7969cf0328000380/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Ann Stephens
ratingvalue: 4.8
reviewcount: 23003
recipeingredient:
- "1 ekor ayam"
- " Jeruk nipis"
- "secukupnya Kemangi"
- "8 cabai merah keriting"
- "5 cabai rawit merah opsional kalau mau ekstra pedas"
- "8 bawang merah"
- "5 bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "4 kemiri"
- "1 lb daun jeruk"
- "1 lb daun salam"
- "2 batang serai"
- " Garam"
- "1 Bks Royco"
recipeinstructions:
- "Cuci bersih ayam Baluri ayam dengan jeruk nipis, diamkan selama 10 menit lalu cuci bersih kembali"
- "Blender halus, kemiri, cabai, duo bawang, jahe dan kunyit lalu tumis dengan minyak panas hingga harum"
- "Iris tipis daun jeruk dan sereh, masukkan ke dalam tumisan bumbu halus tambahkan daun salam, Royco dan garam lalu koreksi rasa"
- "Jika bumbu sudah matang masukan ayam aduk hingga seluruh ayam terkena bumbu lalu beri air hingga ayam terendam"
- "Diamkan hingga air menyusut, sesekali aduk ayam agar matang merata"
- "Setelah hampir matang masukan kemangi dan tunggu hingga layu, selesai"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 250 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/7969cf0328000380/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang harus kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa kesan tersendiri yang merupakan keragaman Kita



Keharmonisan keluarga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam rica kemangi untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang dapat anda coba salah satunya ayam rica kemangi yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Jangan lupa 1 ekor ayam
1. Tambah  Jeruk nipis
1. Siapkan secukupnya Kemangi
1. Harap siapkan 8 cabai merah keriting
1. Jangan lupa 5 cabai rawit merah (opsional kalau mau ekstra pedas)
1. Harus ada 8 bawang merah
1. Dibutuhkan 5 bawang putih
1. Jangan lupa 1 ruas jahe
1. Dibutuhkan 1 ruas kunyit
1. Dibutuhkan 4 kemiri
1. Diperlukan 1 lb daun jeruk
1. Dibutuhkan 1 lb daun salam
1. Dibutuhkan 2 batang serai
1. Tambah  Garam
1. Dibutuhkan 1 Bks Royco




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica kemangi:

1. Cuci bersih ayam Baluri ayam dengan jeruk nipis, diamkan selama 10 menit lalu cuci bersih kembali
1. Blender halus, kemiri, cabai, duo bawang, jahe dan kunyit lalu tumis dengan minyak panas hingga harum
1. Iris tipis daun jeruk dan sereh, masukkan ke dalam tumisan bumbu halus tambahkan daun salam, Royco dan garam lalu koreksi rasa
1. Jika bumbu sudah matang masukan ayam aduk hingga seluruh ayam terkena bumbu lalu beri air hingga ayam terendam
1. Diamkan hingga air menyusut, sesekali aduk ayam agar matang merata
1. Setelah hampir matang masukan kemangi dan tunggu hingga layu, selesai




Demikianlah cara membuat ayam rica kemangi yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
