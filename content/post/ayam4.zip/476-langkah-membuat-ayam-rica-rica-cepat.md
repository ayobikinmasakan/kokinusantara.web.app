---
description: "Langkah membuat Ayam rica - rica Cepat"
title: "Langkah membuat Ayam rica - rica Cepat"
slug: 476-langkah-membuat-ayam-rica-rica-cepat
date: 2020-10-20T20:51:42.180Z
image: https://img-global.cpcdn.com/recipes/283ffb7ce867e242/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/283ffb7ce867e242/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/283ffb7ce867e242/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Calvin Ramirez
ratingvalue: 4.2
reviewcount: 48460
recipeingredient:
- "1/2 ekor ayam"
- " Jeruk nipis"
- " Bahan halus "
- "5 siung bawang merah"
- "3 siung bawang putih"
- "2 buah cabe besar"
- "5 cabe rawit"
- " Pelengkap "
- "1 lembar daun salam"
- "3 lembar daun jeruk"
- " Serai geprok"
recipeinstructions:
- "Potong ayam beberapa bagian lalu cuci bersih, lumuri jeruk nipis lalu bilas kembali dan siapkan bahan lain nya"
- "Blender bumbu halus kemudian tumis"
- "Tumis daun salam, daun jeruk dan serai sampai harum,kemudian masukkan air kurleb 400ml"
- "Masukkan ayam lalu ungkep kurleb 15menit"
- "Jika dirasa sdh empuk tambahkan gula garam secukupnya.Aduk rata dan koreksi rasa. Ayam rica - rica siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 184 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam rica - rica](https://img-global.cpcdn.com/recipes/283ffb7ce867e242/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica - rica yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan keistimewahan yang merupakan keragaman Indonesia

Keharmonisan keluarga bisa diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam rica - rica untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang dapat anda coba salah satunya ayam rica - rica yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan cepat menemukan resep ayam rica - rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica - rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 11 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica - rica:

1. Dibutuhkan 1/2 ekor ayam
1. Diperlukan  Jeruk nipis
1. Tambah  Bahan halus :
1. Jangan lupa 5 siung bawang merah
1. Jangan lupa 3 siung bawang putih
1. Dibutuhkan 2 buah cabe besar
1. Siapkan 5 cabe rawit
1. Jangan lupa  Pelengkap :
1. Siapkan 1 lembar daun salam
1. Tambah 3 lembar daun jeruk
1. Siapkan  Serai geprok




<!--inarticleads2-->

##### Cara membuat  Ayam rica - rica:

1. Potong ayam beberapa bagian lalu cuci bersih, lumuri jeruk nipis lalu bilas kembali dan siapkan bahan lain nya
1. Blender bumbu halus kemudian tumis
1. Tumis daun salam, daun jeruk dan serai sampai harum,kemudian masukkan air kurleb 400ml
1. Masukkan ayam lalu ungkep kurleb 15menit
1. Jika dirasa sdh empuk tambahkan gula garam secukupnya.Aduk rata dan koreksi rasa. Ayam rica - rica siap dihidangkan




Demikianlah cara membuat ayam rica - rica yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
