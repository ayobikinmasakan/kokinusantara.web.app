---
description: "Steps membuat Ayam Rica-Rica Khas Manado terupdate"
title: "Steps membuat Ayam Rica-Rica Khas Manado terupdate"
slug: 444-steps-membuat-ayam-rica-rica-khas-manado-terupdate
date: 2020-08-08T07:04:17.097Z
image: https://img-global.cpcdn.com/recipes/ea686990db8b4218/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ea686990db8b4218/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ea686990db8b4218/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg
author: Christina Soto
ratingvalue: 4
reviewcount: 41099
recipeingredient:
- "1 ekor Ayam"
- " Bumbu Marinasi"
- "2 buah Jeruk Nipis"
- "1 sdm Garam"
- "1 sdm Kunyit Bubuk  2 ruas jari Kunyit Segar yg dihaluskan"
- " Bumbu Halus"
- "1 ons Cabai Merah  Keriting"
- "1/2 ons Cabai Rawit"
- "5 siung Bawang Merah"
- "5 siung Bawang Putih"
- "1 ruas jari Jahe"
- "1 ruas jari Kunyit"
- "1 ruas jari Lengkuas"
- "3 butir Kemiri"
- " Bumbu Pelengkap"
- "3 batang Serai geprek"
- "1 lembar Daun Pandan simpulkan"
- "5 lembar Daun Salam"
- "5 lembar Daun Jeruk iris tipis"
- "2 batang Daun Bawang"
- "2 ikat Daun Kemangi petiki"
- " Bahan Tambahan"
- "1 sdt Garam"
- "1/2 sdt Kaldu"
- "1 sdm Gula Pasir"
- "400 ml Air"
- "5 sdm Minyak Goreng"
recipeinstructions:
- "Marinasi Ayam selama 10 menit. Lalu goreng setengah kering, tiriskan"
- "Tumis bumbu halus dan masukkan bumbu pelengkapnya (kecuali daun kemangi) hingga harum"
- "Beri Air dan masukkan ayam gorengnya"
- "Beri gula, garam, dan kaldunya. Koreksi rasa, masak hingga kuahnya meresap dan asat, baru masukkan daun kemangi aduk sebentar dan matikan api (gunakan api sedang)"
- "Siap disajikan dan Selamat Menikmati"
categories:
- Recipe
tags:
- ayam
- ricarica
- khas

katakunci: ayam ricarica khas 
nutrition: 256 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Rica-Rica Khas Manado](https://img-global.cpcdn.com/recipes/ea686990db8b4218/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis dan renyah. Ciri kuliner Indonesia ayam rica-rica khas manado yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Ayam Rica-Rica Khas Manado untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang dapat anda contoh salah satunya ayam rica-rica khas manado yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam rica-rica khas manado tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Khas Manado yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 27 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Khas Manado:

1. Tambah 1 ekor Ayam
1. Dibutuhkan  Bumbu Marinasi
1. Tambah 2 buah Jeruk Nipis
1. Dibutuhkan 1 sdm Garam
1. Jangan lupa 1 sdm Kunyit Bubuk / 2 ruas jari Kunyit Segar yg dihaluskan
1. Diperlukan  Bumbu Halus
1. Harap siapkan 1 ons Cabai Merah / Keriting
1. Jangan lupa 1/2 ons Cabai Rawit
1. Harus ada 5 siung Bawang Merah
1. Diperlukan 5 siung Bawang Putih
1. Harus ada 1 ruas jari Jahe
1. Jangan lupa 1 ruas jari Kunyit
1. Harus ada 1 ruas jari Lengkuas
1. Harap siapkan 3 butir Kemiri
1. Harap siapkan  Bumbu Pelengkap
1. Harap siapkan 3 batang Serai (geprek)
1. Tambah 1 lembar Daun Pandan (simpulkan)
1. Tambah 5 lembar Daun Salam
1. Jangan lupa 5 lembar Daun Jeruk (iris tipis)
1. Dibutuhkan 2 batang Daun Bawang
1. Siapkan 2 ikat Daun Kemangi (petiki)
1. Diperlukan  Bahan Tambahan
1. Tambah 1 sdt Garam
1. Diperlukan 1/2 sdt Kaldu
1. Jangan lupa 1 sdm Gula Pasir
1. Jangan lupa 400 ml Air
1. Harus ada 5 sdm Minyak Goreng




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica Khas Manado:

1. Marinasi Ayam selama 10 menit. Lalu goreng setengah kering, tiriskan
1. Tumis bumbu halus dan masukkan bumbu pelengkapnya (kecuali daun kemangi) hingga harum
1. Beri Air dan masukkan ayam gorengnya
1. Beri gula, garam, dan kaldunya. Koreksi rasa, masak hingga kuahnya meresap dan asat, baru masukkan daun kemangi aduk sebentar dan matikan api (gunakan api sedang)
1. Siap disajikan dan Selamat Menikmati




Demikianlah cara membuat ayam rica-rica khas manado yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan cepat, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
