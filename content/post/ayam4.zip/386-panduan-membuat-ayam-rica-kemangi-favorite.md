---
description: "Panduan membuat Ayam Rica Kemangi Favorite"
title: "Panduan membuat Ayam Rica Kemangi Favorite"
slug: 386-panduan-membuat-ayam-rica-kemangi-favorite
date: 2020-09-29T10:22:49.949Z
image: https://img-global.cpcdn.com/recipes/5dd8a41dd6bea65b/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5dd8a41dd6bea65b/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5dd8a41dd6bea65b/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Lilly Hammond
ratingvalue: 5
reviewcount: 17022
recipeingredient:
- "4 ekor ayam"
- "4 ikat kemangi"
- "1 ruas lengkuas geprek"
- "1 btg sereh geprek"
- "5 lmbr daun jeruk"
- "1 btg daun bawang iris"
- "Secukupnya garam kaldu jamur"
- "Secukupnya air"
- " Bumbu Halus "
- "5 siung bawang merah"
- "2 siung bawang putih"
- "6 bh cabe merah kriting"
- "15 bh cabe rawit setan optional"
- "2 btr kemiri"
- "Secukupnya jahe  kunyit"
- "Secukupnya gula merah"
recipeinstructions:
- "Siapkan wajan dan panaskan minyak"
- "Masukan bumbu halus, lengkuas, sereh, dan daun jeruk.. masak hingga harum"
- "Jika sdh harum masukan potongan ayam yg sdh di bersihkan, lalu beri air secukupnya"
- "Diamkan hingga ayam matang dan empuk, jika sdh mpuk beri garam dan kaldu jamur.."
- "Aduk&#34;hingga tercampur rata lalu cicipi, stlh rasa nya ok.. masukan kemangi dan daun bawang.. aduk&#34; lagi sebentar lalu matikan kompor.."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 143 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/5dd8a41dd6bea65b/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah menampilkan keistimewahan yang merupakan keragaman Indonesia

Keharmonisan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica Kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang bisa anda coba salah satunya ayam rica kemangi yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Harus ada 4 ekor ayam
1. Tambah 4 ikat kemangi
1. Siapkan 1 ruas lengkuas (geprek)
1. Tambah 1 btg sereh (geprek)
1. Harus ada 5 lmbr daun jeruk
1. Harus ada 1 btg daun bawang (iris)
1. Tambah Secukupnya garam, kaldu jamur
1. Dibutuhkan Secukupnya air
1. Jangan lupa  Bumbu Halus :
1. Harus ada 5 siung bawang merah
1. Siapkan 2 siung bawang putih
1. Diperlukan 6 bh cabe merah kriting
1. Harap siapkan 15 bh cabe rawit setan (optional)
1. Jangan lupa 2 btr kemiri
1. Tambah Secukupnya jahe &amp; kunyit
1. Tambah Secukupnya gula merah




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Kemangi:

1. Siapkan wajan dan panaskan minyak
1. Masukan bumbu halus, lengkuas, sereh, dan daun jeruk.. masak hingga harum
1. Jika sdh harum masukan potongan ayam yg sdh di bersihkan, lalu beri air secukupnya
1. Diamkan hingga ayam matang dan empuk, jika sdh mpuk beri garam dan kaldu jamur..
1. Aduk&#34;hingga tercampur rata lalu cicipi, stlh rasa nya ok.. masukan kemangi dan daun bawang.. aduk&#34; lagi sebentar lalu matikan kompor..




Demikianlah cara membuat ayam rica kemangi yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
