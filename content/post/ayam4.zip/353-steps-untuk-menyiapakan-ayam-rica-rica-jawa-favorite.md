---
description: "Steps untuk menyiapakan Ayam rica rica jawa Favorite"
title: "Steps untuk menyiapakan Ayam rica rica jawa Favorite"
slug: 353-steps-untuk-menyiapakan-ayam-rica-rica-jawa-favorite
date: 2021-01-18T17:07:12.118Z
image: https://img-global.cpcdn.com/recipes/98ca6693605b5b29/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/98ca6693605b5b29/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/98ca6693605b5b29/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg
author: Cecelia Dawson
ratingvalue: 4.7
reviewcount: 15006
recipeingredient:
- "1/2 kg ayam potong agak kecil"
- "7 butir bawang merah"
- "4 butir bawang putih"
- "10 cabe merah keriting"
- "7 biji cabe rawit setan"
- "3 butir kemiri"
- "1 lembar daun jeruksalam"
- "1 batang serai memarkan"
- "1 ruas jari lengkuas memarkan"
- "2-3 sdm kecap bngo"
- "Secukupnya garam gula penyedap merica"
recipeinstructions:
- "Rebus ayam kemudian tiriskan,"
- "Haluskan bawang merah putih, cabe, kemiri kemudian tumis beserta daun jeruk+salam+lengkuas+serai"
- "Setelah bumbu matang masukkan ayam dan aduk², tunggu sebentar kemudian tambahkan air+garam+gula+penyedap aduk² tunggu sampai menyusut"
- "Jika sudah menyusut, tambahkan kecap manis dan air lagi, aduk² lagi dan tunggu sampai air menyusut, tambahkan merica bubuk secukupnya aja"
- "Kalo suka tekstur rica kering, aduk² sampai benar² air menyusut, kalo saya lebih suka yg agak nyemek gini ya bun, mantap bangett..."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 247 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT50M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica rica jawa](https://img-global.cpcdn.com/recipes/98ca6693605b5b29/751x532cq70/ayam-rica-rica-jawa-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica rica jawa yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara



Keharmonisan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica rica jawa untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang dapat anda praktekkan salah satunya ayam rica rica jawa yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica rica jawa tanpa harus bersusah payah.
Seperti resep Ayam rica rica jawa yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica jawa:

1. Jangan lupa 1/2 kg ayam potong² agak kecil
1. Harap siapkan 7 butir bawang merah
1. Jangan lupa 4 butir bawang putih
1. Harap siapkan 10 cabe merah keriting
1. Harap siapkan 7 biji cabe rawit setan
1. Harap siapkan 3 butir kemiri
1. Diperlukan 1 lembar daun jeruk+salam
1. Jangan lupa 1 batang serai memarkan
1. Harus ada 1 ruas jari lengkuas memarkan
1. Jangan lupa 2-3 sdm kecap b*ngo
1. Jangan lupa Secukupnya garam gula penyedap merica




<!--inarticleads2-->

##### Cara membuat  Ayam rica rica jawa:

1. Rebus ayam kemudian tiriskan,
1. Haluskan bawang merah putih, cabe, kemiri kemudian tumis beserta daun jeruk+salam+lengkuas+serai
1. Setelah bumbu matang masukkan ayam dan aduk², tunggu sebentar kemudian tambahkan air+garam+gula+penyedap aduk² tunggu sampai menyusut
1. Jika sudah menyusut, tambahkan kecap manis dan air lagi, aduk² lagi dan tunggu sampai air menyusut, tambahkan merica bubuk secukupnya aja
1. Kalo suka tekstur rica kering, aduk² sampai benar² air menyusut, kalo saya lebih suka yg agak nyemek gini ya bun, mantap bangett...




Demikianlah cara membuat ayam rica rica jawa yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
