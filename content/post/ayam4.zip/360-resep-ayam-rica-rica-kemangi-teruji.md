---
description: "Resep : Ayam rica-rica kemangi Teruji"
title: "Resep : Ayam rica-rica kemangi Teruji"
slug: 360-resep-ayam-rica-rica-kemangi-teruji
date: 2021-01-21T18:15:04.425Z
image: https://img-global.cpcdn.com/recipes/090d3daa66c1fffc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/090d3daa66c1fffc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/090d3daa66c1fffc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Frederick Sanchez
ratingvalue: 4.2
reviewcount: 41703
recipeingredient:
- "1 kg ayam"
- "secukupnya Jeruk nipis"
- "3 ikat Kemangi"
- "7 lembar Daun jeruk"
- "1 batang Sereh"
- " Lengkuas 1 ruas geprek"
- "secukupnya Garam gula  penyedap"
- " Air untuk mengungkep ayam"
- " Bumbu halus "
- "3 Cabe merah besar"
- "5 Cabe keriting"
- " Cabe rawit merah 5 optional kalau suka pedas"
- "8 Bawang merah"
- "4 Bawang putih"
- "secukupnya Jahe  kunyit"
- "3 butir Kemiri"
- " Minyak goreng untuk menumis bumbu"
recipeinstructions:
- "Potong ayam sesuai selera, cuci dan bersihkan lalu lumuri dengan jeruk nipis diamkan -+ 10menit lalu bilas sampai bersih"
- "Haluskan semua bumbu lalu masukkan juga bumbu tambahan daun jeruk, sereh, lengkuas dan tumis hingga harum"
- "Setelah itu masukan ayam kedalam bumbu tumis tadi, lalu aduk2 dan beri air sampai ayam terendam, ungkep sampai matang dan tambahkan garam, gula, penyedap, tes rasa"
- "Kalau air sudah agak menyusut dan ayam sudah matang, campurkan daun kemangi lalu aduk sampai rata"
- "Ayam siap d sajikan.. Selamat mencoba 😊"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 150 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/090d3daa66c1fffc/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis dan renyah. Karasteristik masakan Nusantara ayam rica-rica kemangi yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kehangatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Ayam rica-rica kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda buat salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Harap siapkan 1 kg ayam
1. Diperlukan secukupnya Jeruk nipis
1. Dibutuhkan 3 ikat Kemangi
1. Dibutuhkan 7 lembar Daun jeruk
1. Jangan lupa 1 batang Sereh
1. Jangan lupa  Lengkuas 1 ruas (geprek)
1. Tambah secukupnya Garam, gula &amp; penyedap
1. Jangan lupa  Air untuk mengungkep ayam
1. Harus ada  Bumbu halus :
1. Dibutuhkan 3 Cabe merah besar
1. Harus ada 5 Cabe keriting
1. Tambah  Cabe rawit merah 5 (optional kalau suka pedas)
1. Harap siapkan 8 Bawang merah
1. Harap siapkan 4 Bawang putih
1. Dibutuhkan secukupnya Jahe &amp; kunyit
1. Siapkan 3 butir Kemiri
1. Harus ada  Minyak goreng untuk menumis bumbu




<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica kemangi:

1. Potong ayam sesuai selera, cuci dan bersihkan lalu lumuri dengan jeruk nipis diamkan -+ 10menit lalu bilas sampai bersih
1. Haluskan semua bumbu lalu masukkan juga bumbu tambahan daun jeruk, sereh, lengkuas dan tumis hingga harum
1. Setelah itu masukan ayam kedalam bumbu tumis tadi, lalu aduk2 dan beri air sampai ayam terendam, ungkep sampai matang dan tambahkan garam, gula, penyedap, tes rasa
1. Kalau air sudah agak menyusut dan ayam sudah matang, campurkan daun kemangi lalu aduk sampai rata
1. Ayam siap d sajikan.. Selamat mencoba 😊




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
