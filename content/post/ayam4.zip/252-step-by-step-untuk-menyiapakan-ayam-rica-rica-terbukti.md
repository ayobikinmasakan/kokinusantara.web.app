---
description: "Step-by-Step untuk menyiapakan Ayam Rica-Rica Terbukti"
title: "Step-by-Step untuk menyiapakan Ayam Rica-Rica Terbukti"
slug: 252-step-by-step-untuk-menyiapakan-ayam-rica-rica-terbukti
date: 2021-02-05T08:03:59.310Z
image: https://img-global.cpcdn.com/recipes/360b274ba8751abf/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/360b274ba8751abf/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/360b274ba8751abf/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Lou Gordon
ratingvalue: 5
reviewcount: 36112
recipeingredient:
- "1/2 Ekor Ayam"
- "8 Siung Bawang Merah"
- "5 Siung Bawang Putih"
- "1 Lengkuas Memarkan"
- "2 Daun jeruk  2 Daun Salam"
- "1 Sereh Memarkan"
- "3 Buah Kemiri"
- "Secukupnya Lada Bubuk"
- "Secukupnya Air"
- " Garam"
- " Gula pasir"
- " Penyedap Rasa me Kaldu Jamur Totole"
- "5 Cabe Caplak"
- "8 Cabe Merah"
- "2-3 Sdm Kecap Bango"
recipeinstructions:
- "Potong Ayam terlebih dahulu, cuci, lalu rebus hingga mendidih dan sisihkan"
- "Haluskan pakai blender bahan berikut bawang putih, bawang merah, kemiri, cabe. Lalu tumis sampai matang"
- "Masukkan ayam yang telah di rebus sebentar lalu tambahkan air secukupnya. Tambahkan garam, gula, penyedap rasa hingga air menyusut"
- "Lalu tambahkan air lagi sampai menyusut, tambahkan kecap dan masukkan lada bubuk secukupnya. Koreksi rasa"
- "Ayam Rica-Rica siap dihidangkan menggunakan nasi panas"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 185 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/360b274ba8751abf/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang dapat kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica-rica yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa kesan tersendiri yang merupakan keragaman Nusantara



Kehangatan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-Rica untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang dapat anda coba salah satunya ayam rica-rica yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Siapkan 1/2 Ekor Ayam
1. Jangan lupa 8 Siung Bawang Merah
1. Diperlukan 5 Siung Bawang Putih
1. Diperlukan 1 Lengkuas (Memarkan)
1. Harus ada 2 Daun jeruk + 2 Daun Salam
1. Diperlukan 1 Sereh (Memarkan)
1. Jangan lupa 3 Buah Kemiri
1. Jangan lupa Secukupnya Lada Bubuk
1. Diperlukan Secukupnya Air
1. Siapkan  Garam
1. Siapkan  Gula pasir
1. Harus ada  Penyedap Rasa (me: Kaldu Jamur Totole)
1. Jangan lupa 5 Cabe Caplak
1. Harus ada 8 Cabe Merah
1. Dibutuhkan 2-3 Sdm Kecap Bango




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica-Rica:

1. Potong Ayam terlebih dahulu, cuci, lalu rebus hingga mendidih dan sisihkan
1. Haluskan pakai blender bahan berikut bawang putih, bawang merah, kemiri, cabe. Lalu tumis sampai matang
1. Masukkan ayam yang telah di rebus sebentar lalu tambahkan air secukupnya. Tambahkan garam, gula, penyedap rasa hingga air menyusut
1. Lalu tambahkan air lagi sampai menyusut, tambahkan kecap dan masukkan lada bubuk secukupnya. Koreksi rasa
1. Ayam Rica-Rica siap dihidangkan menggunakan nasi panas




Demikianlah cara membuat ayam rica-rica yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
