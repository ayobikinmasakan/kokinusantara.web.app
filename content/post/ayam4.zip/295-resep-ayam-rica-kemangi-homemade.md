---
description: "Resep : Ayam rica kemangi Homemade"
title: "Resep : Ayam rica kemangi Homemade"
slug: 295-resep-ayam-rica-kemangi-homemade
date: 2020-08-27T04:22:38.054Z
image: https://img-global.cpcdn.com/recipes/ddb9acf88a0961fa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ddb9acf88a0961fa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ddb9acf88a0961fa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Maggie Schultz
ratingvalue: 4.7
reviewcount: 39661
recipeingredient:
- "1/2 ekor ayam potong sesuai selera"
- "1 buah jeruk nipis"
- "1 buah tomat potongpotong"
- "Seruas jahe geprek"
- " Daun salam"
- " Daun jeruk"
- "Sebatang sereh"
- " Daun kunyit saya skip  gk ada stok"
- " Lengkuas geprek"
- "3 ikat daun kemangisaya suka banyak kemangi"
- "1 batang daun bawang"
- " Bumbu halussaya uleg sedikit kasar"
- "8 buah cabe rawit merah"
- "6 buah cabe merah"
- "6 butir bawang merah"
- "3 siung bawang putih"
- "3 butir kemiri sangrai"
- "sedikit Kunyit"
- "secukupnya Garam gula"
recipeinstructions:
- "Cuci bersih ayam dan lumuri dengan air perasan jeruk nipis dan garam, diamkan sebentar"
- "Goreng ayam setengah matang, sisihkan."
- "Tumis bumbu halus aduk masukkan daun jeruk, salam, sereh lengkuas jahe.tumis sampai harum dan matang"
- "Masukkan ayam aduk rata tambahkan sedikit air, masak dengan api kecil sampai bumbu meresap"
- "Masukkan gula garam,daun bawang, tomat,daun kemangi.aduk rata,tes rasa.angkat sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 298 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/ddb9acf88a0961fa/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga gurih. Ciri khas kuliner Indonesia ayam rica kemangi yang kaya dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap.

Keharmonisan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam rica kemangi untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi masakan yang dapat anda buat salah satunya ayam rica kemangi yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica kemangi:

1. Tambah 1/2 ekor ayam potong sesuai selera
1. Tambah 1 buah jeruk nipis
1. Harus ada 1 buah tomat potong-potong
1. Dibutuhkan Seruas jahe geprek
1. Tambah  Daun salam
1. Harap siapkan  Daun jeruk
1. Jangan lupa Sebatang sereh
1. Diperlukan  Daun kunyit (saya skip / gk ada stok)
1. Dibutuhkan  Lengkuas geprek
1. Tambah 3 ikat daun kemangi(saya suka banyak kemangi)
1. Jangan lupa 1 batang daun bawang
1. Tambah  Bumbu halus(saya uleg sedikit kasar):
1. Harus ada 8 buah cabe rawit merah
1. Tambah 6 buah cabe merah
1. Dibutuhkan 6 butir bawang merah
1. Dibutuhkan 3 siung bawang putih
1. Dibutuhkan 3 butir kemiri sangrai
1. Jangan lupa sedikit Kunyit
1. Jangan lupa secukupnya Garam gula


Perlu kamu ketahui bahwa di luar negeri mungkin daun basil sangat terkenal untuk campuran makanan. Akan tetapi, di Indonesia juga memiliki daun kemangi merupakan. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica kemangi:

1. Cuci bersih ayam dan lumuri dengan air perasan jeruk nipis dan garam, diamkan sebentar
1. Goreng ayam setengah matang, sisihkan.
1. Tumis bumbu halus aduk masukkan daun jeruk, salam, sereh lengkuas jahe.tumis sampai harum dan matang
1. Masukkan ayam aduk rata tambahkan sedikit air, masak dengan api kecil sampai bumbu meresap
1. Masukkan gula garam,daun bawang, tomat,daun kemangi.aduk rata,tes rasa.angkat sajikan


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat. 

Demikianlah cara membuat ayam rica kemangi yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
