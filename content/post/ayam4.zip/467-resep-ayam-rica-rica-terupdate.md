---
description: "Resep : Ayam Rica-Rica terupdate"
title: "Resep : Ayam Rica-Rica terupdate"
slug: 467-resep-ayam-rica-rica-terupdate
date: 2020-10-22T15:07:38.436Z
image: https://img-global.cpcdn.com/recipes/2986277087ddda2b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2986277087ddda2b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2986277087ddda2b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Charlotte Hanson
ratingvalue: 4.4
reviewcount: 4894
recipeingredient:
- "1/2 kg ayam"
- "Secukupnya minyak menumis"
- "Secukupnya air"
- " Bumbu Tabur"
- "1 sdt garam"
- "1 sdm gula"
- "1/2 sdt micin optional"
- " Bumbu Halus"
- "5 siung bawang putih"
- "7 siung bawang merah"
- "2 buah cabe besar"
- "10 buah cabe rawit"
- "1 buah tomat"
- "1 ruas jahe"
- "1 ruas kunyit"
- " Daun Aromatik"
- "1 buah serai geprek"
- "3 lembar daun jeruk"
- "1 ruas lengkuas geprek"
- "1 genggam daun kemangi"
recipeinstructions:
- "Siapkan bahan. Blender sampai halus."
- "Panaskan minyak, tumis bumbu halus dengan daun jeruk, lengkuas dan serai. Masukkan ayam, aduk secara merata. Lalu tambahkan air dan bumbu tabur. Tutup wajan, biarkan ayam mateng dan air menyusut"
- "Terakhir masukkan daun kemangi. Koreksi rasa. Sajikan👌"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 106 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/2986277087ddda2b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang dapat kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica-rica yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa keistimewahan yang merupakan keragaman Nusantara

Keharmonisan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica-Rica untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak variasi resep yang dapat anda coba salah satunya ayam rica-rica yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica:

1. Tambah 1/2 kg ayam
1. Tambah Secukupnya minyak (menumis)
1. Jangan lupa Secukupnya air
1. Harap siapkan  Bumbu Tabur
1. Diperlukan 1 sdt garam
1. Diperlukan 1 sdm gula
1. Siapkan 1/2 sdt micin (optional)
1. Dibutuhkan  Bumbu Halus
1. Tambah 5 siung bawang putih
1. Siapkan 7 siung bawang merah
1. Harus ada 2 buah cabe besar
1. Jangan lupa 10 buah cabe rawit
1. Tambah 1 buah tomat
1. Siapkan 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Diperlukan  Daun Aromatik
1. Siapkan 1 buah serai (geprek)
1. Harap siapkan 3 lembar daun jeruk
1. Siapkan 1 ruas lengkuas (geprek)
1. Tambah 1 genggam daun kemangi




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica:

1. Siapkan bahan. Blender sampai halus.
1. Panaskan minyak, tumis bumbu halus dengan daun jeruk, lengkuas dan serai. Masukkan ayam, aduk secara merata. Lalu tambahkan air dan bumbu tabur. Tutup wajan, biarkan ayam mateng dan air menyusut
1. Terakhir masukkan daun kemangi. Koreksi rasa. Sajikan👌




Demikianlah cara membuat ayam rica-rica yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
