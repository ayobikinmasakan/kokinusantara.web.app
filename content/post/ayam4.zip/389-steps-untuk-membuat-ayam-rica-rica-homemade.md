---
description: "Steps untuk membuat Ayam Rica Rica Homemade"
title: "Steps untuk membuat Ayam Rica Rica Homemade"
slug: 389-steps-untuk-membuat-ayam-rica-rica-homemade
date: 2020-11-21T06:16:05.631Z
image: https://img-global.cpcdn.com/recipes/c8eaf65a4d30f698/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c8eaf65a4d30f698/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c8eaf65a4d30f698/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Seth Hayes
ratingvalue: 5
reviewcount: 40620
recipeingredient:
- "500 gr daging ayam"
- "1/2 tsp kunyit bubuk"
- "1/2 tsp garam"
- " Bumbu rempah"
- "2 lbr daun salam"
- "2 lbr daun jeruk"
- "1 btg sereh geprek"
- "1 ruas lengkuas iris"
- "1 btg daun bawang iris"
- "Secukupnya kemangi optional"
- "1 tsp garam"
- "1 tsp kaldu bubuk"
- "400 ml air"
- "Sejumput gula pasir"
- " Bumbu halus"
- "6 siung bw merah"
- "3 siung bw putih"
- "2 btr kemiri sangrai"
- "1/2 ruas jari jahe"
- "15 bh cabe merah"
- "8 bh cabe rawit"
recipeinstructions:
- "Bersihkan daging ayam, tambahkan garam dan kunyit bubuk (kunyit dihaluskan) aduk rata kemudian marinate selama 15 menit agar bumbu meresap lalu goreng hingga matang, angkat dan tiriskan"
- "Panaskan minyak, masukkan bumbu yang sudah dihaluskan (tidak usah terlalu halus) lalu masukkan bumbu rempah, tumis bumbu hingga matang"
- "Tambahkan air lalu masukkan ayam yang sudah digoreng, tambahkan garam, kaldu bubuk, merica dan gula pasir kemudian aduk rata dan masak hingga matang (bumbu menyerap ke daging ayam)"
- "Setelah air dan bumbu menyusut tambahkan daun bawang dan kemangi aduk rata sebentar lalu sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 203 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/c8eaf65a4d30f698/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau empuk. Ciri kuliner Indonesia ayam rica rica yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Ayam Rica Rica untuk orang di rumah. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang bisa anda contoh salah satunya ayam rica rica yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica:

1. Tambah 500 gr daging ayam
1. Harap siapkan 1/2 tsp kunyit bubuk
1. Harap siapkan 1/2 tsp garam
1. Harus ada  Bumbu rempah:
1. Harap siapkan 2 lbr daun salam
1. Siapkan 2 lbr daun jeruk
1. Siapkan 1 btg sereh (geprek)
1. Harap siapkan 1 ruas lengkuas (iris)
1. Tambah 1 btg daun bawang (iris)
1. Jangan lupa Secukupnya kemangi (optional)
1. Tambah 1 tsp garam
1. Siapkan 1 tsp kaldu bubuk
1. Siapkan 400 ml air
1. Harap siapkan Sejumput gula pasir
1. Tambah  Bumbu halus:
1. Dibutuhkan 6 siung bw merah
1. Siapkan 3 siung bw putih
1. Dibutuhkan 2 btr kemiri (sangrai)
1. Harus ada 1/2 ruas jari jahe
1. Harus ada 15 bh cabe merah
1. Dibutuhkan 8 bh cabe rawit




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica:

1. Bersihkan daging ayam, tambahkan garam dan kunyit bubuk (kunyit dihaluskan) aduk rata kemudian marinate selama 15 menit agar bumbu meresap lalu goreng hingga matang, angkat dan tiriskan
1. Panaskan minyak, masukkan bumbu yang sudah dihaluskan (tidak usah terlalu halus) lalu masukkan bumbu rempah, tumis bumbu hingga matang
1. Tambahkan air lalu masukkan ayam yang sudah digoreng, tambahkan garam, kaldu bubuk, merica dan gula pasir kemudian aduk rata dan masak hingga matang (bumbu menyerap ke daging ayam)
1. Setelah air dan bumbu menyusut tambahkan daun bawang dan kemangi aduk rata sebentar lalu sajikan




Demikianlah cara membuat ayam rica rica yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
