---
description: "Bagaimana membuat Ayam Rica Rica Cepat"
title: "Bagaimana membuat Ayam Rica Rica Cepat"
slug: 438-bagaimana-membuat-ayam-rica-rica-cepat
date: 2020-09-23T03:35:32.285Z
image: https://img-global.cpcdn.com/recipes/2adc3c180bf74271/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2adc3c180bf74271/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2adc3c180bf74271/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Bernice Logan
ratingvalue: 4.5
reviewcount: 30275
recipeingredient:
- "1 ekor ayam potong 12"
- "sejempol Jahe"
- "2 btg serai geprek"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 buah tomat besar"
- "1 siung daun bawang"
- "1 ikat kemangi kl saya skip krn bwt anak"
- "secukupnya Garamgula dan penyedap"
- " Bumbu Halus "
- "6 siung bawang merah"
- "4 siung bawang putih"
- "2 butir kemiri"
- "6 buah cabe  sesuai selera"
- "secukupnya Air"
recipeinstructions:
- "Cuci bersih ayam lalu lumurin air perasan air jeruk diemkan slm kurleb 10menit lalu cuci bersih rebus sebentar ksih jahe yg sudah geprek. Rebus sebentar matikan kompor."
- "Tumiskan bumbu halus lalu masukkan daun salam, serai dan daun jeruk (disobek) lalu tuang air rebusan td sedikit lalu aduk masukkan garam,gula dan penyedap"
- "Masukkan ayam aduk koreksi rasa masukkan tomat dan daun bawang lalu tggu hingga mateng lalu masukkan kemangi. Aduk matikan kompor sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 133 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/2adc3c180bf74271/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan gurih. Ciri khas makanan Indonesia ayam rica rica yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga bisa ditemukan dengan cara simple. Salah satunya adalah memasak Ayam Rica Rica untuk orang di rumah. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang bisa anda praktekkan salah satunya ayam rica rica yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 15 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica:

1. Dibutuhkan 1 ekor ayam potong 12
1. Harus ada sejempol Jahe
1. Harus ada 2 btg serai geprek
1. Harus ada 2 lembar daun salam
1. Jangan lupa 3 lembar daun jeruk
1. Harap siapkan 1 buah tomat besar
1. Tambah 1 siung daun bawang
1. Jangan lupa 1 ikat kemangi (kl saya skip krn bwt anak²)
1. Siapkan secukupnya Garam,gula, dan penyedap
1. Harus ada  Bumbu Halus :
1. Tambah 6 siung bawang merah
1. Harus ada 4 siung bawang putih
1. Tambah 2 butir kemiri
1. Diperlukan 6 buah cabe / sesuai selera
1. Tambah secukupnya Air




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica:

1. Cuci bersih ayam lalu lumurin air perasan air jeruk diemkan slm kurleb 10menit lalu cuci bersih rebus sebentar ksih jahe yg sudah geprek. Rebus sebentar matikan kompor.
1. Tumiskan bumbu halus lalu masukkan daun salam, serai dan daun jeruk (disobek) lalu tuang air rebusan td sedikit lalu aduk masukkan garam,gula dan penyedap
1. Masukkan ayam aduk koreksi rasa masukkan tomat dan daun bawang lalu tggu hingga mateng lalu masukkan kemangi. Aduk matikan kompor sajikan




Demikianlah cara membuat ayam rica rica yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
