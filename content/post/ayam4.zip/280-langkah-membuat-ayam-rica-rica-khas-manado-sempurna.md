---
description: "Langkah membuat Ayam Rica-rica Khas Manado Sempurna"
title: "Langkah membuat Ayam Rica-rica Khas Manado Sempurna"
slug: 280-langkah-membuat-ayam-rica-rica-khas-manado-sempurna
date: 2020-11-24T01:44:02.011Z
image: https://img-global.cpcdn.com/recipes/dd248eebce971413/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dd248eebce971413/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dd248eebce971413/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg
author: Jim Todd
ratingvalue: 4.4
reviewcount: 6277
recipeingredient:
- "1 ekor ayam potong kecil"
- "1 ikat kemangisiangi ambil daunnya aja"
- "1 lembar daun pandanikat simpul"
- "5 lembar daun jeruk purutiris halus"
- "2 batang daun bawangiris"
- "2 cm laosgeprek"
- "4 batang seraiukuran kecil geprek"
- "1 sdt Garam"
- "1/2 sdt royco"
- " Minyak goreng"
- " Air"
- " Bumbu yang dihaluskan "
- "1 ons cabe merah"
- "1/2 ons cabe rawit"
- "50 gr bawang merah"
- "50 gr bawang putih"
- "3 buah kemiri"
- "2 cm jahe"
recipeinstructions:
- "Siapkan semua bahan,cuci bersih dan tiriskan semua bahan.iris daun bawang dan daun jeruk purut,petiki daun kemangi,geprek laos dan serai."
- "Bumbui ayam dengan garam, kunyit bubuk,jeruk nipis(aku jeruk sambel) selama kurang lebih 10 menit, goreng setengah masak., tiriskan."
- "Choper/haluskan bumbu,beri sedikit minyak goreng. panaskan minyak goreng,tumis sampai wangi."
- "Tambahkan pandan, daun salam, serai dan laos, masukan ayam yg sudah digoreng, aduk hingga rata, masukan air secukupnya. Tambahkan garam,kunyit bubuk dan penyedap secukupnya, masak sampai ayam empuk sekitar 20 menit."
- "Setelah ayam empuk dan kuah mengering masukan daun kemangi dan daun bawang, aduk hingga layu."
- "Tes rasa, pindah ke piring saji."
categories:
- Recipe
tags:
- ayam
- ricarica
- khas

katakunci: ayam ricarica khas 
nutrition: 224 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica-rica Khas Manado](https://img-global.cpcdn.com/recipes/dd248eebce971413/751x532cq70/ayam-rica-rica-khas-manado-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau gurih. Ciri makanan Nusantara ayam rica-rica khas manado yang kaya dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica-rica Khas Manado untuk keluarga bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang dapat anda coba salah satunya ayam rica-rica khas manado yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan gampang menemukan resep ayam rica-rica khas manado tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Khas Manado yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Khas Manado:

1. Tambah 1 ekor ayam, potong kecil
1. Siapkan 1 ikat kemangi,siangi ambil daunnya aja
1. Jangan lupa 1 lembar daun pandan,ikat simpul
1. Harus ada 5 lembar daun jeruk purut,iris halus
1. Harus ada 2 batang daun bawang,iris
1. Siapkan 2 cm laos,geprek
1. Harus ada 4 batang serai(ukuran kecil), geprek
1. Diperlukan 1 sdt Garam
1. Harap siapkan 1/2 sdt royco
1. Tambah  Minyak goreng
1. Dibutuhkan  Air
1. Dibutuhkan  Bumbu yang dihaluskan :
1. Tambah 1 ons cabe merah
1. Siapkan 1/2 ons cabe rawit
1. Jangan lupa 50 gr bawang merah
1. Dibutuhkan 50 gr bawang putih
1. Diperlukan 3 buah kemiri
1. Jangan lupa 2 cm jahe




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-rica Khas Manado:

1. Siapkan semua bahan,cuci bersih dan tiriskan semua bahan.iris daun bawang dan daun jeruk purut,petiki daun kemangi,geprek laos dan serai.
1. Bumbui ayam dengan garam, kunyit bubuk,jeruk nipis(aku jeruk sambel) selama kurang lebih 10 menit, goreng setengah masak., tiriskan.
1. Choper/haluskan bumbu,beri sedikit minyak goreng. panaskan minyak goreng,tumis sampai wangi.
1. Tambahkan pandan, daun salam, serai dan laos, masukan ayam yg sudah digoreng, aduk hingga rata, masukan air secukupnya. Tambahkan garam,kunyit bubuk dan penyedap secukupnya, masak sampai ayam empuk sekitar 20 menit.
1. Setelah ayam empuk dan kuah mengering masukan daun kemangi dan daun bawang, aduk hingga layu.
1. Tes rasa, pindah ke piring saji.




Demikianlah cara membuat ayam rica-rica khas manado yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
