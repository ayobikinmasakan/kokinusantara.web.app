---
description: "Panduan untuk membuat Ayam Madu Pedas Manis Sempurna"
title: "Panduan untuk membuat Ayam Madu Pedas Manis Sempurna"
slug: 60-panduan-untuk-membuat-ayam-madu-pedas-manis-sempurna
date: 2020-10-01T21:06:44.919Z
image: https://img-global.cpcdn.com/recipes/1a3342a9691e9e88/751x532cq70/ayam-madu-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1a3342a9691e9e88/751x532cq70/ayam-madu-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1a3342a9691e9e88/751x532cq70/ayam-madu-pedas-manis-foto-resep-utama.jpg
author: Dylan Klein
ratingvalue: 4.1
reviewcount: 30512
recipeingredient:
- "1 ekor ayam 15kg"
- "5 sdm madu"
- "1 sdt garam selera"
- "1/2 sdt lada bubuk"
- "1 sdm ketumbar bubuk"
- "2 sdm kecap manis"
- "2 sdm saus tiram"
- "3 sdm bumbu merah           lihat resep"
- "300 ml air"
- " Minyak untuk menggoreng"
- " Bumbu halus"
- "4 bh bawang merah"
- "3 siung bawang putih"
- "1 ruas jari jahe"
- " Pelengkap"
- " Sambal Bawang           lihat resep"
recipeinstructions:
- "Siapkan bahan-bahannya."
- "Lumuri ayam dengan air jeruk dan garam aduk rata kemudian cuci dan bilas kembali hingga bersih."
- "Ayam dalam wajan diberi bumbu halus dan bumbu dasar merah, saus tiram, garam, kecap manis, lada bubuk dan ketumbar bubuk. Tuang dengan air ungkep dan biarkan matang dan airnya tinggal sedikit. Koreksi rasa. Angkat."
- "Goreng dalam minyak panas dengan api kecil. Setelah matang seperti ayam panggang angkat. Sajikan bersama sambal atau lalapan."
categories:
- Recipe
tags:
- ayam
- madu
- pedas

katakunci: ayam madu pedas 
nutrition: 297 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Madu Pedas Manis](https://img-global.cpcdn.com/recipes/1a3342a9691e9e88/751x532cq70/ayam-madu-pedas-manis-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau gurih. Ciri makanan Indonesia ayam madu pedas manis yang penuh dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Madu Pedas Manis untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian resep yang dapat anda contoh salah satunya ayam madu pedas manis yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam madu pedas manis tanpa harus bersusah payah.
Seperti resep Ayam Madu Pedas Manis yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Madu Pedas Manis:

1. Dibutuhkan 1 ekor ayam (1.5kg)
1. Jangan lupa 5 sdm madu
1. Dibutuhkan 1 sdt garam (selera)
1. Siapkan 1/2 sdt lada bubuk
1. Diperlukan 1 sdm ketumbar bubuk
1. Harus ada 2 sdm kecap manis
1. Harap siapkan 2 sdm saus tiram
1. Diperlukan 3 sdm bumbu merah           (lihat resep)
1. Siapkan 300 ml air
1. Harus ada  Minyak untuk menggoreng
1. Harus ada  Bumbu halus:
1. Jangan lupa 4 bh bawang merah
1. Dibutuhkan 3 siung bawang putih
1. Harus ada 1 ruas jari jahe
1. Jangan lupa  Pelengkap:
1. Diperlukan  Sambal Bawang           (lihat resep)




<!--inarticleads2-->

##### Langkah membuat  Ayam Madu Pedas Manis:

1. Siapkan bahan-bahannya.
1. Lumuri ayam dengan air jeruk dan garam aduk rata kemudian cuci dan bilas kembali hingga bersih.
1. Ayam dalam wajan diberi bumbu halus dan bumbu dasar merah, saus tiram, garam, kecap manis, lada bubuk dan ketumbar bubuk. Tuang dengan air ungkep dan biarkan matang dan airnya tinggal sedikit. Koreksi rasa. Angkat.
1. Goreng dalam minyak panas dengan api kecil. Setelah matang seperti ayam panggang angkat. Sajikan bersama sambal atau lalapan.




Demikianlah cara membuat ayam madu pedas manis yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat mudah dan teruji, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
