---
description: "Cara menyiapakan Ayam Rica-rica Terbukti"
title: "Cara menyiapakan Ayam Rica-rica Terbukti"
slug: 388-cara-menyiapakan-ayam-rica-rica-terbukti
date: 2020-11-11T18:31:02.655Z
image: https://img-global.cpcdn.com/recipes/d780e63cabbfac20/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d780e63cabbfac20/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d780e63cabbfac20/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Jonathan Hogan
ratingvalue: 4.8
reviewcount: 49524
recipeingredient:
- "1/2 kg ayam"
- "4 batang sereh geprek"
- "2 siung bawang putih geprek"
- "5 lembar daun salam"
- "5 lembar daun kunyit"
- "2 ruas jahe geprek"
- "2 ruas lengkuas geprek"
- "1 ikat daun kemangi"
- " Bumbu Halus"
- "1/2 ruas kunyit"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "2 butir kemiri"
- "15 bh cabai rawit"
- "7 bh cabai merah besar"
- " Bahan Tambahan"
- "1 bh jeruk nipis"
- "1/4 sdt garam"
- "1/2 sdt gula pasir"
- "1/4 sdt kaldu bubuk"
- "secukupnya Air"
- " Minyak goreng"
recipeinstructions:
- "Cuci bersih ayam, kemudian beri jeruk nipis. Diamkan sebentar, cuci bersih kembali."
- "Rebus ayam bersama jahe, bawang putih, dan sereh untuk menghilangkan bau amis. Tiriskan, lalu goreng ayam yang sudah direbus."
- "Panaskan minyak goreng secukupnya, tumis bumbu halus hingga harum. Tambahkan jahe lengkuas sereh daun salam dan daun jeruk. Tumis bumbu hingga harum Tambahkan air secukupnya."
- "Bumbui dengan garam, gula pasir dan kaldu bubuk titik aduk rata, koreksi rasa. Kemudian masukkan ayam aduk rata Masak hingga air menyusut. Bila air sudah menyusut masukkan kemangi aduk rata sebentar lalu mati kan api.siap disajikan"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 245 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica-rica](https://img-global.cpcdn.com/recipes/d780e63cabbfac20/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau empuk. Ciri makanan Indonesia ayam rica-rica yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat diperoleh dengan cara simple. Salah satunya adalah memasak Ayam Rica-rica untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda buat salah satunya ayam rica-rica yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 22 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica:

1. Tambah 1/2 kg ayam
1. Diperlukan 4 batang sereh, geprek
1. Dibutuhkan 2 siung bawang putih, geprek
1. Harap siapkan 5 lembar daun salam
1. Siapkan 5 lembar daun kunyit
1. Jangan lupa 2 ruas jahe, geprek
1. Tambah 2 ruas lengkuas, geprek
1. Diperlukan 1 ikat daun kemangi
1. Harap siapkan  Bumbu Halus
1. Siapkan 1/2 ruas kunyit
1. Harap siapkan 6 siung bawang merah
1. Harap siapkan 3 siung bawang putih
1. Dibutuhkan 2 butir kemiri
1. Harap siapkan 15 bh cabai rawit
1. Tambah 7 bh cabai merah besar
1. Harus ada  Bahan Tambahan
1. Siapkan 1 bh jeruk nipis
1. Dibutuhkan 1/4 sdt garam
1. Dibutuhkan 1/2 sdt gula pasir
1. Harap siapkan 1/4 sdt kaldu bubuk
1. Harus ada secukupnya Air
1. Harap siapkan  Minyak goreng




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-rica:

1. Cuci bersih ayam, kemudian beri jeruk nipis. Diamkan sebentar, cuci bersih kembali.
1. Rebus ayam bersama jahe, bawang putih, dan sereh untuk menghilangkan bau amis. Tiriskan, lalu goreng ayam yang sudah direbus.
1. Panaskan minyak goreng secukupnya, tumis bumbu halus hingga harum. Tambahkan jahe lengkuas sereh daun salam dan daun jeruk. Tumis bumbu hingga harum Tambahkan air secukupnya.
1. Bumbui dengan garam, gula pasir dan kaldu bubuk titik aduk rata, koreksi rasa. Kemudian masukkan ayam aduk rata Masak hingga air menyusut. Bila air sudah menyusut masukkan kemangi aduk rata sebentar lalu mati kan api.siap disajikan




Demikianlah cara membuat ayam rica-rica yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
