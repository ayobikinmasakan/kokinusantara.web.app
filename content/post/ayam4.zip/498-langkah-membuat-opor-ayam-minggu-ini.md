---
description: "Langkah membuat Opor ayam minggu ini"
title: "Langkah membuat Opor ayam minggu ini"
slug: 498-langkah-membuat-opor-ayam-minggu-ini
date: 2021-01-09T09:39:23.220Z
image: https://img-global.cpcdn.com/recipes/a922619269b8f787/751x532cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a922619269b8f787/751x532cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a922619269b8f787/751x532cq70/opor-ayam-foto-resep-utama.jpg
author: Lena Lawrence
ratingvalue: 4.1
reviewcount: 5460
recipeingredient:
- "1/2 ekor ayam"
- "1 batang serai"
- "1 lbr daun salam"
- "200 ml santan kental me  santan instant"
- " garam  penyedap mekaldu jamur secukup nya"
- " Bumbu Halus"
- "7 butir bawah merah"
- "3 butir bawah putih"
- "2 buah kemiri"
- "2 cm jahe"
- "2 cm lengkuas"
- "1/2 sdt ketumbar halus"
- "1/4 sdt lada putih"
recipeinstructions:
- "Cuci bersih potongan ayam dan diberi perasan jeruk nipis diamkan sebentar cuci bersih."
- "Rebus ayam di air yang telah di didihkan sebentar saja. Angkat dan tiriskan."
- "Tumis bumbu halus sampai wangi dan masak agar tidak berbau langu."
- "Masukan ayam di aduk rata sampai ayam telumuri bumbu agar meresap."
- "Masukan santan dan air aduk perlahan agar santan tidak pecah."
- "Tambahkan garam dan kaldu jamur secukup nya. Masak sampai mendidih, koreksi rasa. Tusuk ayam dengan garpu jika sudah lembut matikan api dan sajikan."
categories:
- Recipe
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 111 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Dessert

---


![Opor ayam](https://img-global.cpcdn.com/recipes/a922619269b8f787/751x532cq70/opor-ayam-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau renyah. Ciri khas masakan Nusantara opor ayam yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Opor ayam untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang dapat anda praktekkan salah satunya opor ayam yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep opor ayam tanpa harus bersusah payah.
Seperti resep Opor ayam yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Opor ayam:

1. Dibutuhkan 1/2 ekor ayam
1. Harus ada 1 batang serai
1. Dibutuhkan 1 lbr daun salam
1. Harap siapkan 200 ml santan kental (me : santan instant)
1. Harus ada  garam &amp; penyedap (me:kaldu jamur) secukup nya
1. Diperlukan  Bumbu Halus
1. Harap siapkan 7 butir bawah merah
1. Tambah 3 butir bawah putih
1. Jangan lupa 2 buah kemiri
1. Siapkan 2 cm jahe
1. Dibutuhkan 2 cm lengkuas
1. Diperlukan 1/2 sdt ketumbar halus
1. Harus ada 1/4 sdt lada putih




<!--inarticleads2-->

##### Bagaimana membuat  Opor ayam:

1. Cuci bersih potongan ayam dan diberi perasan jeruk nipis diamkan sebentar cuci bersih.
1. Rebus ayam di air yang telah di didihkan sebentar saja. Angkat dan tiriskan.
1. Tumis bumbu halus sampai wangi dan masak agar tidak berbau langu.
1. Masukan ayam di aduk rata sampai ayam telumuri bumbu agar meresap.
1. Masukan santan dan air aduk perlahan agar santan tidak pecah.
1. Tambahkan garam dan kaldu jamur secukup nya. Masak sampai mendidih, koreksi rasa. Tusuk ayam dengan garpu jika sudah lembut matikan api dan sajikan.




Demikianlah cara membuat opor ayam yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
