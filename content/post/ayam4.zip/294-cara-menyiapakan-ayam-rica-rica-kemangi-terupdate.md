---
description: "Cara menyiapakan Ayam Rica-Rica Kemangi terupdate"
title: "Cara menyiapakan Ayam Rica-Rica Kemangi terupdate"
slug: 294-cara-menyiapakan-ayam-rica-rica-kemangi-terupdate
date: 2021-01-07T10:21:16.857Z
image: https://img-global.cpcdn.com/recipes/d289ac8f7d557a20/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d289ac8f7d557a20/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d289ac8f7d557a20/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Ivan Nichols
ratingvalue: 4.2
reviewcount: 10103
recipeingredient:
- "1 ekor ayam kampung"
- "2 buah jeruk nipis"
- " Bahan Bumbu"
- "6 siung bawang putih"
- "10 biji bawang merah"
- "10-15 cabe rawit selera"
- "1 ruas jahe"
- "1 ruas kunyit"
- " Lengkuas sedikit saja"
- "2 batang sereh"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- " Bahan Pelengkap"
- "3 pohon kemangi ambil daunnya saja"
- "2 batang daun bawang"
- "3 sdm minyak goreng"
- "1 sdm garam"
- "1 sdt gula"
- "1 sdm kaldu bubuk"
- "1 sdt merica"
recipeinstructions:
- "Potong ayam sesuai selera (saya potong kecil² supaya bumbu cepat meresap) lalu lumuri dgn jeruk nipis dan garam. Diamkan selama kurang lebih 15 menit."
- "Setelah ayam dicuci bersih, goreng ayam sebentar diatas teflon. Ini selera ya, tdk digoreng jg gapapa. Setelah digoreng, lalu tiriskan."
- "Blender semua bahan bumbu, kecuali sereh, daun salam, daun jeruk dan lengkuas."
- "Setelah bumbu halus, panaskan minyak goreng, masukkan bumbu halus beserta lengkuas dan batang sereh yg sudah di geprek, daun salam dan daun jeruk. Aduk sebentar sampai wangi. Lalu tambahkan sedikit air."
- "Setelah itu, masukkan ayam. Aduk sampai bumbu tercampur rata. Diamkan sebentar supaya bumbu meresap dan air mulai menyusut."
- "Setelah air menyusut dan ayam empuk, masukkan kemangi dan daun bawang. Aduk sebentar lalu matikan api."
- "Ayam rica-rica siap dihidangkan bersama nasi hangat dan lalapan mentimun/selada."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 266 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/d289ac8f7d557a20/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga gurih. Karasteristik makanan Nusantara ayam rica-rica kemangi yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Kedekatan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica-Rica Kemangi untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang dapat anda contoh salah satunya ayam rica-rica kemangi yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Kemangi:

1. Tambah 1 ekor ayam kampung
1. Jangan lupa 2 buah jeruk nipis
1. Jangan lupa  Bahan Bumbu
1. Diperlukan 6 siung bawang putih
1. Jangan lupa 10 biji bawang merah
1. Jangan lupa 10-15 cabe rawit (selera)
1. Dibutuhkan 1 ruas jahe
1. Dibutuhkan 1 ruas kunyit
1. Siapkan  Lengkuas sedikit saja
1. Jangan lupa 2 batang sereh
1. Harap siapkan 2 lembar daun salam
1. Tambah 2 lembar daun jeruk
1. Harap siapkan  Bahan Pelengkap
1. Tambah 3 pohon kemangi, ambil daunnya saja
1. Diperlukan 2 batang daun bawang
1. Siapkan 3 sdm minyak goreng
1. Jangan lupa 1 sdm garam
1. Harap siapkan 1 sdt gula
1. Siapkan 1 sdm kaldu bubuk
1. Diperlukan 1 sdt merica


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica Kemangi:

1. Potong ayam sesuai selera (saya potong kecil² supaya bumbu cepat meresap) lalu lumuri dgn jeruk nipis dan garam. Diamkan selama kurang lebih 15 menit.
1. Setelah ayam dicuci bersih, goreng ayam sebentar diatas teflon. Ini selera ya, tdk digoreng jg gapapa. Setelah digoreng, lalu tiriskan.
1. Blender semua bahan bumbu, kecuali sereh, daun salam, daun jeruk dan lengkuas.
1. Setelah bumbu halus, panaskan minyak goreng, masukkan bumbu halus beserta lengkuas dan batang sereh yg sudah di geprek, daun salam dan daun jeruk. Aduk sebentar sampai wangi. Lalu tambahkan sedikit air.
1. Setelah itu, masukkan ayam. Aduk sampai bumbu tercampur rata. Diamkan sebentar supaya bumbu meresap dan air mulai menyusut.
1. Setelah air menyusut dan ayam empuk, masukkan kemangi dan daun bawang. Aduk sebentar lalu matikan api.
1. Ayam rica-rica siap dihidangkan bersama nasi hangat dan lalapan mentimun/selada.


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan teruji, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
