---
description: "Steps membuat Ayam Rica-Rica Luar biasa"
title: "Steps membuat Ayam Rica-Rica Luar biasa"
slug: 338-steps-membuat-ayam-rica-rica-luar-biasa
date: 2020-12-10T10:07:39.397Z
image: https://img-global.cpcdn.com/recipes/ab7c51b787a646fa/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ab7c51b787a646fa/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ab7c51b787a646fa/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: George Graves
ratingvalue: 4.6
reviewcount: 22303
recipeingredient:
- "6-9 potong ayam"
- "4 ikat kemangi petik daunnya"
- "200 ml air"
- "1/2 sdt garam"
- "1 sdt kaldu ayam bubuk"
- "1 batang daun bawang"
- " Bumbu Halus"
- "10 cabe merah besar"
- "3 cabe merah keriting"
- "4 bawang putih"
- "10 bawang merah"
- "2 kemiri sudah disangrai"
- "1 cm kunyit"
- "1 sdm gula merah"
- " Bumbu Pelengkap"
- "2 daun salam"
- "6 daun jeruk"
- "3 cm lengkoas geprek"
- "2 cm jahe geprek"
- "1 sereh geprek"
recipeinstructions:
- "Haluskan semua bumbu halus. Tumis bumbu halus, tambahkan bumbu pelengkap. Tumis sampai harum, kemudian masukkan garam dan kaldu bubuk. Aduk rata."
- "Masukkan ayam, masak sebentar sampai ayam berubah warna. Masukkan air, aduk rata."
- "Jika air sudah mendidih, tutup wajannya, masak dengan api kecil selama 30 menit supaya ayam empuk dan bumbu meresap."
- "Setelah 30 menit, icip, koreksi rasa. Kemudian masukkan kemangi dan daun bawang. Masak hingga layu. Selesai, sajikan 🤗"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 265 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/ab7c51b787a646fa/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau renyah. Ciri khas kuliner Indonesia ayam rica-rica yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica-Rica untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang bisa anda buat salah satunya ayam rica-rica yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Siapkan 6-9 potong ayam
1. Jangan lupa 4 ikat kemangi, petik daunnya
1. Siapkan 200 ml air
1. Harus ada 1/2 sdt garam
1. Jangan lupa 1 sdt kaldu ayam bubuk
1. Harap siapkan 1 batang daun bawang
1. Siapkan  Bumbu Halus:
1. Tambah 10 cabe merah besar
1. Harus ada 3 cabe merah keriting
1. Dibutuhkan 4 bawang putih
1. Harus ada 10 bawang merah
1. Jangan lupa 2 kemiri, sudah disangrai
1. Diperlukan 1 cm kunyit
1. Diperlukan 1 sdm gula merah
1. Dibutuhkan  Bumbu Pelengkap:
1. Tambah 2 daun salam
1. Tambah 6 daun jeruk
1. Dibutuhkan 3 cm lengkoas, geprek
1. Dibutuhkan 2 cm jahe, geprek
1. Siapkan 1 sereh, geprek




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-Rica:

1. Haluskan semua bumbu halus. Tumis bumbu halus, tambahkan bumbu pelengkap. Tumis sampai harum, kemudian masukkan garam dan kaldu bubuk. Aduk rata.
1. Masukkan ayam, masak sebentar sampai ayam berubah warna. Masukkan air, aduk rata.
1. Jika air sudah mendidih, tutup wajannya, masak dengan api kecil selama 30 menit supaya ayam empuk dan bumbu meresap.
1. Setelah 30 menit, icip, koreksi rasa. Kemudian masukkan kemangi dan daun bawang. Masak hingga layu. Selesai, sajikan 🤗




Demikianlah cara membuat ayam rica-rica yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan cepat, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
