---
description: "Resep : Ayam rica rica cabe ijo Luar biasa"
title: "Resep : Ayam rica rica cabe ijo Luar biasa"
slug: 257-resep-ayam-rica-rica-cabe-ijo-luar-biasa
date: 2020-09-24T10:07:02.252Z
image: https://img-global.cpcdn.com/recipes/fd373d6f0abb4fb7/751x532cq70/ayam-rica-rica-cabe-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fd373d6f0abb4fb7/751x532cq70/ayam-rica-rica-cabe-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fd373d6f0abb4fb7/751x532cq70/ayam-rica-rica-cabe-ijo-foto-resep-utama.jpg
author: Connor Copeland
ratingvalue: 4.5
reviewcount: 39000
recipeingredient:
- "1/2 kg ayam"
- "15 buah cabe ijo"
- "1 batang daun sereh"
- "4 lembar daun jeruk"
- "2 lembar daun salam"
- "1 buah tomat"
- "1 ruas lengkuas geprek"
- "1 sdm garam"
- "1 sdt gula"
- " Sejuput micin"
- " Bumbu halus"
- "5 buah cabe rawit"
- "2 buah cabe merah"
- "4 siung bawang putih"
- "5 siung bawang merah"
- "4 butir kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
recipeinstructions:
- "Siapakan semua bahan, cuci bersih ayam potong2 sesuai selera"
- "Blender bumbu halus, siapkan wajan masak bumbu halus sampai meletup2, masukan daun sereh, daun salam, dan lengkuas geprek masak sampai harum masukan ayam aduk2 hingga tercampur rata"
- "Kemudian masukan 500ml air, tutup sampai meletup2, tambahkan irisan tomat, cabe ijo, garam, gula, micin, aduk2 sebentar, tutup kembali sampai air asat dan bumbu meresap"
- "Setelah air asat, matikan kompor dan siap di santap dg nasi hangat lebih mantap, selesai selamat mencoba semuanya 💛"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 137 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam rica rica cabe ijo](https://img-global.cpcdn.com/recipes/fd373d6f0abb4fb7/751x532cq70/ayam-rica-rica-cabe-ijo-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan enak. Ciri khas masakan Indonesia ayam rica rica cabe ijo yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah memasak Ayam rica rica cabe ijo untuk orang di rumah bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda contoh salah satunya ayam rica rica cabe ijo yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep ayam rica rica cabe ijo tanpa harus bersusah payah.
Seperti resep Ayam rica rica cabe ijo yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica cabe ijo:

1. Diperlukan 1/2 kg ayam
1. Siapkan 15 buah cabe ijo
1. Diperlukan 1 batang daun sereh
1. Harus ada 4 lembar daun jeruk
1. Tambah 2 lembar daun salam
1. Harus ada 1 buah tomat
1. Harus ada 1 ruas lengkuas (geprek)
1. Diperlukan 1 sdm garam
1. Jangan lupa 1 sdt gula
1. Siapkan  Sejuput micin
1. Jangan lupa  Bumbu halus
1. Siapkan 5 buah cabe rawit
1. Harap siapkan 2 buah cabe merah
1. Harus ada 4 siung bawang putih
1. Siapkan 5 siung bawang merah
1. Siapkan 4 butir kemiri
1. Diperlukan 1 ruas jahe
1. Harap siapkan 1 ruas kunyit




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica cabe ijo:

1. Siapakan semua bahan, cuci bersih ayam potong2 sesuai selera
1. Blender bumbu halus, siapkan wajan masak bumbu halus sampai meletup2, masukan daun sereh, daun salam, dan lengkuas geprek masak sampai harum masukan ayam aduk2 hingga tercampur rata
1. Kemudian masukan 500ml air, tutup sampai meletup2, tambahkan irisan tomat, cabe ijo, garam, gula, micin, aduk2 sebentar, tutup kembali sampai air asat dan bumbu meresap
1. Setelah air asat, matikan kompor dan siap di santap dg nasi hangat lebih mantap, selesai selamat mencoba semuanya 💛




Demikianlah cara membuat ayam rica rica cabe ijo yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan terbukti, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
