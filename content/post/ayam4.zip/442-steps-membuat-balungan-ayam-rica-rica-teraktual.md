---
description: "Steps membuat Balungan Ayam Rica - Rica teraktual"
title: "Steps membuat Balungan Ayam Rica - Rica teraktual"
slug: 442-steps-membuat-balungan-ayam-rica-rica-teraktual
date: 2020-12-31T10:14:16.826Z
image: https://img-global.cpcdn.com/recipes/3c99fe947c425f44/751x532cq70/balungan-ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3c99fe947c425f44/751x532cq70/balungan-ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3c99fe947c425f44/751x532cq70/balungan-ayam-rica-rica-foto-resep-utama.jpg
author: Victoria Lane
ratingvalue: 4.4
reviewcount: 9138
recipeingredient:
- "1 kg balungan ayam"
- " Bumbu Halus "
- "8 siung bawang merah"
- "1 ons cabe keriting"
- "15 bh cabe rawit orange"
- "5 siung bawang putih"
- "2 cm jahe"
- "2 cm kunyit"
- "3 buah kemiri"
- "2 cm lengkuas"
- " Bahan Cemplung "
- "3 lembar daun salam"
- "1 lembar daun pandan ikat simpul"
- "5 lembar daun jeruk iris halus"
- "3 batang sereh memarkan"
- "3 batang daun kemangi petiki daun nya"
- "Secukup nya garam gula dan kaldu bubuk"
- " Minyak untuk menumis"
- "1 buah jeruk nipis"
recipeinstructions:
- "Cuci bersih balungan ayam lalu beri garam secukup nya lalu kucuri jeruk nipis aduk hingga kesat diam kan 10 menit cuci bersih kembali"
- "Panaskan minyak secukup nya lalu gorengan ayam hingga garing angkat tiriskan"
- "Tumis bumbu halus hingga harum masukan daun salam, daun pandan, sereh dan daun jeruk aduk rata hingga bau langu nya hilang setelah itu masukan ayam aduk rata"
- "Beri air secukup nya biar kan hingga mendidih lalu beri garam, gula dan kaldu bubuk biar kan air nya susut koreksi rasa terahir masukan daun kemangi. Sajikan"
categories:
- Recipe
tags:
- balungan
- ayam
- rica

katakunci: balungan ayam rica 
nutrition: 215 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dessert

---


![Balungan Ayam Rica - Rica](https://img-global.cpcdn.com/recipes/3c99fe947c425f44/751x532cq70/balungan-ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau empuk. Ciri masakan Indonesia balungan ayam rica - rica yang kaya dengan rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Balungan Ayam Rica - Rica untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda contoh salah satunya balungan ayam rica - rica yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep balungan ayam rica - rica tanpa harus bersusah payah.
Berikut ini resep Balungan Ayam Rica - Rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Balungan Ayam Rica - Rica:

1. Tambah 1 kg balungan ayam
1. Diperlukan  Bumbu Halus :
1. Jangan lupa 8 siung bawang merah
1. Diperlukan 1 ons cabe keriting
1. Diperlukan 15 bh cabe rawit orange
1. Dibutuhkan 5 siung bawang putih
1. Tambah 2 cm jahe
1. Dibutuhkan 2 cm kunyit
1. Tambah 3 buah kemiri
1. Jangan lupa 2 cm lengkuas
1. Tambah  Bahan Cemplung :
1. Dibutuhkan 3 lembar daun salam
1. Jangan lupa 1 lembar daun pandan ikat simpul
1. Diperlukan 5 lembar daun jeruk iris halus
1. Harus ada 3 batang sereh memarkan
1. Harap siapkan 3 batang daun kemangi petiki daun nya
1. Dibutuhkan Secukup nya garam, gula dan kaldu bubuk
1. Diperlukan  Minyak untuk menumis
1. Tambah 1 buah jeruk nipis




<!--inarticleads2-->

##### Bagaimana membuat  Balungan Ayam Rica - Rica:

1. Cuci bersih balungan ayam lalu beri garam secukup nya lalu kucuri jeruk nipis aduk hingga kesat diam kan 10 menit cuci bersih kembali
1. Panaskan minyak secukup nya lalu gorengan ayam hingga garing angkat tiriskan
1. Tumis bumbu halus hingga harum masukan daun salam, daun pandan, sereh dan daun jeruk aduk rata hingga bau langu nya hilang setelah itu masukan ayam aduk rata
1. Beri air secukup nya biar kan hingga mendidih lalu beri garam, gula dan kaldu bubuk biar kan air nya susut koreksi rasa terahir masukan daun kemangi. Sajikan




Demikianlah cara membuat balungan ayam rica - rica yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
