---
description: "Resep : Ayam Rica Rica Kemangi Luar biasa"
title: "Resep : Ayam Rica Rica Kemangi Luar biasa"
slug: 308-resep-ayam-rica-rica-kemangi-luar-biasa
date: 2021-01-31T22:19:24.644Z
image: https://img-global.cpcdn.com/recipes/e5ec23a440247769/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e5ec23a440247769/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e5ec23a440247769/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Tillie McGuire
ratingvalue: 4.1
reviewcount: 6668
recipeingredient:
- "1/2 ekor ayam kampung"
- "Segenggam daun kemangi"
- " Minyak untuk menumis"
- "secukupnya Air"
- " Bumbu Non Halus"
- "1 batang sereh geprek"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- " Bumbu Halus"
- "17 buah cabe rawit pedas sesuai selera"
- "5 buah cabe merah keriting"
- "4 siung bawang putih"
- "7 siung bawang merah"
- "2 buah kemiri"
- "1 ruas jahe"
- "2 ruas lengkuas"
- "1 sdm bubuk kunyit kurang lebih segitu"
- "1 sdt bubuk ketumbar opsional"
- "1 sdt lada bubuk opsional"
- " Bumbu Tambahan"
- "Secukupnya Garam"
- "secukupnya Gula"
- "secukupnya Kaldu ayam  me masako ayam seujung sendok teh"
- "2 sdm Kecap manis kurang lebih  opsional"
recipeinstructions:
- "Bersihkan ayam lalu potong2 sesuai selera kemudian rebus dulu sekitar +- 1 jam lalu tiriskan, tujuannya supaya ayam gak alot karena tekstur ayam kampung beda sama ayam negri, kalo pake ayam negri langkah ini bisa kalian skip"
- "Haluskan bumbu halus kemudian tumis dengan minyak panas lalu masukkan sereh, daun salam dan daun jeruk. Tumis hingga wangi."
- "Tambahkan air secukupnya ke bumbu yg sedang ditumis (bisa pake air rebusan ayam sebelumnya/air biasa) tunggu hingga mendidih kemudian masukkan ayamnya."
- "Masukkan garam, gula, kaldu ayam, dan kecap, masak hingga ayam empuk"
- "Setelah itu cek rasa, jika dirasa sudah pas semua matikan api dan masukkan daun kemangi yang sudah dicuci bersih kemudian diaduk dan siap disajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 143 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/e5ec23a440247769/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita jaga karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica rica kemangi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Indonesia



Kedekatan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Rica Kemangi untuk keluarga. kebersamaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda praktekkan salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 24 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Diperlukan 1/2 ekor ayam kampung
1. Jangan lupa Segenggam daun kemangi
1. Jangan lupa  Minyak untuk menumis
1. Tambah secukupnya Air
1. Siapkan  Bumbu Non Halus
1. Harap siapkan 1 batang sereh geprek
1. Harus ada 2 lembar daun salam
1. Diperlukan 3 lembar daun jeruk
1. Dibutuhkan  Bumbu Halus
1. Jangan lupa 17 buah cabe rawit (pedas sesuai selera)
1. Tambah 5 buah cabe merah keriting
1. Diperlukan 4 siung bawang putih
1. Diperlukan 7 siung bawang merah
1. Diperlukan 2 buah kemiri
1. Harap siapkan 1 ruas jahe
1. Tambah 2 ruas lengkuas
1. Harap siapkan 1 sdm bubuk kunyit (kurang lebih segitu)
1. Siapkan 1 sdt bubuk ketumbar (opsional)
1. Harus ada 1 sdt lada bubuk (opsional)
1. Tambah  Bumbu Tambahan
1. Dibutuhkan Secukupnya Garam
1. Harap siapkan secukupnya Gula
1. Harus ada secukupnya Kaldu ayam  (me: masako ayam seujung sendok teh)
1. Siapkan 2 sdm Kecap manis kurang lebih  (opsional)




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica Kemangi:

1. Bersihkan ayam lalu potong2 sesuai selera kemudian rebus dulu sekitar +- 1 jam lalu tiriskan, tujuannya supaya ayam gak alot karena tekstur ayam kampung beda sama ayam negri, kalo pake ayam negri langkah ini bisa kalian skip
1. Haluskan bumbu halus kemudian tumis dengan minyak panas lalu masukkan sereh, daun salam dan daun jeruk. Tumis hingga wangi.
1. Tambahkan air secukupnya ke bumbu yg sedang ditumis (bisa pake air rebusan ayam sebelumnya/air biasa) tunggu hingga mendidih kemudian masukkan ayamnya.
1. Masukkan garam, gula, kaldu ayam, dan kecap, masak hingga ayam empuk
1. Setelah itu cek rasa, jika dirasa sudah pas semua matikan api dan masukkan daun kemangi yang sudah dicuci bersih kemudian diaduk dan siap disajikan.




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan cepat, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
