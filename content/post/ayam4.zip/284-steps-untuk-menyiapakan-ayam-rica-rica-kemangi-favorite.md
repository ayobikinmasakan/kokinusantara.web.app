---
description: "Steps untuk menyiapakan Ayam rica-rica kemangi Favorite"
title: "Steps untuk menyiapakan Ayam rica-rica kemangi Favorite"
slug: 284-steps-untuk-menyiapakan-ayam-rica-rica-kemangi-favorite
date: 2020-09-21T12:22:53.517Z
image: https://img-global.cpcdn.com/recipes/d522c05c2df88ae9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d522c05c2df88ae9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d522c05c2df88ae9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Austin Miles
ratingvalue: 4.9
reviewcount: 40714
recipeingredient:
- "1,5 kg ayam potong"
- "1 buah tomat"
- " Bumbu halus "
- "4 buah Bawang putih"
- "6 buah Bawang merah"
- "1 buah Kemiri"
- "secukupnya Gula Jawa"
- "secukupnya Ketumbar"
- "secukupnya Cabe merah"
- "secukupnya Cabe rawit"
- " Garam"
- " Merica bubuk"
- " Laos"
- " Daun salam"
- " Serai"
- " Kecap manis"
- " Daun kemangi"
recipeinstructions:
- "Cuci bersih ayam &amp; rebus dalam air mendidih"
- "Uleg bumbu halus kecuali Laos, serai, daun salam"
- "Panaskan sedikit minyak, kemudian tumis bumbu halus hingga berbau harum"
- "Setelah berbau harum tambahkan sedikit air agar bumbu tdk gosong, sambil cek rasa. Masukkan Laos, daun salam dan serai."
- "Setelah itu, masukkan ayam yg sudah direbus tadi ke dalam tumisan bumbu"
- "Tambahkan sedikit kecap manis sambil cek rasa kembali"
- "Setelah rasa pas, masukkan daun kemangi"
- "Setelah daun kemangi masuk, lgsg matikan api kompor agar kemangi tdk terlalu matang"
- "Rica ayam kemangi sudah siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 228 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/d522c05c2df88ae9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan enak. Ciri khas makanan Indonesia ayam rica-rica kemangi yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam rica-rica kemangi untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis makanan yang dapat anda buat salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Siapkan 1,5 kg ayam potong
1. Tambah 1 buah tomat
1. Diperlukan  Bumbu halus :
1. Tambah 4 buah Bawang putih
1. Jangan lupa 6 buah Bawang merah
1. Harap siapkan 1 buah Kemiri
1. Tambah secukupnya Gula Jawa
1. Siapkan secukupnya Ketumbar
1. Dibutuhkan secukupnya Cabe merah
1. Diperlukan secukupnya Cabe rawit
1. Harus ada  Garam
1. Jangan lupa  Merica bubuk
1. Siapkan  Laos
1. Siapkan  Daun salam
1. Harap siapkan  Serai
1. Harap siapkan  Kecap manis
1. Siapkan  Daun kemangi




<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica kemangi:

1. Cuci bersih ayam &amp; rebus dalam air mendidih
1. Uleg bumbu halus kecuali Laos, serai, daun salam
1. Panaskan sedikit minyak, kemudian tumis bumbu halus hingga berbau harum
1. Setelah berbau harum tambahkan sedikit air agar bumbu tdk gosong, sambil cek rasa. Masukkan Laos, daun salam dan serai.
1. Setelah itu, masukkan ayam yg sudah direbus tadi ke dalam tumisan bumbu
1. Tambahkan sedikit kecap manis sambil cek rasa kembali
1. Setelah rasa pas, masukkan daun kemangi
1. Setelah daun kemangi masuk, lgsg matikan api kompor agar kemangi tdk terlalu matang
1. Rica ayam kemangi sudah siap dihidangkan




Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
