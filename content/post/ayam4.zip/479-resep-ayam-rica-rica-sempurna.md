---
description: "Resep : Ayam Rica-Rica Sempurna"
title: "Resep : Ayam Rica-Rica Sempurna"
slug: 479-resep-ayam-rica-rica-sempurna
date: 2020-10-24T17:58:58.659Z
image: https://img-global.cpcdn.com/recipes/c8d35b9594cb6ddc/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c8d35b9594cb6ddc/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c8d35b9594cb6ddc/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Micheal Carson
ratingvalue: 4.7
reviewcount: 30979
recipeingredient:
- "700 gr daging ayam potong"
- "1 bh jeruk lemonnipis ambil airnya"
- "4 lbr daun jeruk"
- "2 bh sereh geprek"
- " Lengkuas saya skip"
- "1 sdt gula pasir"
- "1 sdt garam"
- "1 sdt kaldu jamur optional"
- "1 ikat kemangi ambil daunnya"
- "300 ml air"
- " Bumbu yang di haluskan"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "3 bh cabe merah tanjung ukuran besar kalau cabenya kecil 6 bh"
- "6 bh cabe rawit merah  cengek domba merah"
- "1 bh tomat merah ukuran sedang"
- "5 cm jahe"
- "3 cm kunyit"
recipeinstructions:
- "Baluri ayam dengan air lemon/nipis, aduk rata dan diamkan 20 menitan."
- "Tumis bumbu halus beserta daun jeruk, sereh, garam, gula dan kaldu jamur, masak hingga bumbu matang dan harum. Lalu masukan ayam, aduk² masak hingga ayam berubah warna."
- "Masukan air, aduk rata. Masak hingga ayam matang dan airnya surut. Masukan daun kemangi, aduk rata, tes rasa dan matikan api. Ayam rica-rica siap di sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 212 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/c8d35b9594cb6ddc/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica-rica yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan ciri khas yang merupakan keragaman Indonesia

Kehangatan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica-Rica untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang bisa anda buat salah satunya ayam rica-rica yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica:

1. Diperlukan 700 gr daging ayam, potong²
1. Diperlukan 1 bh jeruk lemon/nipis (ambil airnya)
1. Diperlukan 4 lbr daun jeruk
1. Harap siapkan 2 bh sereh, geprek
1. Harap siapkan  Lengkuas (saya skip)
1. Dibutuhkan 1 sdt gula pasir
1. Harap siapkan 1 sdt garam
1. Jangan lupa 1 sdt kaldu jamur (optional)
1. Harap siapkan 1 ikat kemangi, ambil daunnya
1. Harus ada 300 ml air
1. Harus ada  Bumbu yang di haluskan:
1. Siapkan 8 siung bawang merah
1. Harus ada 5 siung bawang putih
1. Siapkan 3 bh cabe merah tanjung ukuran besar (kalau cabenya kecil 6 bh)
1. Dibutuhkan 6 bh cabe rawit merah / cengek domba merah
1. Diperlukan 1 bh tomat merah ukuran sedang
1. Harap siapkan 5 cm jahe
1. Diperlukan 3 cm kunyit




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-Rica:

1. Baluri ayam dengan air lemon/nipis, aduk rata dan diamkan 20 menitan.
1. Tumis bumbu halus beserta daun jeruk, sereh, garam, gula dan kaldu jamur, masak hingga bumbu matang dan harum. Lalu masukan ayam, aduk² masak hingga ayam berubah warna.
1. Masukan air, aduk rata. Masak hingga ayam matang dan airnya surut. Masukan daun kemangi, aduk rata, tes rasa dan matikan api. Ayam rica-rica siap di sajikan.




Demikianlah cara membuat ayam rica-rica yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
