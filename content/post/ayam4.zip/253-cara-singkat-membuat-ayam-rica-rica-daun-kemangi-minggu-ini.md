---
description: "Cara singkat membuat Ayam rica-rica daun kemangi minggu ini"
title: "Cara singkat membuat Ayam rica-rica daun kemangi minggu ini"
slug: 253-cara-singkat-membuat-ayam-rica-rica-daun-kemangi-minggu-ini
date: 2020-12-14T20:38:59.754Z
image: https://img-global.cpcdn.com/recipes/8295ee86d391737a/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8295ee86d391737a/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8295ee86d391737a/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Douglas Jacobs
ratingvalue: 5
reviewcount: 10775
recipeingredient:
- "1/2 ekor ayam boiler"
- "1 bh jeruk nipis"
- "3 ikat kemangi"
- "1 btg serai geprek"
- "seruas lengkuas geprek"
- "7 lbr daun jeruk"
- "1 btg daun bawang"
- "Secukupnya air"
- " Garam kaldu jamur"
- "1 sdm gula merah disisir"
- " Bumbu halus "
- "6 bh bamer"
- "2 siung baput"
- "8 bh cabe merah"
- "20 bh cabe rawit selera"
- "2 btr kemiri"
- "Sejempol jahe  kunyit"
recipeinstructions:
- "Cuci bersih ayam, beri perasan jeruk nipis diamkan 1 jam -/+."
- "Goreng cabe merah, rawit, baput, bamer, hingga layu. Lalu blender halus bersama bumbu lainnya."
- "Beri minyak aga banyak, -/+ 5 sdm.. panaskan. Masukan bumbu halus. Lanjut masukan serai, lengkuas, daun jeruk. Tumis hingga wangi. Lalu masukan gula merah. Aduk hingga tercampur."
- "Beri sedikit air -/+ stengah gelas kecil. Lalu masukan garam &amp; kaldu. Cek rasa. Masukan ayam. Masak hingga matang. Balik sisi ya klo airnya g rata dgn ayamnya. Menit akhir stelah ayam sdh matang. Masukan daun bawang &amp; kemangi. Sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- daun

katakunci: ayam ricarica daun 
nutrition: 207 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica-rica daun kemangi](https://img-global.cpcdn.com/recipes/8295ee86d391737a/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau enak. Karasteristik makanan Nusantara ayam rica-rica daun kemangi yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan rumah tangga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica-rica daun kemangi untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang bisa anda buat salah satunya ayam rica-rica daun kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep ayam rica-rica daun kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica daun kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica daun kemangi:

1. Harus ada 1/2 ekor ayam boiler
1. Jangan lupa 1 bh jeruk nipis
1. Harap siapkan 3 ikat kemangi
1. Tambah 1 btg serai (geprek)
1. Jangan lupa seruas lengkuas (geprek)
1. Harap siapkan 7 lbr daun jeruk
1. Tambah 1 btg daun bawang
1. Harus ada Secukupnya air
1. Siapkan  Garam, kaldu jamur
1. Dibutuhkan 1 sdm gula merah (disisir)
1. Harus ada  Bumbu halus :
1. Harus ada 6 bh bamer
1. Dibutuhkan 2 siung baput
1. Harap siapkan 8 bh cabe merah
1. Tambah 20 bh cabe rawit *selera
1. Diperlukan 2 btr kemiri
1. Tambah Sejempol jahe &amp; kunyit




<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica daun kemangi:

1. Cuci bersih ayam, beri perasan jeruk nipis diamkan 1 jam -/+.
1. Goreng cabe merah, rawit, baput, bamer, hingga layu. Lalu blender halus bersama bumbu lainnya.
1. Beri minyak aga banyak, -/+ 5 sdm.. panaskan. Masukan bumbu halus. Lanjut masukan serai, lengkuas, daun jeruk. Tumis hingga wangi. Lalu masukan gula merah. Aduk hingga tercampur.
1. Beri sedikit air -/+ stengah gelas kecil. Lalu masukan garam &amp; kaldu. Cek rasa. Masukan ayam. Masak hingga matang. Balik sisi ya klo airnya g rata dgn ayamnya. Menit akhir stelah ayam sdh matang. Masukan daun bawang &amp; kemangi. Sajikan.




Demikianlah cara membuat ayam rica-rica daun kemangi yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
