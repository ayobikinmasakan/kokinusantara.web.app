---
description: "Resep : Ayam Rica-rica Terbukti"
title: "Resep : Ayam Rica-rica Terbukti"
slug: 299-resep-ayam-rica-rica-terbukti
date: 2020-09-23T12:26:48.690Z
image: https://img-global.cpcdn.com/recipes/60e59ad8f449627a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/60e59ad8f449627a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/60e59ad8f449627a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Brian Park
ratingvalue: 4
reviewcount: 20483
recipeingredient:
- "1 ekor ayam potong 14 buang kulitnya"
- "2 batang serai memarkan"
- "3 lembar daun jeruk"
- "3 cm lengkuas memarkan"
- "3 cm jahe memarkan"
- "secukupnya garam"
- "Secukupnya penyedap rasa"
- "2 sdm kecap manis"
- "1 sdt perasan jeruk nipis"
- "1 sdm gula merah"
- " Kemangi"
- "secukupnya air"
- " Bumbu halus"
- "15 buah cabai rawit merah"
- "5 buah cabai merah besar"
- "5 siung bawang putih"
- "10 siung bawang merah"
- "1 buah tomat"
recipeinstructions:
- "Panaskan minyak lalu goreng ayam sampai 1/2 matang, sisihkan"
- "Haluskan bumbu kemudian tumis sampai harum"
- "Tambahkan bahan2 lainnya"
- "Masukkan ayam dan tambahkan air, aduk rata"
- "Masak sampai ayam matang dan bumbu meresap"
- "Koreksi rasa lalu masukkan kemangi"
- "Masak sebentar sambil diaduk"
- "Siap disajikan"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 233 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica-rica](https://img-global.cpcdn.com/recipes/60e59ad8f449627a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau gurih. Ciri khas masakan Indonesia ayam rica-rica yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-rica untuk keluarga. kebiasaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda coba salah satunya ayam rica-rica yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica:

1. Jangan lupa 1 ekor ayam, potong 14 buang kulitnya
1. Harus ada 2 batang serai, memarkan
1. Harap siapkan 3 lembar daun jeruk
1. Jangan lupa 3 cm lengkuas, memarkan
1. Diperlukan 3 cm jahe, memarkan
1. Harap siapkan secukupnya garam
1. Harap siapkan Secukupnya penyedap rasa
1. Siapkan 2 sdm kecap manis
1. Tambah 1 sdt perasan jeruk nipis
1. Harus ada 1 sdm gula merah
1. Harap siapkan  Kemangi
1. Harap siapkan secukupnya air
1. Harus ada  Bumbu halus:
1. Harap siapkan 15 buah cabai rawit merah
1. Harus ada 5 buah cabai merah besar
1. Dibutuhkan 5 siung bawang putih
1. Diperlukan 10 siung bawang merah
1. Siapkan 1 buah tomat




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica:

1. Panaskan minyak lalu goreng ayam sampai 1/2 matang, sisihkan
1. Haluskan bumbu kemudian tumis sampai harum
1. Tambahkan bahan2 lainnya
1. Masukkan ayam dan tambahkan air, aduk rata
1. Masak sampai ayam matang dan bumbu meresap
1. Koreksi rasa lalu masukkan kemangi
1. Masak sebentar sambil diaduk
1. Siap disajikan




Demikianlah cara membuat ayam rica-rica yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
