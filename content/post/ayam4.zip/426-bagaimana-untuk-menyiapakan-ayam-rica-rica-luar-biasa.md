---
description: "Bagaimana untuk menyiapakan Ayam Rica-Rica Luar biasa"
title: "Bagaimana untuk menyiapakan Ayam Rica-Rica Luar biasa"
slug: 426-bagaimana-untuk-menyiapakan-ayam-rica-rica-luar-biasa
date: 2020-08-23T06:02:17.477Z
image: https://img-global.cpcdn.com/recipes/56638a2867f22637/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/56638a2867f22637/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/56638a2867f22637/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Belle Rodriquez
ratingvalue: 4.3
reviewcount: 21383
recipeingredient:
- " Bumbu marinasi"
- "1/2 ekor ayam"
- "1 buah jeruk nipis"
- "1/2 sdt lada bubuk"
- " Bumbu tumis"
- "Secukupnya minyak"
- "5 lembar daun jeruk"
- "1 batang sereh lagi gak ada"
- "1 ruas lengkuas geprek"
- "1/2 sdm garam"
- "1 sdm gula"
- "1 sdt lada bubuk"
- "1 sdt kaldu jamur"
- "2 buah tomat hijau"
- " Bumbu halus 1"
- "20 cabe rawit"
- "5 buah cabe hijau"
- " Bumbu halus 2"
- "2 ruas kunyit"
- "1 ruas jahe"
- "5 siung bawang merah"
- "3 siung bawang putih"
recipeinstructions:
- "Cuci bersih ayam lalu beri perasan jeruk nipis dan lada bubuk, tunggu sampai sekitar 10 menit lalu goreng, sisihkan."
- "Blender bumbu halus 1, sisihkan. Blender bumbu halus 2, sisihkan"
- "Tuang minyak secukupnya, masukkan bumbu halus 2, daun jeruk dan lengkuas, tumis hingga harum"
- "Masukkan bumbu halus 1 lalu masukkan ayam yg sudah d goreng, beri air sedikit, aduk-aduk lalu tambahkan garam, gula, lada bubuk dan kaldu jamur. Jangan lupa tes rasa"
- "Terakhir masukkan tomat hijau yg telah dipotong-potong. Sajikan"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 106 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/56638a2867f22637/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica-rica yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan keistimewahan yang merupakan keragaman Nusantara

Keharmonisan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-Rica untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang dapat anda praktekkan salah satunya ayam rica-rica yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 22 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Siapkan  Bumbu marinasi
1. Siapkan 1/2 ekor ayam
1. Diperlukan 1 buah jeruk nipis
1. Jangan lupa 1/2 sdt lada bubuk
1. Harap siapkan  Bumbu tumis
1. Harap siapkan Secukupnya minyak
1. Tambah 5 lembar daun jeruk
1. Dibutuhkan 1 batang sereh (lagi gak ada)
1. Siapkan 1 ruas lengkuas geprek
1. Diperlukan 1/2 sdm garam
1. Harus ada 1 sdm gula
1. Siapkan 1 sdt lada bubuk
1. Jangan lupa 1 sdt kaldu jamur
1. Dibutuhkan 2 buah tomat hijau
1. Jangan lupa  Bumbu halus 1
1. Diperlukan 20 cabe rawit
1. Harus ada 5 buah cabe hijau
1. Tambah  Bumbu halus 2
1. Dibutuhkan 2 ruas kunyit
1. Jangan lupa 1 ruas jahe
1. Dibutuhkan 5 siung bawang merah
1. Harus ada 3 siung bawang putih




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica:

1. Cuci bersih ayam lalu beri perasan jeruk nipis dan lada bubuk, tunggu sampai sekitar 10 menit lalu goreng, sisihkan.
1. Blender bumbu halus 1, sisihkan. Blender bumbu halus 2, sisihkan
1. Tuang minyak secukupnya, masukkan bumbu halus 2, daun jeruk dan lengkuas, tumis hingga harum
1. Masukkan bumbu halus 1 lalu masukkan ayam yg sudah d goreng, beri air sedikit, aduk-aduk lalu tambahkan garam, gula, lada bubuk dan kaldu jamur. Jangan lupa tes rasa
1. Terakhir masukkan tomat hijau yg telah dipotong-potong. Sajikan




Demikianlah cara membuat ayam rica-rica yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
