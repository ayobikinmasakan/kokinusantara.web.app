---
description: "Cara untuk membuat Ayam Rica-Rica Kemangi Terbukti"
title: "Cara untuk membuat Ayam Rica-Rica Kemangi Terbukti"
slug: 250-cara-untuk-membuat-ayam-rica-rica-kemangi-terbukti
date: 2020-12-11T07:25:27.004Z
image: https://img-global.cpcdn.com/recipes/c5d0fdf24024715e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c5d0fdf24024715e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c5d0fdf24024715e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Leah Ross
ratingvalue: 4.8
reviewcount: 33606
recipeingredient:
- "1/2 ekor ayam"
- "4 ikat kemangi petik"
- "2 btg sereh geprek"
- "2 lbr daun salam"
- "7 lbr daun jeruk"
- " Lengkuas secukupnya geprek"
- " Air perasan jeruk nipis sedikit saja"
- "5 bh cabe rawit merah utuh bisa diskip"
- "secukupnya Gula merah"
- "secukupnya Kaldu jamur bubuk"
- "secukupnya Garam"
- "secukupnya Air"
- " Bumbu yg Dihaluskan"
- "6 btr bawang merah"
- "3 btr bawang putih"
- "9 bh cabe merah keriting"
- "12 bh cabe rawit merah"
- "2 btr kemiri sangrai"
- "2 ruas jahe"
- "2 ruas kunyit"
recipeinstructions:
- "Goreng sebentar semua bahan bumbu halus kecuali kemiri &amp; kunyit. Setelah digoreng, diamkan sebentar lalu blender bersama kemiri, kunyit, dan minyak sedikit"
- "Tumis bumbu yg telah dihaluskan bersama dg sereh, lengkuas, daun salam, &amp; daun jeruk sampai harum"
- "Masukan kaldu jamur, garam, dan gula merah, tumis kembali hingga matang"
- "Masukan ayam, masak hingga bumbu merata"
- "Masukan air, aduk-aduk dan diamkan sebentar"
- "Masukan air perasan jeruk nipis, icip untuk koreksi rasa, masukan cabe rawit merah, masak kembali hingga air meresap"
- "Masukan kemangi, aduk-aduk, dan SELESAI 😊"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 217 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/c5d0fdf24024715e/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga gurih. Ciri khas kuliner Nusantara ayam rica-rica kemangi yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.




Keharmonisan keluarga dapat ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-Rica Kemangi untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi makanan yang bisa anda contoh salah satunya ayam rica-rica kemangi yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Kemangi:

1. Harus ada 1/2 ekor ayam
1. Jangan lupa 4 ikat kemangi, petik
1. Harap siapkan 2 btg sereh, geprek
1. Siapkan 2 lbr daun salam
1. Harus ada 7 lbr daun jeruk
1. Harus ada  Lengkuas secukupnya, geprek
1. Siapkan  Air perasan jeruk nipis (sedikit saja)
1. Tambah 5 bh cabe rawit merah utuh (bisa diskip)
1. Jangan lupa secukupnya Gula merah
1. Harap siapkan secukupnya Kaldu jamur bubuk
1. Dibutuhkan secukupnya Garam
1. Harus ada secukupnya Air
1. Tambah  Bumbu yg Dihaluskan
1. Harap siapkan 6 btr bawang merah
1. Siapkan 3 btr bawang putih
1. Harus ada 9 bh cabe merah keriting
1. Jangan lupa 12 bh cabe rawit merah
1. Tambah 2 btr kemiri, sangrai
1. Dibutuhkan 2 ruas jahe
1. Harap siapkan 2 ruas kunyit




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-Rica Kemangi:

1. Goreng sebentar semua bahan bumbu halus kecuali kemiri &amp; kunyit. Setelah digoreng, diamkan sebentar lalu blender bersama kemiri, kunyit, dan minyak sedikit
1. Tumis bumbu yg telah dihaluskan bersama dg sereh, lengkuas, daun salam, &amp; daun jeruk sampai harum
1. Masukan kaldu jamur, garam, dan gula merah, tumis kembali hingga matang
1. Masukan ayam, masak hingga bumbu merata
1. Masukan air, aduk-aduk dan diamkan sebentar
1. Masukan air perasan jeruk nipis, icip untuk koreksi rasa, masukan cabe rawit merah, masak kembali hingga air meresap
1. Masukan kemangi, aduk-aduk, dan SELESAI 😊




Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
