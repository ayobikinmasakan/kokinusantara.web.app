---
description: "Cara untuk membuat Ayam Rica-rica Kemangi Cepat"
title: "Cara untuk membuat Ayam Rica-rica Kemangi Cepat"
slug: 321-cara-untuk-membuat-ayam-rica-rica-kemangi-cepat
date: 2020-12-04T12:38:47.805Z
image: https://img-global.cpcdn.com/recipes/00bd827261d1c0d9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/00bd827261d1c0d9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/00bd827261d1c0d9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Ruth Scott
ratingvalue: 4.7
reviewcount: 16432
recipeingredient:
- "1/2 kg Daging ayam paha atas"
- "1 ikat Kemangi siangi  cuci"
- "1 buah Jeruk nipis"
- "2 batang Serai geprek"
- "2 lembar Daun salam tambahan sy"
- "5 lembar Daun jeruk"
- "1 ruas Lengkuas geprek"
- "1 batang Daun bawang iris"
- "1 sdm Gula merah"
- "Secukupnya Garam  Kaldu ayam bubuk"
- "Secukupnya Air"
- "Secukupnya Minyak goreng utk menumis"
- " Bumbu halus "
- "6 buah Bawang merah"
- "2 siung Bawang putih"
- "6 buah Cabe merah keriting"
- "10 buah Cabe rawit domba"
- "2 buah Kemiri"
- "1 ruas Jahe"
- "1 ruas Kunyit"
recipeinstructions:
- "Beri perasan jeruk nipis pada daging ayam. Diamkan selama 30 menit. Cuci bersih dan potong2 sesuai selera."
- "Panaskan minyak goreng, tumis bumbu halus, serai, daun salam, daun jeruk, dan lengkuas hingga harum. Masukkan daging ayam, masak hingga berubah warna kemudian tambah air hingga menutupi daging ayam."
- "Masukkan garam, kaldu ayam bubuk, dan gula merah. Aduk rata. Masak hingga air mengental dan daging empuk. Koreksi rasa."
- "Terakhir masukkan kemangi dan daun bawang. Matikan api kompor. Ayam rica-rica kemangi siap disajikan 🥰🥰"
- "Makan sama nasi panas aja udh nikmaaat bangeettt 😋😋"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 266 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT53M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/00bd827261d1c0d9/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang harus kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu memberikan keistimewahan yang merupakan keragaman Indonesia

Kedekatan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam Rica-rica Kemangi untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda coba salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi:

1. Dibutuhkan 1/2 kg Daging ayam (paha atas)
1. Dibutuhkan 1 ikat Kemangi, siangi &amp; cuci
1. Dibutuhkan 1 buah Jeruk nipis
1. Jangan lupa 2 batang Serai, geprek
1. Siapkan 2 lembar Daun salam (tambahan sy)
1. Diperlukan 5 lembar Daun jeruk
1. Tambah 1 ruas Lengkuas, geprek
1. Diperlukan 1 batang Daun bawang, iris
1. Siapkan 1 sdm Gula merah
1. Jangan lupa Secukupnya Garam &amp; Kaldu ayam bubuk
1. Tambah Secukupnya Air
1. Tambah Secukupnya Minyak goreng (utk menumis)
1. Harus ada  Bumbu halus :
1. Dibutuhkan 6 buah Bawang merah
1. Diperlukan 2 siung Bawang putih
1. Jangan lupa 6 buah Cabe merah keriting
1. Harus ada 10 buah Cabe rawit domba
1. Siapkan 2 buah Kemiri
1. Jangan lupa 1 ruas Jahe
1. Jangan lupa 1 ruas Kunyit




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Kemangi:

1. Beri perasan jeruk nipis pada daging ayam. Diamkan selama 30 menit. Cuci bersih dan potong2 sesuai selera.
1. Panaskan minyak goreng, tumis bumbu halus, serai, daun salam, daun jeruk, dan lengkuas hingga harum. Masukkan daging ayam, masak hingga berubah warna kemudian tambah air hingga menutupi daging ayam.
1. Masukkan garam, kaldu ayam bubuk, dan gula merah. Aduk rata. Masak hingga air mengental dan daging empuk. Koreksi rasa.
1. Terakhir masukkan kemangi dan daun bawang. Matikan api kompor. Ayam rica-rica kemangi siap disajikan 🥰🥰
1. Makan sama nasi panas aja udh nikmaaat bangeettt 😋😋




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
