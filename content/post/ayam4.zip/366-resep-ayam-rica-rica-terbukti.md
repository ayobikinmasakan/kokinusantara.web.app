---
description: "Resep : Ayam rica-rica Terbukti"
title: "Resep : Ayam rica-rica Terbukti"
slug: 366-resep-ayam-rica-rica-terbukti
date: 2020-09-12T06:47:54.675Z
image: https://img-global.cpcdn.com/recipes/ef2cd48d9630e90b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ef2cd48d9630e90b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ef2cd48d9630e90b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Jennie Owens
ratingvalue: 5
reviewcount: 27700
recipeingredient:
- "250 gr dada ayam filet"
- "2 lembar daun jeruk"
- "1 batang serai"
- "2 lembar daun salam"
- "1 ruas laos"
- "10 sdm minyak goreng"
- "1 1/2 sdm gula"
- "1 sdt garam"
- "Sejumput micin"
- "Sejumput penyedap rasa"
- "200 ml Air"
- " Bumbu halus"
- "10 biji cabai rawit merah"
- "5 biji cabai merah besar"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "1 cm jahe"
- "2 cm kunyit"
- "1 sdt merica"
recipeinstructions:
- "Potong dadu daging ayam."
- "Haluskan cabai, bawang merah, bawang putih, jahe, kunyit dan merica"
- "Geprak laos dan serai"
- "Panaskan minyak. Kemudian tumis bumbu halus, serai, daun salam, laos dan daun jeruk sampai harum"
- "Masukkan ayam yang sudah di potong -potong tadi."
- "Beri air. Tunggu sampai mendidih. Masukkan garam, gula, micin dan penyedap rasa."
- "Tunggu sampai sedikit surut airnya dan daging sudah empuk."
- "Angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 268 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica-rica](https://img-global.cpcdn.com/recipes/ef2cd48d9630e90b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica-rica yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa kesan tersendiri yang merupakan keragaman Kita

Keharmonisan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam rica-rica untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang bisa anda buat salah satunya ayam rica-rica yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam rica-rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica:

1. Diperlukan 250 gr dada ayam filet
1. Dibutuhkan 2 lembar daun jeruk
1. Siapkan 1 batang serai
1. Harap siapkan 2 lembar daun salam
1. Harap siapkan 1 ruas laos
1. Harus ada 10 sdm minyak goreng
1. Harus ada 1 1/2 sdm gula
1. Diperlukan 1 sdt garam
1. Tambah Sejumput micin
1. Siapkan Sejumput penyedap rasa
1. Harus ada 200 ml Air
1. Tambah  Bumbu halus:
1. Siapkan 10 biji cabai rawit merah
1. Dibutuhkan 5 biji cabai merah besar
1. Harus ada 5 siung bawang merah
1. Diperlukan 4 siung bawang putih
1. Diperlukan 1 cm jahe
1. Dibutuhkan 2 cm kunyit
1. Dibutuhkan 1 sdt merica




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica:

1. Potong dadu daging ayam.
1. Haluskan cabai, bawang merah, bawang putih, jahe, kunyit dan merica
1. Geprak laos dan serai
1. Panaskan minyak. Kemudian tumis bumbu halus, serai, daun salam, laos dan daun jeruk sampai harum
1. Masukkan ayam yang sudah di potong -potong tadi.
1. Beri air. Tunggu sampai mendidih. Masukkan garam, gula, micin dan penyedap rasa.
1. Tunggu sampai sedikit surut airnya dan daging sudah empuk.
1. Angkat dan sajikan.




Demikianlah cara membuat ayam rica-rica yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
