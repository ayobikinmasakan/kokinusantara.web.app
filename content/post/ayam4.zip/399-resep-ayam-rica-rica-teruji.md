---
description: "Resep : Ayam Rica Rica Teruji"
title: "Resep : Ayam Rica Rica Teruji"
slug: 399-resep-ayam-rica-rica-teruji
date: 2020-09-29T07:51:54.939Z
image: https://img-global.cpcdn.com/recipes/c80cd2bd0dd9d86a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c80cd2bd0dd9d86a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c80cd2bd0dd9d86a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: John Henry
ratingvalue: 4.8
reviewcount: 38738
recipeingredient:
- "1 ekor Ayam"
- "1 buah jeruk nipis"
- " Kaldu bubuk optional"
- " Minyak secukupnya untuk menggoreng ayam"
- "2 lembar Daun salam"
- "3 lembar Daun jeruk iris tipis"
- "1 tangkai Daun bawang iris sedang"
- "2 ikat kecil Daun kemangi sesuai selera"
- "1 batang Sereh geprek"
- "200 ml Air"
- " Bumbu yang dihaluskan "
- "10 buah Cabai merah keriting"
- "8 buah Cabai rawit sesuai selera"
- "5 siung Bawang merah"
- "2 siung Bawang putih"
- "3 butir kemiri"
- "1 ruas jari Kunyit"
- "1 ruas jari lengkuas"
- "1 ruas jari jahe"
- "1 sdt Garam"
- "1  2 sdt Gula putih"
- " Kaldu bubuk rasa ayam optional"
recipeinstructions:
- "Potong ayam menjadi 10 bagian. Bersihkan. Lumuri dengan air jeruk nipis dan kaldu bubuk (optional), diamkan 30 menit. Lalu goreng 1/2 matang, angkat tiriskan."
- "Siapkan bumbu-bumbu. Haluskan, diulek atau diblender. Tumis bumbu halus (ambil 2 sendok makan minyak bekas goreng ayam), masukkan daun salam, serai dan daun jeruk, tumis sampai harum. Masukkan ayam, aduk rata dengan bumbu."
- "Tuang air dan tambahkan garam, gula putih dan kaldu bubuk, ratakan. Masak ayam sampai air kering (sesekali ayam diaduk), sebelum diangkat masukkan daun kemangi dan daun bawang, aduk rata, tes rasa. Ayam rica-rica siap disantap."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 161 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT39M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/c80cd2bd0dd9d86a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita jaga karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica rica yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Kedekatan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica Rica untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang dapat anda coba salah satunya ayam rica rica yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 3 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica:

1. Harus ada 1 ekor Ayam
1. Diperlukan 1 buah jeruk nipis
1. Jangan lupa  Kaldu bubuk (optional)
1. Harus ada  Minyak secukupnya untuk menggoreng ayam
1. Dibutuhkan 2 lembar Daun salam
1. Harap siapkan 3 lembar Daun jeruk (iris tipis)
1. Jangan lupa 1 tangkai Daun bawang (iris sedang)
1. Harus ada 2 ikat kecil Daun kemangi (sesuai selera)
1. Harap siapkan 1 batang Sereh (geprek)
1. Diperlukan 200 ml Air
1. Siapkan  Bumbu yang dihaluskan :
1. Harus ada 10 buah Cabai merah keriting
1. Harap siapkan 8 buah Cabai rawit (sesuai selera)
1. Dibutuhkan 5 siung Bawang merah
1. Jangan lupa 2 siung Bawang putih
1. Jangan lupa 3 butir kemiri
1. Dibutuhkan 1 ruas jari Kunyit
1. Tambah 1 ruas jari lengkuas
1. Siapkan 1 ruas jari jahe
1. Harus ada 1 sdt Garam
1. Tambah 1 / 2 sdt Gula putih
1. Tambah  Kaldu bubuk rasa ayam (optional)




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica:

1. Potong ayam menjadi 10 bagian. Bersihkan. Lumuri dengan air jeruk nipis dan kaldu bubuk (optional), diamkan 30 menit. Lalu goreng 1/2 matang, angkat tiriskan.
1. Siapkan bumbu-bumbu. Haluskan, diulek atau diblender. Tumis bumbu halus (ambil 2 sendok makan minyak bekas goreng ayam), masukkan daun salam, serai dan daun jeruk, tumis sampai harum. Masukkan ayam, aduk rata dengan bumbu.
1. Tuang air dan tambahkan garam, gula putih dan kaldu bubuk, ratakan. Masak ayam sampai air kering (sesekali ayam diaduk), sebelum diangkat masukkan daun kemangi dan daun bawang, aduk rata, tes rasa. Ayam rica-rica siap disantap.




Demikianlah cara membuat ayam rica rica yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
