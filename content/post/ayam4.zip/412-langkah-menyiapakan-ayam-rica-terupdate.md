---
description: "Langkah menyiapakan Ayam Rica terupdate"
title: "Langkah menyiapakan Ayam Rica terupdate"
slug: 412-langkah-menyiapakan-ayam-rica-terupdate
date: 2020-08-13T10:33:11.562Z
image: https://img-global.cpcdn.com/recipes/de1146df94709b73/751x532cq70/ayam-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/de1146df94709b73/751x532cq70/ayam-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/de1146df94709b73/751x532cq70/ayam-rica-foto-resep-utama.jpg
author: Douglas Cole
ratingvalue: 4.6
reviewcount: 6552
recipeingredient:
- "1/2 kg ayam potong2"
- "12 buah cabai merah keriting"
- "6 butir bawang merah"
- "2 siung bawang putih"
- "1 ruas kecil jahe geprek"
- "1/2 ruas kunyit geprek"
- "3 butir kemiri haluskan"
- "2 buah tomat"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1/2 ruas lengkuas geprek"
- "1 batang serai"
- "1 sdt garam"
- "1/2 buah gula merah"
- "1 sdm gula pasir"
- "1/2 sdt kaldu bubuk"
- "1/4 sdt merica"
- "1 sdm kecap manis"
- "Secukupnya daun kemangi"
- "Secukupnya daun bawang"
- "2 gelas air"
recipeinstructions:
- "Haluskan semua bumbu kecuali daun jeruk, daun salam, lengkuas, dan serai. Tumis semua bumbu bersamaan hingga harum."
- "Tambahkan tomat yang sudah dipotong-potong, aduk rata hingga tomat layu dan hancur."
- "Masukkan ayam. Aduk rata hingga 1/2 kering lalu beri air 1 gelas. Setelah mendidih masukkan gula, garam, merica dan kaldu bubuk. Besarkan api. Aduk sesekali hingga air menyusut."
- "Koreksi rasa. Tambahkan kecap manis. Terakhir masukkan daun kemangi dan daun bawang. Aduk sebentar lalu matikan api."
- "Angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica

katakunci: ayam rica 
nutrition: 202 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica](https://img-global.cpcdn.com/recipes/de1146df94709b73/751x532cq70/ayam-rica-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan empuk. Karasteristik masakan Nusantara ayam rica yang penuh dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang dapat anda buat salah satunya ayam rica yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep ayam rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica:

1. Diperlukan 1/2 kg ayam, potong2
1. Harap siapkan 12 buah cabai merah keriting
1. Diperlukan 6 butir bawang merah
1. Diperlukan 2 siung bawang putih
1. Harap siapkan 1 ruas kecil jahe, geprek
1. Tambah 1/2 ruas kunyit, geprek
1. Jangan lupa 3 butir kemiri, haluskan
1. Siapkan 2 buah tomat
1. Siapkan 2 lembar daun salam
1. Dibutuhkan 2 lembar daun jeruk
1. Harus ada 1/2 ruas lengkuas, geprek
1. Harus ada 1 batang serai
1. Harus ada 1 sdt garam
1. Jangan lupa 1/2 buah gula merah
1. Harus ada 1 sdm gula pasir
1. Siapkan 1/2 sdt kaldu bubuk
1. Jangan lupa 1/4 sdt merica
1. Tambah 1 sdm kecap manis
1. Siapkan Secukupnya daun kemangi
1. Harus ada Secukupnya daun bawang
1. Siapkan 2 gelas air




<!--inarticleads2-->

##### Cara membuat  Ayam Rica:

1. Haluskan semua bumbu kecuali daun jeruk, daun salam, lengkuas, dan serai. Tumis semua bumbu bersamaan hingga harum.
1. Tambahkan tomat yang sudah dipotong-potong, aduk rata hingga tomat layu dan hancur.
1. Masukkan ayam. Aduk rata hingga 1/2 kering lalu beri air 1 gelas. Setelah mendidih masukkan gula, garam, merica dan kaldu bubuk. Besarkan api. Aduk sesekali hingga air menyusut.
1. Koreksi rasa. Tambahkan kecap manis. Terakhir masukkan daun kemangi dan daun bawang. Aduk sebentar lalu matikan api.
1. Angkat dan sajikan.




Demikianlah cara membuat ayam rica yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
