---
description: "Resep : Usus Ayam Rica - Rica Homemade"
title: "Resep : Usus Ayam Rica - Rica Homemade"
slug: 382-resep-usus-ayam-rica-rica-homemade
date: 2021-01-20T16:34:01.996Z
image: https://img-global.cpcdn.com/recipes/a22a6ae74fba3279/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a22a6ae74fba3279/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a22a6ae74fba3279/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg
author: Ronnie Summers
ratingvalue: 4.3
reviewcount: 23098
recipeingredient:
- "1/2 kg usus ayam"
- "1 biji jeruk nipis"
- "1 batang sereh memarkan"
- "2 lembar daun jeruk"
- "1 lembar daun salam"
- " minyak goreng"
- "secukupnya garam"
- "secukupnya kaldu jamur"
- " Bumbu Halus "
- "5 siung bawang merah"
- "3 siungbawang putih"
- "1 buah cabe merah besar"
- "10 buah cabe rawit"
- "1 buah tomat"
recipeinstructions:
- "Bersihkan usus ayam kemudian peras dengan 1 biji jeruk nipis diamkan 15 menit cuci bersih kemudian rebus sampai matang"
- "Jika sudah di rasa cukup matang matikan api cuci bersih kemudian potong2"
- "Haluskan bawang meeah, bawang putih tomat dan cabe merah besar dan cabe rawit sampai halus."
- "Jika sudah halus tumis bumbu dengan minyak horeng secukupnya sampai harum kemudian masukan sereh, Daun jeruk dan daun salam. aduk rata"
- "Kemudian masukan usus ayam aduk rata beri sedikit air aduk rata masukan garam dan kaldu jamur tunggu air meyusut dan meresap cek rasa dan matikan api."
- "Usus ayam rica2 siap di santap dengan nasi hangat"
categories:
- Recipe
tags:
- usus
- ayam
- rica

katakunci: usus ayam rica 
nutrition: 119 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dessert

---


![Usus Ayam Rica - Rica](https://img-global.cpcdn.com/recipes/a22a6ae74fba3279/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau renyah. Karasteristik kuliner Nusantara usus ayam rica - rica yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga bisa didapat dengan cara mudah. Diantaranya adalah memasak Usus Ayam Rica - Rica untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak varian makanan yang dapat anda contoh salah satunya usus ayam rica - rica yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep usus ayam rica - rica tanpa harus bersusah payah.
Seperti resep Usus Ayam Rica - Rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Usus Ayam Rica - Rica:

1. Dibutuhkan 1/2 kg usus ayam
1. Harus ada 1 biji jeruk nipis
1. Siapkan 1 batang sereh memarkan
1. Dibutuhkan 2 lembar daun jeruk
1. Dibutuhkan 1 lembar daun salam
1. Tambah  minyak goreng
1. Diperlukan secukupnya garam
1. Dibutuhkan secukupnya kaldu jamur
1. Harus ada  Bumbu Halus :
1. Siapkan 5 siung bawang merah
1. Dibutuhkan 3 siungbawang putih
1. Harus ada 1 buah cabe merah besar
1. Harap siapkan 10 buah cabe rawit
1. Harap siapkan 1 buah tomat




<!--inarticleads2-->

##### Cara membuat  Usus Ayam Rica - Rica:

1. Bersihkan usus ayam kemudian peras dengan 1 biji jeruk nipis diamkan 15 menit cuci bersih kemudian rebus sampai matang
1. Jika sudah di rasa cukup matang matikan api cuci bersih kemudian potong2
1. Haluskan bawang meeah, bawang putih tomat dan cabe merah besar dan cabe rawit sampai halus.
1. Jika sudah halus tumis bumbu dengan minyak horeng secukupnya sampai harum kemudian masukan sereh, Daun jeruk dan daun salam. aduk rata
1. Kemudian masukan usus ayam aduk rata beri sedikit air aduk rata masukan garam dan kaldu jamur tunggu air meyusut dan meresap cek rasa dan matikan api.
1. Usus ayam rica2 siap di santap dengan nasi hangat




Demikianlah cara membuat usus ayam rica - rica yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
