---
description: "Resep : Ayam Bakar Madu Pedas Manis Favorite"
title: "Resep : Ayam Bakar Madu Pedas Manis Favorite"
slug: 5-resep-ayam-bakar-madu-pedas-manis-favorite
date: 2020-10-05T17:08:18.207Z
image: https://img-global.cpcdn.com/recipes/5d9358a282d69193/751x532cq70/ayam-bakar-madu-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5d9358a282d69193/751x532cq70/ayam-bakar-madu-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5d9358a282d69193/751x532cq70/ayam-bakar-madu-pedas-manis-foto-resep-utama.jpg
author: Mildred Lewis
ratingvalue: 4.4
reviewcount: 9368
recipeingredient:
- "1 kg Ayam"
- " Bumbu Halus"
- "6 sium Bawang Putih"
- "8 sium Bawang Merah"
- "5 buah Cabai Merah"
- "5 buah Cabai Rawit Setan"
- "3 butir Kemiri"
- "2 ruas Jahe"
- "2 ruas Kunyit"
- "1 sdt Ketumbar"
- "1 sdt Lada butirlada halus"
- "1/4 sdt Jinten"
- "1 sdt Garam"
- "1 sdt Penyedap RasaKaldu Jamur"
- "Secukupnya air 50ml"
- "Secukupnya Minyak untuk menumis"
- " Bahan Tambahan Saat Ungkep Ayam"
- "1 Liter Air Bersih"
- "150 ml Santan aku 2 bungkus santen Sasa segitiga dilarutkan dengan air"
- "1 buah Gula Merah Kecil"
- "1 batang Sereh Geprek"
- "2 Ruas Lengkuas Geprek"
- "3 lembar Daun Jeruk"
- "3 lembar Daun Salam"
- "3 sdm Kecap Manis"
- "3 sdm Madu merk apa sajamadu murni"
- " Bahan Olesan saat Bakar Ayam"
- "5 sdm Kecap Manis"
- "1 sdt Saus Tiram aku Kikkoman"
- "2 sdm Madu"
recipeinstructions:
- "Bersihkan ayam dan rebus sebentar untuk menghilangkan kotoran dan lemak pada ayam."
- "Haluskan bumbu, kemudian tumis dengan minyak secukupnya sampai harum. Aku lebih suka di tumis sebentar agar tidak langu."
- "Masukan bumbu halus kedalam panci, kemudian tambahkan bahan lainnya. Masak hingga air agak menyusut dan meresap kedalam ayam."
- "Panggang ayam dengan berikan olesan bumbu. Angkat jika sudah merasa cukup."
- "Ayam yang belum mau di panggang bisa dimasukkan kedalam kulkas. Kemudian ayam bisa dinikmati bersama nasi panas dan lauh lainnya (tempe/tahu)"
categories:
- Recipe
tags:
- ayam
- bakar
- madu

katakunci: ayam bakar madu 
nutrition: 196 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT43M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Bakar Madu Pedas Manis](https://img-global.cpcdn.com/recipes/5d9358a282d69193/751x532cq70/ayam-bakar-madu-pedas-manis-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita jaga karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam bakar madu pedas manis yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Kita

Keharmonisan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam Bakar Madu Pedas Manis untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang dapat anda contoh salah satunya ayam bakar madu pedas manis yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep ayam bakar madu pedas manis tanpa harus bersusah payah.
Berikut ini resep Ayam Bakar Madu Pedas Manis yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 30 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Bakar Madu Pedas Manis:

1. Tambah 1 kg Ayam
1. Siapkan  Bumbu Halus
1. Siapkan 6 sium Bawang Putih
1. Siapkan 8 sium Bawang Merah
1. Diperlukan 5 buah Cabai Merah
1. Jangan lupa 5 buah Cabai Rawit Setan
1. Dibutuhkan 3 butir Kemiri
1. Tambah 2 ruas Jahe
1. Siapkan 2 ruas Kunyit
1. Jangan lupa 1 sdt Ketumbar
1. Jangan lupa 1 sdt Lada butir/lada halus
1. Dibutuhkan 1/4 sdt Jinten
1. Siapkan 1 sdt Garam
1. Siapkan 1 sdt Penyedap Rasa/Kaldu Jamur
1. Harus ada Secukupnya air (50ml)
1. Jangan lupa Secukupnya Minyak untuk menumis
1. Dibutuhkan  Bahan Tambahan Saat Ungkep Ayam
1. Siapkan 1 Liter Air Bersih
1. Harus ada 150 ml Santan (aku: 2 bungkus santen Sasa segitiga dilarutkan dengan air)
1. Tambah 1 buah Gula Merah Kecil
1. Harap siapkan 1 batang Sereh Geprek
1. Harus ada 2 Ruas Lengkuas Geprek
1. Harus ada 3 lembar Daun Jeruk
1. Diperlukan 3 lembar Daun Salam
1. Diperlukan 3 sdm Kecap Manis
1. Diperlukan 3 sdm Madu (merk apa saja/madu murni)
1. Dibutuhkan  Bahan Olesan saat Bakar Ayam
1. Jangan lupa 5 sdm Kecap Manis
1. Diperlukan 1 sdt Saus Tiram (aku: Kikkoman)
1. Dibutuhkan 2 sdm Madu




<!--inarticleads2-->

##### Instruksi membuat  Ayam Bakar Madu Pedas Manis:

1. Bersihkan ayam dan rebus sebentar untuk menghilangkan kotoran dan lemak pada ayam.
1. Haluskan bumbu, kemudian tumis dengan minyak secukupnya sampai harum. Aku lebih suka di tumis sebentar agar tidak langu.
1. Masukan bumbu halus kedalam panci, kemudian tambahkan bahan lainnya. Masak hingga air agak menyusut dan meresap kedalam ayam.
1. Panggang ayam dengan berikan olesan bumbu. Angkat jika sudah merasa cukup.
1. Ayam yang belum mau di panggang bisa dimasukkan kedalam kulkas. Kemudian ayam bisa dinikmati bersama nasi panas dan lauh lainnya (tempe/tahu)




Demikianlah cara membuat ayam bakar madu pedas manis yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
