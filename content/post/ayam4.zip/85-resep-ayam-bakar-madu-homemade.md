---
description: "Resep : Ayam Bakar Madu Homemade"
title: "Resep : Ayam Bakar Madu Homemade"
slug: 85-resep-ayam-bakar-madu-homemade
date: 2020-10-03T19:33:36.248Z
image: https://img-global.cpcdn.com/recipes/2750f92116f9898b/751x532cq70/ayam-bakar-madu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2750f92116f9898b/751x532cq70/ayam-bakar-madu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2750f92116f9898b/751x532cq70/ayam-bakar-madu-foto-resep-utama.jpg
author: Jeanette Klein
ratingvalue: 4.7
reviewcount: 40110
recipeingredient:
- "1 ekor ayam potong jadi 6"
- "1 cm lengkuas"
- "1 cm jahe"
- "5 cm Gula merah diameter"
- "1 sdt asam jawa"
- " Bumbu halus"
- "4 siung bawang putih"
- "6 siung bawang merah"
- "1 sdt ketumbar bubuk"
- "1 sdt merica bubuk"
- "1 cm kunyit"
- " Bumbu olesan"
- "1 sdm margarin cair"
- "3 sdm madu"
- "2 sdm kecap manis"
- "1 sdm jeruk nipis"
- " Dioles pakai sereh"
- " Bahan sambal"
- "12 buah cabai rawit merah"
- "1 siung bawang putih"
- "1 sdm gula pasir"
- "1 sdt garam"
- "1 sdt terasi"
- "1 buah tomat iris"
- "1 ikat kemangi"
recipeinstructions:
- "Bersihkan ayam, lumuri dengan jeruk nipis dan diamkan 15 menit"
- "Haluskan bumbu hingga halus, tambahkan garam"
- "Panaskan minyak, tumis bumbu halus hingga harum. Masukkan ayam aduk aduk sebentar. Kemudian tambahkan air."
- "Masukkan gula merah masak hingga meresap dan air menyusut."
- "Siapkan wadah untuk mencampurkan bahan olesan."
- "Bakar sebentar ayam hingga matang sempurna. Temani dengan sambal kemangi."
- "Siapkan bahan sambal kemangi. Uleg halus cabai, bawang putih"
- "Iris iris tomat, campurkan dengan cabai yang telah dihaluskan tadi. Tambahkan gula, garam, dan terakhir masukkan kemangi"
categories:
- Recipe
tags:
- ayam
- bakar
- madu

katakunci: ayam bakar madu 
nutrition: 189 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT30M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Bakar Madu](https://img-global.cpcdn.com/recipes/2750f92116f9898b/751x532cq70/ayam-bakar-madu-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau enak. Ciri makanan Nusantara ayam bakar madu yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam Bakar Madu untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda contoh salah satunya ayam bakar madu yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam bakar madu tanpa harus bersusah payah.
Berikut ini resep Ayam Bakar Madu yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 25 bahan dan 8 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Bakar Madu:

1. Harap siapkan 1 ekor ayam potong jadi 6
1. Siapkan 1 cm lengkuas
1. Tambah 1 cm jahe
1. Diperlukan 5 cm Gula merah diameter
1. Harus ada 1 sdt asam jawa
1. Dibutuhkan  Bumbu halus
1. Harus ada 4 siung bawang putih
1. Siapkan 6 siung bawang merah
1. Harus ada 1 sdt ketumbar bubuk
1. Diperlukan 1 sdt merica bubuk
1. Jangan lupa 1 cm kunyit
1. Siapkan  Bumbu olesan
1. Tambah 1 sdm margarin cair
1. Diperlukan 3 sdm madu
1. Siapkan 2 sdm kecap manis
1. Harap siapkan 1 sdm jeruk nipis
1. Dibutuhkan  Dioles pakai sereh
1. Siapkan  Bahan sambal
1. Diperlukan 12 buah cabai rawit merah
1. Diperlukan 1 siung bawang putih
1. Siapkan 1 sdm gula pasir
1. Dibutuhkan 1 sdt garam
1. Harus ada 1 sdt terasi
1. Dibutuhkan 1 buah tomat iris
1. Tambah 1 ikat kemangi




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Bakar Madu:

1. Bersihkan ayam, lumuri dengan jeruk nipis dan diamkan 15 menit
1. Haluskan bumbu hingga halus, tambahkan garam
1. Panaskan minyak, tumis bumbu halus hingga harum. Masukkan ayam aduk aduk sebentar. Kemudian tambahkan air.
1. Masukkan gula merah masak hingga meresap dan air menyusut.
1. Siapkan wadah untuk mencampurkan bahan olesan.
1. Bakar sebentar ayam hingga matang sempurna. Temani dengan sambal kemangi.
1. Siapkan bahan sambal kemangi. Uleg halus cabai, bawang putih
1. Iris iris tomat, campurkan dengan cabai yang telah dihaluskan tadi. Tambahkan gula, garam, dan terakhir masukkan kemangi




Demikianlah cara membuat ayam bakar madu yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
