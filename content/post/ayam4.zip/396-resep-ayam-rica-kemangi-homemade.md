---
description: "Resep : Ayam Rica Kemangi Homemade"
title: "Resep : Ayam Rica Kemangi Homemade"
slug: 396-resep-ayam-rica-kemangi-homemade
date: 2020-08-21T03:18:46.732Z
image: https://img-global.cpcdn.com/recipes/5b512e02c7c8e3b0/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5b512e02c7c8e3b0/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5b512e02c7c8e3b0/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Roxie Medina
ratingvalue: 4.5
reviewcount: 35358
recipeingredient:
- " Bahan utama"
- "10 potong ayam"
- "1 buah lemon untuk marinasi"
- "1 ikat kemangi petik daunnya"
- " Bahan yang dihaluskandirajang"
- "6 siung bawang merah"
- "1 siung bawang putih"
- "5 buah cabe merah atau tambah rawit bila suka pedas"
- "1 cm jahe"
- "3 cm kunyit"
- "1 batang sereh memarkan"
- "2 lembar daun salam"
- "3 lembar daun jeruk iris2"
recipeinstructions:
- "Bersihkan ayam. Lumuri dengan perasan jeruk nipis. Simpan di kulkas selama 15 menit. Petik daun kemangi, sisinkan."
- "Siapkan bumbu yg akan dihaluskan/diiris."
- "Haluskan bawang, kunyit, jahe, cabe, dengan ulekan atau blender. Iris daun jeruk, memarkan sereh. Sisihkan bersama daun salam."
- "Siapkan minyak panas di wajan. Tumis bumbu halus hingga harum. Kemudian masukkan daun salam, daun jeruj,.dan sereh. Lanjutkan tumis sampai harum/matang."
- "Masukkan potongan ayam, aduk2 masak hingga kira2 dagingnya sudah tidak terlihat merah atau bumbu meresap. Beri air secukupnya. Tambakan garam dan gula pasir. Test rasa. Tutup wajan dan masak sampai kuah ayam sedikit mengering/meresap dan dagingnya empuk."
- "Setelah daging empuk dan rasa sudah oke, masukkan daun kemangi, aduk2 sebentar, lalu matikan kompor."
- "Ayam Rica Kemangi siap dinikmati."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 155 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/5b512e02c7c8e3b0/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang patut kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah menampilkan kesan tersendiri yang merupakan keragaman Indonesia

Kehangatan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang bisa anda praktekkan salah satunya ayam rica kemangi yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Tambah  Bahan utama
1. Jangan lupa 10 potong ayam
1. Diperlukan 1 buah lemon untuk marinasi
1. Tambah 1 ikat kemangi, petik daunnya
1. Harap siapkan  Bahan yang dihaluskan/dirajang
1. Dibutuhkan 6 siung bawang merah
1. Siapkan 1 siung bawang putih
1. Diperlukan 5 buah cabe merah, atau tambah rawit bila suka pedas
1. Jangan lupa 1 cm jahe
1. Harus ada 3 cm kunyit
1. Dibutuhkan 1 batang sereh, memarkan
1. Harap siapkan 2 lembar daun salam
1. Harus ada 3 lembar daun jeruk, iris2




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Kemangi:

1. Bersihkan ayam. Lumuri dengan perasan jeruk nipis. Simpan di kulkas selama 15 menit. Petik daun kemangi, sisinkan.
1. Siapkan bumbu yg akan dihaluskan/diiris.
1. Haluskan bawang, kunyit, jahe, cabe, dengan ulekan atau blender. Iris daun jeruk, memarkan sereh. Sisihkan bersama daun salam.
1. Siapkan minyak panas di wajan. Tumis bumbu halus hingga harum. Kemudian masukkan daun salam, daun jeruj,.dan sereh. Lanjutkan tumis sampai harum/matang.
1. Masukkan potongan ayam, aduk2 masak hingga kira2 dagingnya sudah tidak terlihat merah atau bumbu meresap. Beri air secukupnya. Tambakan garam dan gula pasir. Test rasa. Tutup wajan dan masak sampai kuah ayam sedikit mengering/meresap dan dagingnya empuk.
1. Setelah daging empuk dan rasa sudah oke, masukkan daun kemangi, aduk2 sebentar, lalu matikan kompor.
1. Ayam Rica Kemangi siap dinikmati.




Demikianlah cara membuat ayam rica kemangi yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
