---
description: "Cara membuat Opor Ayam Simple 🇮🇩 Teruji"
title: "Cara membuat Opor Ayam Simple 🇮🇩 Teruji"
slug: 494-cara-membuat-opor-ayam-simple-teruji
date: 2020-10-06T06:34:42.779Z
image: https://img-global.cpcdn.com/recipes/8705125c41610c8d/751x532cq70/opor-ayam-simple-🇮🇩-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8705125c41610c8d/751x532cq70/opor-ayam-simple-🇮🇩-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8705125c41610c8d/751x532cq70/opor-ayam-simple-🇮🇩-foto-resep-utama.jpg
author: Dennis Griffin
ratingvalue: 4.8
reviewcount: 23759
recipeingredient:
- "1 ekor ayam"
- "1 buat jeruk nipis"
- " Bumbu halus "
- "7 siung bawang merah"
- "5 siung bawang putih"
- "3 butir kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- " Bahan Cemplung "
- "1 ruas lengkuas keprek"
- "2 batang sereh keprek"
- "2 lembar daun salam"
- "1 sdt garam"
- "1 sdm kaldu jamur"
- "Sejumput ladamerica bubuk"
- "Sejumput gula"
- "1/2 butir kelapa santan 500ml"
- "200 ml air"
- "3 Sdm minyak goreng"
recipeinstructions:
- "Siapkan bumbu halus yang sudah di bersihkan n cuci (bawang putih n Merah, kemiri, jahe, kunyit) haluskan. Keprek lengkuas dan sereh."
- "Bersihkan ayam, balurkan dengan jeruk nipis dan sisihkan. Selama 5 menit. Lalu cuci sekali saja dengan air bersih dan sisihkan."
- "Siapkan wajan, masuk minyak panaskan dengan api sedang lalu masukkan bumbu halus, sereh, lengkuas dan daun salam, tumis hingga harum. Lalu masukkan Ayam, aduk sebentar lalu tambahkan air, masak hingga ayam mulai berubah warna dan ayam empuk."
- "Setelah nampak ayam berubah warna, masukkan santan, aduk perlahan. Tambahkan garam, kaldu jamur, gula, merica, aduk kembali agar tercampur. Masak kembali hingga bumbu meresap. Test rasa dan matikan kompor. Salin opor dan beri taburan bawang goreng."
categories:
- Recipe
tags:
- opor
- ayam
- simple

katakunci: opor ayam simple 
nutrition: 182 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT30M"
recipeyield: "1"
recipecategory: Dinner

---


![Opor Ayam Simple 🇮🇩](https://img-global.cpcdn.com/recipes/8705125c41610c8d/751x532cq70/opor-ayam-simple-🇮🇩-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan renyah. Ciri makanan Nusantara opor ayam simple 🇮🇩 yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.




Kehangatan keluarga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Opor Ayam Simple 🇮🇩 untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda coba salah satunya opor ayam simple 🇮🇩 yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep opor ayam simple 🇮🇩 tanpa harus bersusah payah.
Berikut ini resep Opor Ayam Simple 🇮🇩 yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Opor Ayam Simple 🇮🇩:

1. Harap siapkan 1 ekor ayam
1. Diperlukan 1 buat jeruk nipis
1. Diperlukan  Bumbu halus :
1. Siapkan 7 siung bawang merah
1. Harap siapkan 5 siung bawang putih
1. Harus ada 3 butir kemiri
1. Jangan lupa 1 ruas jahe
1. Harus ada 1 ruas kunyit
1. Diperlukan  Bahan Cemplung :
1. Harap siapkan 1 ruas lengkuas (keprek)
1. Harus ada 2 batang sereh (keprek)
1. Jangan lupa 2 lembar daun salam
1. Tambah 1 sdt garam
1. Jangan lupa 1 sdm kaldu jamur
1. Siapkan Sejumput lada/merica bubuk
1. Jangan lupa Sejumput gula
1. Diperlukan 1/2 butir kelapa (santan) 500ml
1. Dibutuhkan 200 ml air
1. Siapkan 3 Sdm minyak goreng




<!--inarticleads2-->

##### Bagaimana membuat  Opor Ayam Simple 🇮🇩:

1. Siapkan bumbu halus yang sudah di bersihkan n cuci (bawang putih n Merah, kemiri, jahe, kunyit) haluskan. Keprek lengkuas dan sereh.
1. Bersihkan ayam, balurkan dengan jeruk nipis dan sisihkan. Selama 5 menit. Lalu cuci sekali saja dengan air bersih dan sisihkan.
1. Siapkan wajan, masuk minyak panaskan dengan api sedang lalu masukkan bumbu halus, sereh, lengkuas dan daun salam, tumis hingga harum. Lalu masukkan Ayam, aduk sebentar lalu tambahkan air, masak hingga ayam mulai berubah warna dan ayam empuk.
1. Setelah nampak ayam berubah warna, masukkan santan, aduk perlahan. Tambahkan garam, kaldu jamur, gula, merica, aduk kembali agar tercampur. Masak kembali hingga bumbu meresap. Test rasa dan matikan kompor. Salin opor dan beri taburan bawang goreng.




Demikianlah cara membuat opor ayam simple 🇮🇩 yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
