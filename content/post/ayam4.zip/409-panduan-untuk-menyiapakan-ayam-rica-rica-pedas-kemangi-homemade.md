---
description: "Panduan untuk menyiapakan Ayam Rica-rica Pedas Kemangi Homemade"
title: "Panduan untuk menyiapakan Ayam Rica-rica Pedas Kemangi Homemade"
slug: 409-panduan-untuk-menyiapakan-ayam-rica-rica-pedas-kemangi-homemade
date: 2021-01-06T08:47:55.749Z
image: https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
author: Isaac Barton
ratingvalue: 4.6
reviewcount: 4510
recipeingredient:
- "1/2 ekor ayam yg sudah direbus dan dipotong sesuai selera tanpa direbus juga boleh"
- "3 lembar daun salam"
- "3 lembar daun jeruk purut"
- "2 batang serai geprek"
- "5 cm lengkuas geprek"
- "1 genggam daunh kemangi"
- "1 lembar daun kunyit"
- "1 batang daun bawang"
- " Bumbu halus "
- "7 siung bawang merah"
- "3 siung bawang putih"
- "6 cm kunyit"
- "6 cm jahe"
- "4 butir kemiri sangrai"
- "1 sdm ketumbar sangrai"
- " Cabe rawit secukupnya bisa banyak bila mau pedes banget"
- "2 buah tomat"
- "500 ml air masak"
- " Minyak goreng utk menumis bumbu"
- "sesuai selera Garam dan penyedap rasa ayam"
recipeinstructions:
- "Siapkan semua bumbu. Ayam saya rebus sekitaran 10 menit dan tiriskan lalu potong sesuai selera. Ketumbar dan kemiri saya sangrai dan tumbuk. Kemudian bumbu halus saya blender."
- "Tumis bumbu hingga wangi dan berubah warna, masukan ayam dan aduk sebentar. Kemudian tuang air hingga menutupi ayam dan beri garam dan penyedap rasa. Aduk hingga rata dan diamkan sekitar 5 menit. Kemudian masukan kemangi, daun kunyit, dan daun bawang. Masak hingga air menyusut."
- "Masukan tomat dan aduk sebentar dan koreksi rasa. Setelah matang dan air menyusut maka ayam rica pedas kemangi siap dihidangkan."
- "Resep ini mudah banget dicobain moms. Enak deh. Dan ayam rica-rica kemangi benar nikmat dan yummy. 🥰🥰🥰🥰"
categories:
- Recipe
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 207 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica-rica Pedas Kemangi](https://img-global.cpcdn.com/recipes/0fbe6bc28195c770/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica-rica pedas kemangi yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia

Kedekatan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica-rica Pedas Kemangi untuk keluarga bisa dicoba. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang dapat anda praktekkan salah satunya ayam rica-rica pedas kemangi yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica-rica pedas kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Pedas Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica Pedas Kemangi:

1. Diperlukan 1/2 ekor ayam yg sudah direbus dan dipotong sesuai selera (tanpa direbus juga boleh)
1. Jangan lupa 3 lembar daun salam
1. Harap siapkan 3 lembar daun jeruk purut
1. Diperlukan 2 batang serai geprek
1. Dibutuhkan 5 cm lengkuas, geprek
1. Siapkan 1 genggam daunh kemangi
1. Jangan lupa 1 lembar daun kunyit
1. Diperlukan 1 batang daun bawang
1. Tambah  Bumbu halus :
1. Siapkan 7 siung bawang merah
1. Diperlukan 3 siung bawang putih
1. Siapkan 6 cm kunyit
1. Dibutuhkan 6 cm jahe
1. Harus ada 4 butir kemiri sangrai
1. Siapkan 1 sdm ketumbar sangrai
1. Tambah  Cabe rawit secukupnya (bisa banyak bila mau pedes banget)
1. Harus ada 2 buah tomat
1. Jangan lupa 500 ml air masak
1. Jangan lupa  Minyak goreng utk menumis bumbu
1. Diperlukan sesuai selera Garam dan penyedap rasa ayam




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-rica Pedas Kemangi:

1. Siapkan semua bumbu. Ayam saya rebus sekitaran 10 menit dan tiriskan lalu potong sesuai selera. Ketumbar dan kemiri saya sangrai dan tumbuk. Kemudian bumbu halus saya blender.
1. Tumis bumbu hingga wangi dan berubah warna, masukan ayam dan aduk sebentar. Kemudian tuang air hingga menutupi ayam dan beri garam dan penyedap rasa. Aduk hingga rata dan diamkan sekitar 5 menit. Kemudian masukan kemangi, daun kunyit, dan daun bawang. Masak hingga air menyusut.
1. Masukan tomat dan aduk sebentar dan koreksi rasa. Setelah matang dan air menyusut maka ayam rica pedas kemangi siap dihidangkan.
1. Resep ini mudah banget dicobain moms. Enak deh. Dan ayam rica-rica kemangi benar nikmat dan yummy. 🥰🥰🥰🥰




Demikianlah cara membuat ayam rica-rica pedas kemangi yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
