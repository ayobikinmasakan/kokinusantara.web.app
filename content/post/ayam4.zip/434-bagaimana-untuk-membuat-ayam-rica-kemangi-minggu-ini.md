---
description: "Bagaimana untuk membuat Ayam Rica Kemangi minggu ini"
title: "Bagaimana untuk membuat Ayam Rica Kemangi minggu ini"
slug: 434-bagaimana-untuk-membuat-ayam-rica-kemangi-minggu-ini
date: 2020-09-03T09:46:20.135Z
image: https://img-global.cpcdn.com/recipes/625f1026f12c3a19/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/625f1026f12c3a19/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/625f1026f12c3a19/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Lewis Mendoza
ratingvalue: 4.4
reviewcount: 35177
recipeingredient:
- "4 potong Ayam ukuran sedang"
- "1 ikat Daun Kemangi petiki daunnya"
- " BumbuBumbu"
- "5 siung Bawang Merah"
- "3 siung Bawang Putih"
- "10 buah Cabe Merah"
- "10 buah Cabe Rawit Merah"
- "2 lembar Daun Salam"
- "3 lembar Daun Jeruk"
- "1 batang Serai geprek"
- "2 cm Lengkuas geprek"
- "Secukupnya gula  garam"
- "250 ml air"
- " Minyak untuk menumis"
recipeinstructions:
- "Goreng ayam sampai berkulit dan agak kering, sisihkan"
- "Haluskan Duo Bawang, Cabe Merah, &amp; Cabe Rawit merah"
- "Tumis bumbu yang sudah dihaluskan, tambahkan daun salam, daun jeruk, serai, dan lengkuas. Tumis sampai harum"
- "Masukkan ayam, tumis ±3 menit.. Masukkan air, masak sampai bumbu meresap dan air menyusut."
- "Masukkan gula &amp; garam, tes rasa."
- "Masukkan Daun Kemangi, masak sampai daun layu."
- "Angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 298 calories
recipecuisine: American
preptime: "PT39M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/625f1026f12c3a19/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang setidaknya kita jaga karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Indonesia



Kedekatan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Kemangi untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda contoh salah satunya ayam rica kemangi yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 7 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Harus ada 4 potong Ayam ukuran sedang
1. Dibutuhkan 1 ikat Daun Kemangi, petiki daunnya
1. Dibutuhkan  Bumbu-Bumbu
1. Diperlukan 5 siung Bawang Merah
1. Harap siapkan 3 siung Bawang Putih
1. Diperlukan 10 buah Cabe Merah
1. Siapkan 10 buah Cabe Rawit Merah
1. Dibutuhkan 2 lembar Daun Salam
1. Jangan lupa 3 lembar Daun Jeruk
1. Tambah 1 batang Serai, geprek
1. Siapkan 2 cm Lengkuas, geprek
1. Diperlukan Secukupnya gula &amp; garam
1. Dibutuhkan 250 ml air
1. Jangan lupa  Minyak untuk menumis




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Goreng ayam sampai berkulit dan agak kering, sisihkan
1. Haluskan Duo Bawang, Cabe Merah, &amp; Cabe Rawit merah
1. Tumis bumbu yang sudah dihaluskan, tambahkan daun salam, daun jeruk, serai, dan lengkuas. Tumis sampai harum
1. Masukkan ayam, tumis ±3 menit.. Masukkan air, masak sampai bumbu meresap dan air menyusut.
1. Masukkan gula &amp; garam, tes rasa.
1. Masukkan Daun Kemangi, masak sampai daun layu.
1. Angkat dan sajikan.




Demikianlah cara membuat ayam rica kemangi yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan cepat, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
