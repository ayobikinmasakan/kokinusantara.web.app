---
description: "Panduan untuk menyiapakan Ayam rica rica teraktual"
title: "Panduan untuk menyiapakan Ayam rica rica teraktual"
slug: 359-panduan-untuk-menyiapakan-ayam-rica-rica-teraktual
date: 2020-12-06T20:08:11.991Z
image: https://img-global.cpcdn.com/recipes/e6d820cd74c7d31b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e6d820cd74c7d31b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e6d820cd74c7d31b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Hulda Ross
ratingvalue: 4.5
reviewcount: 10536
recipeingredient:
- " Ayam potong paha sayap dada sesuai selera"
- " bumbu marinir ayam"
- "2 sdm garam"
- "1/2 sdt kunyit bubuk"
- " bumbu halus"
- "4-5 siung bawang merah"
- "12 cabe merah kecil"
- "5 siung bawang putih"
- "1 inci jahe"
- "2 kemiri"
- " bahan tambahan"
- "1 batang serai"
- " I inci lengkuas"
- "secukupnya Daun bawang"
- "2-3 lembar daun jeruk"
- "secukupnya Daun kemangi"
- "secukupnya Garam"
- " Gula"
- "500 ml air"
recipeinstructions:
- "Ayam yg sudah di potong dan bersih kan selanjutnya kita marinir dengan garam dan kunyit bubuk lalu aduk aduk dan diamkan dulu sebelum nanti kita goreng"
- "Selanjutnya aku blender halus jahe dan kemiri dan tambahkan sedikit air"
- "Lalu setelah jahe dan kemiri halus selanjutnya aku masukan bawang merah, bawang putih, cabe dan aku blender Kasar saja"
- "Selanjutnya potong daun bawang kecil kecil dan geprek serai nya dan siapkan lengkuas nya juga lalu potong daun jeruk dan buang tangkai nya"
- "Selanjutnya aku panaskan minyak dan goreng ayam sampai matang tapi jangan sampai kering kalo sudah matang angkat dan tiriskan"
- "Selanjutnya aku tumis bumbunya dan aku aduk aduk sampai bau harum"
- "Lalu aku masukan serai yg sudah di geprek dan lengkuas serta masukan juga daun jeruk nya aduk aduk sampai bau harum dan bumbu matang"
- "Dan selanjutnya aku masukan ayamnya dan aku aduk aduk setelah itu aku tambahkan juga air nya aduk aduk kembali dan aku tambahkan juga garam dan gula nya lalu aduk aduk agar semua tercampur rata lalu biyarkan air sampai meresap"
- "Setelah air meresap aku masukan daun bawang dan daun kemangi lalu aduk aduk kembali dan aku matikan kompor agar kemangi tidak lembek"
- "Dan selanjutnya kita hidangkan semoga bermanfaat yah"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 154 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica rica](https://img-global.cpcdn.com/recipes/e6d820cd74c7d31b/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan renyah. Karasteristik masakan Nusantara ayam rica rica yang penuh dengan rempah membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Kedekatan rumah tangga bisa ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica rica untuk keluarga. kebersamaan makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang dapat anda contoh salah satunya ayam rica rica yang merupakan resep terkenal yang simpel dengan varian sederhana. Untungnya saat ini kamu bisa dengan gampang menemukan resep ayam rica rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 19 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica:

1. Diperlukan  Ayam potong (paha, sayap, dada) sesuai selera
1. Jangan lupa  bumbu marinir ayam
1. Siapkan 2 sdm garam
1. Harap siapkan 1/2 sdt kunyit bubuk
1. Jangan lupa  bumbu halus
1. Diperlukan 4-5 siung bawang merah
1. Harus ada 12 cabe merah kecil
1. Dibutuhkan 5 siung bawang putih
1. Harus ada 1 inci jahe
1. Dibutuhkan 2 kemiri
1. Tambah  bahan tambahan
1. Tambah 1 batang serai
1. Dibutuhkan  I inci lengkuas
1. Harus ada secukupnya Daun bawang
1. Dibutuhkan 2-3 lembar daun jeruk
1. Harus ada secukupnya Daun kemangi
1. Dibutuhkan secukupnya Garam
1. Siapkan  Gula
1. Harus ada 500 ml air




<!--inarticleads2-->

##### Cara membuat  Ayam rica rica:

1. Ayam yg sudah di potong dan bersih kan selanjutnya kita marinir dengan garam dan kunyit bubuk lalu aduk aduk dan diamkan dulu sebelum nanti kita goreng
1. Selanjutnya aku blender halus jahe dan kemiri dan tambahkan sedikit air
1. Lalu setelah jahe dan kemiri halus selanjutnya aku masukan bawang merah, bawang putih, cabe dan aku blender Kasar saja
1. Selanjutnya potong daun bawang kecil kecil dan geprek serai nya dan siapkan lengkuas nya juga lalu potong daun jeruk dan buang tangkai nya
1. Selanjutnya aku panaskan minyak dan goreng ayam sampai matang tapi jangan sampai kering kalo sudah matang angkat dan tiriskan
1. Selanjutnya aku tumis bumbunya dan aku aduk aduk sampai bau harum
1. Lalu aku masukan serai yg sudah di geprek dan lengkuas serta masukan juga daun jeruk nya aduk aduk sampai bau harum dan bumbu matang
1. Dan selanjutnya aku masukan ayamnya dan aku aduk aduk setelah itu aku tambahkan juga air nya aduk aduk kembali dan aku tambahkan juga garam dan gula nya lalu aduk aduk agar semua tercampur rata lalu biyarkan air sampai meresap
1. Setelah air meresap aku masukan daun bawang dan daun kemangi lalu aduk aduk kembali dan aku matikan kompor agar kemangi tidak lembek
1. Dan selanjutnya kita hidangkan semoga bermanfaat yah




Demikianlah cara membuat ayam rica rica yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
