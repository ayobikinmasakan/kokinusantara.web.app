---
description: "Panduan untuk menyiapakan Ayam Rica-Rica Luar biasa"
title: "Panduan untuk menyiapakan Ayam Rica-Rica Luar biasa"
slug: 241-panduan-untuk-menyiapakan-ayam-rica-rica-luar-biasa
date: 2020-12-14T20:08:42.316Z
image: https://img-global.cpcdn.com/recipes/a4610e7a732e8c9c/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a4610e7a732e8c9c/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a4610e7a732e8c9c/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Roxie Douglas
ratingvalue: 4.9
reviewcount: 41780
recipeingredient:
- "1 ekor Ayam sy 12 ekor"
- "1/2 Buah jeruk nipis ambil airnya"
- "2 cm Kunyit haluskan"
- "1/4 sdt Garam"
- " Bumbu Halus "
- "1 ons Cabe Kriting sy pakai 7 Buah"
- "1/2 ons cabe Rawit sy pakai 6 Buah"
- "5 siung bawang merah"
- "5 siung bawang putih sy cuma pakai 3 siung besar2"
- "2 cm jahe"
- "2 cm kunyit"
- "3 Butir kemiri"
- "2 cm Lengkuas sy skip lagi ga Punya"
- " Bumbu Kasar "
- "3 batang serai"
- "1 lembar daun pandan"
- "5 lembar daun sala"
- "5 lembar daun jeruk"
- "2 ikat daun kemangi sy skip krn ga Punya"
- "2 batang daun bawang tambahan dari Saya"
- "Secukupnya garam"
- "Sejumput Gula pasir tambahan dari Saya"
- "Secukupnya penyedap Rasa sy skip"
- "Secukupnya air matang"
- "Secukupnya Minyak goreng"
recipeinstructions:
- "Potong2 Ayam, kemudian cuci bersih, lumuri dengan kunyit yg sudah dihaluskan (bs pakai kunyit bubuk) air jeruk nipis (1 sdm) dan Garam, diamkan selama 15 Menit supaya menyerap. Setelah itu goreng ayam 1/2 Kering, sisihkan."
- "Siapkan Bumbu yang Akan di haluskan kemudian cuci bersih, Setelah itu haluskan dengan Blender, sisihkan. Siapkan bumbu Kasar, simpul daun pandan, potong2 kasar daun jeruk dan daun bawang."
- "Siapkan wajan dan beri sedikit minyak kemudian tumis bumbu halus sampai Harum kemudian masukkan, daun salam, daun pandan dan sereh, masak sampai Harum. Masukkan ayam aduk rata."
- "Beri air, masak hingga air sedikit menyusut, tambahkan Garam dan gula, aduk rata masak hingga tercampur rata, masak lagi hingga air menyusut banyak. Setelah air menyusut tambahkan daun jeruk dan daun bawang."
- "Aduk rata, masak lagi sebentar, koreksi Rasa, kemudian angkat, siap di sajikan dengan Nasi hangat, Selamat mencoba 😉🙏"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 286 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/a4610e7a732e8c9c/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan renyah. Karasteristik makanan Indonesia ayam rica-rica yang kaya dengan rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan keluarga dapat ditemukan dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica-Rica untuk keluarga. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda buat salah satunya ayam rica-rica yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 25 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica:

1. Diperlukan 1 ekor Ayam (sy 1/2 ekor)
1. Harus ada 1/2 Buah jeruk nipis (ambil airnya)
1. Harap siapkan 2 cm Kunyit (haluskan)
1. Harus ada 1/4 sdt Garam
1. Dibutuhkan  Bumbu Halus :
1. Tambah 1 ons Cabe Kriting (sy pakai 7 Buah)
1. Tambah 1/2 ons cabe Rawit (sy pakai 6 Buah)
1. Harus ada 5 siung bawang merah
1. Dibutuhkan 5 siung bawang putih (sy cuma pakai 3 siung besar2)
1. Tambah 2 cm jahe
1. Tambah 2 cm kunyit
1. Dibutuhkan 3 Butir kemiri
1. Dibutuhkan 2 cm Lengkuas (sy skip lagi ga Punya)
1. Siapkan  Bumbu Kasar :
1. Siapkan 3 batang serai
1. Harus ada 1 lembar daun pandan
1. Dibutuhkan 5 lembar daun sala
1. Tambah 5 lembar daun jeruk
1. Tambah 2 ikat daun kemangi (sy skip krn ga Punya)
1. Siapkan 2 batang daun bawang (tambahan dari Saya)
1. Siapkan Secukupnya garam
1. Dibutuhkan Sejumput Gula pasir (tambahan dari Saya)
1. Tambah Secukupnya penyedap Rasa (sy skip)
1. Harap siapkan Secukupnya air matang
1. Harus ada Secukupnya Minyak goreng




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica:

1. Potong2 Ayam, kemudian cuci bersih, lumuri dengan kunyit yg sudah dihaluskan (bs pakai kunyit bubuk) air jeruk nipis (1 sdm) dan Garam, diamkan selama 15 Menit supaya menyerap. Setelah itu goreng ayam 1/2 Kering, sisihkan.
1. Siapkan Bumbu yang Akan di haluskan kemudian cuci bersih, Setelah itu haluskan dengan Blender, sisihkan. Siapkan bumbu Kasar, simpul daun pandan, potong2 kasar daun jeruk dan daun bawang.
1. Siapkan wajan dan beri sedikit minyak kemudian tumis bumbu halus sampai Harum kemudian masukkan, daun salam, daun pandan dan sereh, masak sampai Harum. Masukkan ayam aduk rata.
1. Beri air, masak hingga air sedikit menyusut, tambahkan Garam dan gula, aduk rata masak hingga tercampur rata, masak lagi hingga air menyusut banyak. Setelah air menyusut tambahkan daun jeruk dan daun bawang.
1. Aduk rata, masak lagi sebentar, koreksi Rasa, kemudian angkat, siap di sajikan dengan Nasi hangat, Selamat mencoba 😉🙏




Demikianlah cara membuat ayam rica-rica yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan terbukti, anda bisa mencari di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
