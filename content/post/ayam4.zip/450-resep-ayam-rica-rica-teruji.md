---
description: "Resep : Ayam rica-rica Teruji"
title: "Resep : Ayam rica-rica Teruji"
slug: 450-resep-ayam-rica-rica-teruji
date: 2021-01-28T06:38:14.258Z
image: https://img-global.cpcdn.com/recipes/b52bca4cf69ab450/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b52bca4cf69ab450/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b52bca4cf69ab450/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Jean Lawrence
ratingvalue: 4.9
reviewcount: 20869
recipeingredient:
- "1 ekor ayam potong sesuai selera jangan terlalu besar"
- "1 jeruk nipis"
- "3 ikat daun kemangi"
- " Daun bawang"
- "1 buah bawang bombay"
- " Daun salam daun jeruk"
- "2 batang sereh memarkan"
- "1 ruas lengkuas"
- " Garam gula merica penyedap rasa"
- "1 sdm saus sambal optional"
- " Bumbu halus"
- "10 siung bawah merah"
- "3 siung bawah putih"
- "1 ruas jahe"
- "1 ruas kunyit bakar sebentar"
- "1 tomat ukuran sedang"
- "2 butir kemiri"
- "sesuai selera Cabe keriting"
recipeinstructions:
- "Bersihkan ayam, beri perasan jeruk diamkan sejenak, kemudian cuci bersih. Siapkan bumbu halus"
- "Tumis bumbu halus bersama bumbu dapur sampai harum. Kemudian masukan ayam, beri gula, garam, merica. Beri air secukupnya. Bisa ditambah saus cabe jika mau. Aduk rata.Tunggu hingga air tersisa sedikit. Matikan api."
- "Jika ingin hasil yang maksimal, biasanya saya akan biarkan terlebih dahulu agar bumbu meresap. Jika saya masak pagi, saya akan hidangkan malam hari. Jika saya masak malam, saya akan hidangkan untuk pagi hari."
- "Setelah bumbu meresap, masak kembali, beri minyak goreng secukupnya, dan masukan irisan bawang bombay. Aduk rata. Koreksi rasa."
- "Setelah bawang bombay layu, masukan daun kemangi dan daun bawang. Aduk sebentar, matikan api. Hidangkan dengan nasi panas."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 165 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam rica-rica](https://img-global.cpcdn.com/recipes/b52bca4cf69ab450/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica-rica yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa ciri khas yang merupakan keragaman Kita

Kedekatan rumah tangga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam rica-rica untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.

Resep Ayam Rica Rica Bahan: Daging Ayam Lemon juice Chicken powder Garam. Bawang merah Bawang putih Cabe Jahe Serai Daun jeruk purut Daun kucai. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda coba salah satunya ayam rica-rica yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam rica-rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica:

1. Harus ada 1 ekor ayam potong sesuai selera (jangan terlalu besar)
1. Diperlukan 1 jeruk nipis
1. Harap siapkan 3 ikat daun kemangi
1. Harap siapkan  Daun bawang
1. Harap siapkan 1 buah bawang bombay
1. Harus ada  Daun salam, daun jeruk
1. Diperlukan 2 batang sereh, memarkan
1. Jangan lupa 1 ruas lengkuas
1. Harap siapkan  Garam, gula, merica, penyedap rasa
1. Dibutuhkan 1 sdm saus sambal (optional)
1. Diperlukan  Bumbu halus
1. Diperlukan 10 siung bawah merah
1. Tambah 3 siung bawah putih
1. Jangan lupa 1 ruas jahe
1. Dibutuhkan 1 ruas kunyit, bakar sebentar
1. Jangan lupa 1 tomat ukuran sedang
1. Jangan lupa 2 butir kemiri
1. Dibutuhkan sesuai selera Cabe keriting


Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. Tak hanya ayam, anda juga bisa memasak. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. 

<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica:

1. Bersihkan ayam, beri perasan jeruk diamkan sejenak, kemudian cuci bersih. Siapkan bumbu halus
1. Tumis bumbu halus bersama bumbu dapur sampai harum. Kemudian masukan ayam, beri gula, garam, merica. Beri air secukupnya. Bisa ditambah saus cabe jika mau. Aduk rata.Tunggu hingga air tersisa sedikit. Matikan api.
1. Jika ingin hasil yang maksimal, biasanya saya akan biarkan terlebih dahulu agar bumbu meresap. Jika saya masak pagi, saya akan hidangkan malam hari. Jika saya masak malam, saya akan hidangkan untuk pagi hari.
1. Setelah bumbu meresap, masak kembali, beri minyak goreng secukupnya, dan masukan irisan bawang bombay. Aduk rata. Koreksi rasa.
1. Setelah bawang bombay layu, masukan daun kemangi dan daun bawang. Aduk sebentar, matikan api. Hidangkan dengan nasi panas.


Tak hanya ayam, anda juga bisa memasak. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. I really don&#39;t know how it was started but if you take away chili peppers from my life… I&#39;m gone! Chef S Table Ayam Rica Rica. Mukbang Nasi Sama Soup Dan Ayam Rica Makanenakindonesia. 

Demikianlah cara membuat ayam rica-rica yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat simple dan terbukti, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
