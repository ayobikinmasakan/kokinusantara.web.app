---
description: "Cara menyiapakan Ayam Goreng Madu ala Korea Cepat"
title: "Cara menyiapakan Ayam Goreng Madu ala Korea Cepat"
slug: 216-cara-menyiapakan-ayam-goreng-madu-ala-korea-cepat
date: 2021-01-01T01:36:15.994Z
image: https://img-global.cpcdn.com/recipes/3de0fe1ba04e706f/751x532cq70/ayam-goreng-madu-ala-korea-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3de0fe1ba04e706f/751x532cq70/ayam-goreng-madu-ala-korea-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3de0fe1ba04e706f/751x532cq70/ayam-goreng-madu-ala-korea-foto-resep-utama.jpg
author: Alejandro West
ratingvalue: 4.8
reviewcount: 48213
recipeingredient:
- "300 gr ayam"
- "1 batang daun bawang"
- "Biji wijen putih"
- " Minyak untuk menggoreng"
- " Bahan marinasi"
- "3 siung bawang putih"
- "2 cm jahe"
- "1/2 buah jeruk nipis"
- " Garam"
- " Merica bubuk"
- " Bahan tepung ayam goreng"
- "5 sdm tepung bumbu serbaguna"
- "1 sdm tepung maizena"
- "1 butir telur"
- " Bahan saos madu"
- "1/2 bawang bombai ukuran sedang"
- "3 siung bawang putih"
- " Minyak untuk menumis"
- "5 sdm kecap manis"
- "2 sdm saos tomat"
- "2 sdm saos tiram"
- "1/2 buah perasan jeruk nipis"
- "1 sdm minyak wijen"
- " Merica bubuk"
- " Kaldu bubuk"
- "Sedikit air"
recipeinstructions:
- "Haluskan bawang putih dan jahe. Potong-potong ayam."
- "Campurkan ayam dengan jahe dan bawang putih yang sudah dihaluskan, tambahkan garam, merica bubuk dan perasan jeruk nipis hingga merata. Marinasi selama minimal 30 menit (saya masukkan kulkas)."
- "Campurkan tepung bumbu serbaguna dengan tepung maizena. Kocok lepas telur ayam."
- "Celupkan ayam dalam kocokan telur ayam lalu gulingkan di campuran tepung."
- "Panaskan minyak untuk menggoreng. Goreng ayam hingga kering, tiriskan."
- "Untuk saos madu, cincang bawang bombai dan bawang putih. Tumis hingga harum masukkan kecap manis, saos tomat, saos tiram, madu dan minyak wijen. Aduk rata, tambahkan sedikit air. Lalu tambahkan merica dan kaldu bubuk. Koreksi rasa."
- "Masukkan ayam goreng dalam saos, aduk rata hingga melapisi permukaan ayam goreng."
- "Tata di atas piring, taburkan biji wijen putih dan irisan daun bawang."
categories:
- Recipe
tags:
- ayam
- goreng
- madu

katakunci: ayam goreng madu 
nutrition: 135 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Goreng Madu ala Korea](https://img-global.cpcdn.com/recipes/3de0fe1ba04e706f/751x532cq70/ayam-goreng-madu-ala-korea-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga empuk. Ciri khas makanan Indonesia ayam goreng madu ala korea yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk warga asing yang berkunjung.




Keharmonisan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Goreng Madu ala Korea untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang bisa anda buat salah satunya ayam goreng madu ala korea yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam goreng madu ala korea tanpa harus bersusah payah.
Seperti resep Ayam Goreng Madu ala Korea yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 26 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Madu ala Korea:

1. Dibutuhkan 300 gr ayam
1. Harus ada 1 batang daun bawang
1. Tambah Biji wijen putih
1. Diperlukan  Minyak untuk menggoreng
1. Siapkan  Bahan marinasi
1. Jangan lupa 3 siung bawang putih
1. Harus ada 2 cm jahe
1. Harus ada 1/2 buah jeruk nipis
1. Siapkan  Garam
1. Siapkan  Merica bubuk
1. Diperlukan  Bahan tepung ayam goreng
1. Harap siapkan 5 sdm tepung bumbu serbaguna
1. Dibutuhkan 1 sdm tepung maizena
1. Dibutuhkan 1 butir telur
1. Diperlukan  Bahan saos madu
1. Dibutuhkan 1/2 bawang bombai ukuran sedang
1. Diperlukan 3 siung bawang putih
1. Harus ada  Minyak untuk menumis
1. Harus ada 5 sdm kecap manis
1. Harap siapkan 2 sdm saos tomat
1. Tambah 2 sdm saos tiram
1. Siapkan 1/2 buah perasan jeruk nipis
1. Diperlukan 1 sdm minyak wijen
1. Dibutuhkan  Merica bubuk
1. Dibutuhkan  Kaldu bubuk
1. Harap siapkan Sedikit air




<!--inarticleads2-->

##### Instruksi membuat  Ayam Goreng Madu ala Korea:

1. Haluskan bawang putih dan jahe. Potong-potong ayam.
1. Campurkan ayam dengan jahe dan bawang putih yang sudah dihaluskan, tambahkan garam, merica bubuk dan perasan jeruk nipis hingga merata. Marinasi selama minimal 30 menit (saya masukkan kulkas).
1. Campurkan tepung bumbu serbaguna dengan tepung maizena. Kocok lepas telur ayam.
1. Celupkan ayam dalam kocokan telur ayam lalu gulingkan di campuran tepung.
1. Panaskan minyak untuk menggoreng. Goreng ayam hingga kering, tiriskan.
1. Untuk saos madu, cincang bawang bombai dan bawang putih. Tumis hingga harum masukkan kecap manis, saos tomat, saos tiram, madu dan minyak wijen. Aduk rata, tambahkan sedikit air. Lalu tambahkan merica dan kaldu bubuk. Koreksi rasa.
1. Masukkan ayam goreng dalam saos, aduk rata hingga melapisi permukaan ayam goreng.
1. Tata di atas piring, taburkan biji wijen putih dan irisan daun bawang.




Demikianlah cara membuat ayam goreng madu ala korea yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan teruji, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
