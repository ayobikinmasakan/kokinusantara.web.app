---
description: "Resep : Opor Ayam Simpel Homemade"
title: "Resep : Opor Ayam Simpel Homemade"
slug: 489-resep-opor-ayam-simpel-homemade
date: 2020-11-29T10:44:31.478Z
image: https://img-global.cpcdn.com/recipes/9b8f4596b0e6202c/751x532cq70/opor-ayam-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9b8f4596b0e6202c/751x532cq70/opor-ayam-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9b8f4596b0e6202c/751x532cq70/opor-ayam-simpel-foto-resep-utama.jpg
author: Mildred Fox
ratingvalue: 4
reviewcount: 25348
recipeingredient:
- "1/2 kg ayam"
- "6 buah cape merah keriting"
- "3 lbr daun salam"
- "1 batang sereh"
- "1 cm lengkuas"
- "2 batang daun bawang"
- "1 sachet santan disini saya pake santan kara"
- " Bawang goreng"
- " Bumbu halus"
- "6 buah bawang merah"
- "4 buah bawang putih"
- "3 buah cabe rawit optional"
- "1 cm kunyit"
- "1 cm jahe"
- "3 butir kemiri"
- "1 sdt merica bubuk"
- "1/4 sdt ketumbar bubuk"
- "Secukupnya pala"
- " Garam"
- " Gula merah"
- " Penyedap rasa"
recipeinstructions:
- "Potong ayam menjadi beberapa bagian, lalu rebus hingga setengah matang"
- "Haluskan semua bumbu yang terterap pada bagian bumbu halus"
- "Panaskan minyak lalu masukan bumbu halus, daun salam, sereh yang sudah digeprek, dan lengkuas yang sudah digeprek. Tumis hingga harum lalu masukkan potongan cabai keriting"
- "Tambahkan air secukupnya, lalu masukan daging ayam kedalamnya"
- "Masukkan santan pada wajan lalu tambahkan bawang daun, garam, gula dan penyedap rasa sembari koreksi rasanya ya bund"
- "Aduk aduk opor ayamnya supaya santan tidak pecah. Tunggu sampai mendidih"
- "Setelah mendidih dan rasanya sudah pas. Opor ayam pun siap disajikan dan ditaburi bawang goreng agar lebih matulll"
categories:
- Recipe
tags:
- opor
- ayam
- simpel

katakunci: opor ayam simpel 
nutrition: 181 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Dinner

---


![Opor Ayam Simpel](https://img-global.cpcdn.com/recipes/9b8f4596b0e6202c/751x532cq70/opor-ayam-simpel-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita lestarikan karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti opor ayam simpel yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu menampilkan ciri khas yang merupakan keragaman Indonesia

Keharmonisan keluarga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Opor Ayam Simpel untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang dapat anda praktekkan salah satunya opor ayam simpel yang merupakan resep favorite yang simpel dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep opor ayam simpel tanpa harus bersusah payah.
Berikut ini resep Opor Ayam Simpel yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Opor Ayam Simpel:

1. Jangan lupa 1/2 kg ayam
1. Tambah 6 buah cape merah keriting
1. Harap siapkan 3 lbr daun salam
1. Diperlukan 1 batang sereh
1. Dibutuhkan 1 cm lengkuas
1. Harap siapkan 2 batang daun bawang
1. Siapkan 1 sachet santan (disini saya pake santan kara)
1. Jangan lupa  Bawang goreng
1. Jangan lupa  Bumbu halus
1. Siapkan 6 buah bawang merah
1. Siapkan 4 buah bawang putih
1. Diperlukan 3 buah cabe rawit (optional)
1. Dibutuhkan 1 cm kunyit
1. Dibutuhkan 1 cm jahe
1. Harap siapkan 3 butir kemiri
1. Jangan lupa 1 sdt merica bubuk
1. Diperlukan 1/4 sdt ketumbar bubuk
1. Siapkan Secukupnya pala
1. Jangan lupa  Garam
1. Harus ada  Gula merah
1. Jangan lupa  Penyedap rasa




<!--inarticleads2-->

##### Cara membuat  Opor Ayam Simpel:

1. Potong ayam menjadi beberapa bagian, lalu rebus hingga setengah matang
1. Haluskan semua bumbu yang terterap pada bagian bumbu halus
1. Panaskan minyak lalu masukan bumbu halus, daun salam, sereh yang sudah digeprek, dan lengkuas yang sudah digeprek. Tumis hingga harum lalu masukkan potongan cabai keriting
1. Tambahkan air secukupnya, lalu masukan daging ayam kedalamnya
1. Masukkan santan pada wajan lalu tambahkan bawang daun, garam, gula dan penyedap rasa sembari koreksi rasanya ya bund
1. Aduk aduk opor ayamnya supaya santan tidak pecah. Tunggu sampai mendidih
1. Setelah mendidih dan rasanya sudah pas. Opor ayam pun siap disajikan dan ditaburi bawang goreng agar lebih matulll




Demikianlah cara membuat opor ayam simpel yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan cepat, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
