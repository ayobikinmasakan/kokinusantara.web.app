---
description: "Cara singkat untuk menyiapakan Ayam Rica Rica teraktual"
title: "Cara singkat untuk menyiapakan Ayam Rica Rica teraktual"
slug: 452-cara-singkat-untuk-menyiapakan-ayam-rica-rica-teraktual
date: 2021-02-04T05:51:17.928Z
image: https://img-global.cpcdn.com/recipes/1c04ac253aba4c87/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1c04ac253aba4c87/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1c04ac253aba4c87/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Betty White
ratingvalue: 4.5
reviewcount: 38612
recipeingredient:
- "1 ekor ayam pejantan"
- "1 jeruk nipis"
- "100 ml air"
- "2 Sereh geprek"
- "4 Daun Salam"
- "2 Daun Jeruk"
- "1 Daun Pandan"
- "1 sdt garam"
- "1/2 sdt kaldu jamur"
- "1/2 sdt gula pasir aku skip"
- " BAHAN PELENGKAP "
- "iris Daun bawang"
- "iris Daun jeruk"
- " Kemangi aku skip"
- " BUMBU HALUS "
- "10 bh cabe merah"
- "5 cabe rawit aku skip"
- "5 bawang merah"
- "5 bawang putih"
- "3 kemiri goreng atau sangrai"
- "2 ruas lengkuas"
- "2 ruas jahe"
- "1 ruas kunyit"
recipeinstructions:
- "Lumuri ayam dengan jeruk nipis, lalu goreng setengah matang."
- "Blender Bumbu Halus, boleh agak kasar yahh.."
- "Tumis bumbu halus sampai harummm dan matang, masukan daun salam, daun pandan, sereh dan daun jeruk."
- "Masukan ayam yang sudah di goreng setengah matang, lalu aduk merata, kemudian tambahkan air secukupnya."
- "Masak ayam sampai matang dan empuk, dan airnya sudah mulai menyusut. Lalu tambahkan garam dan kaldu jamur, kalau mau pakai gula silahkan saja yah. Koreksi rasa."
- "Terakhir tambahkan daun bawang, daun jeruk iris dan kemangi, ternyata kemangiku ga bisa dipakai jadi aku skip. Tapi rasanya tetep enak dann kaya rasa bangetttttt.....bisa ngabisin nasi. 😄😄"
- "Ayam rica rica siap untuk disajikan. Duh ini tuh enak kalo menurutkuu.. bikin yuk..."
- "Ayam nya lembut, karena aku pake pejantan jadi bumbu nya meresapp, kalau mau pake ayam negeri or kampung boleh ajah yah selera masing2.."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 173 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/1c04ac253aba4c87/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica rica yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Indonesia

Keharmonisan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica Rica untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis makanan yang bisa anda contoh salah satunya ayam rica rica yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 23 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica:

1. Diperlukan 1 ekor ayam pejantan
1. Diperlukan 1 jeruk nipis
1. Harus ada 100 ml air
1. Tambah 2 Sereh geprek
1. Harus ada 4 Daun Salam
1. Dibutuhkan 2 Daun Jeruk
1. Harus ada 1 Daun Pandan
1. Diperlukan 1 sdt garam
1. Tambah 1/2 sdt kaldu jamur
1. Diperlukan 1/2 sdt gula pasir (aku skip)
1. Tambah  BAHAN PELENGKAP :
1. Diperlukan iris Daun bawang
1. Dibutuhkan iris Daun jeruk
1. Harap siapkan  Kemangi (aku skip)
1. Diperlukan  BUMBU HALUS :
1. Harus ada 10 bh cabe merah
1. Jangan lupa 5 cabe rawit (aku skip)
1. Harus ada 5 bawang merah
1. Diperlukan 5 bawang putih
1. Tambah 3 kemiri goreng atau sangrai
1. Diperlukan 2 ruas lengkuas
1. Dibutuhkan 2 ruas jahe
1. Harap siapkan 1 ruas kunyit




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica:

1. Lumuri ayam dengan jeruk nipis, lalu goreng setengah matang.
1. Blender Bumbu Halus, boleh agak kasar yahh..
1. Tumis bumbu halus sampai harummm dan matang, masukan daun salam, daun pandan, sereh dan daun jeruk.
1. Masukan ayam yang sudah di goreng setengah matang, lalu aduk merata, kemudian tambahkan air secukupnya.
1. Masak ayam sampai matang dan empuk, dan airnya sudah mulai menyusut. Lalu tambahkan garam dan kaldu jamur, kalau mau pakai gula silahkan saja yah. Koreksi rasa.
1. Terakhir tambahkan daun bawang, daun jeruk iris dan kemangi, ternyata kemangiku ga bisa dipakai jadi aku skip. Tapi rasanya tetep enak dann kaya rasa bangetttttt.....bisa ngabisin nasi. 😄😄
1. Ayam rica rica siap untuk disajikan. Duh ini tuh enak kalo menurutkuu.. bikin yuk...
1. Ayam nya lembut, karena aku pake pejantan jadi bumbu nya meresapp, kalau mau pake ayam negeri or kampung boleh ajah yah selera masing2..




Demikianlah cara membuat ayam rica rica yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan teruji, anda bisa menelusuri di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
