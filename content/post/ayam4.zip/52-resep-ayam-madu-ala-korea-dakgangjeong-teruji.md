---
description: "Resep : Ayam Madu ala Korea (Dakgangjeong) Teruji"
title: "Resep : Ayam Madu ala Korea (Dakgangjeong) Teruji"
slug: 52-resep-ayam-madu-ala-korea-dakgangjeong-teruji
date: 2021-01-27T04:25:37.759Z
image: https://img-global.cpcdn.com/recipes/91e959560ec66abf/751x532cq70/ayam-madu-ala-korea-dakgangjeong-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/91e959560ec66abf/751x532cq70/ayam-madu-ala-korea-dakgangjeong-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/91e959560ec66abf/751x532cq70/ayam-madu-ala-korea-dakgangjeong-foto-resep-utama.jpg
author: Peter Johnson
ratingvalue: 4.8
reviewcount: 19712
recipeingredient:
- "500 gr ayam potong kecil2"
- " bumbu marinasi ayam"
- "1/2 jahe haluskan"
- "2 siung bawang putih haluskan"
- "1 sdm Minyak wijen"
- "1 sdm Garam  Gula"
- "1 sdm Merica sesuai selera"
- "1 butir telur"
- " bahan ayam tepung kering"
- " Tepung maizena"
- " Penyedap rasa ayam"
- " Tepung instans ayam goreng tepung"
- " bahan saos"
- "2 sdm kecap asin"
- "5 sdm madu"
- "1 sdm gula palem  merah"
- "2 sdm minyak wijen"
- "2 sdm margarin  minyak"
- "3 siung bawang putih"
- "3 sdm wijen di sangrai"
- "2 sdm saus pedas"
- "2 sdm saus tomat"
- "2 sdm gochujang bubuk cabe korea beli di shopee aja"
- "1 sdm jeruk jipis sesuai selera asem"
- "secukupnya Air"
recipeinstructions:
- "Marinasi ayam dengan bumbu marinasi (minimal 1 jam / 1 malam biar rasa lebih enak lagi) tutup rapat masukkan ke kulkas biar meresap"
- "Campurkan ayam yang di marinasi dengan resep tepung ayam + lalu goreng dengan minyak panas dan banyak."
- "Panaskan minyak (margarin lebih enak rasanya) tumis bawang2an"
- "Masukkan semua resep saos. Aduk rata"
- "Tambahkan gochujang (boleh bubuk/ saos) sesuai selera pedasnya"
- "Masukkan ayam goreng tepung, aduk rata, dan tambahkan wijen yg sudah di sangrai"
categories:
- Recipe
tags:
- ayam
- madu
- ala

katakunci: ayam madu ala 
nutrition: 256 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Madu ala Korea (Dakgangjeong)](https://img-global.cpcdn.com/recipes/91e959560ec66abf/751x532cq70/ayam-madu-ala-korea-dakgangjeong-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan renyah. Karasteristik makanan Indonesia ayam madu ala korea (dakgangjeong) yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kehangatan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam Madu ala Korea (Dakgangjeong) untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda buat salah satunya ayam madu ala korea (dakgangjeong) yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam madu ala korea (dakgangjeong) tanpa harus bersusah payah.
Berikut ini resep Ayam Madu ala Korea (Dakgangjeong) yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 25 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Madu ala Korea (Dakgangjeong):

1. Tambah 500 gr ayam (potong kecil2)
1. Tambah  bumbu marinasi ayam
1. Diperlukan 1/2 jahe (haluskan)
1. Tambah 2 siung bawang putih (haluskan)
1. Tambah 1 sdm Minyak wijen
1. Harap siapkan 1 sdm Garam + Gula
1. Harap siapkan 1 sdm Merica (sesuai selera)
1. Jangan lupa 1 butir telur
1. Tambah  bahan ayam tepung kering
1. Dibutuhkan  Tepung maizena
1. Harus ada  Penyedap rasa ayam
1. Tambah  Tepung instans ayam goreng tepung
1. Diperlukan  bahan saos
1. Harus ada 2 sdm kecap asin
1. Jangan lupa 5 sdm madu
1. Harus ada 1 sdm gula palem / merah
1. Diperlukan 2 sdm minyak wijen
1. Tambah 2 sdm margarin / minyak
1. Tambah 3 siung bawang putih
1. Dibutuhkan 3 sdm wijen di sangrai
1. Tambah 2 sdm saus pedas
1. Harus ada 2 sdm saus tomat
1. Harap siapkan 2 sdm gochujang (bubuk cabe korea) beli di shopee aja
1. Diperlukan 1 sdm jeruk jipis (sesuai selera asem)
1. Harap siapkan secukupnya Air




<!--inarticleads2-->

##### Langkah membuat  Ayam Madu ala Korea (Dakgangjeong):

1. Marinasi ayam dengan bumbu marinasi (minimal 1 jam / 1 malam biar rasa lebih enak lagi) tutup rapat masukkan ke kulkas biar meresap
1. Campurkan ayam yang di marinasi dengan resep tepung ayam + lalu goreng dengan minyak panas dan banyak.
1. Panaskan minyak (margarin lebih enak rasanya) tumis bawang2an
1. Masukkan semua resep saos. Aduk rata
1. Tambahkan gochujang (boleh bubuk/ saos) sesuai selera pedasnya
1. Masukkan ayam goreng tepung, aduk rata, dan tambahkan wijen yg sudah di sangrai




Demikianlah cara membuat ayam madu ala korea (dakgangjeong) yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
