---
description: "Resep : Ayam Rica Favorit Keluarga minggu ini"
title: "Resep : Ayam Rica Favorit Keluarga minggu ini"
slug: 367-resep-ayam-rica-favorit-keluarga-minggu-ini
date: 2021-01-03T10:22:16.595Z
image: https://img-global.cpcdn.com/recipes/fbf4c641b8e41a34/751x532cq70/ayam-rica-favorit-keluarga-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fbf4c641b8e41a34/751x532cq70/ayam-rica-favorit-keluarga-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fbf4c641b8e41a34/751x532cq70/ayam-rica-favorit-keluarga-foto-resep-utama.jpg
author: Leonard Copeland
ratingvalue: 4.3
reviewcount: 18187
recipeingredient:
- "1/2 kg ayam potong 10 bagian"
- "Secukupnya daun kemangi di sini Rp 4000"
- "50-100 ml air sesuai selera jika ingin yang berkuah"
- "Secukupnya garam dan gula"
- "6 sdm minyak untuk menumis"
- " Bumbu halus"
- "5 butir bawang merah"
- "3 siung bawang putih"
- "3 buah cabai merah besar"
- "3 buah cabai rawit"
recipeinstructions:
- "Balur ayam dengan sedikit garam, lalu goreng sampai matang. Sisihkan"
- "Tumis bumbu halus SAMPAI MATANG (10-15 menit). Tumis dengan api sedang. Step ini sangat penting, ya. Karena jika bumbu tidak matang, rasa masakannya akan mentah dan berbau bawang. Jangan tambahkan apa-apa dulu pada step ini, seperti air ataupun kemangi. Biarkan matang terlebih dahulu"
- "Jika bumbu sudah matang, terlihat dari warnanya yang lebih menghitam dan lebih pekat. Bagaimana cara mengetahui bumbu sudah matang atau belum? Tes rasa. Jika rasanya sudah cocok dan tidak ada rasa mentah, berarti bumbu sudah siap."
- "Tambahkan air dan bumbu-bumbu penyedap. Tes rasa. Masukkan kemangi."
- "Masukkan ayam goreng, aduk rata, sajikan."
- "Siap dinikmati bersama nasi hangat"
categories:
- Recipe
tags:
- ayam
- rica
- favorit

katakunci: ayam rica favorit 
nutrition: 203 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica Favorit Keluarga](https://img-global.cpcdn.com/recipes/fbf4c641b8e41a34/751x532cq70/ayam-rica-favorit-keluarga-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau enak. Ciri khas masakan Nusantara ayam rica favorit keluarga yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.




Keharmonisan keluarga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Favorit Keluarga untuk keluarga. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang dapat anda contoh salah satunya ayam rica favorit keluarga yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan cepat menemukan resep ayam rica favorit keluarga tanpa harus bersusah payah.
Seperti resep Ayam Rica Favorit Keluarga yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Favorit Keluarga:

1. Harus ada 1/2 kg ayam, potong 10 bagian
1. Diperlukan Secukupnya daun kemangi (di sini Rp. 4000)
1. Harap siapkan 50-100 ml air (sesuai selera jika ingin yang berkuah)
1. Harap siapkan Secukupnya garam dan gula
1. Diperlukan 6 sdm minyak untuk menumis
1. Dibutuhkan  Bumbu halus
1. Jangan lupa 5 butir bawang merah
1. Dibutuhkan 3 siung bawang putih
1. Harap siapkan 3 buah cabai merah besar
1. Tambah 3 buah cabai rawit




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Favorit Keluarga:

1. Balur ayam dengan sedikit garam, lalu goreng sampai matang. Sisihkan
1. Tumis bumbu halus SAMPAI MATANG (10-15 menit). Tumis dengan api sedang. Step ini sangat penting, ya. Karena jika bumbu tidak matang, rasa masakannya akan mentah dan berbau bawang. Jangan tambahkan apa-apa dulu pada step ini, seperti air ataupun kemangi. Biarkan matang terlebih dahulu
1. Jika bumbu sudah matang, terlihat dari warnanya yang lebih menghitam dan lebih pekat. Bagaimana cara mengetahui bumbu sudah matang atau belum? Tes rasa. Jika rasanya sudah cocok dan tidak ada rasa mentah, berarti bumbu sudah siap.
1. Tambahkan air dan bumbu-bumbu penyedap. Tes rasa. Masukkan kemangi.
1. Masukkan ayam goreng, aduk rata, sajikan.
1. Siap dinikmati bersama nasi hangat




Demikianlah cara membuat ayam rica favorit keluarga yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat simple dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
