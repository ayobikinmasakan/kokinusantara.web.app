---
description: "Resep : Ayam rica rica Homemade"
title: "Resep : Ayam rica rica Homemade"
slug: 340-resep-ayam-rica-rica-homemade
date: 2021-01-17T22:21:49.487Z
image: https://img-global.cpcdn.com/recipes/65a26600abb1556e/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/65a26600abb1556e/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/65a26600abb1556e/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Paul Lucas
ratingvalue: 4.9
reviewcount: 13995
recipeingredient:
- "500 gr ayambagian paha atas"
- "Segenggam kemangi"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "7 buah cabe keriting"
- "4 buah rawit"
- "1 cm kunyit"
- "2 cm jahe geprek"
- "1 buah sereh geprek"
- "200 m air"
- "sesuai selera Gula dan garam"
recipeinstructions:
- "Bersihkan ayam..pilih bagian paha atas krna lebih lembut dan mudah menyerap bumbu"
- "Haluskan semua bumbu kecuali jahe dan sereh"
- "Tumis bumbu halus Tips : sebelum menumis ketika minyak panas, masukan terlebih dahulu jahe dan sereh agar minyak menyerap aroma nya"
- "Setelah jumbu matang dan beraroma masukan ayam.. aduk sampe bumbu merata.."
- "Setelah bumbu merata, masukan air masak hingga ayam matang dan air menyusut Tips : tutup wajan agar lebih cepat"
- "Setelah air susut, masukan kemangi matikan api.. aduk rata.. Done ^^"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 140 calories
recipecuisine: American
preptime: "PT40M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica rica](https://img-global.cpcdn.com/recipes/65a26600abb1556e/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau empuk. Ciri khas makanan Nusantara ayam rica rica yang kaya dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica rica untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang dapat anda contoh salah satunya ayam rica rica yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam rica rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica:

1. Tambah 500 gr ayam,bagian paha atas
1. Diperlukan Segenggam kemangi
1. Dibutuhkan 6 siung bawang merah
1. Siapkan 3 siung bawang putih
1. Jangan lupa 7 buah cabe keriting
1. Siapkan 4 buah rawit
1. Harus ada 1 cm kunyit
1. Diperlukan 2 cm jahe geprek
1. Harap siapkan 1 buah sereh geprek
1. Dibutuhkan 200 m air
1. Tambah sesuai selera Gula dan garam




<!--inarticleads2-->

##### Cara membuat  Ayam rica rica:

1. Bersihkan ayam..pilih bagian paha atas krna lebih lembut dan mudah menyerap bumbu
1. Haluskan semua bumbu kecuali jahe dan sereh
1. Tumis bumbu halus Tips : sebelum menumis ketika minyak panas, masukan terlebih dahulu jahe dan sereh agar minyak menyerap aroma nya
1. Setelah jumbu matang dan beraroma masukan ayam.. aduk sampe bumbu merata..
1. Setelah bumbu merata, masukan air masak hingga ayam matang dan air menyusut Tips : tutup wajan agar lebih cepat
1. Setelah air susut, masukan kemangi matikan api.. aduk rata.. Done ^^




Demikianlah cara membuat ayam rica rica yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan teruji, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
