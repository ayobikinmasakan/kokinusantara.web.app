---
description: "Resep : Ayam rica kemangi terupdate"
title: "Resep : Ayam rica kemangi terupdate"
slug: 375-resep-ayam-rica-kemangi-terupdate
date: 2021-01-08T05:08:42.884Z
image: https://img-global.cpcdn.com/recipes/bbd8e729baa7e083/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bbd8e729baa7e083/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bbd8e729baa7e083/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Wayne Ross
ratingvalue: 4.3
reviewcount: 12142
recipeingredient:
- "1 kg Ayam dada boneless"
- " Bumbu halus"
- "10 Cabe merah"
- "15 Cabe rawit"
- "5 Kemiri sangrai"
- "1 cm Kunyit"
- "12 Bawang merah"
- "6 Bawang putih"
- "1 buah Tomat"
- " Minyak goreng untuk tumis"
- " Bumbu pelengkap"
- "2 lbr Salam"
- "2 Serai"
- "3 Daun jeruk"
- "3 tangkai Daun bawang"
- "3 ikat Kemangi"
- " Garam"
- " Gula"
recipeinstructions:
- "Potong dadu ayam dada boneless"
- "Tumis bumbu halus dan masukkan serai daun salam serta daun jeruk, masukan garam 2sdt, 2 sdt gula tunggu bumbu wangi"
- "Masukkan potongan ayam ke bumbu tumis"
- "Masak sampai bumbu menyusut dan koreksi rasa saat sudah menyusut... menghindari rasa keasinan apabila di coba saat air masih banyak"
- "Tambahkan kemangi dan daun bawang aduk sampai layu.."
- "Siap di santap..bisa dilengkapi dengan sayuran rebus untuk menghadirkan vitamin dan serat yg lengkap tetapi tdk merubah rasa"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 296 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT57M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/bbd8e729baa7e083/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap wilayah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan keistimewahan yang merupakan keragaman Nusantara

Kedekatan rumah tangga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda coba salah satunya ayam rica kemangi yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica kemangi:

1. Harap siapkan 1 kg Ayam dada boneless
1. Dibutuhkan  Bumbu halus
1. Dibutuhkan 10 Cabe merah
1. Harus ada 15 Cabe rawit
1. Harus ada 5 Kemiri sangrai
1. Harap siapkan 1 cm Kunyit
1. Siapkan 12 Bawang merah
1. Diperlukan 6 Bawang putih
1. Siapkan 1 buah Tomat
1. Jangan lupa  Minyak goreng untuk tumis
1. Tambah  Bumbu pelengkap
1. Siapkan 2 lbr Salam
1. Tambah 2 Serai
1. Harus ada 3 Daun jeruk
1. Dibutuhkan 3 tangkai Daun bawang
1. Harus ada 3 ikat Kemangi
1. Harap siapkan  Garam
1. Diperlukan  Gula




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica kemangi:

1. Potong dadu ayam dada boneless
1. Tumis bumbu halus dan masukkan serai daun salam serta daun jeruk, masukan garam 2sdt, 2 sdt gula tunggu bumbu wangi
1. Masukkan potongan ayam ke bumbu tumis
1. Masak sampai bumbu menyusut dan koreksi rasa saat sudah menyusut... menghindari rasa keasinan apabila di coba saat air masih banyak
1. Tambahkan kemangi dan daun bawang aduk sampai layu..
1. Siap di santap..bisa dilengkapi dengan sayuran rebus untuk menghadirkan vitamin dan serat yg lengkap tetapi tdk merubah rasa




Demikianlah cara membuat ayam rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
