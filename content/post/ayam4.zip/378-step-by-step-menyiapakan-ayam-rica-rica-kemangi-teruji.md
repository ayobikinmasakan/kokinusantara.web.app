---
description: "Step-by-Step menyiapakan Ayam rica rica kemangi Teruji"
title: "Step-by-Step menyiapakan Ayam rica rica kemangi Teruji"
slug: 378-step-by-step-menyiapakan-ayam-rica-rica-kemangi-teruji
date: 2021-02-03T17:54:55.326Z
image: https://img-global.cpcdn.com/recipes/99a36fb1d5ebc3ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/99a36fb1d5ebc3ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/99a36fb1d5ebc3ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Johanna Rhodes
ratingvalue: 4.7
reviewcount: 12655
recipeingredient:
- "1/2 kg ayam"
- " Bumbu halus"
- "5 siung bawang putih"
- "5 siung bawang merah"
- "20 buah cabe merah keriting"
- "5-10 buah cabe rawit"
- "1 butir kemiri sangrai dulu"
- "Sedikit ketumbar"
- " Bahan cemplung "
- "1 ruas lengkuas"
- "3 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang serai"
- "1 buah tomat"
- " "
- "1 ikat daun kemangi"
- "1 batang daun bawang"
- "Secukupnya garam"
- "Secukupnya gula merah"
- "Secukupnya gula putih"
- "Secukupnya lada bubuk"
- "Secukupnya penyedap rasa"
recipeinstructions:
- "Cuci bersih ayam. Kemudian goreng sebentar setengah matang dengan dilumuri bubuk bawang putih. Ketumbar. kunyit dan garam"
- "Kemudian haluskan semua bumbu halus. Kemudian tumis beserta bahan cemplung sampai harum dan matang"
- "Setelah harum dan matang tambahkan air sebanyak 1½gelas belimbing. Masukan pula ayamnya. Tambahkan juga bumbu penyedap lainnya seperti garam dll."
- "Masan hingga sampai sedikit menyusut. Lalu masukan daun bawang iris dan kemangi"
- "Masak hingga benar2 matang dan airnya menyusut"
- "Koreksi rasa dahulu.dirasa cukup. Angkat dan sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 103 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/99a36fb1d5ebc3ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis hingga gurih. Ciri kuliner Indonesia ayam rica rica kemangi yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam rica rica kemangi untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang bisa anda contoh salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Harus ada 1/2 kg ayam
1. Dibutuhkan  Bumbu halus:
1. Harus ada 5 siung bawang putih
1. Dibutuhkan 5 siung bawang merah
1. Siapkan 20 buah cabe merah keriting
1. Diperlukan 5-10 buah cabe rawit
1. Tambah 1 butir kemiri (sangrai dulu)
1. Diperlukan Sedikit ketumbar
1. Tambah  Bahan cemplung :
1. Jangan lupa 1 ruas lengkuas
1. Harap siapkan 3 lembar daun salam
1. Harap siapkan 3 lembar daun jeruk
1. Harap siapkan 1 batang serai
1. Harap siapkan 1 buah tomat
1. Tambah  ~~~
1. Harus ada 1 ikat daun kemangi
1. Dibutuhkan 1 batang daun bawang
1. Harap siapkan Secukupnya garam
1. Siapkan Secukupnya gula merah
1. Harus ada Secukupnya gula putih
1. Diperlukan Secukupnya lada bubuk
1. Siapkan Secukupnya penyedap rasa




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica kemangi:

1. Cuci bersih ayam. Kemudian goreng sebentar setengah matang dengan dilumuri bubuk bawang putih. Ketumbar. kunyit dan garam
1. Kemudian haluskan semua bumbu halus. Kemudian tumis beserta bahan cemplung sampai harum dan matang
1. Setelah harum dan matang tambahkan air sebanyak 1½gelas belimbing. Masukan pula ayamnya. Tambahkan juga bumbu penyedap lainnya seperti garam dll.
1. Masan hingga sampai sedikit menyusut. Lalu masukan daun bawang iris dan kemangi
1. Masak hingga benar2 matang dan airnya menyusut
1. Koreksi rasa dahulu.dirasa cukup. Angkat dan sajikan




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
