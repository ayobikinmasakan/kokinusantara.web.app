---
description: "Steps untuk menyiapakan Ayam Rica Kemangi Teruji"
title: "Steps untuk menyiapakan Ayam Rica Kemangi Teruji"
slug: 327-steps-untuk-menyiapakan-ayam-rica-kemangi-teruji
date: 2020-10-13T07:02:56.599Z
image: https://img-global.cpcdn.com/recipes/1c114eee7c4c45e6/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1c114eee7c4c45e6/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1c114eee7c4c45e6/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Cory Mann
ratingvalue: 4.8
reviewcount: 22448
recipeingredient:
- "1/2 kg ayam"
- "1 buah jeruk nipis"
- "3 daun salam"
- "3 daun jeruk"
- "1 batang serai geprek"
- "3 cm jahe geprek"
- "3 cm lengkuas geprek"
- "secukupnya Minyak"
- "secukupnya Air"
- "secukupnya Garam  gula"
- "Seikat daun kemangi"
- " Bumbu halus"
- "6 bawang merah"
- "3 bawang putih"
- "10 cabe merah"
- "3 cabe rawit"
- "2 cm kunyit"
- "3 biji kemiri"
- "1/2 sdt merica"
- "1/2 sdt ketumbar"
recipeinstructions:
- "Cuci bersih ayam lalu tambahkan perasan jeruk nipis supaya tidak amis dan diamkan sebentar"
- "Goreng ayam setengah matang lalu tiriskan"
- "Sambil menunggu ayam setengah matang, haluskan semua bumbu halus"
- "Panaskan minyak, lalu tumis bumbu halus"
- "Masukkan daun salam, daun jeruk, daun sereh, lengkuas, dan jahe lalu tumis hingga wangi"
- "Tambahkan air sesuai selera"
- "Masukkan ayam yang telah digoreng setengah matang dan aduk merata"
- "Masukkan garam &amp; gula secukupnya"
- "Ketika sudah hampir matang, masukkan seikat daun kemangi yang sudah dipetik dan dicuci bersih"
- "Tunggu sebentar hingga daun kemangi sedikit lalu, matikan api, angkat, lalu sajikan dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 282 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/1c114eee7c4c45e6/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas hingga enak. Ciri khas masakan Indonesia ayam rica kemangi yang penuh dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica Kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang dapat anda coba salah satunya ayam rica kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 20 bahan dan 10 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Harap siapkan 1/2 kg ayam
1. Siapkan 1 buah jeruk nipis
1. Harap siapkan 3 daun salam
1. Jangan lupa 3 daun jeruk
1. Tambah 1 batang serai (geprek)
1. Dibutuhkan 3 cm jahe (geprek)
1. Diperlukan 3 cm lengkuas (geprek)
1. Diperlukan secukupnya Minyak
1. Harap siapkan secukupnya Air
1. Jangan lupa secukupnya Garam &amp; gula
1. Diperlukan Seikat daun kemangi
1. Harus ada  Bumbu halus:
1. Tambah 6 bawang merah
1. Tambah 3 bawang putih
1. Diperlukan 10 cabe merah
1. Harap siapkan 3 cabe rawit
1. Harus ada 2 cm kunyit
1. Jangan lupa 3 biji kemiri
1. Harap siapkan 1/2 sdt merica
1. Jangan lupa 1/2 sdt ketumbar




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Kemangi:

1. Cuci bersih ayam lalu tambahkan perasan jeruk nipis supaya tidak amis dan diamkan sebentar
1. Goreng ayam setengah matang lalu tiriskan
1. Sambil menunggu ayam setengah matang, haluskan semua bumbu halus
1. Panaskan minyak, lalu tumis bumbu halus
1. Masukkan daun salam, daun jeruk, daun sereh, lengkuas, dan jahe lalu tumis hingga wangi
1. Tambahkan air sesuai selera
1. Masukkan ayam yang telah digoreng setengah matang dan aduk merata
1. Masukkan garam &amp; gula secukupnya
1. Ketika sudah hampir matang, masukkan seikat daun kemangi yang sudah dipetik dan dicuci bersih
1. Tunggu sebentar hingga daun kemangi sedikit lalu, matikan api, angkat, lalu sajikan dengan nasi hangat




Demikianlah cara membuat ayam rica kemangi yang sederhana dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan cepat, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
