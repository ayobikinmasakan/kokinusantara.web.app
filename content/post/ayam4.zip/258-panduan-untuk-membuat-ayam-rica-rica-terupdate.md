---
description: "Panduan untuk membuat Ayam rica - rica terupdate"
title: "Panduan untuk membuat Ayam rica - rica terupdate"
slug: 258-panduan-untuk-membuat-ayam-rica-rica-terupdate
date: 2020-09-08T23:19:35.694Z
image: https://img-global.cpcdn.com/recipes/2dd5e6993fbdca8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2dd5e6993fbdca8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2dd5e6993fbdca8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Bettie Mendoza
ratingvalue: 4.3
reviewcount: 13946
recipeingredient:
- "1 ekor ayampotongcuci bersih beri perasan jeruk nipis  garam"
- "5 lembar daun jeruk"
- "1 batang serai geprek"
- "2 ikat daun kemangi sy skip"
- "secukupnya Garam"
- " Bumbu Halus"
- "10 buah cabe merah keriting sesuai selera sy 4 cb mrh besar"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "1 buah tomat"
- "Seruas jahe"
- "Seruas kunyit"
- "2 sendok teh ketumbar sangrai dulu"
- "50 gram gula merah"
- "8 buah cabe rawit merah biarkan utuh sy skip"
- "secukupnya Air"
recipeinstructions:
- "Goreng ayam sampai berwarna kecoklatan tapi jangan sampai kering, sisihkan"
- "Tumis bumbu halus lalu masukkan sere, daun jeruk, kemudian masukkan ayam aduk rata beri garam dan beri air secukupnya"
- "Biarkan mendidih dengan api sedang, masak sampai ayam empuk dan air menyusut, lalu koreksi rasa"
- "Matikan api, angkat ayam"
- "Sajikan dengan nasi putih hangat"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 267 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica - rica](https://img-global.cpcdn.com/recipes/2dd5e6993fbdca8a/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita jaga karena setiap tempat memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica - rica yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan bumbu membawa ciri khas yang merupakan keragaman Indonesia



Keharmonisan keluarga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica - rica untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda coba salah satunya ayam rica - rica yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica - rica tanpa harus bersusah payah.
Seperti resep Ayam rica - rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica - rica:

1. Harus ada 1 ekor ayam,potong²cuci bersih beri perasan jeruk nipis &amp; garam
1. Siapkan 5 lembar daun jeruk
1. Siapkan 1 batang serai, geprek
1. Diperlukan 2 ikat daun kemangi, sy skip
1. Tambah secukupnya Garam
1. Harap siapkan  Bumbu Halus
1. Diperlukan 10 buah cabe merah keriting (sesuai selera), sy 4 cb mrh besar
1. Diperlukan 8 siung bawang merah
1. Diperlukan 5 siung bawang putih
1. Diperlukan 1 buah tomat
1. Jangan lupa Seruas jahe
1. Tambah Seruas kunyit
1. Dibutuhkan 2 sendok teh ketumbar sangrai dulu
1. Jangan lupa 50 gram gula merah
1. Jangan lupa 8 buah cabe rawit merah (biarkan utuh), sy skip
1. Tambah secukupnya Air




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica - rica:

1. Goreng ayam sampai berwarna kecoklatan tapi jangan sampai kering, sisihkan
1. Tumis bumbu halus lalu masukkan sere, daun jeruk, kemudian masukkan ayam aduk rata beri garam dan beri air secukupnya
1. Biarkan mendidih dengan api sedang, masak sampai ayam empuk dan air menyusut, lalu koreksi rasa
1. Matikan api, angkat ayam
1. Sajikan dengan nasi putih hangat




Demikianlah cara membuat ayam rica - rica yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
