---
description: "Cara singkat membuat Ayam Rica Rica Kemangi minggu ini"
title: "Cara singkat membuat Ayam Rica Rica Kemangi minggu ini"
slug: 445-cara-singkat-membuat-ayam-rica-rica-kemangi-minggu-ini
date: 2020-08-27T23:31:27.038Z
image: https://img-global.cpcdn.com/recipes/b45ed06922704b0a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b45ed06922704b0a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b45ed06922704b0a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Lawrence Rodriquez
ratingvalue: 4.2
reviewcount: 46930
recipeingredient:
- " Ayam Tepung"
- "6 sdm Tepung Maizena"
- "3 sdm Tepung Beras"
- "500 gram Ayam saya pakai ayam dada dipotong kecil"
- " Bumbu Ulek Kasar"
- "10 buah Cabai Merah Keriting"
- "5 buah Cabai Rawit"
- "6 siung Bawang Merah"
- "3 siung Bawang Putih"
- " Bumbu Kasar"
- "4 lembar Daun Jeruk dibuang tulangnya iris tipis"
- "3 lembar Daun Salam"
- "1 batang Sereh digeprek"
- " Bumbu Pelengkap"
- " Garam"
- " Gula Merah"
- " Penyedap rasa"
- "10 ml Air"
- "1 ikat Daun Kemangi"
recipeinstructions:
- "Tambahkan garam pada ayam, lalu diamkan selama 15 menit."
- "Campurkan Tepung Maizena dan Tepung Beras, ditambah dengan garam dan penyedap secukupnya."
- "Lumuri ayam dengan campuran tepung maizena, lalu goreng hingga matang."
- "Ulek bumbu halus kasar, lalu tumis menggunakan api sedang."
- "Tambahkan 10 ml air"
- "Tambahkan garam, gula merah dan penyedap rasa sesuai selera."
- "Masukkan bumbu kasar, hingga air surut."
- "Masukkan ayam ke dalam bumbu, aduk hingga rata."
- "Tambahkan daun kemangi, aduk rata. Diamkan hingga bumbu meresap kurang lebih 3 menit."
- "Ayam siap disajikaaan 🎉"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 282 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/b45ed06922704b0a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang dapat kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Kita



Kedekatan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica Rica Kemangi untuk keluarga. Momen makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang bisa anda praktekkan salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 10 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Tambah  Ayam Tepung
1. Dibutuhkan 6 sdm Tepung Maizena
1. Harus ada 3 sdm Tepung Beras
1. Harus ada 500 gram Ayam (saya pakai ayam dada, dipotong kecil)
1. Harap siapkan  Bumbu Ulek Kasar
1. Harus ada 10 buah Cabai Merah Keriting
1. Siapkan 5 buah Cabai Rawit
1. Diperlukan 6 siung Bawang Merah
1. Diperlukan 3 siung Bawang Putih
1. Diperlukan  Bumbu Kasar
1. Diperlukan 4 lembar Daun Jeruk dibuang tulangnya, iris tipis
1. Siapkan 3 lembar Daun Salam
1. Jangan lupa 1 batang Sereh digeprek
1. Harus ada  Bumbu Pelengkap
1. Harap siapkan  Garam
1. Jangan lupa  Gula Merah
1. Harus ada  Penyedap rasa
1. Harus ada 10 ml Air
1. Tambah 1 ikat Daun Kemangi




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica Kemangi:

1. Tambahkan garam pada ayam, lalu diamkan selama 15 menit.
1. Campurkan Tepung Maizena dan Tepung Beras, ditambah dengan garam dan penyedap secukupnya.
1. Lumuri ayam dengan campuran tepung maizena, lalu goreng hingga matang.
1. Ulek bumbu halus kasar, lalu tumis menggunakan api sedang.
1. Tambahkan 10 ml air
1. Tambahkan garam, gula merah dan penyedap rasa sesuai selera.
1. Masukkan bumbu kasar, hingga air surut.
1. Masukkan ayam ke dalam bumbu, aduk hingga rata.
1. Tambahkan daun kemangi, aduk rata. Diamkan hingga bumbu meresap kurang lebih 3 menit.
1. Ayam siap disajikaaan 🎉




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan terbukti, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
