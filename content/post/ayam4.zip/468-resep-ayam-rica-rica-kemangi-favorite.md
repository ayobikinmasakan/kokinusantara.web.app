---
description: "Resep : Ayam Rica-rica Kemangi Favorite"
title: "Resep : Ayam Rica-rica Kemangi Favorite"
slug: 468-resep-ayam-rica-rica-kemangi-favorite
date: 2020-08-08T22:32:23.685Z
image: https://img-global.cpcdn.com/recipes/92c2b61eb5624e99/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/92c2b61eb5624e99/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/92c2b61eb5624e99/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Lester Dean
ratingvalue: 4.1
reviewcount: 46418
recipeingredient:
- "1 ekor ayam potong sedang"
- "1 buah jeruk nipis"
- "1 ikat kemangi"
- "1 buah tomat"
- "2 batang sereh"
- "1 ruas lengkuas"
- "1 ruas jahe"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "100 ml air matang"
- " Bumbu halus"
- "6 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas kunyit"
- "3 butir kemiri"
- "6 buah cabe merah keriting"
- "1/2 sdt ketumbar"
- "1/2 sdt lada bubuk"
- "1 sdt kaldu bubuk"
- "Secukupnya garam  gula"
recipeinstructions:
- "Cuci bersih ayam, beri perasan jeruk nipis, kemudian diamkan selama 10 menit, lalu cuci bersih kembali. Goreng ayam setengah matang."
- "Blender bumbu halus, kemudian tumis sampai harum. Masukan daun salam, daun jeruk, lengkuas, jahe &amp; sereh yg Sdh di geprek. Tunggu sampai bumbu sedikit mengental. Masukan ayam, tambahkan sedikit air, garam, gula &amp; kaldu ayam bubuk aduk rata,."
- "Masukan tomat &amp; kemangi, aduk rata kembali sebentar saja lalu koreksi rasa. Setelah pas matikan api &amp; Siap disajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 152 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/92c2b61eb5624e99/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan gurih. Ciri khas makanan Indonesia ayam rica-rica kemangi yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Kehangatan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-rica Kemangi untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian masakan yang bisa anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi:

1. Harap siapkan 1 ekor ayam potong sedang
1. Harap siapkan 1 buah jeruk nipis
1. Siapkan 1 ikat kemangi
1. Harus ada 1 buah tomat
1. Harap siapkan 2 batang sereh
1. Harus ada 1 ruas lengkuas
1. Harap siapkan 1 ruas jahe
1. Diperlukan 2 lembar daun salam
1. Dibutuhkan 3 lembar daun jeruk
1. Harus ada 100 ml air matang
1. Tambah  Bumbu halus:
1. Dibutuhkan 6 siung bawang merah
1. Tambah 3 siung bawang putih
1. Diperlukan 1 ruas kunyit
1. Tambah 3 butir kemiri
1. Jangan lupa 6 buah cabe merah keriting
1. Dibutuhkan 1/2 sdt ketumbar
1. Jangan lupa 1/2 sdt lada bubuk
1. Diperlukan 1 sdt kaldu bubuk
1. Dibutuhkan Secukupnya garam &amp; gula


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-rica Kemangi:

1. Cuci bersih ayam, beri perasan jeruk nipis, kemudian diamkan selama 10 menit, lalu cuci bersih kembali. Goreng ayam setengah matang.
1. Blender bumbu halus, kemudian tumis sampai harum. Masukan daun salam, daun jeruk, lengkuas, jahe &amp; sereh yg Sdh di geprek. Tunggu sampai bumbu sedikit mengental. Masukan ayam, tambahkan sedikit air, garam, gula &amp; kaldu ayam bubuk aduk rata,.
1. Masukan tomat &amp; kemangi, aduk rata kembali sebentar saja lalu koreksi rasa. Setelah pas matikan api &amp; Siap disajikan.


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
