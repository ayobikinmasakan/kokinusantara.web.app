---
description: "Langkah menyiapakan Ayam Rica-Rica 🌶️ terupdate"
title: "Langkah menyiapakan Ayam Rica-Rica 🌶️ terupdate"
slug: 304-langkah-menyiapakan-ayam-rica-rica-terupdate
date: 2020-11-07T15:42:15.018Z
image: https://img-global.cpcdn.com/recipes/8e966cd1065dc3e0/751x532cq70/ayam-rica-rica-🌶️-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8e966cd1065dc3e0/751x532cq70/ayam-rica-rica-🌶️-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8e966cd1065dc3e0/751x532cq70/ayam-rica-rica-🌶️-foto-resep-utama.jpg
author: Troy Marshall
ratingvalue: 4.9
reviewcount: 11557
recipeingredient:
- "600 gr ayam potong sesuai selera"
- "2 ikat kemangi petiki daunnya"
- "1 btg daun bawang"
- "3 lbr daun jeruk"
- "2 lbr daun salam"
- "2 btg sereh geprek"
- "2 ruas lengkuas geprek"
- "1/2 sdm kaldu bubuk"
- "2 sdt gula pasir"
- "1 sdt garam"
- "400 ml air"
- " Bumbu marinasi"
- "1 bh jeruk nipis"
- "1 sdt garam"
- "1 sdt kunyit bubuk"
- " Bumbu halus"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "3 bh kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- "12 bh cabe merah keriting"
- "10 bh cabe rawit merah"
recipeinstructions:
- "Pertama ayam saya marinasi terlebih dahulu dgn perasan air jeruk nipis, diamkan selama10 menit lalu bilas. Selanjutnya marinasi ayam dgn garam dan kunyit bubuk, aduk rata lalu diamkan selama kurleb 30 menit hingga bumbunya meresap."
- "Panaskan minyak kemudian goreng ayam hingga berwarna kecoklatan, gunakan api sedang. Angkat dan tiriskan. Sisihkan."
- "Siapkan bumbu halus kemudian tumis bumbu dengan sedikit minyak sisa menggoreng ayam. Masukkan sereh, salam, daun jeruk, dan lengkuas lalu tumis bumbu hingga harum dan matangnya tanak agar tidak mudah basi. Masukkan air lalu gula, garam, dan kaldu bubuk, aduk sebentar lalu masukkan ayam goreng."
- "Masak ayam hingga kuahnya mulai menyusut, jangan lupa koreksi rasanya. Terakhir masukkan kemangi dan daun bawang lalu aduk rata sebentar aja. Angkat dan sajikan"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 130 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica-Rica 🌶️](https://img-global.cpcdn.com/recipes/8e966cd1065dc3e0/751x532cq70/ayam-rica-rica-🌶️-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas atau enak. Ciri khas masakan Indonesia ayam rica-rica 🌶️ yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kehangatan keluarga bisa didapat dengan cara simple. Diantaranya adalah memasak Ayam Rica-Rica 🌶️ untuk keluarga. Momen makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis resep yang dapat anda coba salah satunya ayam rica-rica 🌶️ yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica-rica 🌶️ tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica 🌶️ yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 23 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica 🌶️:

1. Dibutuhkan 600 gr ayam, potong sesuai selera
1. Jangan lupa 2 ikat kemangi, petiki daunnya
1. Dibutuhkan 1 btg daun bawang
1. Dibutuhkan 3 lbr daun jeruk
1. Dibutuhkan 2 lbr daun salam
1. Harus ada 2 btg sereh, geprek
1. Harap siapkan 2 ruas lengkuas, geprek
1. Diperlukan 1/2 sdm kaldu bubuk
1. Dibutuhkan 2 sdt gula pasir
1. Jangan lupa 1 sdt garam
1. Siapkan 400 ml air
1. Tambah  Bumbu marinasi:
1. Siapkan 1 bh jeruk nipis
1. Jangan lupa 1 sdt garam
1. Dibutuhkan 1 sdt kunyit bubuk
1. Siapkan  Bumbu halus:
1. Tambah 6 siung bawang merah
1. Jangan lupa 4 siung bawang putih
1. Diperlukan 3 bh kemiri
1. Harap siapkan 1 ruas jahe
1. Jangan lupa 1 ruas kunyit
1. Harus ada 12 bh cabe merah keriting
1. Harus ada 10 bh cabe rawit merah




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica 🌶️:

1. Pertama ayam saya marinasi terlebih dahulu dgn perasan air jeruk nipis, diamkan selama10 menit lalu bilas. Selanjutnya marinasi ayam dgn garam dan kunyit bubuk, aduk rata lalu diamkan selama kurleb 30 menit hingga bumbunya meresap.
1. Panaskan minyak kemudian goreng ayam hingga berwarna kecoklatan, gunakan api sedang. Angkat dan tiriskan. Sisihkan.
1. Siapkan bumbu halus kemudian tumis bumbu dengan sedikit minyak sisa menggoreng ayam. Masukkan sereh, salam, daun jeruk, dan lengkuas lalu tumis bumbu hingga harum dan matangnya tanak agar tidak mudah basi. Masukkan air lalu gula, garam, dan kaldu bubuk, aduk sebentar lalu masukkan ayam goreng.
1. Masak ayam hingga kuahnya mulai menyusut, jangan lupa koreksi rasanya. Terakhir masukkan kemangi dan daun bawang lalu aduk rata sebentar aja. Angkat dan sajikan




Demikianlah cara membuat ayam rica-rica 🌶️ yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
