---
description: "Resep : Ayam Rica Rica Pedas 🌶 Terbukti"
title: "Resep : Ayam Rica Rica Pedas 🌶 Terbukti"
slug: 244-resep-ayam-rica-rica-pedas-terbukti
date: 2021-01-31T04:01:26.378Z
image: https://img-global.cpcdn.com/recipes/9e2d69fd10ee308e/751x532cq70/ayam-rica-rica-pedas-🌶-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9e2d69fd10ee308e/751x532cq70/ayam-rica-rica-pedas-🌶-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9e2d69fd10ee308e/751x532cq70/ayam-rica-rica-pedas-🌶-foto-resep-utama.jpg
author: Sadie Bryant
ratingvalue: 4.5
reviewcount: 12913
recipeingredient:
- "1/2 kg Sayap Ayam"
- "  Bumbu Halus"
- "8 buah Bawang Merah"
- "2 siung Bawang Putih"
- "3 buah Cabe Merah Besar"
- "5 cabe Rawit"
- "1/2 ruas Kunyit"
- "5 butir kemiri"
- "  Bumbu Geprek"
- "2 Ruas Serai"
- "Sedikit jahe"
- "4 lembar Daun jeruk sobek2"
- "Secukupnya garam merica kaldu bubuk"
- "  Campuran"
- "2 ikat kemangi stok habis saya skip"
- "1 tomat iris jadi 4"
- "Secukupnya cabe rawit utuh"
- "1 batang Daun bawang"
recipeinstructions:
- "Rebus ayam sampai empuk."
- "Tumis bumbu halus sampai harum masukkan serai, daun jeruk, dan jahe. Tambahkan garam, merica,dan kaldu bubuk."
- "Masukkan cabe utuh, tomat dan daun bawang iris. Aduk rata."
- "Masukkan ayam dan air bekas rebusan ayam tadi,"
- "Masukkan kemangi (berhubung stok di kulkas gk ada, di tukang sayur jga gk ada jadi saya skip) tunggu hingga airnya agak susut."
- "Sajikan dengan nasi hangat 😊"
- "Selamat mencoba 😊"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 150 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Rica Pedas 🌶](https://img-global.cpcdn.com/recipes/9e2d69fd10ee308e/751x532cq70/ayam-rica-rica-pedas-🌶-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang dapat kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica rica pedas 🌶 yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa kesan tersendiri yang merupakan keragaman Indonesia



Kehangatan keluarga bisa didapat dengan cara mudah. Salah satunya adalah memasak Ayam Rica Rica Pedas 🌶 untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak jenis masakan yang bisa anda contoh salah satunya ayam rica rica pedas 🌶 yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica rica pedas 🌶 tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Pedas 🌶 yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 18 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Pedas 🌶:

1. Jangan lupa 1/2 kg Sayap Ayam
1. Siapkan  👉 Bumbu Halus
1. Siapkan 8 buah Bawang Merah
1. Jangan lupa 2 siung Bawang Putih
1. Dibutuhkan 3 buah Cabe Merah Besar
1. Dibutuhkan 5 cabe Rawit
1. Harap siapkan 1/2 ruas Kunyit
1. Jangan lupa 5 butir kemiri
1. Jangan lupa  👉 Bumbu Geprek
1. Diperlukan 2 Ruas Serai
1. Diperlukan Sedikit jahe
1. Dibutuhkan 4 lembar Daun jeruk sobek2
1. Harus ada Secukupnya garam, merica, kaldu bubuk
1. Tambah  👉 Campuran
1. Dibutuhkan 2 ikat kemangi (stok habis saya skip)
1. Dibutuhkan 1 tomat iris jadi 4
1. Siapkan Secukupnya cabe rawit utuh
1. Harap siapkan 1 batang Daun bawang




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica Pedas 🌶:

1. Rebus ayam sampai empuk.
1. Tumis bumbu halus sampai harum masukkan serai, daun jeruk, dan jahe. Tambahkan garam, merica,dan kaldu bubuk.
1. Masukkan cabe utuh, tomat dan daun bawang iris. Aduk rata.
1. Masukkan ayam dan air bekas rebusan ayam tadi,
1. Masukkan kemangi (berhubung stok di kulkas gk ada, di tukang sayur jga gk ada jadi saya skip) tunggu hingga airnya agak susut.
1. Sajikan dengan nasi hangat 😊
1. Selamat mencoba 😊




Demikianlah cara membuat ayam rica rica pedas 🌶 yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan teruji, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
