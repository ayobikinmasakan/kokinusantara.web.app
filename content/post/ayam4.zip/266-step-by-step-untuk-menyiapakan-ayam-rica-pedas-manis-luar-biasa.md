---
description: "Step-by-Step untuk menyiapakan Ayam Rica Pedas Manis Luar biasa"
title: "Step-by-Step untuk menyiapakan Ayam Rica Pedas Manis Luar biasa"
slug: 266-step-by-step-untuk-menyiapakan-ayam-rica-pedas-manis-luar-biasa
date: 2020-08-14T05:08:07.553Z
image: https://img-global.cpcdn.com/recipes/34a5cb022f09220b/751x532cq70/ayam-rica-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/34a5cb022f09220b/751x532cq70/ayam-rica-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/34a5cb022f09220b/751x532cq70/ayam-rica-pedas-manis-foto-resep-utama.jpg
author: Stephen Pena
ratingvalue: 4.1
reviewcount: 43573
recipeingredient:
- "1/2 kg ayam cocok yang bagian sayap kepala ceker"
- "4 siung besar Bawang merah"
- "3 siung besar Bawang putih"
- "4 cabe merah besar kriting memberi warna merah dan rasa pedas"
- "10 cabe rawit kecil"
- "1 ruas kunir"
- "2 butir kemiri ukuran kecil"
- "3 lembar daun salam"
- "2 lembar daun jeruk purut"
- " Merica dan pala bubuk"
- "5 SDM kecap manis bisa lebih tergantung selera"
- "1 SDT garam"
- "1 SDT penyedap"
- " Bawang goreng merah penyajian"
recipeinstructions:
- "Potong bagian ayam menjadi ukuran kecil. Ayam Rica nikmat jika dimakan berukuran kecil. Misal satu sayap dipotong menjadi 2-3 bagian."
- "Rebus ayam mentah untuk membuang lemak kotor. Beri sedikit garam. Sebaiknya ayam yang mentah jangan di cuci terlebih dahulu, perebusan ayam gunanya untuk membuang zat kotoran pada ayam mentah."
- "Haluskan bumbu kecuali daun salam, daun jeruk purut karna untuk menumis bumbu."
- "Setelah ayam empuk angkat dan tiriskan."
- "Tumis bumbu yg sudah di haluskan. Masukan daun salam dan daun jeruk purut. Tumis hingga harum. Jika harum Tambahan air 200ml, kecap, garam, penyedap rasa, merica dan pala bubuk."
- "Masukan ayam kedalam bumbu, masak hingga bumbu meresap."
- "Sajikan ayam bersama bawang goreng."
categories:
- Recipe
tags:
- ayam
- rica
- pedas

katakunci: ayam rica pedas 
nutrition: 165 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Pedas Manis](https://img-global.cpcdn.com/recipes/34a5cb022f09220b/751x532cq70/ayam-rica-pedas-manis-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang dapat kita jaga karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica pedas manis yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Kita



Keharmonisan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica Pedas Manis untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang bisa anda praktekkan salah satunya ayam rica pedas manis yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam rica pedas manis tanpa harus bersusah payah.
Seperti resep Ayam Rica Pedas Manis yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 7 langkah dan 14 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Pedas Manis:

1. Harus ada 1/2 kg ayam (cocok yang bagian sayap, kepala, ceker)
1. Diperlukan 4 siung besar Bawang merah
1. Diperlukan 3 siung besar Bawang putih
1. Dibutuhkan 4 cabe merah besar kriting (memberi warna merah dan rasa pedas)
1. Siapkan 10 cabe rawit kecil
1. Jangan lupa 1 ruas kunir
1. Tambah 2 butir kemiri ukuran kecil
1. Tambah 3 lembar daun salam
1. Harap siapkan 2 lembar daun jeruk purut
1. Jangan lupa  Merica dan pala bubuk
1. Dibutuhkan 5 SDM kecap manis bisa lebih tergantung selera
1. Harus ada 1 SDT garam
1. Siapkan 1 SDT penyedap
1. Siapkan  Bawang goreng merah penyajian




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Pedas Manis:

1. Potong bagian ayam menjadi ukuran kecil. Ayam Rica nikmat jika dimakan berukuran kecil. Misal satu sayap dipotong menjadi 2-3 bagian.
1. Rebus ayam mentah untuk membuang lemak kotor. Beri sedikit garam. Sebaiknya ayam yang mentah jangan di cuci terlebih dahulu, perebusan ayam gunanya untuk membuang zat kotoran pada ayam mentah.
1. Haluskan bumbu kecuali daun salam, daun jeruk purut karna untuk menumis bumbu.
1. Setelah ayam empuk angkat dan tiriskan.
1. Tumis bumbu yg sudah di haluskan. Masukan daun salam dan daun jeruk purut. Tumis hingga harum. Jika harum Tambahan air 200ml, kecap, garam, penyedap rasa, merica dan pala bubuk.
1. Masukan ayam kedalam bumbu, masak hingga bumbu meresap.
1. Sajikan ayam bersama bawang goreng.




Demikianlah cara membuat ayam rica pedas manis yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan cepat, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
