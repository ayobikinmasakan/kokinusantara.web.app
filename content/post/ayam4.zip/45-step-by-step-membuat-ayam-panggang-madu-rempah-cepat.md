---
description: "Step-by-Step membuat Ayam panggang Madu Rempah Cepat"
title: "Step-by-Step membuat Ayam panggang Madu Rempah Cepat"
slug: 45-step-by-step-membuat-ayam-panggang-madu-rempah-cepat
date: 2021-01-13T08:45:03.473Z
image: https://img-global.cpcdn.com/recipes/87025713adf86993/751x532cq70/ayam-panggang-madu-rempah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/87025713adf86993/751x532cq70/ayam-panggang-madu-rempah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/87025713adf86993/751x532cq70/ayam-panggang-madu-rempah-foto-resep-utama.jpg
author: Willie Blake
ratingvalue: 4.4
reviewcount: 30769
recipeingredient:
- "1 ekor ayam potong sesuai selera"
- "1 batang wortel potong besar"
- "2 buah kentang cuci bersih potong 4"
- "5 batang buncis"
- "1/2 bawang bombay potong bulat"
- "1/4 sdt lada hitam"
- "1 cm kayu manis"
- "3 siung bawang putih haluskan"
- "1 ruas jahe haluskan"
- " Bahan olesan"
- "1/4 sdt kunyit bubuk"
- "1 sdt ketumbar"
- "3 sdm madu"
- " Kaldu bubuk"
- " Minyak gorengmargarin"
- "1 sdt thyme saya pkai parsley"
recipeinstructions:
- "Cuci bersih potongan ayam, kemudian beri perasan jeruk nipis. Dimakan sebentar lalu remas-remas dan bilas."
- "Siapkan sayurannya"
- "Didihkn air, masukkan lada hitam, kayu manis dan bumbu halus."
- "Masukkan ayam dan sayuran, masak dgn api sedang selma 20 menit. Angkat sayurannya lanjutkan memasak ayamnya selama 10 menit lagi."
- "Siapkan bahan olesan, campur semua bahan olesan aduk rata dan sisihkan"
- "Setelah matang, angkat ayam kemudian pindahkan ke wadah tahan panas. Lalu oles ayam dan sayuran dengan bahan olesan dan beri potongan bawang bombay"
- "Panggang di oven suhu 160°c selama 40 menit. (Sesuaikan aja dengan oven masing-masing)"
- "Setelah matang, angkat kemudian oles lagi dengan bahan olesan.. Siap disajikan.."
categories:
- Recipe
tags:
- ayam
- panggang
- madu

katakunci: ayam panggang madu 
nutrition: 238 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam panggang Madu Rempah](https://img-global.cpcdn.com/recipes/87025713adf86993/751x532cq70/ayam-panggang-madu-rempah-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan renyah. Ciri masakan Indonesia ayam panggang madu rempah yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam panggang Madu Rempah untuk keluarga. kebiasaan makan bersama keluarga sudah menjadi budaya, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi makanan yang bisa anda contoh salah satunya ayam panggang madu rempah yang merupakan resep favorite yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam panggang madu rempah tanpa harus bersusah payah.
Seperti resep Ayam panggang Madu Rempah yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam panggang Madu Rempah:

1. Harus ada 1 ekor ayam, potong sesuai selera
1. Jangan lupa 1 batang wortel, potong besar
1. Jangan lupa 2 buah kentang, cuci bersih, potong 4
1. Diperlukan 5 batang buncis
1. Jangan lupa 1/2 bawang bombay, potong bulat
1. Siapkan 1/4 sdt lada hitam
1. Harus ada 1 cm kayu manis
1. Harap siapkan 3 siung bawang putih, haluskan
1. Jangan lupa 1 ruas jahe, haluskan
1. Jangan lupa  Bahan olesan
1. Tambah 1/4 sdt kunyit bubuk
1. Jangan lupa 1 sdt ketumbar
1. Diperlukan 3 sdm madu
1. Harap siapkan  Kaldu bubuk
1. Siapkan  Minyak goreng/margarin
1. Jangan lupa 1 sdt thyme (saya pkai parsley)




<!--inarticleads2-->

##### Instruksi membuat  Ayam panggang Madu Rempah:

1. Cuci bersih potongan ayam, kemudian beri perasan jeruk nipis. Dimakan sebentar lalu remas-remas dan bilas.
1. Siapkan sayurannya
1. Didihkn air, masukkan lada hitam, kayu manis dan bumbu halus.
1. Masukkan ayam dan sayuran, masak dgn api sedang selma 20 menit. Angkat sayurannya lanjutkan memasak ayamnya selama 10 menit lagi.
1. Siapkan bahan olesan, campur semua bahan olesan aduk rata dan sisihkan
1. Setelah matang, angkat ayam kemudian pindahkan ke wadah tahan panas. Lalu oles ayam dan sayuran dengan bahan olesan dan beri potongan bawang bombay
1. Panggang di oven suhu 160°c selama 40 menit. (Sesuaikan aja dengan oven masing-masing)
1. Setelah matang, angkat kemudian oles lagi dengan bahan olesan.. Siap disajikan..
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam panggang Madu Rempah">



Demikianlah cara membuat ayam panggang madu rempah yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
