---
description: "Cara membuat Ayam Rica-Rica Favorite"
title: "Cara membuat Ayam Rica-Rica Favorite"
slug: 420-cara-membuat-ayam-rica-rica-favorite
date: 2020-09-07T03:54:59.349Z
image: https://img-global.cpcdn.com/recipes/b6e590348ab66be4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b6e590348ab66be4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b6e590348ab66be4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Cole Hines
ratingvalue: 4.1
reviewcount: 39276
recipeingredient:
- "500 gr Ayam"
- "1 buah Jeruk nipis"
- "2 sdt kunyit bubuk"
- "1 sdt garam"
- "4 lembar Daun Jeruk purut"
- "2 lembar daun salam1 batang sereh"
- " Bumbu Halus "
- "10 cabe Rawit"
- "1 btg sereh"
- "2 cm Lengkuas"
- "2 cm Jahe"
- "2 cm Kunyit"
- "20 ml Air"
- " Bumbu tambahan"
- "1 sdt garam"
- "1 sdt Kaldu bubuk"
- "1/2 sdt merica bubuk"
- "2 sdm kecap manis"
recipeinstructions:
- "Bersihkan ayam, lumuri dgn Kunyit, garam, perasan jeruk nipis"
- "Rebus ayam sampai daging empuk. Kurang lebih 15 menit. Lalu tiriskan."
- "Siapkan semua bahan yg ingin dihaluskan, seperti : baput, Bamer, Jahe, cabe rawit, kunyit, lengkuas. Masukan sedikit minyk. Jika bahan kurang hancur, tambahkan sedikit air. lalu blender hingga halus."
- "Panaskan wajan, masukan bumbu yg sudah di haluskan, jika sdh wangi. Masukan sereh yg sdh di geprek. Aduk dan tunggu hingga bumbu wangi."
- "Nah, tambahkan daun jeruk, dan daun salam. Aduk-aduk sebentar. Tuangkan ayam yg sudah ditiriskan tadi. Dan aduk lagi sampai bumbu merata"
- "Tambahkan garam, Kaldu bubuk, merica bubuk, dan kecap manis. sambil icip2 rasa bumbu. Jika sudah pas, diamkan sebentar hingga bumbu meresap."
- "Aduk-aduk lagi. Matikan kompor, dan ayam rica-rica, siap di hidangkan"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 294 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/b6e590348ab66be4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau renyah. Karasteristik makanan Nusantara ayam rica-rica yang kaya dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga bisa diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica-Rica untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang bisa anda praktekkan salah satunya ayam rica-rica yang merupakan makanan terkenal yang mudah dengan varian sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica:

1. Dibutuhkan 500 gr Ayam
1. Diperlukan 1 buah Jeruk nipis
1. Harap siapkan 2 sdt kunyit bubuk
1. Diperlukan 1 sdt garam
1. Harap siapkan 4 lembar Daun Jeruk purut
1. Jangan lupa 2 lembar daun salam1 batang sereh
1. Jangan lupa  Bumbu Halus :
1. Jangan lupa 10 cabe Rawit
1. Jangan lupa 1 btg sereh
1. Siapkan 2 cm Lengkuas
1. Siapkan 2 cm Jahe
1. Jangan lupa 2 cm Kunyit
1. Siapkan 20 ml Air
1. Dibutuhkan  Bumbu tambahan
1. Harus ada 1 sdt garam
1. Jangan lupa 1 sdt Kaldu bubuk
1. Harap siapkan 1/2 sdt merica bubuk
1. Tambah 2 sdm kecap manis




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica-Rica:

1. Bersihkan ayam, lumuri dgn Kunyit, garam, perasan jeruk nipis
1. Rebus ayam sampai daging empuk. Kurang lebih 15 menit. Lalu tiriskan.
1. Siapkan semua bahan yg ingin dihaluskan, seperti : baput, Bamer, Jahe, cabe rawit, kunyit, lengkuas. Masukan sedikit minyk. Jika bahan kurang hancur, tambahkan sedikit air. lalu blender hingga halus.
1. Panaskan wajan, masukan bumbu yg sudah di haluskan, jika sdh wangi. Masukan sereh yg sdh di geprek. Aduk dan tunggu hingga bumbu wangi.
1. Nah, tambahkan daun jeruk, dan daun salam. Aduk-aduk sebentar. Tuangkan ayam yg sudah ditiriskan tadi. Dan aduk lagi sampai bumbu merata
1. Tambahkan garam, Kaldu bubuk, merica bubuk, dan kecap manis. sambil icip2 rasa bumbu. Jika sudah pas, diamkan sebentar hingga bumbu meresap.
1. Aduk-aduk lagi. Matikan kompor, dan ayam rica-rica, siap di hidangkan




Demikianlah cara membuat ayam rica-rica yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan terbukti, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
