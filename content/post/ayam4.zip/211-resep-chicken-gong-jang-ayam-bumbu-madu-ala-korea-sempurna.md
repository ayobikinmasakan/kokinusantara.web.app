---
description: "Resep : Chicken Gong Jang (Ayam Bumbu Madu ala Korea) Sempurna"
title: "Resep : Chicken Gong Jang (Ayam Bumbu Madu ala Korea) Sempurna"
slug: 211-resep-chicken-gong-jang-ayam-bumbu-madu-ala-korea-sempurna
date: 2020-08-12T05:13:57.565Z
image: https://img-global.cpcdn.com/recipes/8661baf3acd575c4/751x532cq70/chicken-gong-jang-ayam-bumbu-madu-ala-korea-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8661baf3acd575c4/751x532cq70/chicken-gong-jang-ayam-bumbu-madu-ala-korea-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8661baf3acd575c4/751x532cq70/chicken-gong-jang-ayam-bumbu-madu-ala-korea-foto-resep-utama.jpg
author: Victoria Murphy
ratingvalue: 4.7
reviewcount: 33396
recipeingredient:
- "4 ptg Ayam bagian paha ukuran besar"
- " Tepung Bumbu Sy pakai Sasa Tepung Bumbu ala Kentucky"
- "3/4 sdt Minyak Wijen"
- " Wijen Sangrai  Seledri untuk hiasan"
- " Saus Madu"
- "1 siung Bawang Putih cincang halus"
- "7 sdm Saus Tomat"
- "2 sdm Madu"
- "5 sdm Air"
- "1/4 sdt Cuka"
- " Margarine"
- " Garam"
- " Gula"
- " Kaldu Jamur"
recipeinstructions:
- "Cuci ayam hingga bersih, lumuri tepung bumbu, goreng hingga matang dan kecoklatan. Sisihkan"
- "Campur saus tomat, madu, garam, gula, kaldu jamur, cuka dan air dalam mangkuk kecil. Aduk rata, koreksi rasa. Sisihkan"
- "Tumis bawang putih hingga harum, masukkan campuran saus, aduk rata. Masak hingga saus mengental dan meletup-letup, tambahkan minyak wijen, aduk kembali."
- "Masukkan potongan ayam, aduk hingga ayam terlapisi saus. Angkat, beri taburan wijen sangrai dan daun seledri cincang. Sajikan"
- "(Tips: kalau ayamnya potongan besar, gunakan api sedang utk memanaskan minyak, tapi goreng dengan api sedang cenderung kecil agar ayam matang sampai dalam)"
categories:
- Recipe
tags:
- chicken
- gong
- jang

katakunci: chicken gong jang 
nutrition: 101 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dessert

---


![Chicken Gong Jang (Ayam Bumbu Madu ala Korea)](https://img-global.cpcdn.com/recipes/8661baf3acd575c4/751x532cq70/chicken-gong-jang-ayam-bumbu-madu-ala-korea-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang harus kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti chicken gong jang (ayam bumbu madu ala korea) yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Kita

Kehangatan rumah tangga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Chicken Gong Jang (Ayam Bumbu Madu ala Korea) untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang dapat anda coba salah satunya chicken gong jang (ayam bumbu madu ala korea) yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini anda dapat dengan gampang menemukan resep chicken gong jang (ayam bumbu madu ala korea) tanpa harus bersusah payah.
Seperti resep Chicken Gong Jang (Ayam Bumbu Madu ala Korea) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 14 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Chicken Gong Jang (Ayam Bumbu Madu ala Korea):

1. Dibutuhkan 4 ptg Ayam (bagian paha ukuran besar)
1. Siapkan  Tepung Bumbu (Sy pakai Sasa Tepung Bumbu ala Kentucky)
1. Siapkan 3/4 sdt Minyak Wijen
1. Diperlukan  Wijen Sangrai &amp; Seledri (untuk hiasan)
1. Siapkan  Saus Madu
1. Dibutuhkan 1 siung Bawang Putih, cincang halus
1. Tambah 7 sdm Saus Tomat
1. Tambah 2 sdm Madu
1. Dibutuhkan 5 sdm Air
1. Diperlukan 1/4 sdt Cuka
1. Diperlukan  Margarine
1. Jangan lupa  Garam
1. Harus ada  Gula
1. Jangan lupa  Kaldu Jamur




<!--inarticleads2-->

##### Langkah membuat  Chicken Gong Jang (Ayam Bumbu Madu ala Korea):

1. Cuci ayam hingga bersih, lumuri tepung bumbu, goreng hingga matang dan kecoklatan. Sisihkan
1. Campur saus tomat, madu, garam, gula, kaldu jamur, cuka dan air dalam mangkuk kecil. Aduk rata, koreksi rasa. Sisihkan
1. Tumis bawang putih hingga harum, masukkan campuran saus, aduk rata. Masak hingga saus mengental dan meletup-letup, tambahkan minyak wijen, aduk kembali.
1. Masukkan potongan ayam, aduk hingga ayam terlapisi saus. Angkat, beri taburan wijen sangrai dan daun seledri cincang. Sajikan
1. (Tips: kalau ayamnya potongan besar, gunakan api sedang utk memanaskan minyak, tapi goreng dengan api sedang cenderung kecil agar ayam matang sampai dalam)




Demikianlah cara membuat chicken gong jang (ayam bumbu madu ala korea) yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat gampang dan teruji, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
