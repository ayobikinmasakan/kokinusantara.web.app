---
description: "Resep : Ayam Rica Rica Cepat"
title: "Resep : Ayam Rica Rica Cepat"
slug: 477-resep-ayam-rica-rica-cepat
date: 2020-10-20T20:23:01.618Z
image: https://img-global.cpcdn.com/recipes/edad9686e3646f43/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/edad9686e3646f43/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/edad9686e3646f43/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Melvin Blake
ratingvalue: 4.7
reviewcount: 13628
recipeingredient:
- "1/2 ekor ayam"
- " Jeruk nipis"
- " Kunyit bubuk  kunyit digiling halus"
- " Bumbu halus"
- "1 ruas jahe"
- "2 butir kemiri"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1 buah tomat ukuran kecil"
- "5 buah cabai rawit"
- "5 sdm cabai merah giling kasar"
- " Bumbu kering"
- "3 lembar daun salam"
- "4 lembar daun jeruk"
- "1 batang serai digeprek"
- " Bumbu tambahan"
- " Garam"
- " Gula"
- "1 batang daun bawang diiris kasar"
recipeinstructions:
- "Lumuri ayam dengan garam, perasan jeruk nipis dan kunyit. Diamkan sebentar, lalu digoreng (boleh goreng hingga matang kecoklatan atau goreng setengah matang)"
- "Uleg kasar semua bumbu halus kecuali cabai merah. (Bisa dengan blender, blender hingga halus kemiri dan jahe, baru masukkan sisa bumbu halus lainnya dan diblender sebentar jangan sampai terlalu halus)"
- "Tumis semua bumbu yang sudah diuleg dan masukkan cabai merah"
- "Masukkan bumbu kering. Tumis hingga semua bumbu matang."
- "Masukkan ayam yg sudah digoreng tadi kedalam tumisan bumbu. Aduk hingga merata. Kemudian tambahkan air sedikit (kira kira ayam setengah terendam)"
- "Masukkan garam gula (coba 1sdt dulu). Masak hingga air surut, koreksi rasa."
- "Masukkan potongan daun bawang (bisa juga ganti dengan seikat daun kemangi). Aduk aduk sebentar, matikan api. Sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 197 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/edad9686e3646f43/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan empuk. Ciri khas masakan Nusantara ayam rica rica yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica Rica untuk keluarga. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan makanan di rumah mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda buat salah satunya ayam rica rica yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica:

1. Jangan lupa 1/2 ekor ayam
1. Siapkan  Jeruk nipis
1. Jangan lupa  Kunyit bubuk / kunyit digiling halus
1. Tambah  Bumbu halus
1. Jangan lupa 1 ruas jahe
1. Dibutuhkan 2 butir kemiri
1. Tambah 5 siung bawang merah
1. Harap siapkan 3 siung bawang putih
1. Tambah 1 buah tomat ukuran kecil
1. Jangan lupa 5 buah cabai rawit
1. Tambah 5 sdm cabai merah giling kasar
1. Siapkan  Bumbu kering
1. Jangan lupa 3 lembar daun salam
1. Diperlukan 4 lembar daun jeruk
1. Diperlukan 1 batang serai digeprek
1. Siapkan  Bumbu tambahan
1. Harap siapkan  Garam
1. Siapkan  Gula
1. Harap siapkan 1 batang daun bawang diiris kasar




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica:

1. Lumuri ayam dengan garam, perasan jeruk nipis dan kunyit. Diamkan sebentar, lalu digoreng (boleh goreng hingga matang kecoklatan atau goreng setengah matang)
1. Uleg kasar semua bumbu halus kecuali cabai merah. (Bisa dengan blender, blender hingga halus kemiri dan jahe, baru masukkan sisa bumbu halus lainnya dan diblender sebentar jangan sampai terlalu halus)
1. Tumis semua bumbu yang sudah diuleg dan masukkan cabai merah
1. Masukkan bumbu kering. Tumis hingga semua bumbu matang.
1. Masukkan ayam yg sudah digoreng tadi kedalam tumisan bumbu. Aduk hingga merata. Kemudian tambahkan air sedikit (kira kira ayam setengah terendam)
1. Masukkan garam gula (coba 1sdt dulu). Masak hingga air surut, koreksi rasa.
1. Masukkan potongan daun bawang (bisa juga ganti dengan seikat daun kemangi). Aduk aduk sebentar, matikan api. Sajikan.




Demikianlah cara membuat ayam rica rica yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
