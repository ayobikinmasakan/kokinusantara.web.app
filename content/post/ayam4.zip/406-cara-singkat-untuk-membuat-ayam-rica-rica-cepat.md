---
description: "Cara singkat untuk membuat Ayam rica-rica Cepat"
title: "Cara singkat untuk membuat Ayam rica-rica Cepat"
slug: 406-cara-singkat-untuk-membuat-ayam-rica-rica-cepat
date: 2021-01-18T09:16:40.986Z
image: https://img-global.cpcdn.com/recipes/658a35344af63ec3/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/658a35344af63ec3/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/658a35344af63ec3/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Nettie Moran
ratingvalue: 4.6
reviewcount: 25841
recipeingredient:
- "1 ekor ayam potong 10"
- "Sesuai selera daun bawang bisa juga pakai kemangi"
- " Bumbu halus "
- "1 ruas Kunyit"
- "6 buah Cabe merah"
- "4 buah Cabe rawit setan kalau suka pedas"
- "3 butir kemiri"
- "8 siung Bawang merah"
- "4 siung Bawang putih"
- "1 ruas jahe"
- " Bumbu tabur "
- "Secukupnya garam"
- "Secukupnya penyedap saya pakai kaldu jamur"
- " Bumbu tumis "
- "1 batang sereh geprek"
- "3 lembar daun jeruk"
- "1 ruas lengkuas"
recipeinstructions:
- "Haluskan bumbu dengan blender."
- "Cuci ayam hingga bersih."
- "Panaskan minyak, tumis bumbu hingga harum."
- "Geprek sereh dan jahe. Lalu masukan daun jeruk dan bumbu yang sudah digeprek. Setelah harum, masukan ayam."
- "Beri sedikit air, masak dengan api yang membesar."
- "Aduk2 sampai bumbu merata. Tutup agar ayam cepat matang dan empuk."
- "Sajikan :))"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 153 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica-rica](https://img-global.cpcdn.com/recipes/658a35344af63ec3/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita lestarikan karena setiap tempat memiliki keunikan tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica-rica yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah menampilkan kesan tersendiri yang merupakan keragaman Nusantara

Kehangatan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica-rica untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang dapat anda coba salah satunya ayam rica-rica yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam rica-rica tanpa harus bersusah payah.
Seperti resep Ayam rica-rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica:

1. Tambah 1 ekor ayam (potong 10)
1. Harus ada Sesuai selera daun bawang (bisa juga pakai kemangi)
1. Tambah  Bumbu halus :
1. Harap siapkan 1 ruas Kunyit
1. Jangan lupa 6 buah Cabe merah
1. Jangan lupa 4 buah Cabe rawit setan (kalau suka pedas)
1. Diperlukan 3 butir kemiri
1. Dibutuhkan 8 siung Bawang merah
1. Harap siapkan 4 siung Bawang putih
1. Tambah 1 ruas jahe
1. Siapkan  Bumbu tabur :
1. Harus ada Secukupnya garam
1. Tambah Secukupnya penyedap (saya pakai kaldu jamur)
1. Siapkan  Bumbu tumis :
1. Jangan lupa 1 batang sereh (geprek)
1. Siapkan 3 lembar daun jeruk
1. Dibutuhkan 1 ruas lengkuas




<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica:

1. Haluskan bumbu dengan blender.
1. Cuci ayam hingga bersih.
1. Panaskan minyak, tumis bumbu hingga harum.
1. Geprek sereh dan jahe. Lalu masukan daun jeruk dan bumbu yang sudah digeprek. Setelah harum, masukan ayam.
1. Beri sedikit air, masak dengan api yang membesar.
1. Aduk2 sampai bumbu merata. Tutup agar ayam cepat matang dan empuk.
<img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam rica-rica"><img src="//assets-global.cpcdn.com/assets/icons/button_play-2c75c40dde080a61004c1f40b05d8f140eaff45d7e9e6481dc71c63d2e7c4909.png" alt="Ayam rica-rica">1. Sajikan :))




Demikianlah cara membuat ayam rica-rica yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan cepat, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
