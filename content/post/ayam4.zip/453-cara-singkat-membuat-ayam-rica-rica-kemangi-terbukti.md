---
description: "Cara singkat membuat Ayam Rica Rica Kemangi Terbukti"
title: "Cara singkat membuat Ayam Rica Rica Kemangi Terbukti"
slug: 453-cara-singkat-membuat-ayam-rica-rica-kemangi-terbukti
date: 2020-12-02T07:44:52.107Z
image: https://img-global.cpcdn.com/recipes/155e0f30aaaca26f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/155e0f30aaaca26f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/155e0f30aaaca26f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Glenn Jensen
ratingvalue: 4
reviewcount: 17708
recipeingredient:
- "1 ekor ayam potong sesuai selera"
- "1 ikat daun kemangi"
- "3 lembar daun jeruk"
- "3 lembar daun salam"
- "1 batang serai geprek"
- "10 buah cabe rawit sy pakai utuhaslinya halus"
- "secukupnya Garam merica gula dan kaldu"
- " Bumbu Halus "
- "1 ruas lengkuas"
- "1 ruas jahe"
- "1 ruas kunyit"
- "6 butir bawang merah"
- "3 siung bawang putih"
- "2 butir kemiri"
- "10 buah cabe merah sesuai selera"
recipeinstructions:
- "Cuci bersih ayam, tambahkan air perasan jeruk nipis sedikit, diamkan sktr 15 menit agar tidak bau amis. Cuci bersih lagi. Rebus ayam sebentar untuk menghilangkan kotoran dan ayam cepat empuk. Tiriskan."
- "Panaskan sedikit minyak, tumis daun jeruk,daun salam dan serai hingga harum. Tambahkan bumbu halus, tumis hingga wangi."
- "Masukkan ayam, tambahkan garam, gula, merica dan kaldu. Aduk rata. Tambahkan sedikit air. Aduk rata."
- "Jika ayam sudah empuk dan air menyusut tambahkan daun kemangi. Aduk sebentar. Koreksi rasa. Sajikan."
- "Hmm enaaak sekali 💖💖."
- "Note : disini saya pakai daging ayam bagian dada dan beberapa ceker ayam. Tapi untuk satu ayam utuh juga bisa atau disesuaikan dgn selera masing2."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 256 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT60M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/155e0f30aaaca26f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang setidaknya kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica rica kemangi yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan ciri khas yang merupakan keragaman Nusantara



Kedekatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Rica Rica Kemangi untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang bisa anda buat salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 6 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Harus ada 1 ekor ayam, potong sesuai selera
1. Siapkan 1 ikat daun kemangi
1. Jangan lupa 3 lembar daun jeruk
1. Dibutuhkan 3 lembar daun salam
1. Harus ada 1 batang serai, geprek
1. Siapkan 10 buah cabe rawit (sy pakai utuh)aslinya halus
1. Diperlukan secukupnya Garam, merica, gula dan kaldu
1. Tambah  Bumbu Halus :
1. Jangan lupa 1 ruas lengkuas
1. Diperlukan 1 ruas jahe
1. Harus ada 1 ruas kunyit
1. Jangan lupa 6 butir bawang merah
1. Tambah 3 siung bawang putih
1. Siapkan 2 butir kemiri
1. Diperlukan 10 buah cabe merah (sesuai selera)




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica Kemangi:

1. Cuci bersih ayam, tambahkan air perasan jeruk nipis sedikit, diamkan sktr 15 menit agar tidak bau amis. Cuci bersih lagi. Rebus ayam sebentar untuk menghilangkan kotoran dan ayam cepat empuk. Tiriskan.
1. Panaskan sedikit minyak, tumis daun jeruk,daun salam dan serai hingga harum. Tambahkan bumbu halus, tumis hingga wangi.
1. Masukkan ayam, tambahkan garam, gula, merica dan kaldu. Aduk rata. Tambahkan sedikit air. Aduk rata.
1. Jika ayam sudah empuk dan air menyusut tambahkan daun kemangi. Aduk sebentar. Koreksi rasa. Sajikan.
1. Hmm enaaak sekali 💖💖.
1. Note : disini saya pakai daging ayam bagian dada dan beberapa ceker ayam. Tapi untuk satu ayam utuh juga bisa atau disesuaikan dgn selera masing2.




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan cepat, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
