---
description: "Resep : Nasi ayam goreng madu Luar biasa"
title: "Resep : Nasi ayam goreng madu Luar biasa"
slug: 65-resep-nasi-ayam-goreng-madu-luar-biasa
date: 2020-11-10T06:07:16.909Z
image: https://img-global.cpcdn.com/recipes/f190fc67d0c8a097/751x532cq70/nasi-ayam-goreng-madu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f190fc67d0c8a097/751x532cq70/nasi-ayam-goreng-madu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f190fc67d0c8a097/751x532cq70/nasi-ayam-goreng-madu-foto-resep-utama.jpg
author: Myrtie Miller
ratingvalue: 4.5
reviewcount: 44156
recipeingredient:
- " BAHAN UTAMA"
- "5 paha ayam"
- "4 sdm penyedap rasa  kaldu bubuk"
- " Air"
- " BAHAN TUMBUK HALUS"
- "8 inci jahe"
- "15 siung bawang putih"
- " BAHAN UNGKEP AYAM"
- "2 sdm sos tiram"
- "1 cup bumbu tumbuk halus"
- "2 sdm kecap manis"
- "1 sdm kecap asin"
- " BAHAN NASI AYAM"
- "1 sdm mentega"
- "1 cup bumbu tumbuk halus"
- "1 buah kayu manis"
- "4 biji buah pelaga"
- "2 biji bunga lawang"
- "3 helai daun pandan"
- "1 batang serai"
- "3 cup beras cuci bersih  tiriskan"
- "3-4 gelas air rebusan ayam"
- "1/2 sdt garam"
- "Sejumput garam"
- " BAHAN SOS SAMBAL"
- "1 cup bumbu tumbuk halus"
- "4 cabe merah besar"
- "4 cabe merah kecil"
- "sesuai selera Garam dan gula"
- "Sedikit air rebusan ayam"
- " BAHAN SAMBAL KECAP"
- " Air sisa ungkep ayam"
- "3 sdm kecap manis"
- "Sedikit air rebusan ayam"
- " BAHAN SUP"
- "1 buah tomat"
- "2 buah kentang"
- "1 buah wortel"
- "sesuai selera Jamur"
- " Sisa air rebusan ayam"
- "sesuai selera Garam dan gula"
- "4 sdm lada bubuk"
- "1 helai daun bawang  daun sup"
- " BAHAN TAMBAHAN"
- " Timun"
- " Sayur salad"
- " Tomat"
- "2 sdm madu untuk olesan ayam nya"
recipeinstructions:
- "Pertama kita buat bumbu tumbuk halus nya dulu yaitu jahe dan bawang putih kita tumbuk sampai halus, setelah halus kita bagi bumbu tumbuk jadi 4 cup/wadah,wadah pertama nanti untuk rebus ayam, ke dua untuk ungkep ayam, ketiga untuk masak nasi dan ke 4 untuk sambal nya nanti, setelah selesai sisihkan"
- "Selanjutnya kita rebus paha ayam nya tapi sebelum itu kita baluri dulu paha ayam dengan bumbu tumbuk halus yang pertama, setelah selesai kita letakan paha ayam dalam panci merebus lalu tambahkan air dan masukan penyedap rasa nya lalu aduk rata kita masak sampai air mendidih"
- "Setelah mendidih dan ayam matang selanjutnya keluarkan ayam nya dan air ungkepan nya jangan di buang yah nanti kita bisa gunakan untuk masak nasi dan bikin sambal serta buat sayur sup nya"
- "Lalu selanjutnya kita ungkep paha ayam nya tapi sebelum itu kita buat bumbu ungkep nya dulu ya yaitu siapkan wadah tambahkan bumbu tumbuk halus ke 2 dan masukan sos tiram, kecap manis dan kecap asin lalu aduk rata lalu baluri bumbu ke semua bagian paha ayam sampai semua bagian paha tercampur rata dengan bumbu lalu diamkan dan sisihkan"
- "Dan selanjutnya kita buat nasi nya seperti layak nya masak nasi biasa kita siapkan mejikom nya dan kita on kan tombol mejikom nya lalu masukan margarin dan masukan bunga lawang, kayu manis, buah pelaga, daun pandan yg di simpulkan, lalu masukan juga serai yg di geprek aduk rata sampai bau harum dan masukan bumbu tumbuk halus ke 3 nya dan aduk rata"
- "Setelah itu masukan beras nya dan aduk aduk sampai agak kering dan masukan air rebusan ayam, lalu tambahkan garam dan kunyit bubuk nya aduk kembali lalu tutup mejikom nya dan biyarkan sampai matang dengan sendiri nya"
- "Sambil menunggu nasi matang kita buat sos sambal nya di sini kita blender cabe merah besar dan kecil, masukan juga bumbu tumbuk halus ke 4 lalu tambahkan sedikit air rebusan ayam dan blender sampai halus"
- "Setelah bumbu sambal halus kita panaskan panci lalu tuangkan bumbu blender tadi dan tambahkan sedikit air rebusan ayam lalu masukan garam dan gula aduk rata biyarkan sampai mendidih setelah mendidih angkat dan pindahkan"
- "Selanjutnya kita pindahkan ayam ungkep ke dalam piring dan sisa bumbu nya kita jadikan sambal kecap nya nanti"
- "Selanjutnya kita buat sambal kecap nya caranya panaskan panci lalu masukan sisa bumbu ungkep, tambahkan juga sedikit air rebusan ayam lalu tambahkan kecap manis aduk rata dan biyarkan sampai mendidih, setelah mendidih kita angkat dan pindahkan ke dalam wadah"
- "Dan ini nasi nya sudah matang, selanjutnya kita buat sup nya"
- "Kita bersihkan kentang dan wortel nya lalu potong sesuai selera, potong juga daun bawangnya, dan potong juga tomat nya"
- "Lalu setelah itu Panaskan sisa air rebusan ayam biyarkan sampai mendidih, lalu masukan kentang,wortel biayarkan sampai empuk, setelah empuk masukan garam, gula, lada bubuk, aduk rata dan tambahkan juga jamur, daun bawang, tomat aduk kembali lalu angkat dan hidangkan"
- "Setelah itu kita panaskan minyak dan goreng ayam sampai matang tapi jangan terlalu kering jangan lupa di bolak balim agar matang ayam merata, setelah matang angkat dan tiriskan"
- "Selanjutnya kita olesi ayam dengan madu di sini ayam jadi lebih mengkilat dan menggugah selera bgt ya setelah selesai sisihkan"
- "Dan yg terahir kita potong bahan pelengkap nya yaitu timun, tomat dan sayur salad nya lalu setelah selesai hidangkan"
- "Dan ini nasi ayam goreng madu siap di hidangkan dan di makan, semoga bermanfaat ya"
categories:
- Recipe
tags:
- nasi
- ayam
- goreng

katakunci: nasi ayam goreng 
nutrition: 165 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Dinner

---


![Nasi ayam goreng madu](https://img-global.cpcdn.com/recipes/f190fc67d0c8a097/751x532cq70/nasi-ayam-goreng-madu-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga enak. Ciri khas kuliner Nusantara nasi ayam goreng madu yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kehangatan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Nasi ayam goreng madu untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda contoh salah satunya nasi ayam goreng madu yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep nasi ayam goreng madu tanpa harus bersusah payah.
Berikut ini resep Nasi ayam goreng madu yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 17 langkah dan 48 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Nasi ayam goreng madu:

1. Siapkan  ●BAHAN UTAMA
1. Harap siapkan 5 paha ayam
1. Harus ada 4 sdm penyedap rasa / kaldu bubuk
1. Diperlukan  Air
1. Harus ada  ●BAHAN TUMBUK HALUS
1. Tambah 8 inci jahe
1. Dibutuhkan 15 siung bawang putih
1. Harap siapkan  ●BAHAN UNGKEP AYAM
1. Diperlukan 2 sdm sos tiram
1. Diperlukan 1 cup bumbu tumbuk halus
1. Harap siapkan 2 sdm kecap manis
1. Diperlukan 1 sdm kecap asin
1. Diperlukan  ●BAHAN NASI AYAM
1. Diperlukan 1 sdm mentega
1. Harus ada 1 cup bumbu tumbuk halus
1. Siapkan 1 buah kayu manis
1. Harap siapkan 4 biji buah pelaga
1. Dibutuhkan 2 biji bunga lawang
1. Harus ada 3 helai daun pandan
1. Siapkan 1 batang serai
1. Jangan lupa 3 cup beras (cuci bersih &amp; tiriskan)
1. Harus ada 3-4 gelas air rebusan ayam
1. Harus ada 1/2 sdt garam
1. Diperlukan Sejumput garam
1. Tambah  ●BAHAN SOS SAMBAL
1. Harap siapkan 1 cup bumbu tumbuk halus
1. Jangan lupa 4 cabe merah besar
1. Harap siapkan 4 cabe merah kecil
1. Harus ada sesuai selera Garam dan gula
1. Harus ada Sedikit air rebusan ayam
1. Jangan lupa  ●BAHAN SAMBAL KECAP
1. Harus ada  Air sisa ungkep ayam
1. Jangan lupa 3 sdm kecap manis
1. Siapkan Sedikit air rebusan ayam
1. Diperlukan  ●BAHAN SUP
1. Siapkan 1 buah tomat
1. Harus ada 2 buah kentang
1. Tambah 1 buah wortel
1. Tambah sesuai selera Jamur
1. Siapkan  Sisa air rebusan ayam
1. Siapkan sesuai selera Garam dan gula
1. Harap siapkan 4 sdm lada bubuk
1. Harus ada 1 helai daun bawang / daun sup
1. Harus ada  ●BAHAN TAMBAHAN
1. Dibutuhkan  Timun
1. Harap siapkan  Sayur salad
1. Dibutuhkan  Tomat
1. Tambah 2 sdm madu untuk olesan ayam nya




<!--inarticleads2-->

##### Langkah membuat  Nasi ayam goreng madu:

1. Pertama kita buat bumbu tumbuk halus nya dulu yaitu jahe dan bawang putih kita tumbuk sampai halus, setelah halus kita bagi bumbu tumbuk jadi 4 cup/wadah,wadah pertama nanti untuk rebus ayam, ke dua untuk ungkep ayam, ketiga untuk masak nasi dan ke 4 untuk sambal nya nanti, setelah selesai sisihkan
1. Selanjutnya kita rebus paha ayam nya tapi sebelum itu kita baluri dulu paha ayam dengan bumbu tumbuk halus yang pertama, setelah selesai kita letakan paha ayam dalam panci merebus lalu tambahkan air dan masukan penyedap rasa nya lalu aduk rata kita masak sampai air mendidih
1. Setelah mendidih dan ayam matang selanjutnya keluarkan ayam nya dan air ungkepan nya jangan di buang yah nanti kita bisa gunakan untuk masak nasi dan bikin sambal serta buat sayur sup nya
1. Lalu selanjutnya kita ungkep paha ayam nya tapi sebelum itu kita buat bumbu ungkep nya dulu ya yaitu siapkan wadah tambahkan bumbu tumbuk halus ke 2 dan masukan sos tiram, kecap manis dan kecap asin lalu aduk rata lalu baluri bumbu ke semua bagian paha ayam sampai semua bagian paha tercampur rata dengan bumbu lalu diamkan dan sisihkan
1. Dan selanjutnya kita buat nasi nya seperti layak nya masak nasi biasa kita siapkan mejikom nya dan kita on kan tombol mejikom nya lalu masukan margarin dan masukan bunga lawang, kayu manis, buah pelaga, daun pandan yg di simpulkan, lalu masukan juga serai yg di geprek aduk rata sampai bau harum dan masukan bumbu tumbuk halus ke 3 nya dan aduk rata
1. Setelah itu masukan beras nya dan aduk aduk sampai agak kering dan masukan air rebusan ayam, lalu tambahkan garam dan kunyit bubuk nya aduk kembali lalu tutup mejikom nya dan biyarkan sampai matang dengan sendiri nya
1. Sambil menunggu nasi matang kita buat sos sambal nya di sini kita blender cabe merah besar dan kecil, masukan juga bumbu tumbuk halus ke 4 lalu tambahkan sedikit air rebusan ayam dan blender sampai halus
1. Setelah bumbu sambal halus kita panaskan panci lalu tuangkan bumbu blender tadi dan tambahkan sedikit air rebusan ayam lalu masukan garam dan gula aduk rata biyarkan sampai mendidih setelah mendidih angkat dan pindahkan
1. Selanjutnya kita pindahkan ayam ungkep ke dalam piring dan sisa bumbu nya kita jadikan sambal kecap nya nanti
1. Selanjutnya kita buat sambal kecap nya caranya panaskan panci lalu masukan sisa bumbu ungkep, tambahkan juga sedikit air rebusan ayam lalu tambahkan kecap manis aduk rata dan biyarkan sampai mendidih, setelah mendidih kita angkat dan pindahkan ke dalam wadah
1. Dan ini nasi nya sudah matang, selanjutnya kita buat sup nya
1. Kita bersihkan kentang dan wortel nya lalu potong sesuai selera, potong juga daun bawangnya, dan potong juga tomat nya
1. Lalu setelah itu Panaskan sisa air rebusan ayam biyarkan sampai mendidih, lalu masukan kentang,wortel biayarkan sampai empuk, setelah empuk masukan garam, gula, lada bubuk, aduk rata dan tambahkan juga jamur, daun bawang, tomat aduk kembali lalu angkat dan hidangkan
1. Setelah itu kita panaskan minyak dan goreng ayam sampai matang tapi jangan terlalu kering jangan lupa di bolak balim agar matang ayam merata, setelah matang angkat dan tiriskan
1. Selanjutnya kita olesi ayam dengan madu di sini ayam jadi lebih mengkilat dan menggugah selera bgt ya setelah selesai sisihkan
1. Dan yg terahir kita potong bahan pelengkap nya yaitu timun, tomat dan sayur salad nya lalu setelah selesai hidangkan
1. Dan ini nasi ayam goreng madu siap di hidangkan dan di makan, semoga bermanfaat ya




Demikianlah cara membuat nasi ayam goreng madu yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep istimewa yang sangat simple dan cepat, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
