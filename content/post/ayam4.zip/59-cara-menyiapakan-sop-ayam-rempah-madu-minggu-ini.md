---
description: "Cara menyiapakan Sop Ayam Rempah Madu minggu ini"
title: "Cara menyiapakan Sop Ayam Rempah Madu minggu ini"
slug: 59-cara-menyiapakan-sop-ayam-rempah-madu-minggu-ini
date: 2021-01-05T05:24:50.950Z
image: https://img-global.cpcdn.com/recipes/a48b470db256e1ca/751x532cq70/sop-ayam-rempah-madu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a48b470db256e1ca/751x532cq70/sop-ayam-rempah-madu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a48b470db256e1ca/751x532cq70/sop-ayam-rempah-madu-foto-resep-utama.jpg
author: Henrietta Gomez
ratingvalue: 4.7
reviewcount: 37392
recipeingredient:
- "1/4 kg sayap ayam"
- "1 buah wortel ukuran besar kupas cuci potongpotong"
- "1 lt air untuk kuah sop"
- "200 ml air untuk strerilisasi ayam"
- "2 buah kentang ukuran kecil kupas cuci potongpotong"
- "1 batang bawang daun potongpotong"
- "1 batang seledri potongpotong"
- "2 siung bawang putih geprek cincang halus"
- "1 buah tomat potongpotong"
- "1 sdt garam"
- "2 sdm madu"
- "1 batang sereh geprek"
- "3 lembar daun salam"
- "1 ruas jahe iris tipis"
- "3 butir cengkeh"
- "2 sdm olive oil"
recipeinstructions:
- "Cuci bersih ayam, didihkan 200 ml air, rebus ayam sebentar, buang airnya."
- "Siapkan wajan, tumis bawang putih, sereh, jahe dan daun salam hingga harum."
- "Dalam panci, didihkan 1 liter air. Masukan bumbu yang sudah ditumis, lalu masukan ayam. Masak hingga ayam 1/2 matang, lalu tambahkan wortel dan kentang. Aduk rata."
- "Tambahkan garam dan cengkeh, aduk rata. Masak hingga matang. Lalu masukan bawang daun, seledri dan tomat. Cek rasa keasinannya. Biarkan hangat."
- "Setelah menghangat, tambahkan madunya. Aduk rata dan cek lagi rasanya. Aroma sopnya enak banget 😍😍😍"
- "Sajikan 💜"
categories:
- Recipe
tags:
- sop
- ayam
- rempah

katakunci: sop ayam rempah 
nutrition: 133 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dessert

---


![Sop Ayam Rempah Madu](https://img-global.cpcdn.com/recipes/a48b470db256e1ca/751x532cq70/sop-ayam-rempah-madu-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga gurih. Ciri makanan Indonesia sop ayam rempah madu yang penuh dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Sop Ayam Rempah Madu untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda contoh salah satunya sop ayam rempah madu yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep sop ayam rempah madu tanpa harus bersusah payah.
Berikut ini resep Sop Ayam Rempah Madu yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Sop Ayam Rempah Madu:

1. Siapkan 1/4 kg sayap ayam
1. Dibutuhkan 1 buah wortel ukuran besar, kupas, cuci, potong-potong
1. Jangan lupa 1 lt air untuk kuah sop
1. Diperlukan 200 ml air untuk strerilisasi ayam
1. Tambah 2 buah kentang ukuran kecil, kupas, cuci, potong-potong
1. Dibutuhkan 1 batang bawang daun, potong-potong
1. Dibutuhkan 1 batang seledri, potong-potong
1. Harap siapkan 2 siung bawang putih, geprek, cincang halus
1. Harap siapkan 1 buah tomat, potong-potong
1. Harus ada 1 sdt garam
1. Harap siapkan 2 sdm madu
1. Harus ada 1 batang sereh, geprek
1. Tambah 3 lembar daun salam
1. Diperlukan 1 ruas jahe, iris tipis
1. Tambah 3 butir cengkeh
1. Jangan lupa 2 sdm olive oil




<!--inarticleads2-->

##### Langkah membuat  Sop Ayam Rempah Madu:

1. Cuci bersih ayam, didihkan 200 ml air, rebus ayam sebentar, buang airnya.
1. Siapkan wajan, tumis bawang putih, sereh, jahe dan daun salam hingga harum.
1. Dalam panci, didihkan 1 liter air. Masukan bumbu yang sudah ditumis, lalu masukan ayam. Masak hingga ayam 1/2 matang, lalu tambahkan wortel dan kentang. Aduk rata.
1. Tambahkan garam dan cengkeh, aduk rata. Masak hingga matang. Lalu masukan bawang daun, seledri dan tomat. Cek rasa keasinannya. Biarkan hangat.
1. Setelah menghangat, tambahkan madunya. Aduk rata dan cek lagi rasanya. Aroma sopnya enak banget 😍😍😍
1. Sajikan 💜




Demikianlah cara membuat sop ayam rempah madu yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
