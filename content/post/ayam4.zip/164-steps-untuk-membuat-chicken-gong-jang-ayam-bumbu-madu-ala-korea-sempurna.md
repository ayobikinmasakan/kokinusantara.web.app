---
description: "Steps untuk membuat Chicken Gong Jang (Ayam Bumbu Madu ala Korea) Sempurna"
title: "Steps untuk membuat Chicken Gong Jang (Ayam Bumbu Madu ala Korea) Sempurna"
slug: 164-steps-untuk-membuat-chicken-gong-jang-ayam-bumbu-madu-ala-korea-sempurna
date: 2020-12-05T12:35:37.236Z
image: https://img-global.cpcdn.com/recipes/be34d5bd4e40f047/751x532cq70/chicken-gong-jang-ayam-bumbu-madu-ala-korea-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/be34d5bd4e40f047/751x532cq70/chicken-gong-jang-ayam-bumbu-madu-ala-korea-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/be34d5bd4e40f047/751x532cq70/chicken-gong-jang-ayam-bumbu-madu-ala-korea-foto-resep-utama.jpg
author: Sam Wise
ratingvalue: 4.3
reviewcount: 22641
recipeingredient:
- "4 potong ayam paha atas"
- " Bumbu Tepung bumbu kfc "
- "6 sdm tepung terigu serbaguna"
- "1 sdt garam"
- "1 sdm minyak wijen"
- "Secukupnya lada putih"
- " Saos Madu "
- "1 buah bawang putihcincang halus"
- "5 sdm saos tomat"
- "2 sdm madu"
- "1/2 sdt cuka"
- "1/2 sdt minyak wijen"
- "5 sdm air"
- "1 sdm margarin"
- "1 sdt gula"
- "1 sdt garam"
- "1 sdt kaldu jamur totole"
- "Secukupnya minyak goreng"
- " Topping "
- " Taburan wijen  seledri"
- " Bon cabe bila suka pedas"
recipeinstructions:
- "Sangrai dahalu wijen nya"
- "Cuci bersih ayam.beri jeruk nipis dan garam diamkan sbntr.lalu cuci lagi.kemudiam ungkep ayam nya supaya matang di dalam hingga berunah warna"
- "Siapkan wadah yang lain untuk bumbu tepung,beri garam lada minyak wijen lalu gulungkan ayam ke tepung hingga rata,lakukan hingga selesai"
- "Goreng ayam nya"
- "Tumis bumbu,buang minyak nya sedikit kemudian masukan margarin tumis bawang putih masukan saos tomat,garam,gula,kaldu jamur,madu,minyak wijen masukan ayam aduk hingga rata masukan air aduk lagi.lalu icipi rasa nya."
- "Sajikan + beri taburan wijen dan seledri sebagai hiasan"
categories:
- Recipe
tags:
- chicken
- gong
- jang

katakunci: chicken gong jang 
nutrition: 132 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Lunch

---


![Chicken Gong Jang (Ayam Bumbu Madu ala Korea)](https://img-global.cpcdn.com/recipes/be34d5bd4e40f047/751x532cq70/chicken-gong-jang-ayam-bumbu-madu-ala-korea-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas dan enak. Ciri makanan Nusantara chicken gong jang (ayam bumbu madu ala korea) yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat diperoleh dengan cara simple. Diantaranya adalah membuat makanan Chicken Gong Jang (Ayam Bumbu Madu ala Korea) untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang bisa anda praktekkan salah satunya chicken gong jang (ayam bumbu madu ala korea) yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep chicken gong jang (ayam bumbu madu ala korea) tanpa harus bersusah payah.
Seperti resep Chicken Gong Jang (Ayam Bumbu Madu ala Korea) yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 21 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Chicken Gong Jang (Ayam Bumbu Madu ala Korea):

1. Jangan lupa 4 potong ayam paha atas
1. Siapkan  Bumbu Tepung /bumbu kfc :
1. Jangan lupa 6 sdm tepung terigu serbaguna
1. Siapkan 1 sdt garam
1. Jangan lupa 1 sdm minyak wijen
1. Siapkan Secukupnya lada putih
1. Diperlukan  Saos Madu :
1. Siapkan 1 buah bawang putih,cincang halus
1. Diperlukan 5 sdm saos tomat
1. Siapkan 2 sdm madu
1. Siapkan 1/2 sdt cuka
1. Diperlukan 1/2 sdt minyak wijen
1. Diperlukan 5 sdm air
1. Harus ada 1 sdm margarin
1. Dibutuhkan 1 sdt gula
1. Tambah 1 sdt garam
1. Tambah 1 sdt kaldu jamur totole
1. Jangan lupa Secukupnya minyak goreng
1. Diperlukan  Topping :
1. Harus ada  Taburan wijen &amp; seledri
1. Dibutuhkan  Bon cabe (bila suka pedas)




<!--inarticleads2-->

##### Langkah membuat  Chicken Gong Jang (Ayam Bumbu Madu ala Korea):

1. Sangrai dahalu wijen nya
1. Cuci bersih ayam.beri jeruk nipis dan garam diamkan sbntr.lalu cuci lagi.kemudiam ungkep ayam nya supaya matang di dalam hingga berunah warna
1. Siapkan wadah yang lain untuk bumbu tepung,beri garam lada minyak wijen lalu gulungkan ayam ke tepung hingga rata,lakukan hingga selesai
1. Goreng ayam nya
1. Tumis bumbu,buang minyak nya sedikit kemudian masukan margarin tumis bawang putih masukan saos tomat,garam,gula,kaldu jamur,madu,minyak wijen masukan ayam aduk hingga rata masukan air aduk lagi.lalu icipi rasa nya.
1. Sajikan + beri taburan wijen dan seledri sebagai hiasan




Demikianlah cara membuat chicken gong jang (ayam bumbu madu ala korea) yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
