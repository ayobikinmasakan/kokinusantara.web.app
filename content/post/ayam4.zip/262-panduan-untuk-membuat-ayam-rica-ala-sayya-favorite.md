---
description: "Panduan untuk membuat Ayam rica ala sayya.. Favorite"
title: "Panduan untuk membuat Ayam rica ala sayya.. Favorite"
slug: 262-panduan-untuk-membuat-ayam-rica-ala-sayya-favorite
date: 2020-09-11T01:11:29.853Z
image: https://img-global.cpcdn.com/recipes/f73f2a7a06c16183/751x532cq70/ayam-rica-ala-sayya-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f73f2a7a06c16183/751x532cq70/ayam-rica-ala-sayya-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f73f2a7a06c16183/751x532cq70/ayam-rica-ala-sayya-foto-resep-utama.jpg
author: Susan Byrd
ratingvalue: 4.9
reviewcount: 11406
recipeingredient:
- "1/2 kg ayam"
- "300 mL Air"
- "1 ikat daun kemangi"
- "3 genggam daun melinjo"
- " Bumbu"
- "7 cabe merah keriting"
- "3 cabe merah besar"
- "7 siung bawang merah"
- "3 siung bawang putih"
- "1 ruas kunyit"
- "1 ruas jahe"
- "3 batang sereh"
- "2 buah tomat merah"
- " Bumbu pelangkap"
- "Secukupnya garam"
- " Penyedap rasa"
- "1/2 sendok teh merica bubuk"
- "Secukupnya minyak goreng untuk menumis"
recipeinstructions:
- "Potong potong ayam menjadi potongan kecil, beri sedikit air jeruk dan garam,cuci bersih dan kukus sebentar"
- "Haluskan semua bumbu, kecuali sereh hanya digeprek"
- "Tumis bumbu yang sudah dihaluskan sampai wangi, tambahkan merica, garam,masukkan ayam dan air,aduk dan masak sampai bumbu meresap dan air sedikit lagi"
- "Masukkan potongan tomat, daun melinjo dan daun kemangi aduk sampai air sat, cek rasa bila suka tambahkan penyedap"
- "Ayam rica dinikmati dengan nasi hangat....#makan bergizi, tingkatkan daya tahan tubuh....semoga sehat selalu🥰"
categories:
- Recipe
tags:
- ayam
- rica
- ala

katakunci: ayam rica ala 
nutrition: 206 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam rica ala sayya..](https://img-global.cpcdn.com/recipes/f73f2a7a06c16183/751x532cq70/ayam-rica-ala-sayya-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau renyah. Ciri masakan Nusantara ayam rica ala sayya.. yang penuh dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam rica ala sayya.. untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang bisa anda contoh salah satunya ayam rica ala sayya.. yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica ala sayya.. tanpa harus bersusah payah.
Seperti resep Ayam rica ala sayya.. yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica ala sayya..:

1. Tambah 1/2 kg ayam
1. Harap siapkan 300 mL Air
1. Dibutuhkan 1 ikat daun kemangi
1. Tambah 3 genggam daun melinjo
1. Jangan lupa  Bumbu
1. Diperlukan 7 cabe merah keriting
1. Dibutuhkan 3 cabe merah besar
1. Jangan lupa 7 siung bawang merah
1. Diperlukan 3 siung bawang putih
1. Diperlukan 1 ruas kunyit
1. Harus ada 1 ruas jahe
1. Dibutuhkan 3 batang sereh
1. Dibutuhkan 2 buah tomat merah
1. Harus ada  Bumbu pelangkap
1. Harap siapkan Secukupnya garam
1. Harap siapkan  Penyedap rasa
1. Harus ada 1/2 sendok teh merica bubuk
1. Tambah Secukupnya minyak goreng untuk menumis




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica ala sayya..:

1. Potong potong ayam menjadi potongan kecil, beri sedikit air jeruk dan garam,cuci bersih dan kukus sebentar
1. Haluskan semua bumbu, kecuali sereh hanya digeprek
1. Tumis bumbu yang sudah dihaluskan sampai wangi, tambahkan merica, garam,masukkan ayam dan air,aduk dan masak sampai bumbu meresap dan air sedikit lagi
1. Masukkan potongan tomat, daun melinjo dan daun kemangi aduk sampai air sat, cek rasa bila suka tambahkan penyedap
1. Ayam rica dinikmati dengan nasi hangat....#makan bergizi, tingkatkan daya tahan tubuh....semoga sehat selalu🥰




Demikianlah cara membuat ayam rica ala sayya.. yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
