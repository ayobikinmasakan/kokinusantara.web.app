---
description: "Steps menyiapakan Ayam Rica Pedas (Menu Diet) Sempurna"
title: "Steps menyiapakan Ayam Rica Pedas (Menu Diet) Sempurna"
slug: 461-steps-menyiapakan-ayam-rica-pedas-menu-diet-sempurna
date: 2020-12-18T17:26:29.305Z
image: https://img-global.cpcdn.com/recipes/df550c43e231644e/751x532cq70/ayam-rica-pedas-menu-diet-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/df550c43e231644e/751x532cq70/ayam-rica-pedas-menu-diet-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/df550c43e231644e/751x532cq70/ayam-rica-pedas-menu-diet-foto-resep-utama.jpg
author: Lida Beck
ratingvalue: 4
reviewcount: 26338
recipeingredient:
- "140 gr dada ayam tanpa kulit"
- "1 sdt saos tiram"
- "1 sdt saos tomat"
- "1 sdt saos sambal"
- "1 batang kecil daun bawang potongpotong"
- "500 ml Air kurleb"
- " Gula garam sedikit saja sesuai selera tanpa garam sudah asin"
- "1 sdt minyak canolaVCOkelapa dll"
- " Bumbu rajang"
- "1 butir bawang putih"
- "1/4 bawang bombai"
- "3 butir cabe rawit sesuai selera"
recipeinstructions:
- "Marinase dada ayam terlebih dahulu dengan sedikit kecap dan merica. Biarkan 30 menitan agar meresap."
- "Tumis bumbu rajang dengan minyak hingga wangi (pilih minyak sehat dan gunakan sedikit saja). Masukkan ayam, tumis sebentar."
- "Beri saos tiram, tomat dan sambal, masukkan daun bawang. Aduk sebentar sembari tambahkan air. Masak hingga bumbu cukup meresap dan mengental."
- "Matikan kompor dan siap santap 🤗"
categories:
- Recipe
tags:
- ayam
- rica
- pedas

katakunci: ayam rica pedas 
nutrition: 193 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Rica Pedas (Menu Diet)](https://img-global.cpcdn.com/recipes/df550c43e231644e/751x532cq70/ayam-rica-pedas-menu-diet-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas dan renyah. Ciri khas kuliner Nusantara ayam rica pedas (menu diet) yang penuh dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica Pedas (Menu Diet) untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang dapat anda contoh salah satunya ayam rica pedas (menu diet) yang merupakan makanan terkenal yang simpel dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica pedas (menu diet) tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Pedas (Menu Diet) yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Pedas (Menu Diet):

1. Dibutuhkan 140 gr dada ayam tanpa kulit
1. Tambah 1 sdt saos tiram
1. Siapkan 1 sdt saos tomat
1. Diperlukan 1 sdt saos sambal
1. Diperlukan 1 batang kecil daun bawang, potong-potong
1. Siapkan 500 ml Air kurleb
1. Harus ada  Gula, garam sedikit saja sesuai selera (tanpa garam sudah asin)
1. Jangan lupa 1 sdt minyak canola/VCO/kelapa dll
1. Tambah  Bumbu rajang:
1. Dibutuhkan 1 butir bawang putih
1. Tambah 1/4 bawang bombai
1. Jangan lupa 3 butir cabe rawit (sesuai selera)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Pedas (Menu Diet):

1. Marinase dada ayam terlebih dahulu dengan sedikit kecap dan merica. Biarkan 30 menitan agar meresap.
1. Tumis bumbu rajang dengan minyak hingga wangi (pilih minyak sehat dan gunakan sedikit saja). Masukkan ayam, tumis sebentar.
1. Beri saos tiram, tomat dan sambal, masukkan daun bawang. Aduk sebentar sembari tambahkan air. Masak hingga bumbu cukup meresap dan mengental.
1. Matikan kompor dan siap santap 🤗




Demikianlah cara membuat ayam rica pedas (menu diet) yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan cepat, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
