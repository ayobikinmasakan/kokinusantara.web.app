---
description: "Cara singkat untuk membuat Ayam rica-rica terupdate"
title: "Cara singkat untuk membuat Ayam rica-rica terupdate"
slug: 320-cara-singkat-untuk-membuat-ayam-rica-rica-terupdate
date: 2021-01-03T14:10:21.126Z
image: https://img-global.cpcdn.com/recipes/a4b698c4877700ba/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a4b698c4877700ba/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a4b698c4877700ba/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Edward Ford
ratingvalue: 4.1
reviewcount: 39048
recipeingredient:
- "1/2 ekor ayam"
- "1 buah tomat"
- "2 cabai besar"
- "5 lembar daun jeruk purut"
- "1 buah jeruk nipis"
- "1 Batang sereh dedeh digeprek"
- "1 ruas jahe digeprek"
- "1 ruas lengkuas digeprek"
- "1 ruas kunyit"
- "4 siung bawang merah"
- "2 siung bawang putih"
- "Secukupnya garam micindan royco"
- " Semangkuk air dingin"
recipeinstructions:
- "Siapkan bahan-bahan"
- "Bersihkan ayam, potong kecil-kecil, cuci kembali lalu tiriskan. Setelah itu taburi dengan jeruk nipis."
- "Ulek bawang merah, bawang putih dan kunyit."
- "Iris cabai, tomat, dan bawang merah (ini untuk ditumis ya)"
- "Siapkan wajan, masukkan minyak secukupnya. Lalu tumis bawang merah"
- "Masukkan bumbu halus yang sudah diulek tadi, tambahkan sereh, jahe, dan lengkuas geprek. Dan tambahkan sedikit air."
- "Masukkan ayam, daun jeruk purut, tomat, irisan cabai, dan tambahkan air secukupnya."
- "Terakhir tambahkan garam, micin, dan royco ayam secukupnya. Setelah matang, bisa langsung disajikan. 😄"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 213 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam rica-rica](https://img-global.cpcdn.com/recipes/a4b698c4877700ba/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang pedas,manis dan gurih. Karasteristik kuliner Nusantara ayam rica-rica yang kaya dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga bisa didapat dengan cara simple. Salah satunya adalah memasak Ayam rica-rica untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak jenis resep yang bisa anda praktekkan salah satunya ayam rica-rica yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 8 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica:

1. Harap siapkan 1/2 ekor ayam
1. Jangan lupa 1 buah tomat
1. Diperlukan 2 cabai besar
1. Dibutuhkan 5 lembar daun jeruk purut
1. Tambah 1 buah jeruk nipis
1. Harus ada 1 Batang sereh dedeh digeprek
1. Tambah 1 ruas jahe digeprek
1. Harap siapkan 1 ruas lengkuas digeprek
1. Siapkan 1 ruas kunyit
1. Jangan lupa 4 siung bawang merah
1. Harus ada 2 siung bawang putih
1. Siapkan Secukupnya garam, micin,dan royco
1. Tambah  Semangkuk air dingin




<!--inarticleads2-->

##### Langkah membuat  Ayam rica-rica:

1. Siapkan bahan-bahan
1. Bersihkan ayam, potong kecil-kecil, cuci kembali lalu tiriskan. Setelah itu taburi dengan jeruk nipis.
1. Ulek bawang merah, bawang putih dan kunyit.
1. Iris cabai, tomat, dan bawang merah (ini untuk ditumis ya)
1. Siapkan wajan, masukkan minyak secukupnya. Lalu tumis bawang merah
1. Masukkan bumbu halus yang sudah diulek tadi, tambahkan sereh, jahe, dan lengkuas geprek. Dan tambahkan sedikit air.
1. Masukkan ayam, daun jeruk purut, tomat, irisan cabai, dan tambahkan air secukupnya.
1. Terakhir tambahkan garam, micin, dan royco ayam secukupnya. Setelah matang, bisa langsung disajikan. 😄




Demikianlah cara membuat ayam rica-rica yang mudah dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan teruji, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
