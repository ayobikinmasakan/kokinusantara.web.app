---
description: "Bagaimana menyiapakan Ayam Rica-Rica Pedas Kemangi Cepat"
title: "Bagaimana menyiapakan Ayam Rica-Rica Pedas Kemangi Cepat"
slug: 401-bagaimana-menyiapakan-ayam-rica-rica-pedas-kemangi-cepat
date: 2021-01-06T18:44:15.261Z
image: https://img-global.cpcdn.com/recipes/70fe4d1a847382bb/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/70fe4d1a847382bb/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/70fe4d1a847382bb/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg
author: Rosalie Dixon
ratingvalue: 4.8
reviewcount: 18438
recipeingredient:
- "6 potong ayam"
- "sesuai selera Tempe dipotong kecil2"
- "2 daun jeruk"
- "1 daun salam"
- "1 ikat kemangi"
- "1 batang sereh digeprek"
- " Gula"
- " Totole kaldu jamur"
- " Bumbu halus"
- "5 bawang merah"
- "2 bawang putih"
- "1 ruas jahe"
- "1 ruas laos"
- " Kunyit secukupnya saya pake kunyit bubuk desaku"
- " Ketumbar sedikit saya pake ketumbar bubuk desaku"
- "5 cabe rawit kecil"
- "1 cabe merah besar"
- "secukupnya Garam"
recipeinstructions:
- "Rebus ayam terlebih dahulu (saya merebusnya dikasih garam sedikit)"
- "Didihkan air, rebus ayam hingga matang. Lalu tiriskan"
- "Bahan2 yang dihaluskan (bawang merah, bawang putih, jahe, laos, kunyit, ketumbar, garam). Boleh diulek boleh pake blender"
- "Panaskan wajan, beri minyak sedikit. Lalu tumis bumbu halus. Masukkan daun jeruk, daun salam, dan sereh. Tumis hingga harum."
- "Setelah harum, beri air secukupnya. Masukkan tempe yg sudah dipotong. Didihkan hingga tempe matang"
- "Lalu masukkan ayam yang sudah direbus. Beri garam, gula, totole. Koreksi rasa. Tunggu hingga bumbu meresap ke dalam ayam dan tempe. Terakhir masukkan daun kemangi. Lalu aduk hingga merata."
categories:
- Recipe
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 197 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica-Rica Pedas Kemangi](https://img-global.cpcdn.com/recipes/70fe4d1a847382bb/751x532cq70/ayam-rica-rica-pedas-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas dan gurih. Ciri masakan Indonesia ayam rica-rica pedas kemangi yang penuh dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica-Rica Pedas Kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis masakan yang dapat anda buat salah satunya ayam rica-rica pedas kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep ayam rica-rica pedas kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-Rica Pedas Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Pedas Kemangi:

1. Jangan lupa 6 potong ayam
1. Siapkan sesuai selera Tempe dipotong kecil2
1. Harus ada 2 daun jeruk
1. Harus ada 1 daun salam
1. Harus ada 1 ikat kemangi
1. Dibutuhkan 1 batang sereh digeprek
1. Jangan lupa  Gula
1. Siapkan  Totole kaldu jamur
1. Jangan lupa  Bumbu halus
1. Siapkan 5 bawang merah
1. Siapkan 2 bawang putih
1. Tambah 1 ruas jahe
1. Diperlukan 1 ruas laos
1. Tambah  Kunyit secukupnya (saya pake kunyit bubuk desaku)
1. Harus ada  Ketumbar sedikit (saya pake ketumbar bubuk desaku)
1. Harus ada 5 cabe rawit kecil
1. Jangan lupa 1 cabe merah besar
1. Harap siapkan secukupnya Garam




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-Rica Pedas Kemangi:

1. Rebus ayam terlebih dahulu (saya merebusnya dikasih garam sedikit)
1. Didihkan air, rebus ayam hingga matang. Lalu tiriskan
1. Bahan2 yang dihaluskan (bawang merah, bawang putih, jahe, laos, kunyit, ketumbar, garam). Boleh diulek boleh pake blender
1. Panaskan wajan, beri minyak sedikit. Lalu tumis bumbu halus. Masukkan daun jeruk, daun salam, dan sereh. Tumis hingga harum.
1. Setelah harum, beri air secukupnya. Masukkan tempe yg sudah dipotong. Didihkan hingga tempe matang
1. Lalu masukkan ayam yang sudah direbus. Beri garam, gula, totole. Koreksi rasa. Tunggu hingga bumbu meresap ke dalam ayam dan tempe. Terakhir masukkan daun kemangi. Lalu aduk hingga merata.




Demikianlah cara membuat ayam rica-rica pedas kemangi yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat simple dan teruji, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
