---
description: "Langkah menyiapakan Ayam Goreng Madu Ala Korea (Dak Kangjeong) Favorite"
title: "Langkah menyiapakan Ayam Goreng Madu Ala Korea (Dak Kangjeong) Favorite"
slug: 159-langkah-menyiapakan-ayam-goreng-madu-ala-korea-dak-kangjeong-favorite
date: 2020-11-15T04:27:55.081Z
image: https://img-global.cpcdn.com/recipes/022bdd612a197e69/751x532cq70/ayam-goreng-madu-ala-korea-dak-kangjeong-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/022bdd612a197e69/751x532cq70/ayam-goreng-madu-ala-korea-dak-kangjeong-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/022bdd612a197e69/751x532cq70/ayam-goreng-madu-ala-korea-dak-kangjeong-foto-resep-utama.jpg
author: Sarah Fernandez
ratingvalue: 4.4
reviewcount: 35674
recipeingredient:
- "300 gram fillet paha ayam potong dadu"
- "1 bungkus tepung bumbu serbaguna ukuran sedang 225 gram"
- "1 mangkuk air es untuk celupan"
- " Wijen sangrai secukupnya untuk taburan"
- " Bahan Saus Madu"
- "2 sdm madu"
- "4 sdm saus tomat bisa di campur dengan saus sambal"
- "2 sdt saus tiram"
- "1 sdt air perasan jeruk nipis"
- "1 sdm cabai bubuk"
- "2 sdm gula pasir"
- "1 sdt merica bubuk"
- "1 sdt garam"
- " Bumbu Halus"
- "1 jempol jahe"
- "3 siung bawang putih"
recipeinstructions:
- "Baluri ayam yang sudah di potong dadu secara merata dengan tepung bumbu serbaguna. Celupkan sebentar ke dalam air es. Kemudian lapisi kembali dengan tepung bumbu hingga rata."
- "Panaskan minyak, goreng ayam yang sudah di baluri tepung hingga matang. Tiriskan."
- "Masukkan semua bahan saus madu ke dalam wajan. Tambahkan sedikit air. Aduk rata hingga mengental dan meletup-letup. Tes rasa."
- "Masukkan ayam goreng ke dalam saus madu. Aduk hingga rata. Sajikan dengan taburan wijen."
categories:
- Recipe
tags:
- ayam
- goreng
- madu

katakunci: ayam goreng madu 
nutrition: 154 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Goreng Madu Ala Korea (Dak Kangjeong)](https://img-global.cpcdn.com/recipes/022bdd612a197e69/751x532cq70/ayam-goreng-madu-ala-korea-dak-kangjeong-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga gurih. Ciri khas kuliner Nusantara ayam goreng madu ala korea (dak kangjeong) yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga bisa diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Goreng Madu Ala Korea (Dak Kangjeong) untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang dapat anda contoh salah satunya ayam goreng madu ala korea (dak kangjeong) yang merupakan makanan favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam goreng madu ala korea (dak kangjeong) tanpa harus bersusah payah.
Seperti resep Ayam Goreng Madu Ala Korea (Dak Kangjeong) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Goreng Madu Ala Korea (Dak Kangjeong):

1. Harap siapkan 300 gram fillet paha ayam, potong dadu
1. Diperlukan 1 bungkus tepung bumbu serbaguna ukuran sedang (225 gram)
1. Harus ada 1 mangkuk air es untuk celupan
1. Jangan lupa  Wijen sangrai secukupnya untuk taburan
1. Dibutuhkan  Bahan Saus Madu:
1. Harus ada 2 sdm madu
1. Tambah 4 sdm saus tomat (bisa di campur dengan saus sambal)
1. Tambah 2 sdt saus tiram
1. Harus ada 1 sdt air perasan jeruk nipis
1. Harus ada 1 sdm cabai bubuk
1. Diperlukan 2 sdm gula pasir
1. Harus ada 1 sdt merica bubuk
1. Jangan lupa 1 sdt garam
1. Diperlukan  Bumbu Halus:
1. Diperlukan 1 jempol jahe
1. Diperlukan 3 siung bawang putih




<!--inarticleads2-->

##### Cara membuat  Ayam Goreng Madu Ala Korea (Dak Kangjeong):

1. Baluri ayam yang sudah di potong dadu secara merata dengan tepung bumbu serbaguna. Celupkan sebentar ke dalam air es. Kemudian lapisi kembali dengan tepung bumbu hingga rata.
1. Panaskan minyak, goreng ayam yang sudah di baluri tepung hingga matang. Tiriskan.
1. Masukkan semua bahan saus madu ke dalam wajan. Tambahkan sedikit air. Aduk rata hingga mengental dan meletup-letup. Tes rasa.
1. Masukkan ayam goreng ke dalam saus madu. Aduk hingga rata. Sajikan dengan taburan wijen.




Demikianlah cara membuat ayam goreng madu ala korea (dak kangjeong) yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menelusuri di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
