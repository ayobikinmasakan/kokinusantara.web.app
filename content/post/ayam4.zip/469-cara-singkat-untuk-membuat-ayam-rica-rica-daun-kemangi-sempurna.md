---
description: "Cara singkat untuk membuat Ayam rica rica daun kemangi Sempurna"
title: "Cara singkat untuk membuat Ayam rica rica daun kemangi Sempurna"
slug: 469-cara-singkat-untuk-membuat-ayam-rica-rica-daun-kemangi-sempurna
date: 2020-09-02T21:56:05.098Z
image: https://img-global.cpcdn.com/recipes/e3e34915e9f22d00/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e3e34915e9f22d00/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e3e34915e9f22d00/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Bill Ortega
ratingvalue: 4.5
reviewcount: 46522
recipeingredient:
- "500 gr ayam bagian dadatulangkulit"
- " bawang merah"
- " bawang putih"
- "3 buah cabe merah"
- "sesuai selera cabe rawit"
- "3 ruas jahe ukuran kecil"
- "1 ruas lengkuas ukuran sedang"
- "3 ruas kunyit ukuran kecil"
- "1 batang daun sereh"
- "3 lembar daun jeruk"
- "1 lembar daun salam"
- "2 ikat daun kemangi"
- " gula"
- " garam"
- " air"
recipeinstructions:
- "Cuci bersih ayam yang sudah di potong menjadi kecil, kemudian rebus dengan panci tertutup supaya cepat empuk (rebus kurang lebih sekitar 20-30 menit) angkat lalu tiriskan"
- "Haluskan semua bahan, kecuali jahe, lengkuas, daun sereh di geprek"
- "Panaskan minyak sedikit, kemudian masukkan semua bumbu yang sudah dihaluskan, tumis sampai wangi lalu masukkan jahe, lengkuas, daun salam, dan daun sereh, tumis kembali sampai semua bumbu tercampur"
- "Tambahkan air secukupnya, kemudian masukkan ayam yang sudah di rebus tadi, beri garam dan gula, aduk rata tunggu sampai mendidih"
- "Masukkan daun kemangi, aduk merata sampai semua bumbu meresap ke ayam, tunggu air sampai agak menyusut sedikit, koreksi rasa lalu siap disajikan 😁"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 206 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica rica daun kemangi](https://img-global.cpcdn.com/recipes/e3e34915e9f22d00/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita jaga karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica rica daun kemangi yang kami tulis berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa kesan tersendiri yang merupakan keragaman Indonesia

Kehangatan keluarga dapat didapat dengan cara mudah. Diantaranya adalah memasak Ayam rica rica daun kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di perantauan.

Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal. Olahan ayam dengan santan yang banyak digemari. selamat mencoba teman- teman . Lihat juga resep Ayam Rica Rica Kemangi enak lainnya.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang dapat anda buat salah satunya ayam rica rica daun kemangi yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica rica daun kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica daun kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica daun kemangi:

1. Siapkan 500 gr ayam, bagian dada/tulang/kulit
1. Jangan lupa  bawang merah
1. Jangan lupa  bawang putih
1. Diperlukan 3 buah cabe merah
1. Siapkan sesuai selera cabe rawit
1. Harap siapkan 3 ruas jahe ukuran kecil
1. Siapkan 1 ruas lengkuas ukuran sedang
1. Dibutuhkan 3 ruas kunyit ukuran kecil
1. Harus ada 1 batang daun sereh
1. Jangan lupa 3 lembar daun jeruk
1. Tambah 1 lembar daun salam
1. Siapkan 2 ikat daun kemangi
1. Diperlukan  gula
1. Dibutuhkan  garam
1. Dibutuhkan  air


Tambahkan irisan daun kemangi lalu aduk sampai hingga merata dan angkat. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. Resep Cara Membuat Ayam Goreng Lengkuas Yang Enak Dan Gurih. Penambah rasa; garam bubuk dan gula pasir putih. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica daun kemangi:

1. Cuci bersih ayam yang sudah di potong menjadi kecil, kemudian rebus dengan panci tertutup supaya cepat empuk (rebus kurang lebih sekitar 20-30 menit) angkat lalu tiriskan
1. Haluskan semua bahan, kecuali jahe, lengkuas, daun sereh di geprek
1. Panaskan minyak sedikit, kemudian masukkan semua bumbu yang sudah dihaluskan, tumis sampai wangi lalu masukkan jahe, lengkuas, daun salam, dan daun sereh, tumis kembali sampai semua bumbu tercampur
1. Tambahkan air secukupnya, kemudian masukkan ayam yang sudah di rebus tadi, beri garam dan gula, aduk rata tunggu sampai mendidih
1. Masukkan daun kemangi, aduk merata sampai semua bumbu meresap ke ayam, tunggu air sampai agak menyusut sedikit, koreksi rasa lalu siap disajikan 😁


Resep Cara Membuat Ayam Goreng Lengkuas Yang Enak Dan Gurih. Penambah rasa; garam bubuk dan gula pasir putih. Cara Membuat Ayam Rica Rica Kemangi. Resep terakhir ini hampir sama dengan resep ayam rica rica dengan daun kemangi. Yang lebih ditonjolkan adalah soal cita rasa pedas namun. 

Demikianlah cara membuat ayam rica rica daun kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
