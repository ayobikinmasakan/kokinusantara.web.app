---
description: "Resep : Opor Ayam Favorite"
title: "Resep : Opor Ayam Favorite"
slug: 491-resep-opor-ayam-favorite
date: 2020-12-13T23:19:15.970Z
image: https://img-global.cpcdn.com/recipes/7dceaa572c78636f/751x532cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7dceaa572c78636f/751x532cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7dceaa572c78636f/751x532cq70/opor-ayam-foto-resep-utama.jpg
author: Elnora Black
ratingvalue: 4.7
reviewcount: 15856
recipeingredient:
- "1 ekor ayam"
- "1/2 buah jeruk nipis"
- "1 sdt garam"
- "5 sdm minyak goreng"
- "1 lt santan dr 1 kelapa 300 ml kental700 ml encer"
- "1/4 buah bawang bombay iris"
- " Bumbu "
- "3 butir kemiri"
- "1/2 sdt lada"
- "8 siung bawang merah"
- "3 siung bawang putih"
- "1 batang sereh"
- "3 lembar daun salam"
- "1 ruas lengkuas"
- "1 ruas jahe"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- "1/2 sdt gula pasir"
recipeinstructions:
- "Siapkan bahan². Potong ayam menjadi 12 bagian atau sesuai selera dan cuci. Beri perasan jeruk nipis dan garam, remas² agar meresap. Diamkan selama 15 menit agar amisnya hilang."
- "Haluskan lada, bawang merah, bawang putih dan kemiri. Geprek lengkuas, jahe dan sereh."
- "Goreng ayam setengah matang."
- "Panaskan minyak dalam wajan dengan api kecil. Tumis bawang bombay sampai harum, masukkan bumbu halus, daun salam, kaldu bubuk dan gula. Tumis sampai bumbu matang. Tambahkan sedikit air, lalu masukkan ayam dan aduk rata, diamkan sebentar agar meresap."
- "Masukkan santan yg encer dulu (perasan kedua), aduk² sampai mendidih. Lalu tambahkan santan kentalnya (perasan pertama), aduk² terus sampai mendidih agar santan tidak pecah (terpisah antara santan dan air). Jumlah santan bisa dikurangi sesuai selera, soalnya kami suka kuahnya banyak. 😁"
- "Bila sudah mendidih koreksi rasa, bisa ditambahkan apa yg kurang terasa. Lalu matikan api, angkat dan sajikan."
- "Note : santan bisa juga memakai 2 bungkus kara kecil yg diencerkan."
categories:
- Recipe
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 217 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Lunch

---


![Opor Ayam](https://img-global.cpcdn.com/recipes/7dceaa572c78636f/751x532cq70/opor-ayam-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti opor ayam yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa ciri khas yang merupakan keragaman Kita

Kehangatan keluarga dapat diperoleh dengan cara simple. Salah satunya adalah membuat makanan Opor Ayam untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang bisa anda praktekkan salah satunya opor ayam yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep opor ayam tanpa harus bersusah payah.
Berikut ini resep Opor Ayam yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Opor Ayam:

1. Harus ada 1 ekor ayam
1. Siapkan 1/2 buah jeruk nipis
1. Dibutuhkan 1 sdt garam
1. Jangan lupa 5 sdm minyak goreng
1. Diperlukan 1 lt santan dr 1 kelapa (300 ml kental,700 ml encer)
1. Siapkan 1/4 buah bawang bombay, iris
1. Siapkan  Bumbu :
1. Harap siapkan 3 butir kemiri
1. Tambah 1/2 sdt lada
1. Siapkan 8 siung bawang merah
1. Diperlukan 3 siung bawang putih
1. Tambah 1 batang sereh
1. Jangan lupa 3 lembar daun salam
1. Siapkan 1 ruas lengkuas
1. Harap siapkan 1 ruas jahe
1. Jangan lupa 1 sdt garam
1. Diperlukan 1 sdt kaldu bubuk
1. Diperlukan 1/2 sdt gula pasir




<!--inarticleads2-->

##### Instruksi membuat  Opor Ayam:

1. Siapkan bahan². Potong ayam menjadi 12 bagian atau sesuai selera dan cuci. Beri perasan jeruk nipis dan garam, remas² agar meresap. Diamkan selama 15 menit agar amisnya hilang.
1. Haluskan lada, bawang merah, bawang putih dan kemiri. Geprek lengkuas, jahe dan sereh.
1. Goreng ayam setengah matang.
1. Panaskan minyak dalam wajan dengan api kecil. Tumis bawang bombay sampai harum, masukkan bumbu halus, daun salam, kaldu bubuk dan gula. Tumis sampai bumbu matang. Tambahkan sedikit air, lalu masukkan ayam dan aduk rata, diamkan sebentar agar meresap.
1. Masukkan santan yg encer dulu (perasan kedua), aduk² sampai mendidih. Lalu tambahkan santan kentalnya (perasan pertama), aduk² terus sampai mendidih agar santan tidak pecah (terpisah antara santan dan air). Jumlah santan bisa dikurangi sesuai selera, soalnya kami suka kuahnya banyak. 😁
1. Bila sudah mendidih koreksi rasa, bisa ditambahkan apa yg kurang terasa. Lalu matikan api, angkat dan sajikan.
1. Note : santan bisa juga memakai 2 bungkus kara kecil yg diencerkan.




Demikianlah cara membuat opor ayam yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep spesial yang sangat gampang dan terbukti, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
