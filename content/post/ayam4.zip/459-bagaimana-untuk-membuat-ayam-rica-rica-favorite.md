---
description: "Bagaimana untuk membuat Ayam Rica-Rica Favorite"
title: "Bagaimana untuk membuat Ayam Rica-Rica Favorite"
slug: 459-bagaimana-untuk-membuat-ayam-rica-rica-favorite
date: 2021-01-31T08:41:15.594Z
image: https://img-global.cpcdn.com/recipes/907770010c66f8a4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/907770010c66f8a4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/907770010c66f8a4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Charlotte Carlson
ratingvalue: 4.9
reviewcount: 44630
recipeingredient:
- "1 kg Ayam"
- "4 lembar Daun Salam"
- "2 batang Sereh"
- "3 sdm Kecap Manis"
- "Secukupnya Garam"
- "Secukupnya Gula"
- "Secukupnya Penyedap optional"
- "Secukupnya Minyak untuk menumis"
- "Secukupnya Air"
- " Bumbu Halus"
- "10 siung Bawang Putih"
- "7 siung Bawang Merah"
- "5 buah Cabai Rawit Merah jumlahnya sesuai selera"
- "5 buah Cabai Merah Besar jumlahnya sesuai selera"
- "1 ruas besar Kunyit"
- "1 ruas Jahe"
- "10 butir Kemiri"
- "1/2 sdt Merica"
- "1 ruas kecil Lengkuas iris tipis"
- "10 lembar Daun Jeruk"
recipeinstructions:
- "Haluskan semua bahan Bumbu Halus."
- "Tumis Bumbu Halus, Daun Salam dan Sereh hingga harum dan layu."
- "Masukkan Ayam, aduk hingga rata. Kemudian masukan Air secukupnya, aduk kembali."
- "Tambahkan Kecap Manis, Garam, Gula dan Penyedap."
- "Kemudian masak hingga ayam matang."
- "Setelah ayam matang. Angkat dan Sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 141 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica-Rica](https://img-global.cpcdn.com/recipes/907770010c66f8a4/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang harus kita lestarikan karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara

Kedekatan rumah tangga bisa ditemukan dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica-Rica untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang kadang mencari makanan kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda praktekkan salah satunya ayam rica-rica yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica:

1. Siapkan 1 kg Ayam
1. Diperlukan 4 lembar Daun Salam
1. Jangan lupa 2 batang Sereh
1. Harus ada 3 sdm Kecap Manis
1. Harap siapkan Secukupnya Garam
1. Harus ada Secukupnya Gula
1. Diperlukan Secukupnya Penyedap (optional)
1. Tambah Secukupnya Minyak untuk menumis
1. Tambah Secukupnya Air
1. Harus ada  Bumbu Halus:
1. Tambah 10 siung Bawang Putih
1. Tambah 7 siung Bawang Merah
1. Siapkan 5 buah Cabai Rawit Merah (jumlahnya sesuai selera)
1. Dibutuhkan 5 buah Cabai Merah Besar (jumlahnya sesuai selera)
1. Tambah 1 ruas besar Kunyit
1. Harus ada 1 ruas Jahe
1. Diperlukan 10 butir Kemiri
1. Dibutuhkan 1/2 sdt Merica
1. Dibutuhkan 1 ruas kecil Lengkuas, iris tipis
1. Dibutuhkan 10 lembar Daun Jeruk




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-Rica:

1. Haluskan semua bahan Bumbu Halus.
1. Tumis Bumbu Halus, Daun Salam dan Sereh hingga harum dan layu.
1. Masukkan Ayam, aduk hingga rata. Kemudian masukan Air secukupnya, aduk kembali.
1. Tambahkan Kecap Manis, Garam, Gula dan Penyedap.
1. Kemudian masak hingga ayam matang.
1. Setelah ayam matang. Angkat dan Sajikan.




Demikianlah cara membuat ayam rica-rica yang mudah dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan cepat, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
