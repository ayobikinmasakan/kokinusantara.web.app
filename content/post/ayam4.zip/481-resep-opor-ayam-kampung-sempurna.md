---
description: "Resep : Opor Ayam Kampung Sempurna"
title: "Resep : Opor Ayam Kampung Sempurna"
slug: 481-resep-opor-ayam-kampung-sempurna
date: 2020-12-09T01:22:47.975Z
image: https://img-global.cpcdn.com/recipes/08dfee854b6fa44d/751x532cq70/opor-ayam-kampung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/08dfee854b6fa44d/751x532cq70/opor-ayam-kampung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/08dfee854b6fa44d/751x532cq70/opor-ayam-kampung-foto-resep-utama.jpg
author: Addie Garner
ratingvalue: 4.6
reviewcount: 5014
recipeingredient:
- "1 ekor ayam kampung potong 8"
- "2 buah kentang potong2"
- "5 butir telur ayam kampung rebus"
- "2 batang sereh geperek"
- "1 ruas langkuas geprek"
- "4 lembar daun jeruk buang tulang daunnya"
- "3 lembar daun salam"
- "100 ml santan cair instan"
- "1 liter air"
- "Secukupnya minyak goreng untuk menumis"
- "2 sdm kaldu bubuk"
- "1/2 sdt lada"
- "1/2 sdt garam"
- " Bumbu halus "
- "6 siung bawang merah"
- "4 siung bawang putih"
- "3 buah cabe merah keriting"
- "1 ruas jahe"
- "1 ruas kunyit"
- "5 buah kemiri sangrai"
recipeinstructions:
- "Cuci ayam dengan diberi air jeruk nipis dan garam. Remas2 sebentar, kemudian cuci bersih ayam"
- "Panaskan air hingga mendidih, rebus ayam sebentar saja untuk menghilangkan kotorannya. Kemudian buang air permukaan rebusan pertama. Rebus kembali, hingga ayam mengeluarkan kaldunya. Diamkan sebentar"
- "Siapkan wajan, panaskan minyak sayur, tumis bumbu halus dengan sereh, langkuas, daun salam dan daun jeruk hingga harum. Aduk rata, hingga bumbu matang merata."
- "Kemudian, tuang bumbu yang sudah ditumis ke panci rebusan ayam. Biarkan hingga mendidih kembali sambil diaduk sesekali. Setelah itu masukkan kentang. Aduk kembali."
- "Masukkan santan, kaldu bubuk, garam dan lada, aduk terus hingga mendidih. Setelah itu masukkan telur. Aduk kembali perlahan agar telur tidak hancur. Lalu, koreksi rasa."
- "Matikan api, pindahkan opor ke wadah dan sajikan bersama lontong saat hangat."
categories:
- Recipe
tags:
- opor
- ayam
- kampung

katakunci: opor ayam kampung 
nutrition: 184 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Dessert

---


![Opor Ayam Kampung](https://img-global.cpcdn.com/recipes/08dfee854b6fa44d/751x532cq70/opor-ayam-kampung-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang manis,pedas dan renyah. Ciri makanan Nusantara opor ayam kampung yang penuh dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Opor Ayam Kampung untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang dapat anda contoh salah satunya opor ayam kampung yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep opor ayam kampung tanpa harus bersusah payah.
Berikut ini resep Opor Ayam Kampung yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 20 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Opor Ayam Kampung:

1. Harap siapkan 1 ekor ayam kampung, potong 8
1. Diperlukan 2 buah kentang, potong2
1. Siapkan 5 butir telur ayam kampung, rebus
1. Diperlukan 2 batang sereh, geperek
1. Diperlukan 1 ruas langkuas, geprek
1. Siapkan 4 lembar daun jeruk, buang tulang daunnya
1. Harap siapkan 3 lembar daun salam
1. Siapkan 100 ml santan cair instan
1. Diperlukan 1 liter air
1. Harus ada Secukupnya minyak goreng untuk menumis
1. Tambah 2 sdm kaldu bubuk
1. Diperlukan 1/2 sdt lada
1. Tambah 1/2 sdt garam
1. Tambah  Bumbu halus :
1. Dibutuhkan 6 siung bawang merah
1. Diperlukan 4 siung bawang putih
1. Jangan lupa 3 buah cabe merah keriting
1. Harap siapkan 1 ruas jahe
1. Tambah 1 ruas kunyit
1. Siapkan 5 buah kemiri sangrai




<!--inarticleads2-->

##### Langkah membuat  Opor Ayam Kampung:

1. Cuci ayam dengan diberi air jeruk nipis dan garam. Remas2 sebentar, kemudian cuci bersih ayam
1. Panaskan air hingga mendidih, rebus ayam sebentar saja untuk menghilangkan kotorannya. Kemudian buang air permukaan rebusan pertama. Rebus kembali, hingga ayam mengeluarkan kaldunya. Diamkan sebentar
1. Siapkan wajan, panaskan minyak sayur, tumis bumbu halus dengan sereh, langkuas, daun salam dan daun jeruk hingga harum. Aduk rata, hingga bumbu matang merata.
1. Kemudian, tuang bumbu yang sudah ditumis ke panci rebusan ayam. Biarkan hingga mendidih kembali sambil diaduk sesekali. Setelah itu masukkan kentang. Aduk kembali.
1. Masukkan santan, kaldu bubuk, garam dan lada, aduk terus hingga mendidih. Setelah itu masukkan telur. Aduk kembali perlahan agar telur tidak hancur. Lalu, koreksi rasa.
1. Matikan api, pindahkan opor ke wadah dan sajikan bersama lontong saat hangat.




Demikianlah cara membuat opor ayam kampung yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan teruji, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
