---
description: "Resep : Ayam rica kemangi Teruji"
title: "Resep : Ayam rica kemangi Teruji"
slug: 400-resep-ayam-rica-kemangi-teruji
date: 2020-10-09T19:13:56.599Z
image: https://img-global.cpcdn.com/recipes/1a6b69d71b2dd347/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1a6b69d71b2dd347/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1a6b69d71b2dd347/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Harvey Payne
ratingvalue: 4.6
reviewcount: 17855
recipeingredient:
- "5 potong ayam paha atas"
- "3 ikat kemangi"
- "1 btg sereh geprek"
- "1 ruas jari lengkuas geprek"
- "7 lbr daun jeruk"
- "1 btg daun bawang iris"
- "Secukupnya air"
- "Secukupnya garam  kaldu jamur"
- " Bumbu halus "
- "6 siung bamer"
- "2 siung baput"
- "6 buah cabe merah kriting"
- "13 buah cabe rawit merah optional"
- "2 btr kemiri"
- "Secukupnya jahe  kunyit"
- "1 sdm gula merah"
recipeinstructions:
- "Cuci bersih ayam beri perasan jeruk nipis diamkan sesaat"
- "Goreng baput bamer cabe jahe hingga layu lalu blender bumbu halus. Tumis bumbu halus hingga harum masukan sereh, lengkuas &amp; d.jeruk"
- "Masukan ayam sampai berubah warna tuang air secukupnya masak sampai mendidih kuahnya tes rasa beri garam &amp; kaldu jamur. Masak sampai kuah mengental juga empuk ayamnya matang"
- "Setelah ayam matang matikan api kompor masukan daun bawang juga kemangi"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 297 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica kemangi](https://img-global.cpcdn.com/recipes/1a6b69d71b2dd347/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang setidaknya kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica kemangi yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah menampilkan ciri khas yang merupakan keragaman Kita

Kehangatan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi kultur, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda buat salah satunya ayam rica kemangi yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 16 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica kemangi:

1. Siapkan 5 potong ayam (paha atas)
1. Harap siapkan 3 ikat kemangi
1. Dibutuhkan 1 btg sereh (geprek)
1. Dibutuhkan 1 ruas jari lengkuas (geprek)
1. Jangan lupa 7 lbr daun jeruk
1. Jangan lupa 1 btg daun bawang (iris)
1. Jangan lupa Secukupnya air
1. Tambah Secukupnya garam &amp; kaldu jamur
1. Harus ada  Bumbu halus :
1. Jangan lupa 6 siung bamer
1. Harus ada 2 siung baput
1. Harap siapkan 6 buah cabe merah kriting
1. Diperlukan 13 buah cabe rawit merah (optional)
1. Dibutuhkan 2 btr kemiri
1. Diperlukan Secukupnya jahe &amp; kunyit
1. Dibutuhkan 1 sdm gula merah


Perlu kamu ketahui bahwa di luar negeri mungkin daun basil sangat terkenal untuk campuran makanan. Akan tetapi, di Indonesia juga memiliki daun kemangi merupakan. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica kemangi:

1. Cuci bersih ayam beri perasan jeruk nipis diamkan sesaat
1. Goreng baput bamer cabe jahe hingga layu lalu blender bumbu halus. Tumis bumbu halus hingga harum masukan sereh, lengkuas &amp; d.jeruk
1. Masukan ayam sampai berubah warna tuang air secukupnya masak sampai mendidih kuahnya tes rasa beri garam &amp; kaldu jamur. Masak sampai kuah mengental juga empuk ayamnya matang
1. Setelah ayam matang matikan api kompor masukan daun bawang juga kemangi


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Ayam rica-rica kemangi dapat disajikan selagi hangat sesuai selera. Cara Membuat Ayam Rica Rica Kemangi. Resep Masakan Ayam Rica-Rica yang Spesial dan Sedap - Nikmatnya ayam rica-rica tentu sudah tidak bisa diragukan lagi. Bumbunya yang kaya berpadu dengan ayam yang empuk akan sangat. 

Demikianlah cara membuat ayam rica kemangi yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
