---
description: "Resep : 95. Ayam Rica-Rica Kemangi terupdate"
title: "Resep : 95. Ayam Rica-Rica Kemangi terupdate"
slug: 311-resep-95-ayam-rica-rica-kemangi-terupdate
date: 2020-11-17T13:40:57.095Z
image: https://img-global.cpcdn.com/recipes/d701e73905430287/751x532cq70/95-ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d701e73905430287/751x532cq70/95-ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d701e73905430287/751x532cq70/95-ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Frances Morris
ratingvalue: 4.8
reviewcount: 32207
recipeingredient:
- " Ayam potong baluri kunyit bubuk air jeruk nispis  garam"
- " Bumbu Halus"
- "1 ons cabe kriting"
- "1/2 ons cabe rawit me 7 biji aja gk berani mkn pedas "
- "5 siung bawang merah"
- "5 siung bawang putih"
- "2 cm jahe"
- "Sedikit kunyit"
- "3 butir kemiri"
- "2 cm lengkuas"
- " Bahan Kasar"
- "3 batang serai geprak"
- "1 lembar daun pandan simpul"
- "5 lembar daun salam"
- "5 lembar daun jeruk iris halus"
- "2 ikat kemangi petiki"
- "Secukupnya garam dan penyedap rasa"
- "secukupnya Air matang"
recipeinstructions:
- "Rebus ayam untuk membuang amis. Kemudian marinasi. Lalu goreng ayam setengah matang."
- "Blender semua bahan bumbu halus lalu tmis bumbu halus sampai wangi masukan daun jeruk, daun salam, daun pandan dan serai."
- "Kemudiam masukan ayam yg sudah digoreng setengah matang tadi. Aduk2 sampai bumbu tercampur rata. Tambahkan air secukupnya"
- "Masukan garam dan penyedap secukupnya. Masak sampai ayam empuk kurang lebih stgah jam."
- "Setelah ayam empuk dan kuah mengering masukan daun kemangi dan daun bawang, aduk hingga layu. Ayam rica rica siap dihidangkan dengan nasi panas bersama lalapan."
categories:
- Recipe
tags:
- 95
- ayam
- ricarica

katakunci: 95 ayam ricarica 
nutrition: 195 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Lunch

---


![95. Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/d701e73905430287/751x532cq70/95-ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang patut kita lestarikan karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti 95. ayam rica-rica kemangi yang kami paparkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Kita



Kehangatan keluarga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak 95. Ayam Rica-Rica Kemangi untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari masakan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda contoh salah satunya 95. ayam rica-rica kemangi yang merupakan resep terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep 95. ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep 95. Ayam Rica-Rica Kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 95. Ayam Rica-Rica Kemangi:

1. Jangan lupa  Ayam potong (baluri kunyit bubuk, air jeruk nispis &amp; garam)
1. Dibutuhkan  Bumbu Halus
1. Diperlukan 1 ons cabe kriting
1. Diperlukan 1/2 ons cabe rawit (me: 7 biji aja.. gk berani mkn pedas 🤭)
1. Siapkan 5 siung bawang merah
1. Harus ada 5 siung bawang putih
1. Harap siapkan 2 cm jahe
1. Dibutuhkan Sedikit kunyit
1. Jangan lupa 3 butir kemiri
1. Siapkan 2 cm lengkuas
1. Dibutuhkan  Bahan Kasar
1. Harus ada 3 batang serai geprak
1. Diperlukan 1 lembar daun pandan simpul
1. Dibutuhkan 5 lembar daun salam
1. Diperlukan 5 lembar daun jeruk iris halus
1. Tambah 2 ikat kemangi, petiki
1. Dibutuhkan Secukupnya garam dan penyedap rasa
1. Dibutuhkan secukupnya Air matang




<!--inarticleads2-->

##### Bagaimana membuat  95. Ayam Rica-Rica Kemangi:

1. Rebus ayam untuk membuang amis. Kemudian marinasi. Lalu goreng ayam setengah matang.
1. Blender semua bahan bumbu halus lalu tmis bumbu halus sampai wangi masukan daun jeruk, daun salam, daun pandan dan serai.
1. Kemudiam masukan ayam yg sudah digoreng setengah matang tadi. Aduk2 sampai bumbu tercampur rata. Tambahkan air secukupnya
1. Masukan garam dan penyedap secukupnya. Masak sampai ayam empuk kurang lebih stgah jam.
1. Setelah ayam empuk dan kuah mengering masukan daun kemangi dan daun bawang, aduk hingga layu. Ayam rica rica siap dihidangkan dengan nasi panas bersama lalapan.




Demikianlah cara membuat 95. ayam rica-rica kemangi yang sederhana dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan terbukti, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
