---
description: "Cara singkat membuat Ayam rica rica simpel Terbukti"
title: "Cara singkat membuat Ayam rica rica simpel Terbukti"
slug: 368-cara-singkat-membuat-ayam-rica-rica-simpel-terbukti
date: 2020-09-24T02:37:35.159Z
image: https://img-global.cpcdn.com/recipes/df0ba687259b0685/751x532cq70/ayam-rica-rica-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/df0ba687259b0685/751x532cq70/ayam-rica-rica-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/df0ba687259b0685/751x532cq70/ayam-rica-rica-simpel-foto-resep-utama.jpg
author: Bettie Vaughn
ratingvalue: 4.6
reviewcount: 46532
recipeingredient:
- "1/2 ekor ayam"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "1/2 bawang bombai"
- "1/2 tomat"
- "9 buah cabe rawit merah tergantung selera"
- "2 lembar daun jeruk"
- "1 sachet royco disesuaikan"
- " Garam disesuaikan"
- " Marinasi ayam"
- "1/2 sdt royco"
- "1/2 sdt kunyit bubuk"
- "1/2 sdt ketumbar bubuk"
- " Garam"
recipeinstructions:
- "Cuci bersih ayam, lalu marinasi ayam dengan bumbu marinasi"
- "Setelah di marinasi 15 menit goreng ayam sampai kecoklatan"
- "Siapkan bumbu untuk rica rica, uleg kasar bawang merah, bawang putih dan cabai"
- "Setelah di uleg kasar, tumis bawang bombai sampai harum lalu masukkan bumbu, daun jeruk, dan tomat tumis hingga matang"
- "Setelah bumbu matang masukkan sedikit air, lalu tambahkan penyedap, garam, gula, cicipi rasanya jika sudah pas masukkan ayam yang sudah di goreng sebelumnya, masak hingga air kering,"
- "Ayam rica rica siap di sajikan bunda🥰🥰"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 178 calories
recipecuisine: American
preptime: "PT15M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica rica simpel](https://img-global.cpcdn.com/recipes/df0ba687259b0685/751x532cq70/ayam-rica-rica-simpel-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang patut kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica rica simpel yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa keistimewahan yang merupakan keragaman Indonesia

Kedekatan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Ayam rica rica simpel untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan makanan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis masakan yang dapat anda buat salah satunya ayam rica rica simpel yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica rica simpel tanpa harus bersusah payah.
Seperti resep Ayam rica rica simpel yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 14 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica simpel:

1. Dibutuhkan 1/2 ekor ayam
1. Jangan lupa 5 siung bawang merah
1. Harap siapkan 3 siung bawang putih
1. Harap siapkan 1/2 bawang bombai
1. Siapkan 1/2 tomat
1. Siapkan 9 buah cabe rawit merah (tergantung selera)
1. Harap siapkan 2 lembar daun jeruk
1. Tambah 1 sachet royco (disesuaikan)
1. Tambah  Garam (disesuaikan)
1. Harus ada  Marinasi ayam
1. Harap siapkan 1/2 sdt royco
1. Dibutuhkan 1/2 sdt kunyit bubuk
1. Jangan lupa 1/2 sdt ketumbar bubuk
1. Dibutuhkan  Garam




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica simpel:

1. Cuci bersih ayam, lalu marinasi ayam dengan bumbu marinasi
1. Setelah di marinasi 15 menit goreng ayam sampai kecoklatan
1. Siapkan bumbu untuk rica rica, uleg kasar bawang merah, bawang putih dan cabai
1. Setelah di uleg kasar, tumis bawang bombai sampai harum lalu masukkan bumbu, daun jeruk, dan tomat tumis hingga matang
1. Setelah bumbu matang masukkan sedikit air, lalu tambahkan penyedap, garam, gula, cicipi rasanya jika sudah pas masukkan ayam yang sudah di goreng sebelumnya, masak hingga air kering,
1. Ayam rica rica siap di sajikan bunda🥰🥰




Demikianlah cara membuat ayam rica rica simpel yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan teruji, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
