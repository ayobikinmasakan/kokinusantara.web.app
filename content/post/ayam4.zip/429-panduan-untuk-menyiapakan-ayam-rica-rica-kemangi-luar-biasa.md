---
description: "Panduan untuk menyiapakan Ayam rica-rica kemangi Luar biasa"
title: "Panduan untuk menyiapakan Ayam rica-rica kemangi Luar biasa"
slug: 429-panduan-untuk-menyiapakan-ayam-rica-rica-kemangi-luar-biasa
date: 2020-10-05T08:22:22.631Z
image: https://img-global.cpcdn.com/recipes/1d4c564ddde0f1cf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1d4c564ddde0f1cf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1d4c564ddde0f1cf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Sylvia Henderson
ratingvalue: 4.8
reviewcount: 44043
recipeingredient:
- "1/2 ekor ayam"
- "2 batang kemangi"
- "8 bawang merah"
- "4 bawang putih"
- "5 cabai keriting"
- "30 cabai rawit jablay"
- "1 buah tomat"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 batang serai"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 ruas lengkuas"
- "2 kemiri"
- "secukupnya Garam"
- "secukupnya Gula pasir"
- "secukupnya Penyedap rasa"
- "200 ml air"
recipeinstructions:
- "Cuci ayam hingga bersih lalu taburi penyedap rasa sedikit, marinasi 5 menit lalu goreng setengah matang"
- "Haluskan semua bahan, sisakan 15 cabai rawit jablay untuk taburan, geprek sereh, lengkuas"
- "Tumis bumbu halus lalu tambahkan garam, gula dan penyedap rasa"
- "Masukkan ayam aduk hingga rata, jika sudah agak menyerap masukkan kemangi dan cabai rawit, tambahkan sedikit air, biar kan hingga menyerap, koreksi rasa"
- "Ayam rica kemangi siap di hidangkan untuk lauk makan siang atau malam"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 236 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/1d4c564ddde0f1cf/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang dapat kita lestarikan karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa ciri khas yang merupakan keragaman Kita

Kedekatan rumah tangga dapat diperoleh dengan cara simple. Salah satunya adalah memasak Ayam rica-rica kemangi untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang dapat anda coba salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Diperlukan 1/2 ekor ayam
1. Diperlukan 2 batang kemangi
1. Siapkan 8 bawang merah
1. Siapkan 4 bawang putih
1. Harap siapkan 5 cabai keriting
1. Jangan lupa 30 cabai rawit jablay
1. Tambah 1 buah tomat
1. Tambah 1 ruas jahe
1. Harus ada 1 ruas kunyit
1. Siapkan 1 batang serai
1. Harap siapkan 2 lembar daun salam
1. Tambah 2 lembar daun jeruk
1. Siapkan 1 ruas lengkuas
1. Siapkan 2 kemiri
1. Dibutuhkan secukupnya Garam
1. Tambah secukupnya Gula pasir
1. Harap siapkan secukupnya Penyedap rasa
1. Tambah 200 ml air




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica kemangi:

1. Cuci ayam hingga bersih lalu taburi penyedap rasa sedikit, marinasi 5 menit lalu goreng setengah matang
1. Haluskan semua bahan, sisakan 15 cabai rawit jablay untuk taburan, geprek sereh, lengkuas
1. Tumis bumbu halus lalu tambahkan garam, gula dan penyedap rasa
1. Masukkan ayam aduk hingga rata, jika sudah agak menyerap masukkan kemangi dan cabai rawit, tambahkan sedikit air, biar kan hingga menyerap, koreksi rasa
1. Ayam rica kemangi siap di hidangkan untuk lauk makan siang atau malam




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan cepat, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
