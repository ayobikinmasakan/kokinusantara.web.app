---
description: "Resep : Ayam rica rica kemangi Teruji"
title: "Resep : Ayam rica rica kemangi Teruji"
slug: 325-resep-ayam-rica-rica-kemangi-teruji
date: 2020-10-10T12:58:59.147Z
image: https://img-global.cpcdn.com/recipes/487b5054e66b7d5f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/487b5054e66b7d5f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/487b5054e66b7d5f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Harry Pratt
ratingvalue: 5
reviewcount: 32488
recipeingredient:
- "5 potong ayam"
- "1 ikat kemangi"
- "4 daun jeruk"
- "1 sereh"
- "2 ruas lengkuas"
- "1 tomat"
- "1 masako"
- "1 jeruk nipis"
- " Bahan halus"
- "5 bawang merah"
- "3 bawang putih"
- "20 cabe rawit"
- "6 cabe merah"
- "2 ruas kunyit"
- "1 ruas jahe"
- "3 kemiri"
recipeinstructions:
- "5 potong ayam, dipotong jadi 3 bagian lagi, cuci bersih lalu beri perasan jeruk nipis, sisihkan"
- "Siapkan bumbu halus dan blender. Tomat di potong², kemangi ambil daunnya saja"
- "Panaskan minyak, tumis bumbu halus hingga harum, masukkan tomat, daun jeruk, sereh geprek dan lengkuas geprek, tumis sampai bumbu berwarna pekat."
- "Masukkan ayam, aduk sampai benar² rata. Tambahkan air sedikit, aduk sampai tercampur rata, tutup masakan dan diamkan sejenak sampai ayam empuk."
- "Masukkan kemangi dan masako, aduk sebentar. Masakan sudah siap dinikmati bersama nasi hangat 😉"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 194 calories
recipecuisine: American
preptime: "PT35M"
cooktime: "PT46M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/487b5054e66b7d5f/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan enak. Ciri khas makanan Nusantara ayam rica rica kemangi yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.




Keharmonisan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Ayam rica rica kemangi untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang bisa anda coba salah satunya ayam rica rica kemangi yang merupakan resep favorite yang simpel dengan kreasi sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 16 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Tambah 5 potong ayam
1. Harap siapkan 1 ikat kemangi
1. Harus ada 4 daun jeruk
1. Siapkan 1 sereh
1. Jangan lupa 2 ruas lengkuas
1. Harus ada 1 tomat
1. Siapkan 1 masako
1. Dibutuhkan 1 jeruk nipis
1. Diperlukan  Bahan halus
1. Siapkan 5 bawang merah
1. Siapkan 3 bawang putih
1. Diperlukan 20 cabe rawit
1. Harus ada 6 cabe merah
1. Siapkan 2 ruas kunyit
1. Diperlukan 1 ruas jahe
1. Jangan lupa 3 kemiri




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica kemangi:

1. 5 potong ayam, dipotong jadi 3 bagian lagi, cuci bersih lalu beri perasan jeruk nipis, sisihkan
1. Siapkan bumbu halus dan blender. Tomat di potong², kemangi ambil daunnya saja
1. Panaskan minyak, tumis bumbu halus hingga harum, masukkan tomat, daun jeruk, sereh geprek dan lengkuas geprek, tumis sampai bumbu berwarna pekat.
1. Masukkan ayam, aduk sampai benar² rata. Tambahkan air sedikit, aduk sampai tercampur rata, tutup masakan dan diamkan sejenak sampai ayam empuk.
1. Masukkan kemangi dan masako, aduk sebentar. Masakan sudah siap dinikmati bersama nasi hangat 😉




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan cepat, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
