---
description: "Cara untuk membuat Ayam Rica-rica Pedas minggu ini"
title: "Cara untuk membuat Ayam Rica-rica Pedas minggu ini"
slug: 431-cara-untuk-membuat-ayam-rica-rica-pedas-minggu-ini
date: 2020-12-11T03:01:29.766Z
image: https://img-global.cpcdn.com/recipes/b8444443b7f03759/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b8444443b7f03759/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b8444443b7f03759/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
author: Jeremiah Warner
ratingvalue: 4.2
reviewcount: 35468
recipeingredient:
- "2 siung Bawang putih cincang"
- "10 butir cabe rawit merah sesukanya tergantung mau level berapa tingkat kepedasannya"
- "1/2 siung bawang bombay cincang"
- "5 potongan ayam paha dan dada beli di Superindo saya potongpotong jadi agak kecil"
- "1 buah tomat potong kecilkecil"
- " Saus tomat saus sambal dan saus tiram campurkan takaran sesuai selera saja ya soalnya saya lupa"
- "1/2 sdm kecap asin"
- "1/2 sdm gula pasir"
- "1 sdt mericalada bubuk"
- "1 sdm kecap manis"
- "1 gelas air"
- "secukupnya Garam"
recipeinstructions:
- "Sebelumnya ayam yang sudah dipotong-potong di marinate dengan bumbu-bumbu: kecap dan lada secukupnya (disesuaikan dengan jumlah ayamnya). Diamkan di dalam kulkas selama beberapa menit (3o-60 menit). Setelah bumbu meresap, goreng ayam sampai matang."
- "Panaskan minyak dalam wajan. Tumis bawang putih dan bawang bombay sampai harum. Usahakan bawang putih jangan sampai gosong yaa.."
- "Masukkan cabe rawit. Masak hingga harum. Masukkan potongan tomat."
- "Masukkan campuran saus tomat, saus sambal dan saus tiram. Masak hingga tercampur rata. Masukkan kecap asin, gula pasir, merica dan kecap manis. Lalu tambahkan air. Masak sebentar. Tambahkan sedikit garam."
- "Masukkan ayamnya yang sudah di goreng sebelumnya. Campurkan hingga tercampur rata pada seluruh ayamnya. Tambahkan daun bawang agar lebih sedap. Hidangkan."
categories:
- Recipe
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 101 calories
recipecuisine: American
preptime: "PT21M"
cooktime: "PT38M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica-rica Pedas](https://img-global.cpcdn.com/recipes/b8444443b7f03759/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan gurih. Karasteristik masakan Indonesia ayam rica-rica pedas yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga bisa diperoleh dengan cara mudah. Salah satunya adalah memasak Ayam Rica-rica Pedas untuk orang di rumah. Momen makan bersama keluarga sudah menjadi budaya, Banyak yang biasanya mencari kuliner kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang dapat anda coba salah satunya ayam rica-rica pedas yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam rica-rica pedas tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Pedas yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Pedas:

1. Dibutuhkan 2 siung Bawang putih, cincang
1. Tambah 10 butir cabe rawit merah (sesukanya, tergantung mau level berapa tingkat kepedasannya)
1. Harus ada 1/2 siung bawang bombay, cincang
1. Diperlukan 5 potongan ayam paha dan dada beli di Superindo (saya potong-potong jadi agak kecil)
1. Jangan lupa 1 buah tomat, potong kecil-kecil
1. Siapkan  Saus tomat, saus sambal dan saus tiram, campurkan (takaran sesuai selera saja ya, soalnya saya lupa)
1. Harus ada 1/2 sdm kecap asin
1. Dibutuhkan 1/2 sdm gula pasir
1. Dibutuhkan 1 sdt merica/lada bubuk
1. Harus ada 1 sdm kecap manis
1. Harus ada 1 gelas air
1. Tambah secukupnya Garam




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Pedas:

1. Sebelumnya ayam yang sudah dipotong-potong di marinate dengan bumbu-bumbu: kecap dan lada secukupnya (disesuaikan dengan jumlah ayamnya). Diamkan di dalam kulkas selama beberapa menit (3o-60 menit). Setelah bumbu meresap, goreng ayam sampai matang.
1. Panaskan minyak dalam wajan. Tumis bawang putih dan bawang bombay sampai harum. Usahakan bawang putih jangan sampai gosong yaa..
1. Masukkan cabe rawit. Masak hingga harum. Masukkan potongan tomat.
1. Masukkan campuran saus tomat, saus sambal dan saus tiram. Masak hingga tercampur rata. Masukkan kecap asin, gula pasir, merica dan kecap manis. Lalu tambahkan air. Masak sebentar. Tambahkan sedikit garam.
1. Masukkan ayamnya yang sudah di goreng sebelumnya. Campurkan hingga tercampur rata pada seluruh ayamnya. Tambahkan daun bawang agar lebih sedap. Hidangkan.




Demikianlah cara membuat ayam rica-rica pedas yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menemukan di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
