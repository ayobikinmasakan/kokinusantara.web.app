---
description: "Langkah untuk membuat Ayam Rica Kemangi Sempurna"
title: "Langkah untuk membuat Ayam Rica Kemangi Sempurna"
slug: 330-langkah-untuk-membuat-ayam-rica-kemangi-sempurna
date: 2021-02-04T18:20:12.919Z
image: https://img-global.cpcdn.com/recipes/32946253ab16d3f7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/32946253ab16d3f7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/32946253ab16d3f7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Sam Hall
ratingvalue: 4.6
reviewcount: 44843
recipeingredient:
- "1 ekor ayam kampung potong 14"
- "2 buah jeruk nipis"
- " Bumbu halus"
- "12 buah cabe merah keriting"
- "4 butir kemiri"
- "10 siung bawang merah"
- "4 siung bawang putih"
- "1 ruas kunyit"
- " Bahan pelengkap"
- "800 ml air"
- "4 lembar daun jeruk iris"
- "1/2 lembar daun kunyit iris"
- "2 tangkai sereh iris"
- "2 lembar daun bawang iris"
- "1 buah tomat potong"
- "2 ruas lengkuas geprek"
- "1 ruas jahe geprek"
- "2 sdt garam"
- "6 buah cabe rawit setan"
- "4 ikat kemangi"
recipeinstructions:
- "Cuci bersih ayam lalu lumuri air perasan jeruk nipis pakai 1 buah, sisanya sisihkan dulu. Biarkan 30 menit, sambil siapkan bahan lainnya. Blender bumbu halus lalu tumis dengan sedikit minyak, masukkan daun jeruk, daun kunyit, jahe, lengkuas, sereh. Masak sampai bumbu halus berubah warna dan harum."
- "Masukkan ayam, aduk rata. Kemudian tuang air, aduk rata. Tutup wajannya dan masak sampai ayam empuk kurleb 50 menit."
- "Setelah ayam empuk, masukkan kemangi lalu aduk rata. Masukkan tomat, daun bawang, cabe rawit setan dan tambahkan garam. Koreksi rasa. Beri perasan jeruk nipis 1/2 buah atau bisa disesuaikan. Setelah rasanya pas, matikan kompor dan sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 262 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/32946253ab16d3f7/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan empuk. Ciri khas masakan Nusantara ayam rica kemangi yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Kemangi untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Banyak yang kadang mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang bisa anda praktekkan salah satunya ayam rica kemangi yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 20 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Siapkan 1 ekor ayam kampung, potong 14
1. Harap siapkan 2 buah jeruk nipis
1. Jangan lupa  Bumbu halus:
1. Jangan lupa 12 buah cabe merah keriting
1. Harus ada 4 butir kemiri
1. Harap siapkan 10 siung bawang merah
1. Diperlukan 4 siung bawang putih
1. Harap siapkan 1 ruas kunyit
1. Jangan lupa  Bahan pelengkap:
1. Harus ada 800 ml air
1. Siapkan 4 lembar daun jeruk, iris
1. Diperlukan 1/2 lembar daun kunyit, iris
1. Diperlukan 2 tangkai sereh, iris
1. Siapkan 2 lembar daun bawang, iris
1. Diperlukan 1 buah tomat, potong
1. Dibutuhkan 2 ruas lengkuas, geprek
1. Harus ada 1 ruas jahe, geprek
1. Harap siapkan 2 sdt garam
1. Jangan lupa 6 buah cabe rawit setan
1. Diperlukan 4 ikat kemangi




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Kemangi:

1. Cuci bersih ayam lalu lumuri air perasan jeruk nipis pakai 1 buah, sisanya sisihkan dulu. Biarkan 30 menit, sambil siapkan bahan lainnya. Blender bumbu halus lalu tumis dengan sedikit minyak, masukkan daun jeruk, daun kunyit, jahe, lengkuas, sereh. Masak sampai bumbu halus berubah warna dan harum.
1. Masukkan ayam, aduk rata. Kemudian tuang air, aduk rata. Tutup wajannya dan masak sampai ayam empuk kurleb 50 menit.
1. Setelah ayam empuk, masukkan kemangi lalu aduk rata. Masukkan tomat, daun bawang, cabe rawit setan dan tambahkan garam. Koreksi rasa. Beri perasan jeruk nipis 1/2 buah atau bisa disesuaikan. Setelah rasanya pas, matikan kompor dan sajikan.




Demikianlah cara membuat ayam rica kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan cepat, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
