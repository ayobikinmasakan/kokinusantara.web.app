---
description: "Step-by-Step menyiapakan Ayam Rica Kemangi Cepat"
title: "Step-by-Step menyiapakan Ayam Rica Kemangi Cepat"
slug: 384-step-by-step-menyiapakan-ayam-rica-kemangi-cepat
date: 2021-01-11T18:31:26.303Z
image: https://img-global.cpcdn.com/recipes/e1712c41e44b44ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e1712c41e44b44ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e1712c41e44b44ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Edith Crawford
ratingvalue: 4.7
reviewcount: 27245
recipeingredient:
- "1/2 ekor ayam"
- " Bumbu halus"
- "3 cabe merah besar"
- "15 cabe rawit"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "2 butir kemiri"
- "1/2 ruas jari jahe"
- "1/4 ruas jari kunyit"
- " Bumbu Pelengkap"
- "2 batang sereh memarkan"
- "1 ruas jari lengkuas memarkan"
- "1/4 keping gula merah"
- "secukupnya Garam gula pasir penyedap rasa"
- "secukupnya Air"
- "1/2 ikat kemangi"
recipeinstructions:
- "Bersihkan ayam. Sisihkan"
- "Uleg bumbu halus. Lalu tumis hingga harum. Masukkan bumbu pelengkap kecuali kemangi. Lalu masukkan ayam. Aduk aduk hingga bumbu rata. Masukkan air sedikit."
- "Tutup ayam hingga air menyusut. Test rasa. Kalo sudah pas masukkan kemangi. Aduk aduk kembali. &amp; ayam Rica kemangi siap disantap. Rasanya muantaap ciiin.. 😁😁😁"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 253 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/e1712c41e44b44ec/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang patut kita jaga karena setiap tempat memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica kemangi yang kami contohkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa ciri khas yang merupakan keragaman Indonesia

Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak jenis masakan yang dapat anda buat salah satunya ayam rica kemangi yang merupakan resep favorite yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi:

1. Diperlukan 1/2 ekor ayam
1. Harap siapkan  Bumbu halus
1. Harus ada 3 cabe merah besar
1. Jangan lupa 15 cabe rawit
1. Siapkan 5 siung bawang merah
1. Harus ada 3 siung bawang putih
1. Harap siapkan 2 butir kemiri
1. Tambah 1/2 ruas jari jahe
1. Harus ada 1/4 ruas jari kunyit
1. Harap siapkan  Bumbu Pelengkap
1. Siapkan 2 batang sereh memarkan
1. Tambah 1 ruas jari lengkuas memarkan
1. Siapkan 1/4 keping gula merah
1. Diperlukan secukupnya Garam, gula pasir, penyedap rasa
1. Jangan lupa secukupnya Air
1. Jangan lupa 1/2 ikat kemangi




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Kemangi:

1. Bersihkan ayam. Sisihkan
1. Uleg bumbu halus. Lalu tumis hingga harum. Masukkan bumbu pelengkap kecuali kemangi. Lalu masukkan ayam. Aduk aduk hingga bumbu rata. Masukkan air sedikit.
1. Tutup ayam hingga air menyusut. Test rasa. Kalo sudah pas masukkan kemangi. Aduk aduk kembali. &amp; ayam Rica kemangi siap disantap. Rasanya muantaap ciiin.. 😁😁😁




Demikianlah cara membuat ayam rica kemangi yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
