---
description: "Bagaimana membuat Ayam Rica Kemangi Homemade"
title: "Bagaimana membuat Ayam Rica Kemangi Homemade"
slug: 405-bagaimana-membuat-ayam-rica-kemangi-homemade
date: 2020-12-21T04:56:55.194Z
image: https://img-global.cpcdn.com/recipes/7de92ab039fcae18/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7de92ab039fcae18/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7de92ab039fcae18/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Matthew Gregory
ratingvalue: 4.1
reviewcount: 10008
recipeingredient:
- "1 ekor Ayam potong 10 bagian"
- "2 genggam Daun Kemangi"
- " Bumbu dihaluskan "
- "8 siung Bawang merah"
- "3 siung Bawang putih"
- "14 buah Cabe merah keriting"
- "3 butir Kemiri sangrai"
- " Bumbu Ungkep "
- "2 batang Sereh geprek"
- "2 ruas jari Jahe ulek kasar"
- "3 ruas jari Kunyit ulek kasar"
- "1 buah Tomat ulek kasar"
- "3 siung Bawang merah"
- "3 siung Bawang putih"
- "3 lembar Daun salam"
- "3 lembar Daun jeruk"
- "Secukupnya Gula garam lada dan penyedap rasa"
- "Segelas Air"
recipeinstructions:
- "Siapkan semua bahan beserta bumbu halus dan bumbu ungkep nya."
- "Tumis bumbu ungkep hingga harum. Masukkan ayam. Aduk hingga bumbu rata di ayamnya. Baru masukkan air. Beri gula, garam, lada dan penyedap rasa. Cicipi rasa. Masak hingga airnya surut dan bumbu meresap."
- "Tumis bumbu yang di haluskan hingga harum. Masukkan ke dalam ayam yang sudah di ungkep beserta daun kemanginya. Masak hingga semua tercampur rata dan mengental bumbunya."
- "Ketika sudah terlihat mengental semua. Matikan apinya dan sajikan hangat 😍"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 196 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/7de92ab039fcae18/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang setidaknya kita lestarikan karena setiap area memiliki ciri khas tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa ciri khas yang merupakan keragaman Kita

Kedekatan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam Rica Kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis makanan yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan cepat menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 4 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Dibutuhkan 1 ekor Ayam potong 10 bagian
1. Harus ada 2 genggam Daun Kemangi
1. Harap siapkan  Bumbu dihaluskan :
1. Harus ada 8 siung Bawang merah
1. Diperlukan 3 siung Bawang putih
1. Harap siapkan 14 buah Cabe merah keriting
1. Harus ada 3 butir Kemiri, sangrai
1. Dibutuhkan  Bumbu Ungkep :
1. Harus ada 2 batang Sereh, geprek
1. Siapkan 2 ruas jari Jahe, ulek kasar
1. Harap siapkan 3 ruas jari Kunyit, ulek kasar
1. Dibutuhkan 1 buah Tomat, ulek kasar
1. Harus ada 3 siung Bawang merah
1. Siapkan 3 siung Bawang putih
1. Tambah 3 lembar Daun salam
1. Tambah 3 lembar Daun jeruk
1. Harap siapkan Secukupnya Gula, garam, lada dan penyedap rasa
1. Harap siapkan Segelas Air




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Kemangi:

1. Siapkan semua bahan beserta bumbu halus dan bumbu ungkep nya.
1. Tumis bumbu ungkep hingga harum. Masukkan ayam. Aduk hingga bumbu rata di ayamnya. Baru masukkan air. Beri gula, garam, lada dan penyedap rasa. Cicipi rasa. Masak hingga airnya surut dan bumbu meresap.
1. Tumis bumbu yang di haluskan hingga harum. Masukkan ke dalam ayam yang sudah di ungkep beserta daun kemanginya. Masak hingga semua tercampur rata dan mengental bumbunya.
1. Ketika sudah terlihat mengental semua. Matikan apinya dan sajikan hangat 😍




Demikianlah cara membuat ayam rica kemangi yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan terbukti, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
