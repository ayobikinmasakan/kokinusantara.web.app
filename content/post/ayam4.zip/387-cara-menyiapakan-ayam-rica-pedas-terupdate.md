---
description: "Cara menyiapakan Ayam Rica Pedas terupdate"
title: "Cara menyiapakan Ayam Rica Pedas terupdate"
slug: 387-cara-menyiapakan-ayam-rica-pedas-terupdate
date: 2021-01-27T23:06:43.791Z
image: https://img-global.cpcdn.com/recipes/9f56c179b30056cb/751x532cq70/ayam-rica-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9f56c179b30056cb/751x532cq70/ayam-rica-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9f56c179b30056cb/751x532cq70/ayam-rica-pedas-foto-resep-utama.jpg
author: Edith Holland
ratingvalue: 4
reviewcount: 19165
recipeingredient:
- "5 potong ayam"
- "secukupnya daun Kemangi"
- "1 batang sereh geprek"
- "3 cm lengkuas geprek"
- "5 lembar daun jeruk"
- "3 lembar daun salam"
- "2 batang daun bawang"
- "1 buah tomat iris kecil"
- " Bumbu halus "
- "10 buah cabe rawit"
- "10 buah cabe keriting"
- "5 buah bawang merah"
- "2 buah bawang putih"
- "4 cm jahe"
- "3 buah kemiri"
- "secukupnya Minyak untuk menumis"
- "1 sdt garam"
- "1 sdm kaldu"
- "1 sdt gula putih"
recipeinstructions:
- "Potong ayam menjadi 2 bagian, lalu rebus sebentar. Angkat lalu tiriskan."
- "Goreng ayam sebentar jgn terlalu garing. Lalu angkat dan tiriskan."
- "Panaskan minyak lalu masukkan bumbu yg sudah di haluskan. Lalu masukkan kembali daun jeruk, salam serem dan lengkoas aduk hingga merata. Tunggu sampai bumbu stgh matang lalu masukkan kemangi. Lalu aduk kembali."
- "Masukkan penyedap rasa dan cicipi. Lalu masukkan ayam yg sudah di goreng tadi. Aduk sebentar. Masukkan kembali daun bawang dan irisan tomat. Aduk merata dan tunggu sebentar."
- "Lalu angkat. Ayam rica pedas siap dihidangkan."
categories:
- Recipe
tags:
- ayam
- rica
- pedas

katakunci: ayam rica pedas 
nutrition: 107 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica Pedas](https://img-global.cpcdn.com/recipes/9f56c179b30056cb/751x532cq70/ayam-rica-pedas-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau gurih. Ciri makanan Indonesia ayam rica pedas yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Keharmonisan keluarga bisa ditemukan dengan cara sederhana. Salah satunya adalah memasak Ayam Rica Pedas untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak jenis makanan yang bisa anda buat salah satunya ayam rica pedas yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam rica pedas tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Pedas yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Pedas:

1. Diperlukan 5 potong ayam
1. Diperlukan secukupnya daun Kemangi
1. Diperlukan 1 batang sereh geprek
1. Dibutuhkan 3 cm lengkuas geprek
1. Jangan lupa 5 lembar daun jeruk
1. Siapkan 3 lembar daun salam
1. Siapkan 2 batang daun bawang
1. Harap siapkan 1 buah tomat iris kecil
1. Harap siapkan  Bumbu halus :
1. Harus ada 10 buah cabe rawit
1. Dibutuhkan 10 buah cabe keriting
1. Harus ada 5 buah bawang merah
1. Harus ada 2 buah bawang putih
1. Diperlukan 4 cm jahe
1. Harus ada 3 buah kemiri
1. Siapkan secukupnya Minyak untuk menumis
1. Jangan lupa 1 sdt garam
1. Tambah 1 sdm kaldu
1. Diperlukan 1 sdt gula putih




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Pedas:

1. Potong ayam menjadi 2 bagian, lalu rebus sebentar. Angkat lalu tiriskan.
1. Goreng ayam sebentar jgn terlalu garing. Lalu angkat dan tiriskan.
1. Panaskan minyak lalu masukkan bumbu yg sudah di haluskan. Lalu masukkan kembali daun jeruk, salam serem dan lengkoas aduk hingga merata. Tunggu sampai bumbu stgh matang lalu masukkan kemangi. Lalu aduk kembali.
1. Masukkan penyedap rasa dan cicipi. Lalu masukkan ayam yg sudah di goreng tadi. Aduk sebentar. Masukkan kembali daun bawang dan irisan tomat. Aduk merata dan tunggu sebentar.
1. Lalu angkat. Ayam rica pedas siap dihidangkan.




Demikianlah cara membuat ayam rica pedas yang sederhana dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
