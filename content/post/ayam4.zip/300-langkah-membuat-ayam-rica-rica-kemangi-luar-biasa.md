---
description: "Langkah membuat Ayam rica rica kemangi Luar biasa"
title: "Langkah membuat Ayam rica rica kemangi Luar biasa"
slug: 300-langkah-membuat-ayam-rica-rica-kemangi-luar-biasa
date: 2021-02-02T06:50:18.468Z
image: https://img-global.cpcdn.com/recipes/e9e4e53b8aff3da7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e9e4e53b8aff3da7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e9e4e53b8aff3da7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Aaron Vargas
ratingvalue: 4.8
reviewcount: 24036
recipeingredient:
- "500 gr daging ayam marinasi dengan 1 ruas kunyit  12 sdt garam  3siung bawang putih uleg halus diamkan 15 menit"
- "1 ikat daun kemangi"
- "3 btg daun bawang diiris"
- "250 ml air"
- " Bumbu halus"
- "7 siung bawang putih"
- "8 siung bawang merah"
- "1 ruas jahe"
- "4 cabe rawit"
- "2 btr kemiri100 gr cabe merah besar"
- " Bumbu cemplung"
- "2 btg serai digeprek"
- "1 ruas lengkuas digeprek"
- "7 lmbr daun jeruk purut"
- "3 lembar daun salam"
- "1 sdt garam"
- "1 sdt kaldu bubuk"
- "2 sdt gula pasir"
recipeinstructions:
- "Haluskan bumbu saya pakai cooper bisa juga diuleg"
- "Goreng ayam yg sudah dimarinasi 1/2 matang saja angkat tiriskan"
- "Panaskan minyak masukkan bumbu halus, bumbu cemplung, tumis hingga bumbu tanak"
- "Masukkan ayam goreng aduk rata"
- "Masukkan air aduk rata lalu tutup masak dengan api kecil hingga kuah agak menyusut"
- "Masukkan garam, kaldu bubuk, gula pasir aduk rata"
- "Masukkan daun bawang aduk rata"
- "Masukkan daun kemangi aduk sebentar lalu matikan kompor"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 168 calories
recipecuisine: American
preptime: "PT10M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/e9e4e53b8aff3da7/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita jaga karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah membawa keistimewahan yang merupakan keragaman Kita



Kehangatan keluarga dapat diperoleh dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica rica kemangi untuk keluarga. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi resep yang dapat anda contoh salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 8 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica kemangi:

1. Diperlukan 500 gr daging ayam marinasi dengan (1 ruas kunyit + 1/2 sdt garam + 3siung bawang putih uleg halus) diamkan 15 menit
1. Jangan lupa 1 ikat daun kemangi
1. Siapkan 3 btg daun bawang diiris
1. Harus ada 250 ml air
1. Harus ada  Bumbu halus
1. Harus ada 7 siung bawang putih
1. Dibutuhkan 8 siung bawang merah
1. Harap siapkan 1 ruas jahe
1. Jangan lupa 4 cabe rawit
1. Tambah 2 btr kemiri100 gr cabe merah besar
1. Dibutuhkan  Bumbu cemplung
1. Harus ada 2 btg serai digeprek
1. Jangan lupa 1 ruas lengkuas digeprek
1. Harus ada 7 lmbr daun jeruk purut
1. Dibutuhkan 3 lembar daun salam
1. Jangan lupa 1 sdt garam
1. Jangan lupa 1 sdt kaldu bubuk
1. Diperlukan 2 sdt gula pasir




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica kemangi:

1. Haluskan bumbu saya pakai cooper bisa juga diuleg
1. Goreng ayam yg sudah dimarinasi 1/2 matang saja angkat tiriskan
1. Panaskan minyak masukkan bumbu halus, bumbu cemplung, tumis hingga bumbu tanak
1. Masukkan ayam goreng aduk rata
1. Masukkan air aduk rata lalu tutup masak dengan api kecil hingga kuah agak menyusut
1. Masukkan garam, kaldu bubuk, gula pasir aduk rata
1. Masukkan daun bawang aduk rata
1. Masukkan daun kemangi aduk sebentar lalu matikan kompor




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
