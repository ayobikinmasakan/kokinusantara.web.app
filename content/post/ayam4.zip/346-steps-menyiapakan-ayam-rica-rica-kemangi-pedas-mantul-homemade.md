---
description: "Steps menyiapakan Ayam Rica - Rica Kemangi Pedas Mantul Homemade"
title: "Steps menyiapakan Ayam Rica - Rica Kemangi Pedas Mantul Homemade"
slug: 346-steps-menyiapakan-ayam-rica-rica-kemangi-pedas-mantul-homemade
date: 2021-01-03T20:45:08.886Z
image: https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg
author: Jeremiah Hale
ratingvalue: 4.9
reviewcount: 45992
recipeingredient:
- "1/2 kg Ayam potong dada dan sayap sesuai selera"
- "1/2 potong jeruk limau"
- " Bumbu Halus"
- "3 buah bawang putih"
- "4 buah bawang merah"
- "5 buah cabe merah besar"
- "10 cabe rawit sesuai selera"
- "1/2 cm Jahe"
- "Sedikit kunyit"
- "3 buah kemiri"
- " Bahan cemplung"
- "secukupnya Garam"
- "secukupnya Gula"
- " Merica secukupny"
- " penyedap rasa"
- "4 lembar daun jeruk"
- "2 daun sereh geprek"
- "1/2 ruas lengkuas"
- "2 lembar daun salam"
- "4 buah cabe hijau boleh skip"
- "1 ikat daun kemangi"
- "1 buah daun bawang"
- " Air matang"
recipeinstructions:
- "Cuci bersih ayam, kemudian lumuri ayam dgn jeruk limau, beri penyedap rasa, garam, ketumbar (bubuk) dan merica (bubuk) untuk marinasi yang simpel. Diamkan dikulkas 5-10 menit. Kemudian goreng setengah matang."
- "Potong- potong bumbu halus untuk di blender/diulek sesuai selera. Kemudian tambahkan minyak, tumis bumbu hingga wangi, masukkan bumbu cemplung tadi aduk rata."
- "Kemudian masukkan ayam potong, aduk sebentar, tambahkan air secukupnya. Setelah itu tambahkan garam, gula, penyedap rasa, dan merica."
- "Tutup sebentar biarkan meresap. Masukkan daun bawang, cabe hijau, cabe rawit utuh dan kemangi aduk rata, kemudian biarkan hingga meresap dan matang."
- "Koreksi rasa, siapkan mangkok ukuran sedang kemudian sajikan 😍. siap untuk dinikmati"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 156 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT33M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica - Rica Kemangi Pedas Mantul](https://img-global.cpcdn.com/recipes/d15711c86b6dfa3f/751x532cq70/ayam-rica-rica-kemangi-pedas-mantul-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga gurih. Ciri khas makanan Nusantara ayam rica - rica kemangi pedas mantul yang kaya dengan rempah-rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Resep ayam rica- rica pedas Bahan² Ayam Bawang putih Bawang merah Cabe keriting merah Cabe rawit merah Daun jeruk Daun kari(boleh tidak pakai tergantung. Lihat juga resep Ayam Rica Kemangi Pedas Nampol enak lainnya. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica.

Kedekatan keluarga dapat ditemukan dengan cara mudah. Salah satunya adalah membuat makanan Ayam Rica - Rica Kemangi Pedas Mantul untuk keluarga. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di rumah mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda praktekkan salah satunya ayam rica - rica kemangi pedas mantul yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica - rica kemangi pedas mantul tanpa harus bersusah payah.
Berikut ini resep Ayam Rica - Rica Kemangi Pedas Mantul yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 23 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica - Rica Kemangi Pedas Mantul:

1. Harap siapkan 1/2 kg Ayam potong (dada dan sayap) sesuai selera
1. Siapkan 1/2 potong jeruk limau
1. Diperlukan  Bumbu Halus
1. Harus ada 3 buah bawang putih
1. Harap siapkan 4 buah bawang merah
1. Siapkan 5 buah cabe merah besar
1. Siapkan 10 cabe rawit (sesuai selera)
1. Siapkan 1/2 cm Jahe
1. Harus ada Sedikit kunyit
1. Jangan lupa 3 buah kemiri
1. Diperlukan  Bahan cemplung
1. Diperlukan secukupnya Garam
1. Dibutuhkan secukupnya Gula
1. Jangan lupa  Merica secukupny
1. Tambah  penyedap rasa
1. Harap siapkan 4 lembar daun jeruk
1. Siapkan 2 daun sereh geprek
1. Siapkan 1/2 ruas lengkuas
1. Diperlukan 2 lembar daun salam
1. Harap siapkan 4 buah cabe hijau (boleh skip)
1. Dibutuhkan 1 ikat daun kemangi
1. Diperlukan 1 buah daun bawang
1. Diperlukan  Air matang


Ayam rica-rica adalah merupakan masakan tradisional nusantara yang asli berasal dari Manado, kata &#34;Rica&#34; itu sendiri adalah kata-kata khas dari masyarakat manado yang berarti &#34;Cabai&#34; atau &#34;Pedas, jadi kalau diterjemahkan dalam bahasa Indonesia sih kurang lebih seperti ini &#34;Ayam Pedas Berbumbu. Resep Ayam Rica Rica Kemangi Pedas Manis Khas Manado Sederhana Spesial Pedas Asli Enak. Ayam rica-rica yang merupakan salah satu panganan khas daerah Manado, Sulawesi Utara. Dimana &#34;rica&#34; ini yang berarti &#34;cabai&#34; atau &#34;pedas&#34; dalam bahasa Manadonya. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica - Rica Kemangi Pedas Mantul:

1. Cuci bersih ayam, kemudian lumuri ayam dgn jeruk limau, beri penyedap rasa, garam, ketumbar (bubuk) dan merica (bubuk) untuk marinasi yang simpel. Diamkan dikulkas 5-10 menit. Kemudian goreng setengah matang.
1. Potong- potong bumbu halus untuk di blender/diulek sesuai selera. Kemudian tambahkan minyak, tumis bumbu hingga wangi, masukkan bumbu cemplung tadi aduk rata.
1. Kemudian masukkan ayam potong, aduk sebentar, tambahkan air secukupnya. Setelah itu tambahkan garam, gula, penyedap rasa, dan merica.
1. Tutup sebentar biarkan meresap. Masukkan daun bawang, cabe hijau, cabe rawit utuh dan kemangi aduk rata, kemudian biarkan hingga meresap dan matang.
1. Koreksi rasa, siapkan mangkok ukuran sedang kemudian sajikan 😍. siap untuk dinikmati


Ayam rica-rica yang merupakan salah satu panganan khas daerah Manado, Sulawesi Utara. Dimana &#34;rica&#34; ini yang berarti &#34;cabai&#34; atau &#34;pedas&#34; dalam bahasa Manadonya. Nah, untuk membuat resep Ayam Rica Kemangi khas Manado ini, tentu ada beberapa hal yang harus diperhatikan. Rempah menjadi bumbu utama dalam resep masakan Ayam Rica Kemangi ini seperti: jahe, daun salam, dan batang serai yang digeprak sebelumnya. Resep ayam dengan bumbu rica-rica yang pedas bisa jadi menu spesial. 

Demikianlah cara membuat ayam rica - rica kemangi pedas mantul yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
