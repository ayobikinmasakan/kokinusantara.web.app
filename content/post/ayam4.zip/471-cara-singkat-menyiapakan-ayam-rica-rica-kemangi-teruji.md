---
description: "Cara singkat menyiapakan Ayam Rica Rica Kemangi Teruji"
title: "Cara singkat menyiapakan Ayam Rica Rica Kemangi Teruji"
slug: 471-cara-singkat-menyiapakan-ayam-rica-rica-kemangi-teruji
date: 2021-01-06T03:09:10.932Z
image: https://img-global.cpcdn.com/recipes/8b111a508e776f2c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8b111a508e776f2c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8b111a508e776f2c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Beulah Pearson
ratingvalue: 4.1
reviewcount: 46217
recipeingredient:
- "1 ekor ayam potong 8"
- " Bumbu halus "
- "5 siung bawang merah ukuran besar"
- "3 siung bawang putih ukuran besar"
- "10 buah cabe rawit merah ukuran besar bisa ganti cabe merah"
- "Sejempol kunyit"
- "Seruas jahe"
- " Ketumbar 1sd saya pakai yang bubuk"
- " Bahan pelengkap"
- "1 buah tomat potong kecil kecil"
- "2 lbr daun jeruk"
- "1 btg sere saya potong 2 kemudian di geprek"
- "Sejempol lengkuas di geprek"
- "1 genggam kemangi"
recipeinstructions:
- "Blender halus bumbu di atas lalu tumis bersama bahan pelengkap hingga harum dan menyatu"
- "Masukkan ayam lalu aduk aduk sampai bumbu Merata"
- "Tambahkan air sampai ayam tenggelam lalu masukkan tomat"
- "Masak hingga ayam empuk dan tomat hancur lalu tambahkan kemangi (saya pakai kemangi serbuk, akan lebih bagus kalau pakai kemangi utuh),garam,gula,kaldu jamur. Tunggu hingga layu dan air menyusut.."
- "Buang sereh dan lengkuas, masakan siap untuk disajikan.. 💕"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 193 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/8b111a508e776f2c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang harus kita jaga karena setiap area memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan warna yang berbeda, seperti ayam rica rica kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan rempah membawa ciri khas yang merupakan keragaman Kita

Kehangatan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Rica Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang bisa anda buat salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 14 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Siapkan 1 ekor ayam potong 8
1. Jangan lupa  Bumbu halus :
1. Siapkan 5 siung bawang merah ukuran besar
1. Diperlukan 3 siung bawang putih ukuran besar
1. Dibutuhkan 10 buah cabe rawit merah ukuran besar (bisa ganti cabe merah)
1. Siapkan Sejempol kunyit
1. Jangan lupa Seruas jahe
1. Siapkan  Ketumbar 1sd (saya pakai yang bubuk)
1. Siapkan  Bahan pelengkap
1. Siapkan 1 buah tomat potong kecil kecil
1. Diperlukan 2 lbr daun jeruk
1. Tambah 1 btg sere (saya potong 2 kemudian di geprek)
1. Tambah Sejempol lengkuas di geprek
1. Tambah 1 genggam kemangi




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica Kemangi:

1. Blender halus bumbu di atas lalu tumis bersama bahan pelengkap hingga harum dan menyatu
1. Masukkan ayam lalu aduk aduk sampai bumbu Merata
1. Tambahkan air sampai ayam tenggelam lalu masukkan tomat
1. Masak hingga ayam empuk dan tomat hancur lalu tambahkan kemangi (saya pakai kemangi serbuk, akan lebih bagus kalau pakai kemangi utuh),garam,gula,kaldu jamur. Tunggu hingga layu dan air menyusut..
1. Buang sereh dan lengkuas, masakan siap untuk disajikan.. 💕




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
