---
description: "Cara membuat Ayam rica-rica kemangi Cepat"
title: "Cara membuat Ayam rica-rica kemangi Cepat"
slug: 243-cara-membuat-ayam-rica-rica-kemangi-cepat
date: 2020-10-25T08:31:38.906Z
image: https://img-global.cpcdn.com/recipes/e5869bac0baffab4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e5869bac0baffab4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e5869bac0baffab4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Elva Powell
ratingvalue: 4.5
reviewcount: 49558
recipeingredient:
- "1/2 kg ayam bag dada balungan lebih mantapp"
- "secukupnya Daun kemangi"
- " Bumbu halus"
- "4 siung bawang putih"
- "6 siung bawang merah"
- "4 buah kemiri"
- "25 buah cabe merah besar"
- "15 cabe rawit ijo"
- "secukupnya Jahe"
- "2 buah tomat ukuran kecil"
- " Bumbu tambahan"
- " Bawang bombai secukupnya iris"
- " Lengkuas secukupnya geprek"
- " Sereh secukupnya geprek"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "5 sdm kecap manis"
- "secukupnya Garam micin gula jawa"
recipeinstructions:
- "Rebus ayam yg uda dipotong² dan tiriskan"
- "Tumis bumbu yg sudah dihaluskan, tambahkan bawang bombai, daun salam, daun jeruk, sereh dan lengkuas"
- "Masukkan ayam kedalam bumbu, beri kecap, garam, micin, gula jawa... dan masukkan daun kemangi....tes rasa...."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 218 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT58M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/e5869bac0baffab4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah membawa kesan tersendiri yang merupakan keragaman Nusantara

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Kedekatan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica-rica kemangi untuk keluarga. Momen makan bersama anak sudah menjadi budaya, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang bisa anda buat salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Pasalnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Diperlukan 1/2 kg ayam bag. dada (balungan lebih mantapp)
1. Siapkan secukupnya Daun kemangi
1. Jangan lupa  Bumbu halus
1. Siapkan 4 siung bawang putih
1. Dibutuhkan 6 siung bawang merah
1. Dibutuhkan 4 buah kemiri
1. Dibutuhkan 25 buah cabe merah besar
1. Harus ada 15 cabe rawit ijo
1. Harus ada secukupnya Jahe
1. Harus ada 2 buah tomat ukuran kecil
1. Harus ada  Bumbu tambahan
1. Siapkan  Bawang bombai secukupnya (iris²)
1. Dibutuhkan  Lengkuas secukupnya (geprek)
1. Harus ada  Sereh secukupnya (geprek)
1. Diperlukan 2 lembar daun salam
1. Harap siapkan 2 lembar daun jeruk
1. Harus ada 5 sdm kecap manis
1. Harap siapkan secukupnya Garam, micin, gula jawa


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica-rica kemangi:

1. Rebus ayam yg uda dipotong² dan tiriskan
1. Tumis bumbu yg sudah dihaluskan, tambahkan bawang bombai, daun salam, daun jeruk, sereh dan lengkuas
1. Masukkan ayam kedalam bumbu, beri kecap, garam, micin, gula jawa... dan masukkan daun kemangi....tes rasa....


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat mudah dan terbukti, anda bisa menelusuri di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
