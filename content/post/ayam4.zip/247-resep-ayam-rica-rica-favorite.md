---
description: "Resep : Ayam Rica Rica Favorite"
title: "Resep : Ayam Rica Rica Favorite"
slug: 247-resep-ayam-rica-rica-favorite
date: 2020-08-23T17:50:39.254Z
image: https://img-global.cpcdn.com/recipes/33c858b6c20dac29/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/33c858b6c20dac29/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/33c858b6c20dac29/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Arthur Carter
ratingvalue: 4.9
reviewcount: 1789
recipeingredient:
- "1/2 kg ayam potongpotong"
- "4 siung bawang putih"
- "6 siung bawang merah"
- "15 buah cabe rawit"
- "2 sdm ketumbar bubuk"
- "1 sdm saos tiram saya pakai saori"
- "Secukupnya kecap manis saya pakai bango"
- "2 sdm minyak wijen"
- "4 sdm saos mentega saya pakai saori"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya penyedap rasa"
- "Secukupnya lada"
- "Secukupnya minyak goreng"
- " Bumbu marinasi ayam "
- "2 siung bawang putih yang dihaluskan"
- "1 sachet bon cabe"
- "2 sdm saos tiram"
- "Secukupnya lada"
- "Secukupnya garam"
- "Secukupnya air"
recipeinstructions:
- "Cuci bersih ayam yang sudah dipotong2 lalu tiriskan"
- "Buat larutan marinasi ayam lalu rendam ayam selama 10 menit"
- "Setelah itu goreng dalam sedikit minyak sambil dibolak balik hingga matang, lalu tiriskan"
- "Haluskan bawang merah, bawang putih, cabe dan ketumbar"
- "Tumis bumbu halus, masukkan ayam yang telah digoreng, lalu tambahkan saos tiram, kecap manis, saos mentega, dan minyak wijen"
- "Lalu tambahkan garam, gula, lada dan penyedap rasa. Aduk rata dan icip lalu tambahkan sedikit air ungkep sebentar hingga matang. Sajikan dengan nasi hangat"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 210 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/33c858b6c20dac29/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga renyah. Ciri masakan Nusantara ayam rica rica yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk warga luar yang berkunjung.




Kehangatan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam Rica Rica untuk orang di rumah. kebiasaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang bisa anda contoh salah satunya ayam rica rica yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan mudah menemukan resep ayam rica rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 21 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica:

1. Diperlukan 1/2 kg ayam potong-potong
1. Jangan lupa 4 siung bawang putih
1. Harap siapkan 6 siung bawang merah
1. Tambah 15 buah cabe rawit
1. Harap siapkan 2 sdm ketumbar bubuk
1. Harus ada 1 sdm saos tiram (saya pakai saori)
1. Harus ada Secukupnya kecap manis (saya pakai bango)
1. Diperlukan 2 sdm minyak wijen
1. Jangan lupa 4 sdm saos mentega (saya pakai saori)
1. Dibutuhkan Secukupnya garam
1. Harus ada Secukupnya gula
1. Jangan lupa Secukupnya penyedap rasa
1. Tambah Secukupnya lada
1. Harus ada Secukupnya minyak goreng
1. Tambah  Bumbu marinasi ayam :
1. Dibutuhkan 2 siung bawang putih yang dihaluskan
1. Siapkan 1 sachet bon cabe
1. Harap siapkan 2 sdm saos tiram
1. Harus ada Secukupnya lada
1. Harap siapkan Secukupnya garam
1. Diperlukan Secukupnya air




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica:

1. Cuci bersih ayam yang sudah dipotong2 lalu tiriskan
1. Buat larutan marinasi ayam lalu rendam ayam selama 10 menit
1. Setelah itu goreng dalam sedikit minyak sambil dibolak balik hingga matang, lalu tiriskan
1. Haluskan bawang merah, bawang putih, cabe dan ketumbar
1. Tumis bumbu halus, masukkan ayam yang telah digoreng, lalu tambahkan saos tiram, kecap manis, saos mentega, dan minyak wijen
1. Lalu tambahkan garam, gula, lada dan penyedap rasa. Aduk rata dan icip lalu tambahkan sedikit air ungkep sebentar hingga matang. Sajikan dengan nasi hangat




Demikianlah cara membuat ayam rica rica yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat gampang dan terbukti, anda bisa mencari di halaman kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
