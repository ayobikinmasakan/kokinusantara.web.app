---
description: "Resep : 103.Ayam Rica Teruji"
title: "Resep : 103.Ayam Rica Teruji"
slug: 365-resep-103ayam-rica-teruji
date: 2020-11-29T01:53:50.473Z
image: https://img-global.cpcdn.com/recipes/624ae7dfc716b40e/751x532cq70/103ayam-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/624ae7dfc716b40e/751x532cq70/103ayam-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/624ae7dfc716b40e/751x532cq70/103ayam-rica-foto-resep-utama.jpg
author: Dennis Alexander
ratingvalue: 4.4
reviewcount: 20923
recipeingredient:
- "1 ayam pejantan potong 12"
- "1 jeruk nipis ambil airnya"
- "3 sereh geprek"
- "6 daun jeruk"
- "3 daun salam"
- "3 batang daun bawang iris 1 cm"
- "1 sdt garam"
- "1 sdt kaldu jamur"
- "1 jempol gula merah iris"
- "1 sdt ketumbur"
- "2 sdm minyak sayur untuk menumis"
- "Secukupnya air"
- " Bumbu halus "
- "12 siung bawang putih"
- "6 siung bawang merah"
- "6 btr kemiri"
- "10 cabe rawit"
- "6 cabe keriting"
- "1 ruas jari kunyit"
- "1 ruas jari jahe"
- "1 ruas jari lengkuas"
recipeinstructions:
- "Cuci.bersih ayam lalu beri perasan jeruk nipis,diamkan 10 menit kemudian cuci kembali."
- "Panaskan minyak,tumis bumbu halus hingga wangi. Masukkan sereh,daun salam,daun bawang,aduk rata beri 3 sdm air lalu tambahkan garam,gula merah dan kaldu. Masak hingga mendidih."
- "Masukkan ayam,aduk rata lalu tambahkan air secukupnya, masak hingga air menyusut sebagian lalu tambahkan daun bawang. Aduk rata,koreksi rasa,masak hingga kental dan ayam mengeluarkan minyak."
- "Ayam rica siap di hidangkan."
categories:
- Recipe
tags:
- 103ayam
- rica

katakunci: 103ayam rica 
nutrition: 109 calories
recipecuisine: American
preptime: "PT24M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Dessert

---


![103.Ayam Rica](https://img-global.cpcdn.com/recipes/624ae7dfc716b40e/751x532cq70/103ayam-rica-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita jaga karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi variasi dan warna yang berbeda, seperti 103.ayam rica yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa kesan tersendiri yang merupakan keragaman Indonesia

Keharmonisan keluarga bisa ditemukan dengan cara mudah. Diantaranya adalah memasak 103.Ayam Rica untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian masakan yang bisa anda coba salah satunya 103.ayam rica yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya saat ini kamu bisa dengan mudah menemukan resep 103.ayam rica tanpa harus bersusah payah.
Berikut ini resep 103.Ayam Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 21 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat 103.Ayam Rica:

1. Dibutuhkan 1 ayam pejantan, potong 12
1. Tambah 1 jeruk nipis ambil airnya
1. Tambah 3 sereh, geprek
1. Harap siapkan 6 daun jeruk
1. Harap siapkan 3 daun salam
1. Harus ada 3 batang daun bawang, iris 1 cm
1. Harap siapkan 1 sdt garam
1. Dibutuhkan 1 sdt kaldu jamur
1. Diperlukan 1 jempol gula merah, iris
1. Tambah 1 sdt ketumbur
1. Jangan lupa 2 sdm minyak sayur untuk menumis
1. Tambah Secukupnya air
1. Siapkan  Bumbu halus :
1. Harus ada 12 siung bawang putih
1. Harap siapkan 6 siung bawang merah
1. Jangan lupa 6 btr kemiri
1. Siapkan 10 cabe rawit
1. Dibutuhkan 6 cabe keriting
1. Jangan lupa 1 ruas jari kunyit
1. Siapkan 1 ruas jari jahe
1. Jangan lupa 1 ruas jari lengkuas




<!--inarticleads2-->

##### Langkah membuat  103.Ayam Rica:

1. Cuci.bersih ayam lalu beri perasan jeruk nipis,diamkan 10 menit kemudian cuci kembali.
1. Panaskan minyak,tumis bumbu halus hingga wangi. Masukkan sereh,daun salam,daun bawang,aduk rata beri 3 sdm air lalu tambahkan garam,gula merah dan kaldu. Masak hingga mendidih.
1. Masukkan ayam,aduk rata lalu tambahkan air secukupnya, masak hingga air menyusut sebagian lalu tambahkan daun bawang. Aduk rata,koreksi rasa,masak hingga kental dan ayam mengeluarkan minyak.
1. Ayam rica siap di hidangkan.




Demikianlah cara membuat 103.ayam rica yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
