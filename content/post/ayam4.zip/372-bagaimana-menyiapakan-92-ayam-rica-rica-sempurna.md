---
description: "Bagaimana menyiapakan #92 Ayam Rica-rica Sempurna"
title: "Bagaimana menyiapakan #92 Ayam Rica-rica Sempurna"
slug: 372-bagaimana-menyiapakan-92-ayam-rica-rica-sempurna
date: 2020-08-08T08:04:40.526Z
image: https://img-global.cpcdn.com/recipes/957a6039ab5c02a6/751x532cq70/92-ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/957a6039ab5c02a6/751x532cq70/92-ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/957a6039ab5c02a6/751x532cq70/92-ayam-rica-rica-foto-resep-utama.jpg
author: Lucinda King
ratingvalue: 4.5
reviewcount: 40843
recipeingredient:
- " Bahan Utama"
- "1 kg ayam potong"
- " Bumbu halus"
- "9 bh cabai keriting merah"
- "5 bh cabai rawit merah"
- "5 siung bawang putih"
- "7 siung bawang merah"
- "3 butir kemiri"
- "1 ruas jahe"
- "1 ruas lengkuas"
- "1 ruas kunyit"
- " Bumbu Pelengkap"
- "2 bh tomat"
- "1 batang serai"
- "3 lembar daun jeruk"
- "3 lembar daun salam"
- "2 sdm kecap manis"
- "1/2 sdt garam"
- "1 sdt gula pasir"
- "1/2 sdt kaldu bubuk"
- "500 ml air"
- "5 sdm minyak goreng"
recipeinstructions:
- "Cuci ayam sampai bersih."
- "Haluskan bumbu. Iris tomat, geprek serai, dan sobek² daun jeruk."
- "Tumis bumbu halus bersama irisan tomat, serai, dan daun jeruk. Tambahkan air dan bumbu pelengkap lainnya. Tunggu sampai mendidih."
- "Masukkan ayam dan masak sampai matang."
- "Sajikan... 👩‍🍳"
categories:
- Recipe
tags:
- 92
- ayam
- ricarica

katakunci: 92 ayam ricarica 
nutrition: 173 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dinner

---


![#92 Ayam Rica-rica](https://img-global.cpcdn.com/recipes/957a6039ab5c02a6/751x532cq70/92-ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau empuk. Ciri khas kuliner Nusantara #92 ayam rica-rica yang penuh dengan bumbu membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga dapat ditemukan dengan cara sederhana. Salah satunya adalah membuat makanan #92 Ayam Rica-rica untuk orang di rumah. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang biasanya mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak variasi masakan yang bisa anda coba salah satunya #92 ayam rica-rica yang merupakan resep favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep #92 ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep #92 Ayam Rica-rica yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 5 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat #92 Ayam Rica-rica:

1. Siapkan  Bahan Utama
1. Harus ada 1 kg ayam potong
1. Diperlukan  Bumbu halus
1. Dibutuhkan 9 bh cabai keriting merah
1. Harap siapkan 5 bh cabai rawit merah
1. Diperlukan 5 siung bawang putih
1. Diperlukan 7 siung bawang merah
1. Dibutuhkan 3 butir kemiri
1. Diperlukan 1 ruas jahe
1. Diperlukan 1 ruas lengkuas
1. Harap siapkan 1 ruas kunyit
1. Siapkan  Bumbu Pelengkap
1. Dibutuhkan 2 bh tomat
1. Harap siapkan 1 batang serai
1. Tambah 3 lembar daun jeruk
1. Diperlukan 3 lembar daun salam
1. Jangan lupa 2 sdm kecap manis
1. Siapkan 1/2 sdt garam
1. Harus ada 1 sdt gula pasir
1. Tambah 1/2 sdt kaldu bubuk
1. Dibutuhkan 500 ml air
1. Harus ada 5 sdm minyak goreng




<!--inarticleads2-->

##### Langkah membuat  #92 Ayam Rica-rica:

1. Cuci ayam sampai bersih.
1. Haluskan bumbu. Iris tomat, geprek serai, dan sobek² daun jeruk.
1. Tumis bumbu halus bersama irisan tomat, serai, dan daun jeruk. Tambahkan air dan bumbu pelengkap lainnya. Tunggu sampai mendidih.
1. Masukkan ayam dan masak sampai matang.
1. Sajikan... 👩‍🍳




Demikianlah cara membuat #92 ayam rica-rica yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan teruji, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
