---
description: "Langkah untuk menyiapakan Ayam rica kemangi bumbu olahan teraktual"
title: "Langkah untuk menyiapakan Ayam rica kemangi bumbu olahan teraktual"
slug: 317-langkah-untuk-menyiapakan-ayam-rica-kemangi-bumbu-olahan-teraktual
date: 2021-01-09T20:27:10.028Z
image: https://img-global.cpcdn.com/recipes/bf42d31bf3f95597/751x532cq70/ayam-rica-kemangi-bumbu-olahan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bf42d31bf3f95597/751x532cq70/ayam-rica-kemangi-bumbu-olahan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bf42d31bf3f95597/751x532cq70/ayam-rica-kemangi-bumbu-olahan-foto-resep-utama.jpg
author: Sophie Wheeler
ratingvalue: 4.9
reviewcount: 12245
recipeingredient:
- "1/2 ekor ayam sudah digoreng setengah masak"
- "3 batang kemangi"
- "1 gelas duralex air biasa"
- "7 sdm minyak goreng"
- " Bahan Halus"
- "5 siung bawang merah"
- "2 siung bawang putih hrusnya 3 Tp khabisan bawang putih"
- "2 biji kemiri"
- "1 ruas kunyit"
- "1 ruas jahe"
- "3 biji cabe kriting"
- "13 biji cabe rawit"
- "1 buah tomat ukuran sedang"
- "1/2 sdt lada bubuk"
- " Bahan cemplung"
- "1 batang serai"
- "2 helai daun salam"
- " Bumbu Rasa"
- "2 sdt garam tidak penuh"
- "2 sdt royco ayam"
- "1 sdm gula pasir tidak penuh"
recipeinstructions:
- "Panaskan minyak dgn api sedang. Kemudian tumis bahan halus bersamaan daun salam dan serai hingga keluar aroma wangi bumbunya"
- "Masukkan ayam, bumbu rasa dan air, aduk sebentar sekiranya semua ayam terendam merata. Tunggu skitar 3 menit, kemudian aduk lagi. Ulangi mengaduk setelah 3 menit hingga air mulai menyusut"
- "Jika sdh menyusut, cek rasa. Jika sudah pas, masukkan daun kemangi yg sudah dibersihkan. Aduk lagi hingga daun kemanginya layu."
- "Jika sudah layu, matikan kompor. Dan ayam rica kemangi bumbu olahan siap disajikan😁"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 106 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica kemangi bumbu olahan](https://img-global.cpcdn.com/recipes/bf42d31bf3f95597/751x532cq70/ayam-rica-kemangi-bumbu-olahan-foto-resep-utama.jpg)

Makanan adalah warisan budaya yang dapat kita lestarikan karena setiap area memiliki ciri tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica kemangi bumbu olahan yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan ciri khas yang merupakan keragaman Nusantara

Kedekatan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah memasak Ayam rica kemangi bumbu olahan untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang dapat anda contoh salah satunya ayam rica kemangi bumbu olahan yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica kemangi bumbu olahan tanpa harus bersusah payah.
Seperti resep Ayam rica kemangi bumbu olahan yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 21 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica kemangi bumbu olahan:

1. Diperlukan 1/2 ekor ayam (sudah digoreng setengah masak)
1. Harap siapkan 3 batang kemangi
1. Tambah 1 gelas duralex air biasa
1. Dibutuhkan 7 sdm minyak goreng
1. Siapkan  Bahan Halus
1. Jangan lupa 5 siung bawang merah
1. Diperlukan 2 siung bawang putih (hrusnya 3. Tp khabisan bawang putih😅)
1. Tambah 2 biji kemiri
1. Jangan lupa 1 ruas kunyit
1. Jangan lupa 1 ruas jahe
1. Diperlukan 3 biji cabe kriting
1. Harap siapkan 13 biji cabe rawit
1. Harus ada 1 buah tomat ukuran sedang
1. Siapkan 1/2 sdt lada bubuk
1. Diperlukan  Bahan cemplung
1. Jangan lupa 1 batang serai
1. Diperlukan 2 helai daun salam
1. Harus ada  Bumbu Rasa
1. Harus ada 2 sdt garam (tidak penuh)
1. Harus ada 2 sdt royco ayam
1. Diperlukan 1 sdm gula pasir (tidak penuh)




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica kemangi bumbu olahan:

1. Panaskan minyak dgn api sedang. Kemudian tumis bahan halus bersamaan daun salam dan serai hingga keluar aroma wangi bumbunya
1. Masukkan ayam, bumbu rasa dan air, aduk sebentar sekiranya semua ayam terendam merata. Tunggu skitar 3 menit, kemudian aduk lagi. Ulangi mengaduk setelah 3 menit hingga air mulai menyusut
1. Jika sdh menyusut, cek rasa. Jika sudah pas, masukkan daun kemangi yg sudah dibersihkan. Aduk lagi hingga daun kemanginya layu.
1. Jika sudah layu, matikan kompor. Dan ayam rica kemangi bumbu olahan siap disajikan😁




Demikianlah cara membuat ayam rica kemangi bumbu olahan yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan teruji, anda bisa menelusuri di website kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
