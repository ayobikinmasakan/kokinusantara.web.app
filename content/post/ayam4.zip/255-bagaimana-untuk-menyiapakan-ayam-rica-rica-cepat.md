---
description: "Bagaimana untuk menyiapakan Ayam Rica-rica Cepat"
title: "Bagaimana untuk menyiapakan Ayam Rica-rica Cepat"
slug: 255-bagaimana-untuk-menyiapakan-ayam-rica-rica-cepat
date: 2020-12-24T17:11:57.609Z
image: https://img-global.cpcdn.com/recipes/27abe66e83cdea84/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/27abe66e83cdea84/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/27abe66e83cdea84/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Francisco Adkins
ratingvalue: 4.6
reviewcount: 17151
recipeingredient:
- "4 potong ayam"
- "8 siung bawang merah"
- "1 batang Daun Bawang"
- "2 lembar daun jeruk"
- "1 buah tomat"
- "secukupnya Garam"
- "secukupnya Kaldu"
- "secukupnya Air"
- "secukupnya Minyak"
- " Bumbu halus"
- "3 siung bawang putih"
- "1 batang sereh"
- "1 ruas kunyit"
- "1 ruas jahe"
- "15 cabe merah keriting"
- "5 cabe rawit merah"
recipeinstructions:
- "Bersihkan ayam kemudian beri perasan jeruk nipis dan garam, lalu diamkan sebentar"
- "Rebus ayam terlebih dahulu agar menghilangkan darah di dalam tulang"
- "Cincang bawang merah, kemudian haluskan bumbu. Setelah itu tumis bawang merah terlebih dahulu, apabila sudah sedikit layu, kemudian masukan bumbu yang sudah dihaluskan."
- "Setelah menumis masukan tomat, daun bawang dan daun jeruk, kemudian masukan ayam, oseng2 sebentar lalu tambahkan air"
- "Bumbui kembali dengan kaldu dan garam, koreksi rasa, lalu sajikan..."
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 202 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-rica](https://img-global.cpcdn.com/recipes/27abe66e83cdea84/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan empuk. Ciri makanan Indonesia ayam rica-rica yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat diperoleh dengan cara mudah. Diantaranya adalah memasak Ayam Rica-rica untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian masakan yang dapat anda coba salah satunya ayam rica-rica yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu dapat dengan gampang menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-rica:

1. Tambah 4 potong ayam
1. Tambah 8 siung bawang merah
1. Tambah 1 batang Daun Bawang
1. Jangan lupa 2 lembar daun jeruk
1. Diperlukan 1 buah tomat
1. Tambah secukupnya Garam
1. Dibutuhkan secukupnya Kaldu
1. Diperlukan secukupnya Air
1. Jangan lupa secukupnya Minyak
1. Dibutuhkan  Bumbu halus
1. Dibutuhkan 3 siung bawang putih
1. Harus ada 1 batang sereh
1. Harus ada 1 ruas kunyit
1. Harus ada 1 ruas jahe
1. Harus ada 15 cabe merah keriting
1. Diperlukan 5 cabe rawit merah




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica:

1. Bersihkan ayam kemudian beri perasan jeruk nipis dan garam, lalu diamkan sebentar
1. Rebus ayam terlebih dahulu agar menghilangkan darah di dalam tulang
1. Cincang bawang merah, kemudian haluskan bumbu. Setelah itu tumis bawang merah terlebih dahulu, apabila sudah sedikit layu, kemudian masukan bumbu yang sudah dihaluskan.
1. Setelah menumis masukan tomat, daun bawang dan daun jeruk, kemudian masukan ayam, oseng2 sebentar lalu tambahkan air
1. Bumbui kembali dengan kaldu dan garam, koreksi rasa, lalu sajikan...




Demikianlah cara membuat ayam rica-rica yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan terbukti, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
