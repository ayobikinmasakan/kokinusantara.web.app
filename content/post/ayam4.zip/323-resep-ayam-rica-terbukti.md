---
description: "Resep : Ayam rica Terbukti"
title: "Resep : Ayam rica Terbukti"
slug: 323-resep-ayam-rica-terbukti
date: 2020-08-29T07:28:10.230Z
image: https://img-global.cpcdn.com/recipes/d53453245e4acd3c/751x532cq70/ayam-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d53453245e4acd3c/751x532cq70/ayam-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d53453245e4acd3c/751x532cq70/ayam-rica-foto-resep-utama.jpg
author: Caleb Neal
ratingvalue: 4.8
reviewcount: 30901
recipeingredient:
- "1/2 kg ayam potong"
- "10 siung cabai rawit merah"
- "6 siung bawang merah"
- "4 siung bawang putih"
- "1 ruas lengkuas"
- "1 ruas kunyit"
- "1 ruas jahe"
- "2 lembar daun salam"
- "1 batang serai"
- "1/2 gula merah"
- "1/2 sendok teh merica bubuk"
- "1/2 sendok teh gula pasir"
- "1/2 sendok teh garam"
- " Royco  penyedap"
- " Minyak goreng"
recipeinstructions:
- "Rebus ayam yg sudah di potong dan di cuci bersih, tambahkan 1 sendok teh garam dan 2 lembar daun salam. Jika sudah mendidih tiriskan"
- "Haluskan bumbu dengan cara apapun kecuali lengkuas, daun salam dan serai."
- "Panaskan minyak dan tumis bumbu halus lalu masukan lengkuas, daun salam dan serai. Tumis hingga harum dan berubah warna"
- "Masukkan ayam yg sudah di rebus lalu tambahkan 2 gelas air dan gula merah."
- "Tunggu hingga air berkurang dan bumbu meresap"
categories:
- Recipe
tags:
- ayam
- rica

katakunci: ayam rica 
nutrition: 178 calories
recipecuisine: American
preptime: "PT28M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica](https://img-global.cpcdn.com/recipes/d53453245e4acd3c/751x532cq70/ayam-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang manis,pedas hingga gurih. Karasteristik masakan Indonesia ayam rica yang kaya dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu merindukan makanan di kampung halaman mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak varian makanan yang bisa anda buat salah satunya ayam rica yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya sekarang ini kamu bisa dengan cepat menemukan resep ayam rica tanpa harus bersusah payah.
Seperti resep Ayam rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica:

1. Diperlukan 1/2 kg ayam potong
1. Dibutuhkan 10 siung cabai rawit merah
1. Tambah 6 siung bawang merah
1. Harap siapkan 4 siung bawang putih
1. Siapkan 1 ruas lengkuas
1. Dibutuhkan 1 ruas kunyit
1. Harus ada 1 ruas jahe
1. Diperlukan 2 lembar daun salam
1. Tambah 1 batang serai
1. Jangan lupa 1/2 gula merah
1. Dibutuhkan 1/2 sendok teh merica bubuk
1. Diperlukan 1/2 sendok teh gula pasir
1. Harus ada 1/2 sendok teh garam
1. Harus ada  Royco / penyedap
1. Harus ada  Minyak goreng




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica:

1. Rebus ayam yg sudah di potong dan di cuci bersih, tambahkan 1 sendok teh garam dan 2 lembar daun salam. Jika sudah mendidih tiriskan
1. Haluskan bumbu dengan cara apapun kecuali lengkuas, daun salam dan serai.
1. Panaskan minyak dan tumis bumbu halus lalu masukan lengkuas, daun salam dan serai. Tumis hingga harum dan berubah warna
1. Masukkan ayam yg sudah di rebus lalu tambahkan 2 gelas air dan gula merah.
1. Tunggu hingga air berkurang dan bumbu meresap




Demikianlah cara membuat ayam rica yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih memiliki banyak resep makanan istimewa yang sangat simple dan teruji, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
