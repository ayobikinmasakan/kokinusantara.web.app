---
description: "Panduan untuk membuat Ayam rica-rica kemangi Teruji"
title: "Panduan untuk membuat Ayam rica-rica kemangi Teruji"
slug: 350-panduan-untuk-membuat-ayam-rica-rica-kemangi-teruji
date: 2020-12-03T15:01:21.488Z
image: https://img-global.cpcdn.com/recipes/5c2a007f00314a27/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5c2a007f00314a27/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5c2a007f00314a27/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Paul Reese
ratingvalue: 4.9
reviewcount: 36571
recipeingredient:
- "500 grm ayam"
- "900 ml santan"
- "1 ikat kemangi"
- "2 btg serai"
- "3 lmbr daun jeruk"
- "1 lmbr daun salam"
- " Minyak untuk menggoreng"
- " Bumbu halus "
- "5 butir bawang merah"
- "3 siung bawang putih"
- "3 buah cabe merah"
- "10 buah cabe rawit"
- "3 butir kemiri sangrai"
- "2 cm kunyit"
- "2 cm jahe"
- "1/2 sdt ketumbar"
recipeinstructions:
- "Cuci bersih ayam kemudian rebus hingga setengah matang angkat dan tiriskn"
- "Goreng ayam tidak sampai garing kemudian sisihkan."
- "Blender bumbu halus kemudia masak di atas wajan dan masukkan serai,daun salam,daun jeruk dan masak hingga tanak."
- "Masukkan ayam ke dalam bumbu masukkan garam,gula dan penyedap rasa dan tmbahkan santan."
- "Masak hingga kuah santan agak menyusut perbarui rasa dan masukkan kemangi yang sudah di cuci dan di siangi."
- "Aduk hingga agak layu kemanginya ayam rica siap di sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 114 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/5c2a007f00314a27/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau empuk. Karasteristik kuliner Nusantara ayam rica-rica kemangi yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Keharmonisan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica-rica kemangi untuk orang di rumah. Momen makan bersama anak sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak variasi resep yang bisa anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica kemangi:

1. Diperlukan 500 grm ayam
1. Dibutuhkan 900 ml santan
1. Harap siapkan 1 ikat kemangi
1. Harap siapkan 2 btg serai
1. Dibutuhkan 3 lmbr daun jeruk
1. Harap siapkan 1 lmbr daun salam
1. Diperlukan  Minyak untuk menggoreng
1. Siapkan  Bumbu halus :
1. Diperlukan 5 butir bawang merah
1. Harus ada 3 siung bawang putih
1. Harap siapkan 3 buah cabe merah
1. Jangan lupa 10 buah cabe rawit
1. Dibutuhkan 3 butir kemiri sangrai
1. Diperlukan 2 cm kunyit
1. Siapkan 2 cm jahe
1. Jangan lupa 1/2 sdt ketumbar


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Cara membuat  Ayam rica-rica kemangi:

1. Cuci bersih ayam kemudian rebus hingga setengah matang angkat dan tiriskn
1. Goreng ayam tidak sampai garing kemudian sisihkan.
1. Blender bumbu halus kemudia masak di atas wajan dan masukkan serai,daun salam,daun jeruk dan masak hingga tanak.
1. Masukkan ayam ke dalam bumbu masukkan garam,gula dan penyedap rasa dan tmbahkan santan.
1. Masak hingga kuah santan agak menyusut perbarui rasa dan masukkan kemangi yang sudah di cuci dan di siangi.
1. Aduk hingga agak layu kemanginya ayam rica siap di sajikan.


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan cepat, anda bisa menemukan di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
