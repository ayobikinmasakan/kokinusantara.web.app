---
description: "Panduan untuk menyiapakan Opor ayam tahu🍗🍗🥘 Cepat"
title: "Panduan untuk menyiapakan Opor ayam tahu🍗🍗🥘 Cepat"
slug: 485-panduan-untuk-menyiapakan-opor-ayam-tahu-cepat
date: 2020-11-25T10:06:56.879Z
image: https://img-global.cpcdn.com/recipes/fdfd1f9b9251c1df/751x532cq70/opor-ayam-tahu🍗🍗🥘-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fdfd1f9b9251c1df/751x532cq70/opor-ayam-tahu🍗🍗🥘-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fdfd1f9b9251c1df/751x532cq70/opor-ayam-tahu🍗🍗🥘-foto-resep-utama.jpg
author: Isabel Garcia
ratingvalue: 4.2
reviewcount: 21210
recipeingredient:
- "1/2 kg ayam"
- " santan dibagi 2 ya moms kental  cair"
- "3 buah tahu potong sesuai selera"
- " minyak untuk menumis"
- " bumbu halus"
- "6 bawang merah"
- "3 bawang putih"
- "secukupnya kemiri"
- "1/2 sdt merica"
- "1/2 sdt ketumbar"
- "1 cm jahe"
- "1 cm kencur"
- "1 cm kunyit"
- "secukupnya garam gulapenyedap rasa"
- " bumbu cemplung"
- " lengkuas geprek"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang seraibelah 2 bagian pangkalnya lalu geprek"
- " pelengkap bawang goreng"
recipeinstructions:
- "Bersihkan ayam, cuci bersih, potong2 menurut selera,,"
- "Siapkan wajan,tuang minyak goreng tunggu sampai panas dulu ya minyaknya kemudian tumis bumbu halus sampai harum,masukan bumbu cemplung (serai dkk),aduk2 tambahkan sedikit air(dikit aja yaa kira2 5 sendok makan), kemudian kecilkan api,tumis sampai minyaknya keluar dan bumbu benar2 matang, masukan gula, garam, penyedap rasa,, lalu masukan tahu,aduk bersama bumbu (aduknya pake perasaan ya moms,soalnya tahu itu sensitif😁), selanjutnya masuk dech tuch ayamnya, aduk lagi dengan penuh perasaan"
- "Setelah di aduk rata bersama bumbu dan tahu kemudian tutup biarkan bumbu meresap (api masih kecil ya,, jangan di tinggal ya moms, sesekali diaduk perlahan😁,,,)rebus ayam tahu bersama bumbu sekitar 15 menitan,,"
- "Kemudian masukan dech santan cairnya,,, aduk2 (apinya naik dilevel sedang ya moms) rebus sampai ayam empuk dan santan agak menyusut,,, terakhir masukan santan kental, sambil diaduk2 ya (api kecilin dikit biar gak pecah santannya)"
- "Kalau sudah mendidih,test rasa, matikan api,,, masukan dech bawang gorengnya,, selamat mencobaa"
categories:
- Recipe
tags:
- opor
- ayam
- tahu

katakunci: opor ayam tahu 
nutrition: 191 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dessert

---


![Opor ayam tahu🍗🍗🥘](https://img-global.cpcdn.com/recipes/fdfd1f9b9251c1df/751x532cq70/opor-ayam-tahu🍗🍗🥘-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga empuk. Ciri khas makanan Indonesia opor ayam tahu🍗🍗🥘 yang penuh dengan bumbu membawa keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga dapat ditemukan dengan cara mudah. Diantaranya adalah membuat makanan Opor ayam tahu🍗🍗🥘 untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

Meski opor ayam dapat dimasak sesuai selera namun takaran bahan dan bumbunya harus pas. Nah bagi kamu yang sedang ingin mengolah opor ayam atau mencoba memasaknya di rumah, namun belum tahu caranya pengolahannya, berikut ini brilio.net himpun dari berbagai sumber pada. Opor Ayam 🍗🥘♨️ —⠀⠀⠀⠀⠀⠀⠀⠀⠀ Spesial di Ramadhan: ⠀⠀⠀⠀⠀⠀ Salah satu menu wajib di bulan Ramadhan adalah opor ayam. Apalagi kalau dimakan sama ketupat, pasti endeus banget!

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang bisa anda contoh salah satunya opor ayam tahu🍗🍗🥘 yang merupakan resep terkenal yang mudah dengan varian sederhana. Pasalnya saat ini kamu dapat dengan gampang menemukan resep opor ayam tahu🍗🍗🥘 tanpa harus bersusah payah.
Seperti resep Opor ayam tahu🍗🍗🥘 yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 20 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Opor ayam tahu🍗🍗🥘:

1. Tambah 1/2 kg ayam
1. Dibutuhkan  santan (dibagi 2 ya moms, kental &amp; cair)
1. Siapkan 3 buah tahu (potong sesuai selera)
1. Jangan lupa  minyak untuk menumis
1. Jangan lupa  bumbu halus:
1. Siapkan 6 bawang merah
1. Harap siapkan 3 bawang putih
1. Harus ada secukupnya kemiri
1. Dibutuhkan 1/2 sdt merica
1. Harus ada 1/2 sdt ketumbar
1. Tambah 1 cm jahe
1. Jangan lupa 1 cm kencur
1. Harus ada 1 cm kunyit
1. Harus ada secukupnya garam, gula,penyedap rasa
1. Jangan lupa  bumbu cemplung:
1. Harus ada  lengkuas (geprek)
1. Tambah 2 lembar daun salam
1. Jangan lupa 3 lembar daun jeruk
1. Harus ada 1 batang serai(belah 2 bagian pangkalnya lalu geprek)
1. Harus ada  pelengkap: bawang goreng


The spice mixture (bumbu) includes galangal, lemongrass, cinnamon, tamarind juice, palm sugar, coriander, cumin, candlenut, garlic, shallot, and pepper. Opor ayam (chicken cooked in coconut milk) is one of the easiest Indonesian recipes you can try at home, and very delicious. Opor ayam is very mild compared to many Indonesian dishes. It has no chilies, making this dish very children friendly. 

<!--inarticleads2-->

##### Bagaimana membuat  Opor ayam tahu🍗🍗🥘:

1. Bersihkan ayam, cuci bersih, potong2 menurut selera,,
1. Siapkan wajan,tuang minyak goreng tunggu sampai panas dulu ya minyaknya kemudian tumis bumbu halus sampai harum,masukan bumbu cemplung (serai dkk),aduk2 tambahkan sedikit air(dikit aja yaa kira2 5 sendok makan), kemudian kecilkan api,tumis sampai minyaknya keluar dan bumbu benar2 matang, masukan gula, garam, penyedap rasa,, lalu masukan tahu,aduk bersama bumbu (aduknya pake perasaan ya moms,soalnya tahu itu sensitif😁), selanjutnya masuk dech tuch ayamnya, aduk lagi dengan penuh perasaan
1. Setelah di aduk rata bersama bumbu dan tahu kemudian tutup biarkan bumbu meresap (api masih kecil ya,, jangan di tinggal ya moms, sesekali diaduk perlahan😁,,,)rebus ayam tahu bersama bumbu sekitar 15 menitan,,
1. Kemudian masukan dech santan cairnya,,, aduk2 (apinya naik dilevel sedang ya moms) rebus sampai ayam empuk dan santan agak menyusut,,, terakhir masukan santan kental, sambil diaduk2 ya (api kecilin dikit biar gak pecah santannya)
1. Kalau sudah mendidih,test rasa, matikan api,,, masukan dech bawang gorengnya,, selamat mencobaa


Opor ayam is very mild compared to many Indonesian dishes. It has no chilies, making this dish very children friendly. I myself remember how this is one of my favorite dishes. Opor ayam merupakan masakan sejenis kari ayam yang sangat dikenal di Indonesia. Masakan ini telah dikenal luas di daerah lain. 

Demikianlah cara membuat opor ayam tahu🍗🍗🥘 yang mudah dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan teruji, anda bisa mencari di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
