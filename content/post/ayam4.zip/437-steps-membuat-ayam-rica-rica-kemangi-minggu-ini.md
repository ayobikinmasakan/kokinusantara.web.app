---
description: "Steps membuat Ayam rica rica kemangi minggu ini"
title: "Steps membuat Ayam rica rica kemangi minggu ini"
slug: 437-steps-membuat-ayam-rica-rica-kemangi-minggu-ini
date: 2020-10-10T03:18:28.569Z
image: https://img-global.cpcdn.com/recipes/e631b4fd3eb1e1d4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e631b4fd3eb1e1d4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e631b4fd3eb1e1d4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Iva McLaughlin
ratingvalue: 4.2
reviewcount: 13307
recipeingredient:
- "1/2 kg sayap ayam"
- " Bumbu uleg "
- "3 siung bawang putih"
- "6 siung bawang merah"
- "1 tangkai sereh"
- "1,5 ruas kunyit"
- "1 ruas Jahe"
- "1 ruas lengkuas"
- "1 sdt ketumbar"
- "2 buah kemiri"
- "5 butir merica"
- "2 lembar daun jeruk"
- "1 lembar daun salam"
- "1 buah jeruk nipis"
- " Kecap manis"
- " Lada bubuk"
- " Garam"
- " Gula"
recipeinstructions:
- "Bersihkan ayam, dibawah air mengalir, goreng sebentar"
- "Haluskan semua bumbu kecuali sereh dan daun salam"
- "Panaskan minyak, tumis bumbu yang sudah diuleg kemudian tambahkan sereh dan daun salam, memarkan sereh dan remas remas daun salam ya"
- "Jika sudah tercium aroma sedap tambahkan air secukupnya hingga ayam terendam"
- "Jika sudah mendidih, tambahkan garam, lada bubuk, penyedap rasa, kecap dan gula"
- "Aduk rata hingga tercamput semua, tunggu hingga air menyusut.. Koreksi rasa dan sajikan dengan Cinta ❤"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 192 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/e631b4fd3eb1e1d4/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis atau renyah. Ciri makanan Nusantara ayam rica rica kemangi yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk warga luar yang berkunjung.


Kedekatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam rica rica kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama orang tua sudah menjadi budaya, Banyak yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang bisa anda praktekkan salah satunya ayam rica rica kemangi yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan gampang menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Harap siapkan 1/2 kg sayap ayam
1. Diperlukan  Bumbu uleg ;
1. Harus ada 3 siung bawang putih
1. Harap siapkan 6 siung bawang merah
1. Harus ada 1 tangkai sereh
1. Dibutuhkan 1,5 ruas kunyit
1. Dibutuhkan 1 ruas Jahe
1. Harap siapkan 1 ruas lengkuas
1. Dibutuhkan 1 sdt ketumbar
1. Harap siapkan 2 buah kemiri
1. Siapkan 5 butir merica
1. Diperlukan 2 lembar daun jeruk
1. Jangan lupa 1 lembar daun salam
1. Harap siapkan 1 buah jeruk nipis
1. Jangan lupa  Kecap manis
1. Harus ada  Lada bubuk
1. Tambah  Garam
1. Tambah  Gula




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica kemangi:

1. Bersihkan ayam, dibawah air mengalir, goreng sebentar
1. Haluskan semua bumbu kecuali sereh dan daun salam
1. Panaskan minyak, tumis bumbu yang sudah diuleg kemudian tambahkan sereh dan daun salam, memarkan sereh dan remas remas daun salam ya
1. Jika sudah tercium aroma sedap tambahkan air secukupnya hingga ayam terendam
1. Jika sudah mendidih, tambahkan garam, lada bubuk, penyedap rasa, kecap dan gula
1. Aduk rata hingga tercamput semua, tunggu hingga air menyusut.. Koreksi rasa dan sajikan dengan Cinta ❤




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
