---
description: "Panduan untuk menyiapakan Ayam rica-rica asam cikala Teruji"
title: "Panduan untuk menyiapakan Ayam rica-rica asam cikala Teruji"
slug: 432-panduan-untuk-menyiapakan-ayam-rica-rica-asam-cikala-teruji
date: 2020-12-01T02:01:49.281Z
image: https://img-global.cpcdn.com/recipes/5a0899cebb077a86/751x532cq70/ayam-rica-rica-asam-cikala-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5a0899cebb077a86/751x532cq70/ayam-rica-rica-asam-cikala-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5a0899cebb077a86/751x532cq70/ayam-rica-rica-asam-cikala-foto-resep-utama.jpg
author: Isabelle Hansen
ratingvalue: 4.8
reviewcount: 30835
recipeingredient:
- "1 ekor ayam kampung potong2 menjadi 6 bagian"
- "3 ikat daun kemangi ambil daunnya dan buang batangnya"
- "2 lembar daun salam"
- "4 lembar daun jeruk"
- "1 batang serai geprek"
- "3 batang daun bawangpre irisiris"
- "6 buah asam cikala jika tidak suka masam bisa dikurangi"
- " jeruk nipiscuka untuk mencuci ayam"
- "secukupnya air matang"
- "secukupnya garam"
- "secukupnya kaldu ayamsapijamur"
- "secukupnya gula"
- " bahan halus"
- "12 buah bawang merah"
- "6 buah bawang putih"
- "10 buah cabe merah keriting"
- "10 buah cabe rawit caplak"
- "1/2 butir kemiri"
- "1 ruas kunyit"
- "1 ruas lengkuas"
- "1 ruas jahe"
recipeinstructions:
- "Cuci semua bahan, jangan lupa cuci ayam dan baluri air jeruk/cuka lalu cuci dengan bersih lalu rebus ayam sebentar dan tiriskan"
- "Tumis bumbu halus, masukan serai daun salam daun jeruk dan asam cikala ke dalam wajan. aduk rata dan tumis sampai 1/2 matang"
- "Jika bumbu sudah 1/2 matang masukkan ayam, aduk2 sampai bumbu merata dan tambahkan air matang sambil menambahkan gula garam dan kaldu ayam/sapi/jamur. aduk rata semuanya, biarkan sampai mendidih"
- "Jika sudah mendidih dan meresap, masukkan daun bawang tunggu sampai matang sambil aduk masakan jika sudah mau sat kuahnya masukkan daun kemangi aduk hingga merata dan angkat 😊 selamat mencoba moms ❤️"
categories:
- Recipe
tags:
- ayam
- ricarica
- asam

katakunci: ayam ricarica asam 
nutrition: 246 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica-rica asam cikala](https://img-global.cpcdn.com/recipes/5a0899cebb077a86/751x532cq70/ayam-rica-rica-asam-cikala-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau renyah. Karasteristik kuliner Nusantara ayam rica-rica asam cikala yang kaya dengan bumbu memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah memasak Ayam rica-rica asam cikala untuk keluarga. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.

untuk kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian masakan yang dapat anda contoh salah satunya ayam rica-rica asam cikala yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam rica-rica asam cikala tanpa harus bersusah payah.
Seperti resep Ayam rica-rica asam cikala yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 21 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica-rica asam cikala:

1. Siapkan 1 ekor ayam kampung (potong2 menjadi 6 bagian)
1. Siapkan 3 ikat daun kemangi (ambil daunnya dan buang batangnya)
1. Harus ada 2 lembar daun salam
1. Jangan lupa 4 lembar daun jeruk
1. Tambah 1 batang serai (geprek)
1. Jangan lupa 3 batang daun bawang/pre (iris-iris)
1. Dibutuhkan 6 buah asam cikala (jika tidak suka masam bisa dikurangi)
1. Dibutuhkan  jeruk nipis/cuka (untuk mencuci ayam)
1. Diperlukan secukupnya air matang
1. Dibutuhkan secukupnya garam
1. Harus ada secukupnya kaldu ayam/sapi/jamur
1. Diperlukan secukupnya gula
1. Tambah  bahan halus
1. Siapkan 12 buah bawang merah
1. Harap siapkan 6 buah bawang putih
1. Tambah 10 buah cabe merah keriting
1. Siapkan 10 buah cabe rawit caplak
1. Diperlukan 1/2 butir kemiri
1. Jangan lupa 1 ruas kunyit
1. Diperlukan 1 ruas lengkuas
1. Dibutuhkan 1 ruas jahe




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica asam cikala:

1. Cuci semua bahan, jangan lupa cuci ayam dan baluri air jeruk/cuka lalu cuci dengan bersih lalu rebus ayam sebentar dan tiriskan
1. Tumis bumbu halus, masukan serai daun salam daun jeruk dan asam cikala ke dalam wajan. aduk rata dan tumis sampai 1/2 matang
1. Jika bumbu sudah 1/2 matang masukkan ayam, aduk2 sampai bumbu merata dan tambahkan air matang sambil menambahkan gula garam dan kaldu ayam/sapi/jamur. aduk rata semuanya, biarkan sampai mendidih
1. Jika sudah mendidih dan meresap, masukkan daun bawang tunggu sampai matang sambil aduk masakan jika sudah mau sat kuahnya masukkan daun kemangi aduk hingga merata dan angkat 😊 selamat mencoba moms ❤️




Demikianlah cara membuat ayam rica-rica asam cikala yang mudah dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan teruji, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
