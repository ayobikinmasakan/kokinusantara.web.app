---
description: "Step-by-Step untuk membuat Ayam Rica Rica Kemangi Pedas Favorite"
title: "Step-by-Step untuk membuat Ayam Rica Rica Kemangi Pedas Favorite"
slug: 302-step-by-step-untuk-membuat-ayam-rica-rica-kemangi-pedas-favorite
date: 2021-01-18T19:04:33.284Z
image: https://img-global.cpcdn.com/recipes/f3c0b0e15b3eccba/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f3c0b0e15b3eccba/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f3c0b0e15b3eccba/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg
author: Mollie Reyes
ratingvalue: 4.8
reviewcount: 30835
recipeingredient:
- "6 Potong Ayam"
- "2 ikat daun kemangi"
recipeinstructions:
- "Potong Ayam menjadi 6 bagian"
- "Didihkan air Rebus ayam selama 10 menit supaya empuk dan agak lunak dan tambahkan sedikit jahe di geprek agar ayam tidak terlalu amis"
- "Bumbu Pelengkap : Daun Salam 2 lembar, Daun jeruk 2 lembar, lenkuas seruas jari di geprek, jahe seruas jari, daun sereh 2 ruas di geprek, kunyit 1 ruas jari di bakar, Bahan Bahan Dihaluskan : Cabai keriting 7 pcs cabai rawit 10 pcs bawang merah 9 siung bawang putih 3 siung kemiri 4 di sangrai ketumbar di sangrai merica bubuk masako ayam mecin garam gula"
- "Tumis bumbu yang sudah di haluskan sampai sudah tercium wangi aroma nya kemudian masukan ayam yang sudah di rebus beri sedikt air tambahkan bumbu penyedap setelah itu koreksi rasa"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 112 calories
recipecuisine: American
preptime: "PT16M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica Rica Kemangi Pedas](https://img-global.cpcdn.com/recipes/f3c0b0e15b3eccba/751x532cq70/ayam-rica-rica-kemangi-pedas-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas atau empuk. Ciri khas kuliner Nusantara ayam rica rica kemangi pedas yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan keluarga dapat diperoleh dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica Rica Kemangi Pedas untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di tempat lain.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis makanan yang dapat anda coba salah satunya ayam rica rica kemangi pedas yang merupakan resep terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica rica kemangi pedas tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Rica Kemangi Pedas yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 2 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi Pedas:

1. Siapkan 6 Potong Ayam
1. Diperlukan 2 ikat daun kemangi




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Rica Kemangi Pedas:

1. Potong Ayam menjadi 6 bagian
1. Didihkan air Rebus ayam selama 10 menit supaya empuk dan agak lunak dan tambahkan sedikit jahe di geprek agar ayam tidak terlalu amis
1. Bumbu Pelengkap : Daun Salam 2 lembar, Daun jeruk 2 lembar, lenkuas seruas jari di geprek, jahe seruas jari, daun sereh 2 ruas di geprek, kunyit 1 ruas jari di bakar, Bahan Bahan Dihaluskan : Cabai keriting 7 pcs cabai rawit 10 pcs bawang merah 9 siung bawang putih 3 siung kemiri 4 di sangrai ketumbar di sangrai merica bubuk masako ayam mecin garam gula
1. Tumis bumbu yang sudah di haluskan sampai sudah tercium wangi aroma nya kemudian masukan ayam yang sudah di rebus beri sedikt air tambahkan bumbu penyedap setelah itu koreksi rasa




Demikianlah cara membuat ayam rica rica kemangi pedas yang sederhana dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan teruji, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
