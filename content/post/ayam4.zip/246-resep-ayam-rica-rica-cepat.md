---
description: "Resep : Ayam rica rica Cepat"
title: "Resep : Ayam rica rica Cepat"
slug: 246-resep-ayam-rica-rica-cepat
date: 2020-09-18T14:30:04.356Z
image: https://img-global.cpcdn.com/recipes/881d8955290939a2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/881d8955290939a2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/881d8955290939a2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Caroline Dawson
ratingvalue: 4.5
reviewcount: 46867
recipeingredient:
- "1/2 kg ayam"
- "1 Iket kemangi"
- " Bumbu ulek"
- " 5 buah bawang merah"
- "2 buah bawang putih"
- "5 buah cabe merah besar"
- "2 buah kemiri sangrai"
- " Jahe"
- " Bumbu geprekcemplung"
- " Lengkuasserehdaun salamdaun jeruk"
- " Garamgulpaspenyedap"
recipeinstructions:
- "Cuci bersih ayam, marinasi dengan garam dan kunyit bubuk,diamkan 10 menit,sambil kita siapkan bumbu bumbu"
- "Goreng ayam setengah matang,angkat tiriskan"
- "Ulek bumbu halus, lalu tumis hingga harum,tambahkan daun salam,daun jeruk,salam,sereh,lengkuas, garam,gula, penyedap"
- "Kemudian masukin ayam, beri sedikit air,aduk rata masak hingga air menyusut"
- "Kemudian masukan daun kemangi,aduk rata lalu angkat dan hidangkan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 236 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam rica rica](https://img-global.cpcdn.com/recipes/881d8955290939a2/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga gurih. Ciri khas masakan Indonesia ayam rica rica yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kehangatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Ayam rica rica untuk orang di rumah bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis resep yang bisa anda praktekkan salah satunya ayam rica rica yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya sekarang ini kamu bisa dengan mudah menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam rica rica yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 11 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica rica:

1. Jangan lupa 1/2 kg ayam
1. Harap siapkan 1 Iket kemangi
1. Harap siapkan  Bumbu ulek
1. Harus ada  5 buah bawang merah
1. Tambah 2 buah bawang putih
1. Siapkan 5 buah cabe merah besar
1. Dibutuhkan 2 buah kemiri sangrai
1. Siapkan  Jahe
1. Harus ada  Bumbu geprek/cemplung
1. Dibutuhkan  Lengkuas,sereh,daun salam,daun jeruk
1. Harap siapkan  Garam,gulpas,penyedap




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica:

1. Cuci bersih ayam, marinasi dengan garam dan kunyit bubuk,diamkan 10 menit,sambil kita siapkan bumbu bumbu
1. Goreng ayam setengah matang,angkat tiriskan
1. Ulek bumbu halus, lalu tumis hingga harum,tambahkan daun salam,daun jeruk,salam,sereh,lengkuas, garam,gula, penyedap
1. Kemudian masukin ayam, beri sedikit air,aduk rata masak hingga air menyusut
1. Kemudian masukan daun kemangi,aduk rata lalu angkat dan hidangkan




Demikianlah cara membuat ayam rica rica yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
