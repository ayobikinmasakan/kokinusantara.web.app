---
description: "Panduan menyiapakan Ayam rica-rica kemangi Luar biasa"
title: "Panduan menyiapakan Ayam rica-rica kemangi Luar biasa"
slug: 264-panduan-menyiapakan-ayam-rica-rica-kemangi-luar-biasa
date: 2020-12-07T21:37:53.907Z
image: https://img-global.cpcdn.com/recipes/236fcd038fbb6a4c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/236fcd038fbb6a4c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/236fcd038fbb6a4c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Elijah Young
ratingvalue: 4.8
reviewcount: 11864
recipeingredient:
- "1/2 ekor ayam"
- "3 ikat daun kemangi"
- "2 lembar daun salam 1 lembar umenumis 1 lemar u di ungkep"
- "5 lemar daun jeruk 3 umenumis 2 u di ungkep"
- "2 batang sereh geprek 1 umenumis 1 udi ungkep"
- "1 buah kunyit"
- "1 buah jahe"
- " BUMBU HALUS "
- "20 buah cabai jablay"
- "10 siung bawang putih"
- "3 siung bawang putih"
- "3 buah kemiri"
- "Sedikit kencur"
- "1 buah tomat"
- " Penyedap rasa garam gula micin kaldu ayam"
recipeinstructions:
- "Ungkep ayam kurang lebih 20menit sampai ayam empuk"
- "Lalu goreng ayam stengah matang"
- "Tumis semua bumbu halus sampai wangi masukan daun jeruk, daun salam, sereh dan tomat tambahkan sedikit air sisa rebusan tadi"
- "Lalu masukan ayam aduk-aduk tambahkan penyedap rasa (garam, gula, micin, kaldu ayam)"
- "Masak ayam sampai air nya menyusut lalu terakhir masukan kemangi"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 202 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/236fcd038fbb6a4c/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang harus kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan tekstur yang berbeda, seperti ayam rica-rica kemangi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan keistimewahan yang merupakan keragaman Indonesia

Keharmonisan keluarga bisa didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam rica-rica kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari masakan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian resep yang bisa anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 15 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Siapkan 1/2 ekor ayam
1. Jangan lupa 3 ikat daun kemangi
1. Diperlukan 2 lembar daun salam (1 lembar u/menumis, 1 lemar u/ di ungkep
1. Jangan lupa 5 lemar daun jeruk (3 u/menumis, 2 u/ di ungkep)
1. Tambah 2 batang sereh geprek (1 u/menumis, 1 u/di ungkep)
1. Dibutuhkan 1 buah kunyit
1. Dibutuhkan 1 buah jahe
1. Jangan lupa  BUMBU HALUS :
1. Diperlukan 20 buah cabai jablay
1. Tambah 10 siung bawang putih
1. Harap siapkan 3 siung bawang putih
1. Harus ada 3 buah kemiri
1. Dibutuhkan Sedikit kencur
1. Harap siapkan 1 buah tomat
1. Jangan lupa  Penyedap rasa (garam, gula, micin, kaldu ayam)




<!--inarticleads2-->

##### Cara membuat  Ayam rica-rica kemangi:

1. Ungkep ayam kurang lebih 20menit sampai ayam empuk
1. Lalu goreng ayam stengah matang
1. Tumis semua bumbu halus sampai wangi masukan daun jeruk, daun salam, sereh dan tomat tambahkan sedikit air sisa rebusan tadi
1. Lalu masukan ayam aduk-aduk tambahkan penyedap rasa (garam, gula, micin, kaldu ayam)
1. Masak ayam sampai air nya menyusut lalu terakhir masukan kemangi




Demikianlah cara membuat ayam rica-rica kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat mudah dan teruji, anda bisa menelusuri di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
