---
description: "Cara singkat menyiapakan Ayam rica rica kemangi Homemade"
title: "Cara singkat menyiapakan Ayam rica rica kemangi Homemade"
slug: 310-cara-singkat-menyiapakan-ayam-rica-rica-kemangi-homemade
date: 2020-09-19T05:59:47.722Z
image: https://img-global.cpcdn.com/recipes/31b25ff97e88ea6d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/31b25ff97e88ea6d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/31b25ff97e88ea6d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Herbert White
ratingvalue: 4.2
reviewcount: 7280
recipeingredient:
- "1 ekor ayam"
- " Bumbu halus"
- "15 cabai rawit merah"
- "10 cabai merah keriting"
- "10 siung bawang merah"
- "6 siung bawang putih"
- "4 butir kemiri"
- "2 cm jahe"
- "2 cm kunyit"
- "5 lembar daun jeruk"
- "4 lembar daun salam"
- "3 ikat kemangi"
- "2 serai memarkan"
recipeinstructions:
- "Potong daging ayam sesuai selera beri garam dan perasan jeruk nipis lalu cuci bersih"
- "Goreng ayam sampai berwarna kecokelatan 1/2 matang jangan sampai kering"
- "Tumis bumbu halus masukkan serai, daun jeruk,dan daun salam aduk2 sampai tercium harum lalu masukkan ayam aduk rata beri garam, gula dan penyedap dan beri air secukupnya"
- ""
- "Tunggu sampai mendidih dengan api sedang masak sampai ayam empuk, koreksi rasa Lalu masukkn daun kemangi"
- "Ayam rica rica kemangi siap dihidangkan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 178 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/31b25ff97e88ea6d/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang manis,pedas dan gurih. Ciri khas kuliner Indonesia ayam rica rica kemangi yang kaya dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga bisa didapat dengan cara simple. Diantaranya adalah memasak Ayam rica rica kemangi untuk orang di rumah bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang bisa anda buat salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang gampang dengan varian sederhana. Untungnya saat ini anda dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 13 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Siapkan 1 ekor ayam
1. Harap siapkan  Bumbu halus
1. Harus ada 15 cabai rawit merah
1. Dibutuhkan 10 cabai merah keriting
1. Tambah 10 siung bawang merah
1. Dibutuhkan 6 siung bawang putih
1. Harap siapkan 4 butir kemiri
1. Siapkan 2 cm jahe
1. Siapkan 2 cm kunyit
1. Tambah 5 lembar daun jeruk
1. Jangan lupa 4 lembar daun salam
1. Jangan lupa 3 ikat kemangi
1. Harap siapkan 2 serai memarkan


Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam rica rica kemangi:

1. Potong daging ayam sesuai selera beri garam dan perasan jeruk nipis lalu cuci bersih
1. Goreng ayam sampai berwarna kecokelatan - 1/2 matang jangan sampai kering
1. Tumis bumbu halus masukkan serai, daun jeruk,dan daun salam aduk2 sampai tercium harum lalu masukkan ayam aduk rata beri garam, gula dan penyedap dan beri air secukupnya
1. 
1. Tunggu sampai mendidih dengan api sedang masak sampai ayam empuk, koreksi rasa - Lalu masukkn daun kemangi
1. Ayam rica rica kemangi siap dihidangkan


Yuk, simak resep dan cara membuat ayam rica kemangi di bawah ini! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Siapa yang tidak mengenal lalapan daun kemangi di Indonesia ini. Ayam Rica-Rica tanpa Kemangi. Для просмотра онлайн кликните на видео ⤵. 

Demikianlah cara membuat ayam rica rica kemangi yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan terbukti, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
