---
description: "Steps untuk menyiapakan Ayam Rica Kemangi Favorite"
title: "Steps untuk menyiapakan Ayam Rica Kemangi Favorite"
slug: 270-steps-untuk-menyiapakan-ayam-rica-kemangi-favorite
date: 2020-11-21T05:06:32.155Z
image: https://img-global.cpcdn.com/recipes/917ddee9ca5aeb2f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/917ddee9ca5aeb2f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/917ddee9ca5aeb2f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Susan Scott
ratingvalue: 4.4
reviewcount: 21362
recipeingredient:
- "2 potong ayam bagian dada saja"
- "Secukupnya daun kemangi"
- " Cabe rawit 5 buah potongpotong jadi 2 bagian saja"
- "3 cm jahe geprek"
- "3 cm lengkuas geprek"
- "1 gelas air matang"
- "Secukupnya merica bubuk gula pasir garam sesuai selera"
- " Bumbu halus uleg"
- "3 buah cabe keriting merah uleg kasar"
- "1 buah cabe merah besar uleg kasar"
- "5 siung bawang merah"
- "4 siung bawang putih"
recipeinstructions:
- "Potong ayam agak kecil kecil lalu rebus dg 1 bawang putih geprek dan 1/2 sdt garam, rebus sebentar lalu sisihkan"
- "Tumis bumbu halus dan cabe rawit sampai harum, tambah 1 gelas air matang, aduk rata"
- "Masukkan ayam yg sudah direbus tadi, aduk hingga tercampur bumbu, tambahkan merica, gula dan garam secukupnya (sesuai selera)"
- "Cek rasa apakah sudah pas atau belum, kalau belum bs tambah lagi gula/garam, jika sudah pas masukkan kemangi"
- "Tunggu hingga kemangi layu dan kuah menyusut, jika sudah matikan api lalu sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 165 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/917ddee9ca5aeb2f/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga renyah. Ciri khas masakan Indonesia ayam rica kemangi yang penuh dengan rempah-rempah membawa keberaragaman yang menjadi ciri budaya kita.


Keharmonisan rumah tangga bisa didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Kemangi untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak jenis resep yang dapat anda contoh salah satunya ayam rica kemangi yang merupakan resep favorite yang simpel dengan varian sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 12 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Harus ada 2 potong ayam bagian dada saja
1. Siapkan Secukupnya daun kemangi
1. Tambah  Cabe rawit 5 buah potong-potong jadi 2 bagian saja
1. Jangan lupa 3 cm jahe geprek
1. Diperlukan 3 cm lengkuas geprek
1. Diperlukan 1 gelas air matang
1. Siapkan Secukupnya merica bubuk, gula pasir, garam (sesuai selera)
1. Dibutuhkan  Bumbu halus uleg
1. Harus ada 3 buah cabe keriting merah uleg kasar
1. Siapkan 1 buah cabe merah besar uleg kasar
1. Jangan lupa 5 siung bawang merah
1. Harap siapkan 4 siung bawang putih




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Kemangi:

1. Potong ayam agak kecil kecil lalu rebus dg 1 bawang putih geprek dan 1/2 sdt garam, rebus sebentar lalu sisihkan
1. Tumis bumbu halus dan cabe rawit sampai harum, tambah 1 gelas air matang, aduk rata
1. Masukkan ayam yg sudah direbus tadi, aduk hingga tercampur bumbu, tambahkan merica, gula dan garam secukupnya (sesuai selera)
1. Cek rasa apakah sudah pas atau belum, kalau belum bs tambah lagi gula/garam, jika sudah pas masukkan kemangi
1. Tunggu hingga kemangi layu dan kuah menyusut, jika sudah matikan api lalu sajikan




Demikianlah cara membuat ayam rica kemangi yang sederhana dan teruji. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
