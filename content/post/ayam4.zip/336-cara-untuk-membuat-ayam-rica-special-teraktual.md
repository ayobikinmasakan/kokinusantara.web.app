---
description: "Cara untuk membuat Ayam rica special teraktual"
title: "Cara untuk membuat Ayam rica special teraktual"
slug: 336-cara-untuk-membuat-ayam-rica-special-teraktual
date: 2020-09-05T17:01:14.201Z
image: https://img-global.cpcdn.com/recipes/de2cff17d10e7e27/751x532cq70/ayam-rica-special-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/de2cff17d10e7e27/751x532cq70/ayam-rica-special-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/de2cff17d10e7e27/751x532cq70/ayam-rica-special-foto-resep-utama.jpg
author: Evelyn Wheeler
ratingvalue: 4.4
reviewcount: 2233
recipeingredient:
- "2 potong ayam di rebus dulu ya bund"
- "1 sere di geprek"
- "secukupnya Kemangi"
- "1 ruas lengkuas di geprek"
- " Bumbu halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "10 cabe rawit kecil"
- "1 ruas kunyit"
- "1/2 ruas jahe"
- "2 kemiri"
- " Bumbu pelengkap"
- " Garam masako kecap saori gula pasir secukupnya semua"
recipeinstructions:
- "Tumis bumbu halus, tumis sampai harum masukkan sere, lengkuas dan ayam, tunggu sampai harum."
- "Masukkan sedikit air, masukan bumbu pelengkap, tunggu air menyusut dan koreksi rasa."
- "Terakhir masukan kemangi, jika rasa sudah pas, tunggu kemangi layu lalu sajikan."
- "Jangan lupa pakai taburan cinta ya bun, biar suami dan putra putri makin lahap 😁 canda ya bund 🤭"
categories:
- Recipe
tags:
- ayam
- rica
- special

katakunci: ayam rica special 
nutrition: 224 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT31M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam rica special](https://img-global.cpcdn.com/recipes/de2cff17d10e7e27/751x532cq70/ayam-rica-special-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau enak. Ciri kuliner Nusantara ayam rica special yang penuh dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kehangatan rumah tangga dapat ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam rica special untuk orang di rumah. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda praktekkan salah satunya ayam rica special yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica special tanpa harus bersusah payah.
Seperti resep Ayam rica special yang bisa anda coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 13 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica special:

1. Harap siapkan 2 potong ayam (di rebus dulu ya bund)
1. Diperlukan 1 sere di geprek
1. Harus ada secukupnya Kemangi
1. Tambah 1 ruas lengkuas di geprek
1. Harap siapkan  Bumbu halus
1. Jangan lupa 5 siung bawang merah
1. Jangan lupa 3 siung bawang putih
1. Jangan lupa 10 cabe rawit kecil
1. Harap siapkan 1 ruas kunyit
1. Tambah 1/2 ruas jahe
1. Tambah 2 kemiri
1. Harap siapkan  Bumbu pelengkap
1. Jangan lupa  Garam, masako, kecap, saori, gula pasir (secukupnya semua)




<!--inarticleads2-->

##### Langkah membuat  Ayam rica special:

1. Tumis bumbu halus, tumis sampai harum masukkan sere, lengkuas dan ayam, tunggu sampai harum.
1. Masukkan sedikit air, masukan bumbu pelengkap, tunggu air menyusut dan koreksi rasa.
1. Terakhir masukan kemangi, jika rasa sudah pas, tunggu kemangi layu lalu sajikan.
1. Jangan lupa pakai taburan cinta ya bun, biar suami dan putra putri makin lahap 😁 canda ya bund 🤭




Demikianlah cara membuat ayam rica special yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa menelusuri di website kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
