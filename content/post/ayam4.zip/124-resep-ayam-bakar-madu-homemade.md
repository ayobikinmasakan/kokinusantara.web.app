---
description: "Resep : Ayam Bakar Madu Homemade"
title: "Resep : Ayam Bakar Madu Homemade"
slug: 124-resep-ayam-bakar-madu-homemade
date: 2020-09-22T07:57:59.062Z
image: https://img-global.cpcdn.com/recipes/84b962a5d8b9034c/751x532cq70/ayam-bakar-madu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/84b962a5d8b9034c/751x532cq70/ayam-bakar-madu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/84b962a5d8b9034c/751x532cq70/ayam-bakar-madu-foto-resep-utama.jpg
author: Nicholas Vega
ratingvalue: 4.8
reviewcount: 3324
recipeingredient:
- "6 potong paha ayam kucuri jeruk nipis cuci bersih"
- "300 ml air"
- "100 ml santan kental instan"
- " Bumbu halus"
- "7 butir bawang merah"
- "6 butir bawang putih"
- "4 butir kemiri sangrai"
- "1 sdm ketumbar bubuk"
- "1 sdt kunyit bubuk"
- " Bumbu cemplung"
- "2 cm lengkuas"
- "1 batang serai"
- "3 lembar daun salam"
- "4 lembar daun jeruk buang tulang daun"
- "2 sdm air asam jawa pekat"
- "3-5 sdm madu"
- "Secukupnya garam gula merah kecap manis"
- "2 cm jahe tambahan saya"
- " Pelengkap"
- " Lalapan"
- " Sambal"
recipeinstructions:
- "Tumis bumbu halus dan bumbu cemplung hingga harum. Tambahkan air dan santan. Masak dengan api sedang-kecil hingga air berkurang 1/3nya dan bumbu mengental. Kemudian masukkan ayam. Masak hingga air menyusut dan ayam matang menyerap bumbu. Sisihkan sisa bumbu untuk olesan ketika memanggang. Saya tambahkan tempe juga ketika mengungkep ayamnya. Simpan ayam diwadah kedap udara utk selanjutnya disimpan dikulkas."
- "Panaskan teflon. Beri 1 sdm margarine. Panggang ayam sambil sesekali di balik dan di oles sisa bumbu. Angkat. Sajikan dengan lalapan dan sambal."
- "Sisa bumbunya saya gunakan untuk membuat ikan bakar keesokan harinya. So yummy 🤤"
categories:
- Recipe
tags:
- ayam
- bakar
- madu

katakunci: ayam bakar madu 
nutrition: 272 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Bakar Madu](https://img-global.cpcdn.com/recipes/84b962a5d8b9034c/751x532cq70/ayam-bakar-madu-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga gurih. Ciri masakan Indonesia ayam bakar madu yang penuh dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat didapat dengan cara mudah. Diantaranya adalah memasak Ayam Bakar Madu untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak jenis resep yang bisa anda coba salah satunya ayam bakar madu yang merupakan makanan favorite yang gampang dengan varian sederhana. Pasalnya saat ini kamu bisa dengan gampang menemukan resep ayam bakar madu tanpa harus bersusah payah.
Seperti resep Ayam Bakar Madu yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 21 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Bakar Madu:

1. Harap siapkan 6 potong paha ayam, kucuri jeruk nipis, cuci bersih
1. Harus ada 300 ml air
1. Jangan lupa 100 ml santan kental instan
1. Dibutuhkan  Bumbu halus
1. Tambah 7 butir bawang merah
1. Jangan lupa 6 butir bawang putih
1. Jangan lupa 4 butir kemiri, sangrai
1. Jangan lupa 1 sdm ketumbar bubuk
1. Jangan lupa 1 sdt kunyit bubuk
1. Tambah  Bumbu cemplung
1. Dibutuhkan 2 cm lengkuas
1. Jangan lupa 1 batang serai
1. Siapkan 3 lembar daun salam
1. Harap siapkan 4 lembar daun jeruk, buang tulang daun
1. Siapkan 2 sdm air asam jawa (pekat)
1. Dibutuhkan 3-5 sdm madu
1. Tambah Secukupnya garam, gula merah, kecap manis
1. Jangan lupa 2 cm jahe (tambahan saya)
1. Diperlukan  Pelengkap
1. Jangan lupa  Lalapan
1. Dibutuhkan  Sambal




<!--inarticleads2-->

##### Langkah membuat  Ayam Bakar Madu:

1. Tumis bumbu halus dan bumbu cemplung hingga harum. Tambahkan air dan santan. Masak dengan api sedang-kecil hingga air berkurang 1/3nya dan bumbu mengental. Kemudian masukkan ayam. Masak hingga air menyusut dan ayam matang menyerap bumbu. Sisihkan sisa bumbu untuk olesan ketika memanggang. Saya tambahkan tempe juga ketika mengungkep ayamnya. Simpan ayam diwadah kedap udara utk selanjutnya disimpan dikulkas.
1. Panaskan teflon. Beri 1 sdm margarine. Panggang ayam sambil sesekali di balik dan di oles sisa bumbu. Angkat. Sajikan dengan lalapan dan sambal.
1. Sisa bumbunya saya gunakan untuk membuat ikan bakar keesokan harinya. So yummy 🤤




Demikianlah cara membuat ayam bakar madu yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat simple dan teruji, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
