---
description: "Resep : Ayam Bakar Kurma Madu Sempurna"
title: "Resep : Ayam Bakar Kurma Madu Sempurna"
slug: 166-resep-ayam-bakar-kurma-madu-sempurna
date: 2020-08-24T12:12:37.857Z
image: https://img-global.cpcdn.com/recipes/0e0a675ec333e6e3/751x532cq70/ayam-bakar-kurma-madu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0e0a675ec333e6e3/751x532cq70/ayam-bakar-kurma-madu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0e0a675ec333e6e3/751x532cq70/ayam-bakar-kurma-madu-foto-resep-utama.jpg
author: Lulu Dennis
ratingvalue: 4.2
reviewcount: 26262
recipeingredient:
- "1 ekor ayam saya12 potong ayam"
- "660 ml air kelapa saya 5 sdm santan instan  700ml air"
- "50 g kurma cicang halus saya 60 gr"
- "2 sdm madu saya 4 sdm"
- "Secukupnya Kecap manis saya 20 ml"
- "secukupnya Garam saya 1  sdm"
- "3 lembar daun salam"
- "3 lembar Daun jeruk"
- "1 batang serai saya geprek"
- "2 cm Lengkuas saya geprek"
- " Bumbu Halus"
- "8 siung bawang merah saya 12 siung"
- "5 siung bawang putih saya 6 siung"
- "4 buah kemiri saya 5 buah"
- "1 sdm ketumbar bubuk saya 1  sdm ketumbar butiran"
- "1 sdt bubuk kunyit saya 3 cm kunyit fresh"
- " Bahan olesan"
- "Secukupnya margarin dicampur kecap manis sy tambahkan lg madu"
recipeinstructions:
- "Siapkan bahan-bahan"
- "Ulek/blender bumbu halus. Campurkan santan dengan air. Sisihkan."
- "Siapkan wajan untuk memasak. Masukan semua bumbu dan air yang sudah dicampur santan.Setelah mendidih, masukan ayam. Aduk rata. Ungkep sampai matang. Cicipi dan koreksi rasa."
- "Setelah kuah menyusut dan mengental matikan api."
- "Campur semua bahan olesan. Siapkan alat panggang, panggang sampai kecoklatan sambil dioles bahan olesan. Kalau saya panggang menggunakan teflon."
- "Sajikan bersama sambal favorit 🤩."
- "Selamat mencobaaa 🤗🥰."
categories:
- Recipe
tags:
- ayam
- bakar
- kurma

katakunci: ayam bakar kurma 
nutrition: 125 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Bakar Kurma Madu](https://img-global.cpcdn.com/recipes/0e0a675ec333e6e3/751x532cq70/ayam-bakar-kurma-madu-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas dan empuk. Ciri khas kuliner Nusantara ayam bakar kurma madu yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.




Kedekatan rumah tangga dapat ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam Bakar Kurma Madu untuk orang di rumah. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak varian resep yang dapat anda contoh salah satunya ayam bakar kurma madu yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu bisa dengan mudah menemukan resep ayam bakar kurma madu tanpa harus bersusah payah.
Berikut ini resep Ayam Bakar Kurma Madu yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 18 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Bakar Kurma Madu:

1. Siapkan 1 ekor ayam (saya12 potong ayam)
1. Tambah 660 ml air kelapa (saya 5 sdm santan instan + 700ml air)
1. Tambah 50 g kurma, cicang halus (saya 60 gr)
1. Jangan lupa 2 sdm madu (saya 4 sdm)
1. Diperlukan Secukupnya Kecap manis (saya 20 ml)
1. Jangan lupa secukupnya Garam (saya 1 ½ sdm)
1. Harus ada 3 lembar daun salam
1. Harap siapkan 3 lembar Daun jeruk
1. Jangan lupa 1 batang serai (saya geprek)
1. Dibutuhkan 2 cm Lengkuas (saya geprek)
1. Harap siapkan  🍀Bumbu Halus🍀
1. Harus ada 8 siung bawang merah (saya 12 siung)
1. Tambah 5 siung bawang putih (saya 6 siung)
1. Siapkan 4 buah kemiri (saya 5 buah)
1. Harus ada 1 sdm ketumbar bubuk (saya 1 ½ sdm ketumbar butiran)
1. Jangan lupa 1 sdt bubuk kunyit (saya 3 cm kunyit fresh)
1. Jangan lupa  🍀Bahan olesan🍀
1. Harap siapkan Secukupnya margarin dicampur kecap manis (sy tambahkan lg madu)




<!--inarticleads2-->

##### Langkah membuat  Ayam Bakar Kurma Madu:

1. Siapkan bahan-bahan
1. Ulek/blender bumbu halus. Campurkan santan dengan air. Sisihkan.
1. Siapkan wajan untuk memasak. Masukan semua bumbu dan air yang sudah dicampur santan.Setelah mendidih, masukan ayam. Aduk rata. Ungkep sampai matang. Cicipi dan koreksi rasa.
1. Setelah kuah menyusut dan mengental matikan api.
1. Campur semua bahan olesan. Siapkan alat panggang, panggang sampai kecoklatan sambil dioles bahan olesan. Kalau saya panggang menggunakan teflon.
1. Sajikan bersama sambal favorit 🤩.
1. Selamat mencobaaa 🤗🥰.




Demikianlah cara membuat ayam bakar kurma madu yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat mudah dan teruji, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
