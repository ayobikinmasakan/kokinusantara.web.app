---
description: "Steps untuk menyiapakan Ayam Rica-rica Kemangi Sempurna"
title: "Steps untuk menyiapakan Ayam Rica-rica Kemangi Sempurna"
slug: 457-steps-untuk-menyiapakan-ayam-rica-rica-kemangi-sempurna
date: 2020-09-26T22:27:52.104Z
image: https://img-global.cpcdn.com/recipes/a7810060acd15532/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a7810060acd15532/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a7810060acd15532/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Raymond Palmer
ratingvalue: 5
reviewcount: 10602
recipeingredient:
- "1/4 Daging ayam"
- " Daun Kemangi"
- "2 siung bawang merah"
- "2 siung bawang putih"
- "1 ruas jahe"
- "1 ruas kunyit"
- "4 buah Kemiri"
- "5 buah cabe merah keriting"
- "3 buah cabe rawit merah"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 batang sereh digeprek"
- "1 buah jeruk nipis"
- "1 sdt garam"
- "2 sdt kaldu bubuk"
- "1/4 Bks lada bubuk"
- "4 sdm minyak goreng"
- "secukupnya Air"
recipeinstructions:
- "Potong ayam menjaji 4 bagian"
- "Marinasi ayam menggunakan jeruk nipis dan sedikit garam, diamkan selama 10 menit."
- "Tambahkan air, dan ungkep ayam sebentar. Jika sudah terlihat matang sisihkan (air kaldunya simpan)"
- "Haluskan bawang merah, bawang putih, kemiri, kunyit, jahe, cabe merah dan cabe rawit."
- "Panaskan wajan, dan tumis bumbu beserta sereh, daun salam dan daun jeruk sampe harum."
- "Masukan air kaldu yang tadi di simpan, setelah mendidih masukan ayam. Masukan juga bumbu penyedap seperti, garam, kaldu bubuk dan merica."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 249 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT59M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/a7810060acd15532/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai citarasa dari masakan yang manis,pedas atau renyah. Ciri masakan Nusantara ayam rica-rica kemangi yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan rumah tangga dapat didapat dengan cara simple. Salah satunya adalah memasak Ayam Rica-rica Kemangi untuk keluarga bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak varian resep yang bisa anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan favorite yang simpel dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica-rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi:

1. Dibutuhkan 1/4 Daging ayam
1. Jangan lupa  Daun Kemangi
1. Tambah 2 siung bawang merah
1. Jangan lupa 2 siung bawang putih
1. Jangan lupa 1 ruas jahe
1. Harus ada 1 ruas kunyit
1. Tambah 4 buah Kemiri
1. Harap siapkan 5 buah cabe merah keriting
1. Jangan lupa 3 buah cabe rawit merah
1. Dibutuhkan 2 lembar daun salam
1. Dibutuhkan 2 lembar daun jeruk
1. Harap siapkan 1 batang sereh (digeprek)
1. Harus ada 1 buah jeruk nipis
1. Harus ada 1 sdt garam
1. Harap siapkan 2 sdt kaldu bubuk
1. Harap siapkan 1/4 Bks lada bubuk
1. Dibutuhkan 4 sdm minyak goreng
1. Harus ada secukupnya Air




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-rica Kemangi:

1. Potong ayam menjaji 4 bagian
1. Marinasi ayam menggunakan jeruk nipis dan sedikit garam, diamkan selama 10 menit.
1. Tambahkan air, dan ungkep ayam sebentar. Jika sudah terlihat matang sisihkan (air kaldunya simpan)
1. Haluskan bawang merah, bawang putih, kemiri, kunyit, jahe, cabe merah dan cabe rawit.
1. Panaskan wajan, dan tumis bumbu beserta sereh, daun salam dan daun jeruk sampe harum.
1. Masukan air kaldu yang tadi di simpan, setelah mendidih masukan ayam. Masukan juga bumbu penyedap seperti, garam, kaldu bubuk dan merica.




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat simple dan teruji, anda bisa menemukan di halaman kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
