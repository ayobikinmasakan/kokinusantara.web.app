---
description: "Resep : Ayam Rica Rica Kemangi Teruji"
title: "Resep : Ayam Rica Rica Kemangi Teruji"
slug: 404-resep-ayam-rica-rica-kemangi-teruji
date: 2021-01-09T00:31:19.823Z
image: https://img-global.cpcdn.com/recipes/1d1e8a7c5727d3a1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1d1e8a7c5727d3a1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1d1e8a7c5727d3a1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Adrian Glover
ratingvalue: 4.3
reviewcount: 42315
recipeingredient:
- "1 ekor ayam Potong2"
- "1 iket kemangi"
- "2 sdm perasan jeruk nipis"
- "1 buah tomat"
- " Bumbu Halus"
- "10 cabe rawit setan"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "4 buah kemiri"
- "2 ruas kunyit"
- "1 ruas jahe"
- " Bumbu Pelengkap"
- "2 lbr daun salam"
- "2 lbr sereh"
- "1 ruas lengkuas"
- "2 lbr daun jeruk"
- "1 sdm kecap"
- " Minyak utk menumis"
- "secukupnya Merica garam penyedap gula"
recipeinstructions:
- "Ayam yg tlah dipotong2 cuci bersih, lumuri perasan jeruk nipis. Sisihkan.."
- "Siapkan wajan beri minyak secukupnya, tumis bumbu halus hingga harus. Masukan salam, sereh, daun jeruk, lengkuas digeprek,"
- "Masukan ayam, tambahkan sedikit air, masukan bumbu pelengkap, merica, garam, kecap, gula, penyedap. Aduk2,, biarkan matang dan air sedikit menyusut."
- "Setelah ayam empuk, cek rasa, masukan kemangi dan tomat yg sudah diiris jd 6. aduk sebentar, angkat sajikan. Selamat mencoba.. 😊👩‍🍳👩‍🍳"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 222 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/1d1e8a7c5727d3a1/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Makanan adalah salah satu warisan budaya yang harus kita lestarikan karena setiap area memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica rica kemangi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan keistimewahan yang merupakan keragaman Kita



Kedekatan rumah tangga dapat didapat dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Rica Rica Kemangi untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di kampung halaman mereka.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang dapat anda contoh salah satunya ayam rica rica kemangi yang merupakan makanan terkenal yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Dibutuhkan 1 ekor ayam. Potong2
1. Diperlukan 1 iket kemangi
1. Siapkan 2 sdm perasan jeruk nipis
1. Harap siapkan 1 buah tomat
1. Harap siapkan  Bumbu Halus
1. Harus ada 10 cabe rawit setan
1. Jangan lupa 8 siung bawang merah
1. Tambah 5 siung bawang putih
1. Diperlukan 4 buah kemiri
1. Dibutuhkan 2 ruas kunyit
1. Harus ada 1 ruas jahe
1. Harus ada  Bumbu Pelengkap
1. Harus ada 2 lbr daun salam
1. Harus ada 2 lbr sereh
1. Jangan lupa 1 ruas lengkuas
1. Tambah 2 lbr daun jeruk
1. Harus ada 1 sdm kecap
1. Diperlukan  Minyak utk menumis
1. Dibutuhkan secukupnya Merica, garam, penyedap, gula




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica Kemangi:

1. Ayam yg tlah dipotong2 cuci bersih, lumuri perasan jeruk nipis. Sisihkan..
1. Siapkan wajan beri minyak secukupnya, tumis bumbu halus hingga harus. Masukan salam, sereh, daun jeruk, lengkuas digeprek,
1. Masukan ayam, tambahkan sedikit air, masukan bumbu pelengkap, merica, garam, kecap, gula, penyedap. Aduk2,, biarkan matang dan air sedikit menyusut.
1. Setelah ayam empuk, cek rasa, masukan kemangi dan tomat yg sudah diiris jd 6. aduk sebentar, angkat sajikan. Selamat mencoba.. 😊👩‍🍳👩‍🍳




Demikianlah cara membuat ayam rica rica kemangi yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep rahasia yang sangat gampang dan teruji, anda bisa mencari di web kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
