---
description: "Steps untuk membuat Ayam Tepung Saus Madu Empuk Homemade"
title: "Steps untuk membuat Ayam Tepung Saus Madu Empuk Homemade"
slug: 214-steps-untuk-membuat-ayam-tepung-saus-madu-empuk-homemade
date: 2020-10-30T14:44:39.502Z
image: https://img-global.cpcdn.com/recipes/1ca6893633079b2b/751x532cq70/ayam-tepung-saus-madu-empuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1ca6893633079b2b/751x532cq70/ayam-tepung-saus-madu-empuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1ca6893633079b2b/751x532cq70/ayam-tepung-saus-madu-empuk-foto-resep-utama.jpg
author: Addie Martin
ratingvalue: 4.8
reviewcount: 28459
recipeingredient:
- " Bahan Ayam Tepung"
- "1 buah dada ayam utuh potong dadu"
- "2 siung bawah putih cincang halus"
- "8-10 sdm tepung terigu"
- "Secukupnya garam"
- "secukupnya Lada"
- "1 butir telur ayam"
- "8-10 sdm tepung terigu disesuaikan besar dada ayam"
- " Minyak untuk menggoreng ayam"
- " Bahan Saus"
- "3 siung bawang putih cincang halus"
- "6 sdm madu"
- "11/2 sdm saus tomat"
- "11/2 sdm kecap manis"
- "11/2 sdm saus tiram"
- "1 sdm gula pasir"
- "1 sdt royco ayam  totole kaldu jamur"
- " Minyak goreng untuk menumis"
- "Biji wijen secukupnya untuk toping"
recipeinstructions:
- "Dada ayam utuh direndam dalam air garam secukupnya dan didiamkan semalaman di kulkas agar empuk. Besoknya dipotong dadu lalu dicampur/dimarinasi dengan bawang putih, garam (sedikit aja) dan lada. Diamkan +/- 5 menit sampai bumbu meresap lalu masukkan ke kocokan telur dan tepung terigu lalu digoreng dengan api kecil agar daging ayam matang dalamnya lalu angkat."
- "Campur jadi satu madu, saus tomat, kecap manis, saus tiram, gula pasir dan royco/totole dalam mangkok."
- "Tumis bawang putih dengan sedikit minyak sampai harum lalu masukkan campuran saus tadi, tunggu hingga mengental lalu masukkan ayam tepung dan diaduk2, angkat dan taruh di piring saji. Taburkan biji wijen yang sudah disangrai sebagai toping. Masakan siap disajikan..🤗"
categories:
- Recipe
tags:
- ayam
- tepung
- saus

katakunci: ayam tepung saus 
nutrition: 239 calories
recipecuisine: American
preptime: "PT37M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Tepung Saus Madu Empuk](https://img-global.cpcdn.com/recipes/1ca6893633079b2b/751x532cq70/ayam-tepung-saus-madu-empuk-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang dapat kita lestarikan karena setiap daerah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam tepung saus madu empuk yang kami paparkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Kita

Keharmonisan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah membuat makanan Ayam Tepung Saus Madu Empuk untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis makanan yang dapat anda buat salah satunya ayam tepung saus madu empuk yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Untungnya sekarang ini anda bisa dengan mudah menemukan resep ayam tepung saus madu empuk tanpa harus bersusah payah.
Berikut ini resep Ayam Tepung Saus Madu Empuk yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Tepung Saus Madu Empuk:

1. Harus ada  Bahan Ayam Tepung
1. Harap siapkan 1 buah dada ayam utuh (potong dadu)
1. Siapkan 2 siung bawah putih (cincang halus)
1. Siapkan 8-10 sdm tepung terigu
1. Diperlukan Secukupnya garam
1. Harap siapkan secukupnya Lada
1. Diperlukan 1 butir telur ayam
1. Diperlukan 8-10 sdm tepung terigu (disesuaikan besar dada ayam)
1. Tambah  Minyak untuk menggoreng ayam
1. Siapkan  Bahan Saus
1. Tambah 3 siung bawang putih (cincang halus)
1. Harap siapkan 6 sdm madu
1. Harus ada 11/2 sdm saus tomat
1. Harap siapkan 11/2 sdm kecap manis
1. Harap siapkan 11/2 sdm saus tiram
1. Siapkan 1 sdm gula pasir
1. Diperlukan 1 sdt royco ayam / totole kaldu jamur
1. Dibutuhkan  Minyak goreng untuk menumis
1. Harap siapkan Biji wijen secukupnya (untuk toping)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Tepung Saus Madu Empuk:

1. Dada ayam utuh direndam dalam air garam secukupnya dan didiamkan semalaman di kulkas agar empuk. Besoknya dipotong dadu lalu dicampur/dimarinasi dengan bawang putih, garam (sedikit aja) dan lada. Diamkan +/- 5 menit sampai bumbu meresap lalu masukkan ke kocokan telur dan tepung terigu lalu digoreng dengan api kecil agar daging ayam matang dalamnya lalu angkat.
1. Campur jadi satu madu, saus tomat, kecap manis, saus tiram, gula pasir dan royco/totole dalam mangkok.
1. Tumis bawang putih dengan sedikit minyak sampai harum lalu masukkan campuran saus tadi, tunggu hingga mengental lalu masukkan ayam tepung dan diaduk2, angkat dan taruh di piring saji. Taburkan biji wijen yang sudah disangrai sebagai toping. Masakan siap disajikan..🤗




Demikianlah cara membuat ayam tepung saus madu empuk yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan cepat, anda bisa menemukan di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
