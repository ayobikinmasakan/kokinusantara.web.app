---
description: "Step-by-Step untuk membuat Ayam Madu Lemon Favorite"
title: "Step-by-Step untuk membuat Ayam Madu Lemon Favorite"
slug: 137-step-by-step-untuk-membuat-ayam-madu-lemon-favorite
date: 2020-10-30T01:46:00.161Z
image: https://img-global.cpcdn.com/recipes/6612acfad2e40bf8/751x532cq70/ayam-madu-lemon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6612acfad2e40bf8/751x532cq70/ayam-madu-lemon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6612acfad2e40bf8/751x532cq70/ayam-madu-lemon-foto-resep-utama.jpg
author: Lewis Holloway
ratingvalue: 4.4
reviewcount: 12053
recipeingredient:
- " Buat ayam tepung"
- "1/2 dada ayam potong kecilkecil"
- "1 butir telur kocok lepas"
- " Tepung terigu secukupnya aja buat balurin ayam"
- " Buat sausnya"
- "1/2 potong bawang bombay"
- "2 siung bawang putih"
- "2 sdm kecap manis"
- "3 sdm madu"
- "1 butir lemon diperas"
- "1 sdm tepung tapioka dilarutkan dengan sedikit air"
- "Secukupnya garam gula lada kaldu ayamsapi"
recipeinstructions:
- "Ayam yang saya gunakan kurang lebih sebanyak ini. Kita buat dahulu ayam tepungnya, ya. Setelah dipotong dan dicuci, ayam dilumuri kocokan telur (dicemplungin gapapa), kemudian guling-gulingin di atas tepung terigu, lalu goreng. Sampe garing lebih mantep."
- "Setelah matang semua ayamnya, sisihkan dahulu, ya."
- "Kemudian kita mulai masak sausnya. Tumis bawang putih dan bawang bombay sampai wangi. Saya pakai mentega biar harum, tapi pakai minyak juga ga masalah."
- "Setelah wangi, masukkan air lemon, kecap manis, garam, gula, lada, dan kaldu. Tunggu sebentar setelah itu masukkan madunya. Ingat tes rasa ya, kalau udah oke lanjutin deh."
- "Nah kalau udah pas rasanya, masukkan larutan tepung tapioka, aduk-aduk sebentar langsung masukkan ayam tepung tadi. Aduk deh sampai rata."
- "Alhamdulillah, udah beres. Selamat menikmati ya, Bun 🥰"
categories:
- Recipe
tags:
- ayam
- madu
- lemon

katakunci: ayam madu lemon 
nutrition: 292 calories
recipecuisine: American
preptime: "PT30M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Madu Lemon](https://img-global.cpcdn.com/recipes/6612acfad2e40bf8/751x532cq70/ayam-madu-lemon-foto-resep-utama.jpg)

Kekayaan adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis dan renyah. Ciri kuliner Indonesia ayam madu lemon yang kaya dengan bumbu memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah membuat makanan Ayam Madu Lemon untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi makanan yang bisa anda contoh salah satunya ayam madu lemon yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam madu lemon tanpa harus bersusah payah.
Seperti resep Ayam Madu Lemon yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Madu Lemon:

1. Tambah  Buat ayam tepung
1. Harus ada 1/2 dada ayam, potong kecil-kecil
1. Jangan lupa 1 butir telur (kocok lepas)
1. Tambah  Tepung terigu (secukupnya aja buat balurin ayam)
1. Jangan lupa  Buat sausnya
1. Dibutuhkan 1/2 potong bawang bombay
1. Harap siapkan 2 siung bawang putih
1. Tambah 2 sdm kecap manis
1. Harus ada 3 sdm madu
1. Diperlukan 1 butir lemon, diperas
1. Diperlukan 1 sdm tepung tapioka (dilarutkan dengan sedikit air)
1. Harap siapkan Secukupnya garam, gula, lada, kaldu ayam/sapi




<!--inarticleads2-->

##### Langkah membuat  Ayam Madu Lemon:

1. Ayam yang saya gunakan kurang lebih sebanyak ini. Kita buat dahulu ayam tepungnya, ya. Setelah dipotong dan dicuci, ayam dilumuri kocokan telur (dicemplungin gapapa), kemudian guling-gulingin di atas tepung terigu, lalu goreng. Sampe garing lebih mantep.
1. Setelah matang semua ayamnya, sisihkan dahulu, ya.
1. Kemudian kita mulai masak sausnya. Tumis bawang putih dan bawang bombay sampai wangi. Saya pakai mentega biar harum, tapi pakai minyak juga ga masalah.
1. Setelah wangi, masukkan air lemon, kecap manis, garam, gula, lada, dan kaldu. Tunggu sebentar setelah itu masukkan madunya. Ingat tes rasa ya, kalau udah oke lanjutin deh.
1. Nah kalau udah pas rasanya, masukkan larutan tepung tapioka, aduk-aduk sebentar langsung masukkan ayam tepung tadi. Aduk deh sampai rata.
1. Alhamdulillah, udah beres. Selamat menikmati ya, Bun 🥰




Demikianlah cara membuat ayam madu lemon yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep rahasia yang sangat mudah dan cepat, anda bisa mencari di situs kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
