---
description: "Resep : Opor Ayam Sempurna"
title: "Resep : Opor Ayam Sempurna"
slug: 496-resep-opor-ayam-sempurna
date: 2021-01-20T21:50:45.598Z
image: https://img-global.cpcdn.com/recipes/955e90051ca9d9b5/751x532cq70/opor-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/955e90051ca9d9b5/751x532cq70/opor-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/955e90051ca9d9b5/751x532cq70/opor-ayam-foto-resep-utama.jpg
author: Rachel Barker
ratingvalue: 4.4
reviewcount: 26376
recipeingredient:
- "6 potong ayam"
- "3 telur rebus"
- "3 daun salam"
- "1 batang serai"
- "5 daun jeruk"
- "2 ruas lengkuas"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya lada"
- "Secukupnya kaldu jamur  penyedap rasa ayam"
- "1,5 liter Air"
- "1/2 bungkus santan kemasan 65 ml"
- " Bumbu halus"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "4 butir kemiri"
- "2 ruas jahe"
- "2 sdt ketumbar bubuk"
- "3 sdt kunyit bubuk"
recipeinstructions:
- "Bersihkan ayam, rebus sebentar dg garam, kemudian tiriskan"
- "Rebus ayam kembali dengan air yang baru (1,5 L)"
- "Tumis bumbu halus hingga matang, masukan serai daun salam daun jeruk dan lengkuas. Aduk rata hingga wangi"
- "Masukan bumbu yang sudah di tumis ke dalam rebusan ayam, aduk rata. Tunggu hingga ayam empuk"
- "Masukan garam, gula, lada, kaldu jamur, penyedap rasa ayam, dan santan. Aduk rata lalu koreksi rasa"
- "Kemudian masukan telur rebus dan tunggu hingga air berkurang agar bumbu meresap"
- "Matikan kompor kemudian tambahkan bawang goreng"
categories:
- Recipe
tags:
- opor
- ayam

katakunci: opor ayam 
nutrition: 150 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT35M"
recipeyield: "3"
recipecategory: Dessert

---


![Opor Ayam](https://img-global.cpcdn.com/recipes/955e90051ca9d9b5/751x532cq70/opor-ayam-foto-resep-utama.jpg)

Kekayaan adat yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau gurih. Ciri khas makanan Indonesia opor ayam yang penuh dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.




Kedekatan rumah tangga dapat diperoleh dengan cara sederhana. Salah satunya adalah memasak Opor Ayam untuk orang di rumah. Momen makan bersama orang tua sudah menjadi budaya, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak varian makanan yang bisa anda contoh salah satunya opor ayam yang merupakan resep favorite yang mudah dengan varian sederhana. Untungnya saat ini anda bisa dengan cepat menemukan resep opor ayam tanpa harus bersusah payah.
Berikut ini resep Opor Ayam yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Opor Ayam:

1. Harus ada 6 potong ayam
1. Siapkan 3 telur rebus
1. Diperlukan 3 daun salam
1. Siapkan 1 batang serai
1. Siapkan 5 daun jeruk
1. Jangan lupa 2 ruas lengkuas
1. Jangan lupa Secukupnya garam
1. Diperlukan Secukupnya gula
1. Jangan lupa Secukupnya lada
1. Siapkan Secukupnya kaldu jamur + penyedap rasa ayam
1. Dibutuhkan 1,5 liter Air
1. Dibutuhkan 1/2 bungkus santan kemasan 65 ml
1. Siapkan  Bumbu halus:
1. Harus ada 8 siung bawang merah
1. Harap siapkan 4 siung bawang putih
1. Harus ada 4 butir kemiri
1. Siapkan 2 ruas jahe
1. Diperlukan 2 sdt ketumbar bubuk
1. Jangan lupa 3 sdt kunyit bubuk




<!--inarticleads2-->

##### Instruksi membuat  Opor Ayam:

1. Bersihkan ayam, rebus sebentar dg garam, kemudian tiriskan
1. Rebus ayam kembali dengan air yang baru (1,5 L)
1. Tumis bumbu halus hingga matang, masukan serai daun salam daun jeruk dan lengkuas. Aduk rata hingga wangi
1. Masukan bumbu yang sudah di tumis ke dalam rebusan ayam, aduk rata. Tunggu hingga ayam empuk
1. Masukan garam, gula, lada, kaldu jamur, penyedap rasa ayam, dan santan. Aduk rata lalu koreksi rasa
1. Kemudian masukan telur rebus dan tunggu hingga air berkurang agar bumbu meresap
1. Matikan kompor kemudian tambahkan bawang goreng




Demikianlah cara membuat opor ayam yang gampang dan teruji. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat gampang dan teruji, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
