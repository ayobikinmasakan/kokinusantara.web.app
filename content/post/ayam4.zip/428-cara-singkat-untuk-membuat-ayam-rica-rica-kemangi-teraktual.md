---
description: "Cara singkat untuk membuat Ayam rica rica kemangi teraktual"
title: "Cara singkat untuk membuat Ayam rica rica kemangi teraktual"
slug: 428-cara-singkat-untuk-membuat-ayam-rica-rica-kemangi-teraktual
date: 2020-11-20T10:58:36.515Z
image: https://img-global.cpcdn.com/recipes/c98f7dfccaab4e1a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c98f7dfccaab4e1a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c98f7dfccaab4e1a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Edna Ortiz
ratingvalue: 5
reviewcount: 9024
recipeingredient:
- "250 gr Ayam potong jadi 4 bagiangoreng sebentar"
- "2 cm lengkuasgeprek"
- "2 lembar daun salam"
- "3 lembar daun jeruk"
- "1 batang serai geprek"
- "segenggam daun kemangi"
- "2 sdt gula pasir"
- "1 sdt garam"
- "1/2 sdt Kaldu jamur"
- " Bumbu halus"
- "2 siung bawang putih"
- "5 siung bawang merah"
- "5 buah cabai rawit"
- "2 buah cabai besar"
- "2 cm kunyit"
- "1 cm jahe"
- "2 butir kemiri"
- "1/2 sdt merica bubuk"
- "1/2 sdt ketumbar bubuk"
recipeinstructions:
- "Tumis bumbu halus,masukkan daun jeruk,daun salam,lengkuas dan serai tumis sampai harum."
- "Masukkan ayam yang sudah digoreng tambahkan sedikit air aduk2."
- "Tambahkan garam,gula dan kaldu jamur aduk rata."
- "Masukkan daun kemangi masak sampai bumbu meresap.Angkat sajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 135 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica rica kemangi](https://img-global.cpcdn.com/recipes/c98f7dfccaab4e1a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah salah satu warisan budaya yang dapat kita jaga karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan aroma yang berbeda, seperti ayam rica rica kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara

Kehangatan keluarga dapat didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam rica rica kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak varian resep yang dapat anda buat salah satunya ayam rica rica kemangi yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini anda bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 19 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica kemangi:

1. Harus ada 250 gr Ayam, potong jadi 4 bagian,goreng sebentar
1. Harap siapkan 2 cm lengkuas,geprek
1. Harap siapkan 2 lembar daun salam
1. Diperlukan 3 lembar daun jeruk
1. Diperlukan 1 batang serai, geprek
1. Siapkan segenggam daun kemangi
1. Diperlukan 2 sdt gula pasir
1. Harus ada 1 sdt garam
1. Diperlukan 1/2 sdt Kaldu jamur
1. Harus ada  Bumbu halus
1. Tambah 2 siung bawang putih
1. Tambah 5 siung bawang merah
1. Dibutuhkan 5 buah cabai rawit
1. Harus ada 2 buah cabai besar
1. Harap siapkan 2 cm kunyit
1. Jangan lupa 1 cm jahe
1. Tambah 2 butir kemiri
1. Diperlukan 1/2 sdt merica bubuk
1. Dibutuhkan 1/2 sdt ketumbar bubuk




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica rica kemangi:

1. Tumis bumbu halus,masukkan daun jeruk,daun salam,lengkuas dan serai tumis sampai harum.
1. Masukkan ayam yang sudah digoreng tambahkan sedikit air aduk2.
1. Tambahkan garam,gula dan kaldu jamur aduk rata.
1. Masukkan daun kemangi masak sampai bumbu meresap.Angkat sajikan.




Demikianlah cara membuat ayam rica rica kemangi yang sederhana dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat simple dan terbukti, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
