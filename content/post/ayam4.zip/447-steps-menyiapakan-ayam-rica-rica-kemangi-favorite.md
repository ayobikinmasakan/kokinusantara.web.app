---
description: "Steps menyiapakan Ayam Rica-Rica Kemangi Favorite"
title: "Steps menyiapakan Ayam Rica-Rica Kemangi Favorite"
slug: 447-steps-menyiapakan-ayam-rica-rica-kemangi-favorite
date: 2020-09-24T14:51:28.711Z
image: https://img-global.cpcdn.com/recipes/5826f8570558c09a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5826f8570558c09a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5826f8570558c09a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Jim Love
ratingvalue: 4.8
reviewcount: 20520
recipeingredient:
- "7 potong ayam beri perasan jeruk nipis  garam diamkan 10 menit"
- "4 lembar daun jeruk"
- "2 lbr daun salam"
- "1 batang serai memarkan"
- "3 cm lengkuas memarkan"
- "1 ikat kecil kemangi"
- "8 gr kaldu jamur"
- "2 sdm kecap manis"
- "Secukupnya gula dan garam"
- "400 ml air"
- " Bumbu Halus"
- "5 bawang merah"
- "5 bawang putih"
- "2 kemiri"
- "10 cabe rawit"
- "5 cabe merah"
- "1/2 sdt merica"
- "3 cm kunyit"
- "2 cm jahe"
recipeinstructions:
- "Tumis bumbu halus dg sedikit minyak, masukkan daun jeruk, daun salam, serai dan lengkuas. Tumis sampai harum kemudian masukkan garam, gula dan kaldu jamur aduk sampai rata."
- "Masukkan ayam sampai ayam terlumuri rata dg bumbu, tambahkan air dan kecap aduk lagi kemudian tutup. Masak dg api kecil tunggu sampai bumbu meresap dan ayam matang."
- "Terakhir masukkan kemangi, aduk sebentar. Matikan api, angkat dan sajikan."
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 103 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica-Rica Kemangi](https://img-global.cpcdn.com/recipes/5826f8570558c09a/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah warisan budaya yang harus kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica-rica kemangi yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara

Ayam, bahan makanan yang sering kita temui sehari hari ini memang bisa dijadikan berbagai macam variasi masakan yang lezat mulai dari ayam kecap,ayam bakar. Lihat juga resep Ayam Rica Rica Kemangi enak lainnya. Nah, ayam rica-rica ini bisa jadi sajian makan pagi siang maupun malam. Cara memasaknya juga terbilang mudah dan cepat dan nggak butuh biaya mahal.

Kedekatan rumah tangga bisa diperoleh dengan cara sederhana. Salah satunya adalah memasak Ayam Rica-Rica Kemangi untuk keluarga. kebiasaan makan bersama anak sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi masakan yang bisa anda praktekkan salah satunya ayam rica-rica kemangi yang merupakan resep favorite yang mudah dengan varian sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica-Rica Kemangi:

1. Harus ada 7 potong ayam, beri perasan jeruk nipis &amp; garam diamkan 10 menit
1. Tambah 4 lembar daun jeruk
1. Siapkan 2 lbr daun salam
1. Harap siapkan 1 batang serai memarkan
1. Dibutuhkan 3 cm lengkuas memarkan
1. Siapkan 1 ikat kecil kemangi
1. Harap siapkan 8 gr kaldu jamur
1. Harus ada 2 sdm kecap manis
1. Jangan lupa Secukupnya gula dan garam
1. Siapkan 400 ml air
1. Tambah  Bumbu Halus
1. Jangan lupa 5 bawang merah
1. Dibutuhkan 5 bawang putih
1. Dibutuhkan 2 kemiri
1. Dibutuhkan 10 cabe rawit
1. Tambah 5 cabe merah
1. Dibutuhkan 1/2 sdt merica
1. Diperlukan 3 cm kunyit
1. Jangan lupa 2 cm jahe


Resep Ayam Rica-rica Simple Banget tapi Rasanya Nagihin ala Diary Dapurku Подробнее. Resep Ayam Rica Rica(ALA KREASI DAPURKU) Подробнее. RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. 

<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica Kemangi:

1. Tumis bumbu halus dg sedikit minyak, masukkan daun jeruk, daun salam, serai dan lengkuas. Tumis sampai harum kemudian masukkan garam, gula dan kaldu jamur aduk sampai rata.
1. Masukkan ayam sampai ayam terlumuri rata dg bumbu, tambahkan air dan kecap aduk lagi kemudian tutup. Masak dg api kecil tunggu sampai bumbu meresap dan ayam matang.
1. Terakhir masukkan kemangi, aduk sebentar. Matikan api, angkat dan sajikan.


RESEP AYAM RICA - RICA enak banget ! Tentu saja, selain menggunakan rica rica ayam pada umumnya, kehadiran basil di dalamnya dapat menambah rasa masakan lezat yang kita buat. Ayam rica-rica dikenal sebagai masakan khas Manado yang menggugah selera. Rica berarti pedas, cocok banget buat bikin selera makan meningkat. Apalagi kalau ayam rica diberikan taburan kemangi, dijamin aromanya makin sedap. 

Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
