---
description: "Resep : Tinorangsak (Ayam Rica- Rica Khas Manado) Teruji"
title: "Resep : Tinorangsak (Ayam Rica- Rica Khas Manado) Teruji"
slug: 455-resep-tinorangsak-ayam-rica-rica-khas-manado-teruji
date: 2020-10-22T03:52:20.923Z
image: https://img-global.cpcdn.com/recipes/66ec24411beca76b/751x532cq70/tinorangsak-ayam-rica-rica-khas-manado-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/66ec24411beca76b/751x532cq70/tinorangsak-ayam-rica-rica-khas-manado-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/66ec24411beca76b/751x532cq70/tinorangsak-ayam-rica-rica-khas-manado-foto-resep-utama.jpg
author: Dollie Wise
ratingvalue: 4
reviewcount: 29241
recipeingredient:
- "1 kg ayam me  paha bawah"
- "2 sdm Minyak wijen buat menumis"
- "secukupnya Gula"
- "secukupnya Garam"
- " Bumbu Halus "
- "10 siung bawang putih"
- "5 siung bawang merah"
- "5 buah cabe merah kriting"
- "1 ruas jahe"
- "1 ruas kunyit"
- "1 sdm lada"
- " Bumbu Cemplung "
- "10 lembar daun jeruk"
- "5 lembar daun kunyit"
- "5 batang sereh geprek"
- "1 ikat kemangi"
- "15 biji cabe rawit"
recipeinstructions:
- "Cuci bersih ayam dan tiriskan"
- "Ulek bumbu halus hingga halus"
- "Panaskan minyak sedikit buat tumis bumbu halus, sereh, daun kunyit dan daun jeruk hingga harum dan wangi"
- "Setelah wangi masukkan ayam aduk rata tambahkan air, garam dan gula aduk rata"
- "Setelah ayam empuk dan bumbu meresap masukkan cabe rawit dan daun kemangi tunggu mendidih segera matikan kompor lalu sajikan dengan buras atau nasi panas hmm yummy"
categories:
- Recipe
tags:
- tinorangsak
- ayam
- rica

katakunci: tinorangsak ayam rica 
nutrition: 163 calories
recipecuisine: American
preptime: "PT17M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Dessert

---


![Tinorangsak (Ayam Rica- Rica Khas Manado)](https://img-global.cpcdn.com/recipes/66ec24411beca76b/751x532cq70/tinorangsak-ayam-rica-rica-khas-manado-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat banyak di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai varian dari masakan yang pedas,manis dan enak. Karasteristik makanan Nusantara tinorangsak (ayam rica- rica khas manado) yang penuh dengan rempah-rempah menampilkan keberaragaman yang menjadi ciri budaya kita.




Keharmonisan rumah tangga bisa didapat dengan cara sederhana. Diantaranya adalah memasak Tinorangsak (Ayam Rica- Rica Khas Manado) untuk orang di rumah. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang dapat anda coba salah satunya tinorangsak (ayam rica- rica khas manado) yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Untungnya saat ini kamu bisa dengan cepat menemukan resep tinorangsak (ayam rica- rica khas manado) tanpa harus bersusah payah.
Seperti resep Tinorangsak (Ayam Rica- Rica Khas Manado) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Tinorangsak (Ayam Rica- Rica Khas Manado):

1. Tambah 1 kg ayam (me : paha bawah)
1. Dibutuhkan 2 sdm Minyak wijen buat menumis
1. Harap siapkan secukupnya Gula
1. Siapkan secukupnya Garam
1. Dibutuhkan  Bumbu Halus :
1. Tambah 10 siung bawang putih
1. Tambah 5 siung bawang merah
1. Harus ada 5 buah cabe merah kriting
1. Jangan lupa 1 ruas jahe
1. Harus ada 1 ruas kunyit
1. Siapkan 1 sdm lada
1. Diperlukan  Bumbu Cemplung :
1. Tambah 10 lembar daun jeruk
1. Tambah 5 lembar daun kunyit
1. Jangan lupa 5 batang sereh geprek
1. Diperlukan 1 ikat kemangi
1. Tambah 15 biji cabe rawit




<!--inarticleads2-->

##### Bagaimana membuat  Tinorangsak (Ayam Rica- Rica Khas Manado):

1. Cuci bersih ayam dan tiriskan
1. Ulek bumbu halus hingga halus
1. Panaskan minyak sedikit buat tumis bumbu halus, sereh, daun kunyit dan daun jeruk hingga harum dan wangi
1. Setelah wangi masukkan ayam aduk rata tambahkan air, garam dan gula aduk rata
1. Setelah ayam empuk dan bumbu meresap masukkan cabe rawit dan daun kemangi tunggu mendidih segera matikan kompor lalu sajikan dengan buras atau nasi panas hmm yummy




Demikianlah cara membuat tinorangsak (ayam rica- rica khas manado) yang gampang dan cepat. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa berkreasi dengan mudah di rumah. Kami masih memiliki banyak resep istimewa yang sangat simple dan terbukti, anda bisa menelusuri di web kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
