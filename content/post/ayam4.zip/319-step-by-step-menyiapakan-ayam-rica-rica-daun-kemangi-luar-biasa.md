---
description: "Step-by-Step menyiapakan Ayam rica-rica daun kemangi Luar biasa"
title: "Step-by-Step menyiapakan Ayam rica-rica daun kemangi Luar biasa"
slug: 319-step-by-step-menyiapakan-ayam-rica-rica-daun-kemangi-luar-biasa
date: 2020-11-27T05:40:05.164Z
image: https://img-global.cpcdn.com/recipes/6f0f4c938cbed18e/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6f0f4c938cbed18e/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6f0f4c938cbed18e/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg
author: Allie Carroll
ratingvalue: 4.8
reviewcount: 44397
recipeingredient:
- "1/2 kg ayam"
- "1 ikat daun kemangi petik sesuai selera"
- "2 daun salam"
- "1 ruas lengkuas yg digeprek"
- "2 lembar daun jeruk"
- "1 sereh yg digeprek"
- "1 sdm gula jawa"
- "secukupnya Garam dan kaldu ayam"
- " Air kaldu ayam"
- "1 gelas kecil Air"
- " Bumbu halus"
- "6 bawang merah"
- "4 bawang putih"
- "1 kemiri"
- "1 cm jahe"
- "1 cm kunyit"
- "Sdt keyumbar"
recipeinstructions:
- "Haluskan bumbu halus dengan minyak"
- "Tumis bumbu halus dan tambahkan daun salam, lengkuas, daun jeruk, sereh..tumis hingga tanak"
- "Masukan ayam dan aduk2 hingga ayam berubah menjadi putih"
- "Tambahkan 250ml air / sesuai selera, kemudian tunggu hingga mendidih"
- "Masukan gula jawa, garam dan kaldu ayam sesuai selera"
- "Aduk² dan tunggu hingga air agak menyusut"
- "Tambahkan daun kemangi, aduk2 sebentar dan matikan api"
- "Tambahkan bawang merah goreng dan siap disajikan"
categories:
- Recipe
tags:
- ayam
- ricarica
- daun

katakunci: ayam ricarica daun 
nutrition: 213 calories
recipecuisine: American
preptime: "PT36M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica-rica daun kemangi](https://img-global.cpcdn.com/recipes/6f0f4c938cbed18e/751x532cq70/ayam-rica-rica-daun-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang harus kita jaga karena setiap daerah memiliki ciri tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam rica-rica daun kemangi yang kami tulis berikut mungkin di area anda berbeda cara memasaknya. Masakan yang kaya dengan rempah membawa ciri khas yang merupakan keragaman Indonesia



Kedekatan keluarga bisa didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam rica-rica daun kemangi untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di kampung halaman mereka.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang dapat anda praktekkan salah satunya ayam rica-rica daun kemangi yang merupakan makanan favorite yang gampang dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam rica-rica daun kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica daun kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 8 langkah dan 17 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica daun kemangi:

1. Siapkan 1/2 kg ayam
1. Dibutuhkan 1 ikat daun kemangi, petik sesuai selera
1. Dibutuhkan 2 daun salam
1. Harus ada 1 ruas lengkuas yg digeprek
1. Harus ada 2 lembar daun jeruk
1. Harus ada 1 sereh yg digeprek
1. Siapkan 1 sdm gula jawa
1. Jangan lupa secukupnya Garam dan kaldu ayam
1. Dibutuhkan  Air kaldu ayam
1. Harap siapkan 1 gelas kecil Air
1. Dibutuhkan  Bumbu halus
1. Tambah 6 bawang merah
1. Diperlukan 4 bawang putih
1. Harus ada 1 kemiri
1. Harus ada 1 cm jahe
1. Harap siapkan 1 cm kunyit
1. Harap siapkan Sdt keyumbar




<!--inarticleads2-->

##### Cara membuat  Ayam rica-rica daun kemangi:

1. Haluskan bumbu halus dengan minyak
1. Tumis bumbu halus dan tambahkan daun salam, lengkuas, daun jeruk, sereh..tumis hingga tanak
1. Masukan ayam dan aduk2 hingga ayam berubah menjadi putih
1. Tambahkan 250ml air / sesuai selera, kemudian tunggu hingga mendidih
1. Masukan gula jawa, garam dan kaldu ayam sesuai selera
1. Aduk² dan tunggu hingga air agak menyusut
1. Tambahkan daun kemangi, aduk2 sebentar dan matikan api
1. Tambahkan bawang merah goreng dan siap disajikan




Demikianlah cara membuat ayam rica-rica daun kemangi yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat mudah dan cepat, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
