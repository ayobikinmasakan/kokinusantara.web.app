---
description: "Step-by-Step untuk membuat Ayam rica jawa tengah terupdate"
title: "Step-by-Step untuk membuat Ayam rica jawa tengah terupdate"
slug: 289-step-by-step-untuk-membuat-ayam-rica-jawa-tengah-terupdate
date: 2020-08-11T11:53:02.404Z
image: https://img-global.cpcdn.com/recipes/eebc8b9951b8dc01/751x532cq70/ayam-rica-jawa-tengah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/eebc8b9951b8dc01/751x532cq70/ayam-rica-jawa-tengah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/eebc8b9951b8dc01/751x532cq70/ayam-rica-jawa-tengah-foto-resep-utama.jpg
author: Ralph Jones
ratingvalue: 4.4
reviewcount: 16784
recipeingredient:
- "1/2 ekor ayam tepong dan sayap"
- "4 siung bawang putih"
- "7 siung bawang merah"
- "1 ruas lengkuas"
- "1 ruas jahe"
- "1 ruas kunyit"
- "2 butir kemiri"
- "10 cabe rawit"
- " Garam"
- " Gula"
- " Totolekaldu jamur"
- "1 batang serai"
- "1 daun bawang"
- " Kecap manis"
- "Secukupnya air"
- "1 buah tomat"
- "1 daun salam"
- " Jeruk nipis"
recipeinstructions:
- "Cuci bersih ayam lalu lumuri dengan jeruk nipis untuk menghilangkan bau amis.diamkan 5 menit.lalu cuci bersih lagi."
- "Haluskan semua bumbu cabe rawit,bawang merah,bawang putih,kunyit dan kemiri.bisa di blender biar praktis.geprek laos dan jahe."
- "Panaskan minyak lalu tumis bumbu halus dan jahe serta laos hingga harum masukkan daun salam.tumis hingga layu dan harum.masukkan air secukupnya."
- "Bumbui dengan garam,gula,dan totole.koreksi rasa.masukkan ayam sampai mendidih dan tercampur dengan bumbu.tunggu sampai ayam empuk.masukkan tomat dan kecap."
- "Koreksi rasa,yang suka pedes bisa ditambahin cabe rawit potong.potongan terakhir masukkan daun bawang yang sudah dipotong. Sajikan dengan nasi panas dan kerupuk.yummy...."
categories:
- Recipe
tags:
- ayam
- rica
- jawa

katakunci: ayam rica jawa 
nutrition: 276 calories
recipecuisine: American
preptime: "PT20M"
cooktime: "PT32M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam rica jawa tengah](https://img-global.cpcdn.com/recipes/eebc8b9951b8dc01/751x532cq70/ayam-rica-jawa-tengah-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau empuk. Karasteristik masakan Indonesia ayam rica jawa tengah yang kaya dengan rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Kehangatan keluarga dapat ditemukan dengan cara mudah. Diantaranya adalah memasak Ayam rica jawa tengah untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi budaya, Tidak jarang yang sering mencari masakan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak varian makanan yang bisa anda contoh salah satunya ayam rica jawa tengah yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica jawa tengah tanpa harus bersusah payah.
Seperti resep Ayam rica jawa tengah yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 5 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica jawa tengah:

1. Siapkan 1/2 ekor ayam (tepong dan sayap)
1. Harap siapkan 4 siung bawang putih
1. Harus ada 7 siung bawang merah
1. Jangan lupa 1 ruas lengkuas
1. Jangan lupa 1 ruas jahe
1. Harap siapkan 1 ruas kunyit
1. Harap siapkan 2 butir kemiri
1. Diperlukan 10 cabe rawit
1. Siapkan  Garam
1. Siapkan  Gula
1. Harus ada  Totole/kaldu jamur
1. Dibutuhkan 1 batang serai
1. Jangan lupa 1 daun bawang
1. Jangan lupa  Kecap manis
1. Tambah Secukupnya air
1. Tambah 1 buah tomat
1. Harus ada 1 daun salam
1. Siapkan  Jeruk nipis




<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica jawa tengah:

1. Cuci bersih ayam lalu lumuri dengan jeruk nipis untuk menghilangkan bau amis.diamkan 5 menit.lalu cuci bersih lagi.
1. Haluskan semua bumbu cabe rawit,bawang merah,bawang putih,kunyit dan kemiri.bisa di blender biar praktis.geprek laos dan jahe.
1. Panaskan minyak lalu tumis bumbu halus dan jahe serta laos hingga harum masukkan daun salam.tumis hingga layu dan harum.masukkan air secukupnya.
1. Bumbui dengan garam,gula,dan totole.koreksi rasa.masukkan ayam sampai mendidih dan tercampur dengan bumbu.tunggu sampai ayam empuk.masukkan tomat dan kecap.
1. Koreksi rasa,yang suka pedes bisa ditambahin cabe rawit potong.potongan terakhir masukkan daun bawang yang sudah dipotong. Sajikan dengan nasi panas dan kerupuk.yummy....




Demikianlah cara membuat ayam rica jawa tengah yang gampang dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep spesial yang sangat simple dan cepat, anda bisa mencari di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
