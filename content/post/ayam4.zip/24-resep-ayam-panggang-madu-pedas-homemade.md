---
description: "Resep : Ayam Panggang Madu Pedas Homemade"
title: "Resep : Ayam Panggang Madu Pedas Homemade"
slug: 24-resep-ayam-panggang-madu-pedas-homemade
date: 2020-08-14T16:28:52.709Z
image: https://img-global.cpcdn.com/recipes/bec1db4191393613/751x532cq70/ayam-panggang-madu-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bec1db4191393613/751x532cq70/ayam-panggang-madu-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bec1db4191393613/751x532cq70/ayam-panggang-madu-pedas-foto-resep-utama.jpg
author: Clifford Alvarez
ratingvalue: 4.7
reviewcount: 22939
recipeingredient:
- " Bahan "
- "1 ekor ayam saya potong 10"
- "2 lembar daun salam"
- "2 lembar daun jeruk"
- "1 buah sereh geprek"
- "3 sdm madu"
- "6 sdm kecap sesuai selera"
- "Secukupnya gula merah"
- "Secukupnya garam"
- "Secukupnya penyedap"
- "Secukupnya air aku pakai 200ml"
- " Bahan Halus "
- "9 siung bawang merah"
- "6 siung bawang putih"
- "1 ruas lengkuas"
- "1 ruas jahe"
- "1 ruas kunyit"
- "2 buah kemiri"
- "15 buah cabe rawit merah sesuai selera"
- "7 buah cabe keriting"
- "1 sdt ketumbar aku pakai bubuk"
- "1 sdt lada"
recipeinstructions:
- "🔪 Cuci bersih ayamnya. Aku pakai 1 ekor di potong 10. Siapkan semua bahan-bahan nya."
- "Siapkan, bahan-bahannya."
- "Blender, Bahan halusnya"
- "Setelah bumbu di haluskan. (Bahan halus). Lalu di tumis yaa.."
- "Masukan sereh, daun salam, daun jeruk, kecap manis, gula merah, garam, penyedap dan madu. Koreksi rasa nya."
- "Masukan ayamnya, aduk rata"
- "Tambahkan 200ml. Untuk air nya secukupnya ya😁😁.ungkep ayamnya sampe bumbu meresap ke ayam. Masak sampai airnya asat."
- "Panggang di teflon atau bisa juga di happy call. Sembari di olesi bumbu ungkepnya biar mantaaaap😁. Kalau sudah selesai, cuss cyiin di makan sama nasi anget 😁"
categories:
- Recipe
tags:
- ayam
- panggang
- madu

katakunci: ayam panggang madu 
nutrition: 135 calories
recipecuisine: American
preptime: "PT27M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Panggang Madu Pedas](https://img-global.cpcdn.com/recipes/bec1db4191393613/751x532cq70/ayam-panggang-madu-pedas-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi variasi dan aroma yang berbeda, seperti ayam panggang madu pedas yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu menampilkan kesan tersendiri yang merupakan keragaman Kita

Keharmonisan keluarga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Ayam Panggang Madu Pedas untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi budaya, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak jenis masakan yang bisa anda coba salah satunya ayam panggang madu pedas yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep ayam panggang madu pedas tanpa harus bersusah payah.
Seperti resep Ayam Panggang Madu Pedas yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 8 langkah dan 22 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Panggang Madu Pedas:

1. Tambah  👄Bahan ::
1. Harap siapkan 1 ekor ayam (saya, potong 10)
1. Siapkan 2 lembar daun salam
1. Dibutuhkan 2 lembar daun jeruk
1. Diperlukan 1 buah sereh (geprek)
1. Harus ada 3 sdm madu
1. Dibutuhkan 6 sdm kecap (sesuai selera)
1. Tambah Secukupnya gula merah
1. Tambah Secukupnya garam
1. Harap siapkan Secukupnya penyedap
1. Siapkan Secukupnya air (aku pakai 200ml)
1. Tambah  👄Bahan Halus ::
1. Dibutuhkan 9 siung bawang merah
1. Harap siapkan 6 siung bawang putih
1. Diperlukan 1 ruas lengkuas
1. Siapkan 1 ruas jahe
1. Harap siapkan 1 ruas kunyit
1. Harus ada 2 buah kemiri
1. Siapkan 15 buah cabe rawit merah (sesuai selera)
1. Jangan lupa 7 buah cabe keriting
1. Dibutuhkan 1 sdt ketumbar (aku pakai bubuk)
1. Harap siapkan 1 sdt lada




<!--inarticleads2-->

##### Cara membuat  Ayam Panggang Madu Pedas:

1. 🔪 Cuci bersih ayamnya. Aku pakai 1 ekor di potong 10. Siapkan semua bahan-bahan nya.
1. Siapkan, bahan-bahannya.
1. Blender, Bahan halusnya
1. Setelah bumbu di haluskan. (Bahan halus). Lalu di tumis yaa..
1. Masukan sereh, daun salam, daun jeruk, kecap manis, gula merah, garam, penyedap dan madu. Koreksi rasa nya.
1. Masukan ayamnya, aduk rata
1. Tambahkan 200ml. Untuk air nya secukupnya ya😁😁.ungkep ayamnya sampe bumbu meresap ke ayam. Masak sampai airnya asat.
1. Panggang di teflon atau bisa juga di happy call. Sembari di olesi bumbu ungkepnya biar mantaaaap😁. Kalau sudah selesai, cuss cyiin di makan sama nasi anget 😁




Demikianlah cara membuat ayam panggang madu pedas yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan istimewa yang sangat gampang dan cepat, anda bisa menelusuri di web kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
