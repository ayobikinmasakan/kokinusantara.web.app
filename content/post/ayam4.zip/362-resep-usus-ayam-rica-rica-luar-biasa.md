---
description: "Resep : Usus ayam rica-rica Luar biasa"
title: "Resep : Usus ayam rica-rica Luar biasa"
slug: 362-resep-usus-ayam-rica-rica-luar-biasa
date: 2020-11-12T04:50:35.889Z
image: https://img-global.cpcdn.com/recipes/fc2b6b9a33d1d47c/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fc2b6b9a33d1d47c/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fc2b6b9a33d1d47c/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg
author: Theresa Phelps
ratingvalue: 4.1
reviewcount: 36008
recipeingredient:
- "300 g usus ayam"
- "1/2 sdt garam"
- "3 lembar daun jeruk"
- "1000 ml air untuk merebus"
- "2 lembar daun salam"
- "1 cm lengkuas dimemarkan"
- "1 batang serai dimemarkan"
- "3 lembar daun jeruk"
- "3/4 sdt garam"
- "1/2 sdt gula pasir"
- "2 sdm minyak untuk menumis"
- " Minyak untuk menggoreng"
- " Bumbu tumbuk Kasar "
- "8 butir bawang merah"
- "2 siung bawang putih"
- "4 buah cabai merah keriting"
- "3 buah cabai merah besar"
- "2 buah cabai"
- "1 buah tomat"
recipeinstructions:
- "Rebus usus ayam, garam dan daun jeruk sampai matang. Angkat. Tiriskan. Goreng dalam minyak yang sudah dipanaskan sampai kuning kecoklatan. Tiriskan."
- "Panaskan minyak, tumis bumbu tumbuk kasar, daun salam, lengkuas, serai, dan daun jeruk hingga harum. Masukkan usus. Aduk rata. Tambahkan garam dan gula pasir. Aduk rata. Masak hingga bumbu meresap."
- "Angkat dan sajikan."
categories:
- Recipe
tags:
- usus
- ayam
- ricarica

katakunci: usus ayam ricarica 
nutrition: 247 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT46M"
recipeyield: "4"
recipecategory: Dinner

---


![Usus ayam rica-rica](https://img-global.cpcdn.com/recipes/fc2b6b9a33d1d47c/751x532cq70/usus-ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan budaya yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang pedas,manis atau empuk. Ciri makanan Nusantara usus ayam rica-rica yang penuh dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah memasak Usus ayam rica-rica untuk keluarga bisa dicoba. Momen makan bersama anak sudah menjadi kultur, Tidak jarang yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.

Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica. Rasa pedas, gurih dan empuk daging ayamnya terbukti sangat cocok disajikan bersama nasi dalam. RICa rica pedas usus ayam, bahan bahan yang disiapkan adalah usus ayam jeruk purut cabe rawit minyak goreng serai bawang putih + bawang merah bawang bombai.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak jenis makanan yang dapat anda praktekkan salah satunya usus ayam rica-rica yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini anda bisa dengan gampang menemukan resep usus ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Usus ayam rica-rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 3 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Usus ayam rica-rica:

1. Siapkan 300 g usus ayam
1. Diperlukan 1/2 sdt garam
1. Jangan lupa 3 lembar daun jeruk
1. Diperlukan 1000 ml air untuk merebus
1. Jangan lupa 2 lembar daun salam
1. Harus ada 1 cm lengkuas, dimemarkan
1. Tambah 1 batang serai, dimemarkan
1. Harap siapkan 3 lembar daun jeruk
1. Siapkan 3/4 sdt garam
1. Dibutuhkan 1/2 sdt gula pasir
1. Harap siapkan 2 sdm minyak untuk menumis
1. Tambah  Minyak untuk menggoreng
1. Tambah  Bumbu tumbuk Kasar ::
1. Jangan lupa 8 butir bawang merah
1. Dibutuhkan 2 siung bawang putih
1. Dibutuhkan 4 buah cabai merah keriting
1. Tambah 3 buah cabai merah besar
1. Siapkan 2 buah cabai
1. Harap siapkan 1 buah tomat


It is made up of chicken that cooked in spicy red and green chili pepper. The origin of this dish is from Minahasan cuisine of North Sulawesi. Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. 

<!--inarticleads2-->

##### Cara membuat  Usus ayam rica-rica:

1. Rebus usus ayam, garam dan daun jeruk sampai matang. Angkat. Tiriskan. Goreng dalam minyak yang sudah dipanaskan sampai kuning kecoklatan. Tiriskan.
1. Panaskan minyak, tumis bumbu tumbuk kasar, daun salam, lengkuas, serai, dan daun jeruk hingga harum. Masukkan usus. Aduk rata. Tambahkan garam dan gula pasir. Aduk rata. Masak hingga bumbu meresap.
1. Angkat dan sajikan.


Resep Ayam Rica Rica - Siapa yang tidak mengenal kuliner yang telah menjamur ditengah masyarakat ini. Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas dari Manado, Sulawesi Utara. Dengan aroma yang menggoda dibumbui dengan rempah-rempah pilihan. This Ayam (chicken) can be pre-cooked and placed on the grill and served with the rica rica (the spicy sauce). Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. 

Demikianlah cara membuat usus ayam rica-rica yang sederhana dan teruji. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan mudah di rumah. Kami masih memiliki banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menemukan di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
