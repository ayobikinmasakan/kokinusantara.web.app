---
description: "Resep : Ayam Rica - Rica Terbukti"
title: "Resep : Ayam Rica - Rica Terbukti"
slug: 454-resep-ayam-rica-rica-terbukti
date: 2020-10-28T07:01:06.368Z
image: https://img-global.cpcdn.com/recipes/bf4211a35314c2fd/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bf4211a35314c2fd/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bf4211a35314c2fd/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Hilda Jensen
ratingvalue: 4.6
reviewcount: 40520
recipeingredient:
- "1 ekor ayam potong 10"
- "500 gram ceker ayam"
- "5 siung bawang putih ulek kasar"
- "1 ruas jari jahe geprek"
- "1 ruas jari lengkuas geprek"
- "3 batang serai geprek"
- "7 lembar daun jeruk"
- "250 gram cabe setan campur cabe merah besar ulek kasar"
- "5 buah tomat hijau iris2"
- "1 sachet penyedap rasa ayam"
- "1 sdm gula palm"
- "1 sdt garam"
- "1 sdm gula pasir tambahan krn krucil mau"
- "150 gram daun kemangi"
- "100 ml air"
- "3 sdm minyak untuk menumis"
recipeinstructions:
- "Rebus ayam dan ceker sampai empuk dengan 1 sdm garam serai jahe lengkuas geprek daun salam sambil siapkan smua bumbu2nya"
- "Ulek bawang putih kasar ulek cabe kasar dan iris2 tomat ijo"
- "Tumis bawang putih sampai harum, masukkan jahe kengkuas serai daun jeruk aduk2 sampai harum kemudian masukkan cabe yang sudah diulek kasar aduk2 sampai layu, lalu masukkan tomat dan air, aduk rata sampai matang layu semua"
- "Masukkan ayam dan bumbu2 penyedap garam dan gula, test rasa kmd aduk2 biarkan sampai matang dan airnya surut. Kemudian terakhir saat mau diangkat, masukkan daun kemangi dan aduk rata jangan sampai hitam"
- "Angkat dan siap sajikan dengan nasi hangat dijamin nikmat😍😋🙏🏻"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 224 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica - Rica](https://img-global.cpcdn.com/recipes/bf4211a35314c2fd/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kuliner adalah keragaman budaya yang dapat kita lestarikan karena setiap wilayah memiliki ciri khas tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica - rica yang kami tulis berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang penuh dengan rempah-rempah memberikan kesan tersendiri yang merupakan keragaman Nusantara



Kehangatan rumah tangga bisa diperoleh dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica - Rica untuk keluarga. Momen makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu merindukan makanan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang bisa anda praktekkan salah satunya ayam rica - rica yang merupakan resep terkenal yang mudah dengan varian sederhana. Untungnya sekarang ini anda dapat dengan gampang menemukan resep ayam rica - rica tanpa harus bersusah payah.
Seperti resep Ayam Rica - Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 5 langkah dan 16 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica - Rica:

1. Harap siapkan 1 ekor ayam potong 10
1. Diperlukan 500 gram ceker ayam
1. Harus ada 5 siung bawang putih ulek kasar
1. Diperlukan 1 ruas jari jahe geprek
1. Dibutuhkan 1 ruas jari lengkuas geprek
1. Tambah 3 batang serai geprek
1. Diperlukan 7 lembar daun jeruk
1. Harus ada 250 gram cabe setan campur cabe merah besar ulek kasar
1. Harus ada 5 buah tomat hijau iris2
1. Tambah 1 sachet penyedap rasa ayam
1. Siapkan 1 sdm gula palm
1. Harus ada 1 sdt garam
1. Diperlukan 1 sdm gula pasir (tambahan krn krucil mau🤭)
1. Jangan lupa 150 gram daun kemangi
1. Harus ada 100 ml air
1. Dibutuhkan 3 sdm minyak untuk menumis




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica - Rica:

1. Rebus ayam dan ceker sampai empuk dengan 1 sdm garam serai jahe lengkuas geprek daun salam sambil siapkan smua bumbu2nya
1. Ulek bawang putih kasar ulek cabe kasar dan iris2 tomat ijo
1. Tumis bawang putih sampai harum, masukkan jahe kengkuas serai daun jeruk aduk2 sampai harum kemudian masukkan cabe yang sudah diulek kasar aduk2 sampai layu, lalu masukkan tomat dan air, aduk rata sampai matang layu semua
1. Masukkan ayam dan bumbu2 penyedap garam dan gula, test rasa kmd aduk2 biarkan sampai matang dan airnya surut. Kemudian terakhir saat mau diangkat, masukkan daun kemangi dan aduk rata jangan sampai hitam
1. Angkat dan siap sajikan dengan nasi hangat dijamin nikmat😍😋🙏🏻




Demikianlah cara membuat ayam rica - rica yang gampang dan teruji. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan istimewa yang sangat gampang dan terbukti, anda bisa mencari di situs kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
