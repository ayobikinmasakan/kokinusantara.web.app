---
description: "Bagaimana menyiapakan Ayam Rica Kemangi Pedas Nampol Homemade"
title: "Bagaimana menyiapakan Ayam Rica Kemangi Pedas Nampol Homemade"
slug: 249-bagaimana-menyiapakan-ayam-rica-kemangi-pedas-nampol-homemade
date: 2021-01-26T06:55:09.303Z
image: https://img-global.cpcdn.com/recipes/570084f62e65ff09/751x532cq70/ayam-rica-kemangi-pedas-nampol-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/570084f62e65ff09/751x532cq70/ayam-rica-kemangi-pedas-nampol-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/570084f62e65ff09/751x532cq70/ayam-rica-kemangi-pedas-nampol-foto-resep-utama.jpg
author: Lena Arnold
ratingvalue: 4.4
reviewcount: 2309
recipeingredient:
- "4 potong ayam bagian apa ja boleh lebih enak paha dan sayap"
- "1 ikat kemangi"
- " Daun bawang"
- " Bumbu Halus"
- "2 Cabai merah besar"
- "10 cabai rawit"
- "5 bawang merah"
- "3 bawang putih"
- "4 butir kemiri"
- "1 ruas kunyit"
- "1 ruas kencur"
- "1 serai"
- "2 gelas Air"
recipeinstructions:
- "Haluskan semua bumbu halus pakai cobek aja. Trus tumis ke minyak yg panas."
- "Kalau bumbunya dah matang dan mengeluarkan aroma sedap, masukin ayamnya yg telah dicuci bersih."
- "Jangan buru2 dikasih air dulu ya bund. Tunggu bagian luar ayamnya setengah matang. Tandanya daging luar dah berwarna putih. Ini supaya bumbunya meresap dan kaldu ayamnya keluar."
- "Nah kalau penampakannya dah kayak foto diatas, baru kasih air. Tunggu sampai mendidih, tambahin cabai utuh klo suka."
- "Kalau sudah mendidih dan kuahnya dah menyusut, tambahin daun bawang, garam ½ sdt, kaldu jamur 1 sdm, gula ½ sdm..Aduk2 sampai bumbu larut."
- "Koreksi rasanya, dan tambahin kemangi. Aduk2..matikan api kompor. Selesai.."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 165 calories
recipecuisine: American
preptime: "PT25M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica Kemangi Pedas Nampol](https://img-global.cpcdn.com/recipes/570084f62e65ff09/751x532cq70/ayam-rica-kemangi-pedas-nampol-foto-resep-utama.jpg)

Kekayaan budaya yang sangat berlimpah di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas hingga renyah. Karasteristik makanan Nusantara ayam rica kemangi pedas nampol yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Keharmonisan keluarga dapat diperoleh dengan cara sederhana. Diantaranya adalah memasak Ayam Rica Kemangi Pedas Nampol untuk orang di rumah bisa dicoba. kebiasaan makan bersama keluarga sudah menjadi kultur, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis masakan yang bisa anda coba salah satunya ayam rica kemangi pedas nampol yang merupakan makanan favorite yang gampang dengan varian sederhana. Untungnya sekarang ini kamu dapat dengan cepat menemukan resep ayam rica kemangi pedas nampol tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi Pedas Nampol yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 13 bahan dan 6 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi Pedas Nampol:

1. Siapkan 4 potong ayam (bagian apa ja boleh, lebih enak paha dan sayap)
1. Tambah 1 ikat kemangi
1. Diperlukan  Daun bawang
1. Harus ada  Bumbu Halus
1. Dibutuhkan 2 Cabai merah besar
1. Harap siapkan 10 cabai rawit
1. Dibutuhkan 5 bawang merah
1. Diperlukan 3 bawang putih
1. Tambah 4 butir kemiri
1. Siapkan 1 ruas kunyit
1. Harap siapkan 1 ruas kencur
1. Harap siapkan 1 serai
1. Dibutuhkan 2 gelas Air




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Kemangi Pedas Nampol:

1. Haluskan semua bumbu halus pakai cobek aja. Trus tumis ke minyak yg panas.
1. Kalau bumbunya dah matang dan mengeluarkan aroma sedap, masukin ayamnya yg telah dicuci bersih.
1. Jangan buru2 dikasih air dulu ya bund. Tunggu bagian luar ayamnya setengah matang. Tandanya daging luar dah berwarna putih. Ini supaya bumbunya meresap dan kaldu ayamnya keluar.
1. Nah kalau penampakannya dah kayak foto diatas, baru kasih air. Tunggu sampai mendidih, tambahin cabai utuh klo suka.
1. Kalau sudah mendidih dan kuahnya dah menyusut, tambahin daun bawang, garam ½ sdt, kaldu jamur 1 sdm, gula ½ sdm..Aduk2 sampai bumbu larut.
1. Koreksi rasanya, dan tambahin kemangi. Aduk2..matikan api kompor. Selesai..




Demikianlah cara membuat ayam rica kemangi pedas nampol yang gampang dan cepat. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih menyimpan banyak resep rahasia yang sangat mudah dan cepat, anda bisa menelusuri di halaman kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
