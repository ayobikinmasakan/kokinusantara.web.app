---
description: "Panduan untuk menyiapakan Ayam Rica  Rica Kemangi Homemade"
title: "Panduan untuk menyiapakan Ayam Rica  Rica Kemangi Homemade"
slug: 380-panduan-untuk-menyiapakan-ayam-rica-rica-kemangi-homemade
date: 2020-12-06T22:03:20.224Z
image: https://img-global.cpcdn.com/recipes/58f9de339fbdc915/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/58f9de339fbdc915/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/58f9de339fbdc915/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Lewis Boone
ratingvalue: 4.9
reviewcount: 8308
recipeingredient:
- "4 potong ayam ukuran besar"
- " Air perasan lemonjeruk nipis"
- "2 ikat kemangi"
- " Bumbu halus"
- "6 siung bawang merah"
- "2 siung bawang putih"
- "10 buah cabai keriting"
- "3 buah cabai rawit sesuai selera"
- "2 butir kemiri"
- "1 ruas jahe"
- "1 ruas kunyit"
- " Bumbu tambahan"
- "1 batang serai di geprek"
- "1 ruas lengkuas di geprek"
- "4 lembar daun jeruk"
- "Sedikit gula merah"
- " Garam"
- " Kaldu bubuk"
- "1 batang Daun bawang"
recipeinstructions:
- "Balurkan ayam dengan air perasan lemon/jeruk nipis"
- "Goreng bawang merah, bawang putih dan cabai hingga layu. Lalu haluskan bersama bumbu halus lainnya"
- "Tumis bumbu halus hingga wangi, tambahkan gula merah secukupnya, masukkan serai, lengkuas dan daun jeruk."
- "Masukkan ayam. Tumis hingga berubah warna"
- "Tambahkan air secukupnya. Lalu biarkan masak hingga matang"
- "Lalu masukkan kemangi dan daun bawang. Masak hingga sayuran layu"
- "Jadi deh!!!"
categories:
- Recipe
tags:
- ayam
- rica
- 

katakunci: ayam rica  
nutrition: 179 calories
recipecuisine: American
preptime: "PT31M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Rica  Rica Kemangi](https://img-global.cpcdn.com/recipes/58f9de339fbdc915/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Masakan adalah keragaman budaya yang harus kita lestarikan karena setiap wilayah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica  rica kemangi yang kami contohkan berikut mungkin di tempat anda berbeda cara memasaknya. Masakan yang kaya dengan rempah memberikan keistimewahan yang merupakan keragaman Kita



Kehangatan rumah tangga dapat didapat dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica  Rica Kemangi untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

untuk kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak varian makanan yang bisa anda buat salah satunya ayam rica  rica kemangi yang merupakan resep terkenal yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan cepat menemukan resep ayam rica  rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica  Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 7 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica  Rica Kemangi:

1. Dibutuhkan 4 potong ayam ukuran besar
1. Jangan lupa  Air perasan lemon/jeruk nipis
1. Harus ada 2 ikat kemangi
1. Harus ada  Bumbu halus
1. Siapkan 6 siung bawang merah
1. Diperlukan 2 siung bawang putih
1. Diperlukan 10 buah cabai keriting
1. Tambah 3 buah cabai rawit (sesuai selera)
1. Siapkan 2 butir kemiri
1. Harap siapkan 1 ruas jahe
1. Siapkan 1 ruas kunyit
1. Diperlukan  Bumbu tambahan
1. Tambah 1 batang serai di geprek
1. Diperlukan 1 ruas lengkuas di geprek
1. Jangan lupa 4 lembar daun jeruk
1. Jangan lupa Sedikit gula merah
1. Diperlukan  Garam
1. Jangan lupa  Kaldu bubuk
1. Harap siapkan 1 batang Daun bawang




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica  Rica Kemangi:

1. Balurkan ayam dengan air perasan lemon/jeruk nipis
1. Goreng bawang merah, bawang putih dan cabai hingga layu. Lalu haluskan bersama bumbu halus lainnya
1. Tumis bumbu halus hingga wangi, tambahkan gula merah secukupnya, masukkan serai, lengkuas dan daun jeruk.
1. Masukkan ayam. Tumis hingga berubah warna
1. Tambahkan air secukupnya. Lalu biarkan masak hingga matang
1. Lalu masukkan kemangi dan daun bawang. Masak hingga sayuran layu
1. Jadi deh!!!




Demikianlah cara membuat ayam rica  rica kemangi yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat simple dan teruji, anda bisa menemukan di situs kami, jika anda terbantu konten ini jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
