---
description: "Resep : Ayam Rica Rica Kemangi Luar biasa"
title: "Resep : Ayam Rica Rica Kemangi Luar biasa"
slug: 446-resep-ayam-rica-rica-kemangi-luar-biasa
date: 2021-01-24T12:29:06.151Z
image: https://img-global.cpcdn.com/recipes/9d4f02d8c5a58c15/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9d4f02d8c5a58c15/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9d4f02d8c5a58c15/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Billy Palmer
ratingvalue: 4.7
reviewcount: 21714
recipeingredient:
- "1/2 Kg Ayam"
- "1 Batang Serai"
- "4 Lembar daun Jeruk"
- "2 Buah Tomat potongpotong"
- "15 Buah Cabai Rawit Merah"
- "1 Mangkok Kemangi"
- "1 Sdm Gula Merah"
- "1/2 Sdm Garam"
- "1 Sdt Kaldu Ayam Bubuk Royco"
- "300 Ml Air"
- " Bumbu yang dihaluskan"
- "6 Buah Cabai Merah Keriting"
- "7 Siung Bawang Merah"
- "4 Siung Bawang Putih"
- "1 Sdt Ketumbar Halus"
- "1 Ruas Kunyit"
- "1 Ruas Jahe"
- " Minyak untuk menumis"
recipeinstructions:
- "Goreng ayam hingga kecoklatan lalu angkat dan tiriskan."
- "Tumis bumbu yang dihaluskan lalu masukkan daun jeruk dan serai. Masak sampai harum lalu masukkan tomat dan gula merah. Aduk sampai rata lalu masukkan ayam, air, garam dan kaldu bubuk (Bisa ditambah gula pasir jika suka)."
- "Setelah air agak menyusut masukkan cabai rawit dan daun kemangi aduk sampai rata, cek juga rasanya."
- "Sajikan Ayam Rica Rica Kemangi selagi hangat. Selamat mencoba."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 208 calories
recipecuisine: American
preptime: "PT12M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/9d4f02d8c5a58c15/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau renyah. Karasteristik kuliner Nusantara ayam rica rica kemangi yang penuh dengan bumbu memberikan kesan tersendiri bahkan untuk warga asing yang berkunjung.


Kehangatan keluarga bisa didapat dengan cara simple. Salah satunya adalah membuat makanan Ayam Rica Rica Kemangi untuk orang di rumah bisa dicoba. kebiasaan makan bersama anak sudah menjadi kultur, Banyak yang biasanya mencari makanan kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda coba salah satunya ayam rica rica kemangi yang merupakan resep terkenal yang simpel dengan varian sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 4 langkah dan 18 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica Kemangi:

1. Tambah 1/2 Kg Ayam
1. Siapkan 1 Batang Serai
1. Harus ada 4 Lembar daun Jeruk
1. Jangan lupa 2 Buah Tomat, potong-potong
1. Tambah 15 Buah Cabai Rawit Merah
1. Diperlukan 1 Mangkok Kemangi
1. Tambah 1 Sdm Gula Merah
1. Harus ada 1/2 Sdm Garam
1. Harus ada 1 Sdt Kaldu Ayam Bubuk (Royco)
1. Harap siapkan 300 Ml Air
1. Diperlukan  Bumbu yang dihaluskan*
1. Dibutuhkan 6 Buah Cabai Merah Keriting
1. Jangan lupa 7 Siung Bawang Merah
1. Jangan lupa 4 Siung Bawang Putih
1. Tambah 1 Sdt Ketumbar Halus
1. Dibutuhkan 1 Ruas Kunyit
1. Harus ada 1 Ruas Jahe
1. Diperlukan  Minyak untuk menumis




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Rica Kemangi:

1. Goreng ayam hingga kecoklatan lalu angkat dan tiriskan.
1. Tumis bumbu yang dihaluskan lalu masukkan daun jeruk dan serai. Masak sampai harum lalu masukkan tomat dan gula merah. Aduk sampai rata lalu masukkan ayam, air, garam dan kaldu bubuk (Bisa ditambah gula pasir jika suka).
1. Setelah air agak menyusut masukkan cabai rawit dan daun kemangi aduk sampai rata, cek juga rasanya.
1. Sajikan Ayam Rica Rica Kemangi selagi hangat. Selamat mencoba.




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan gampang di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat simple dan cepat, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
