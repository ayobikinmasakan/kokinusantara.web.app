---
description: "Resep : Ayam Rica Kemangi (resep mertua ❤) Luar biasa"
title: "Resep : Ayam Rica Kemangi (resep mertua ❤) Luar biasa"
slug: 273-resep-ayam-rica-kemangi-resep-mertua-luar-biasa
date: 2020-12-11T05:06:31.445Z
image: https://img-global.cpcdn.com/recipes/8bf3c17925fe646d/751x532cq70/ayam-rica-kemangi-resep-mertua-❤-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8bf3c17925fe646d/751x532cq70/ayam-rica-kemangi-resep-mertua-❤-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8bf3c17925fe646d/751x532cq70/ayam-rica-kemangi-resep-mertua-❤-foto-resep-utama.jpg
author: Anne Vega
ratingvalue: 4.4
reviewcount: 1084
recipeingredient:
- "300 gr ayam"
- " Daun kemangi"
- " Daun jeruk"
- " Bumbu Blender"
- "4 bawang merah"
- "6 bawang putih"
- "3 cabe rawit merah"
- "4 cabe keriting merah"
- "1 butir kemiri"
- "jempol Jahe sekuku"
- "jempol Kunyit sekuku"
- "1/2 batang serai"
recipeinstructions:
- "Goreng ayam sebentar (kata mertua ku, kalo ayam kampung enaknya ga ush goreng dulu, tapi kalo ayam biasa enaknya digoreng dulu sebentar) setelah digoreng tiriskan."
- "Cincang daun jeruk lalu sisihkan"
- "Blender semua bumbu. Lalu tumis sebentar bumbunya dan beri air. Masukan garam gula merica dan totole. Koreksi rasa. Setelah rasa pas, masukan ayamnya lalu masak sampai air berkurang. Lalu masukan daun kemangi. Dan taburkan daun jeruk cincang diatasnya aduk2 sebentar di atas api. Dan ayam rica-rica siap disajikan 😊"
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 280 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Rica Kemangi (resep mertua ❤)](https://img-global.cpcdn.com/recipes/8bf3c17925fe646d/751x532cq70/ayam-rica-kemangi-resep-mertua-❤-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat berlimpah di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang pedas,manis atau empuk. Ciri khas masakan Nusantara ayam rica kemangi (resep mertua ❤) yang kaya dengan rempah membawa keberaragaman yang menjadi ciri budaya kita.


Kedekatan keluarga dapat didapat dengan cara sederhana. Diantaranya adalah memasak Ayam Rica Kemangi (resep mertua ❤) untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.



untuk kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak variasi resep yang bisa anda contoh salah satunya ayam rica kemangi (resep mertua ❤) yang merupakan resep favorite yang gampang dengan varian sederhana. Untungnya saat ini anda bisa dengan gampang menemukan resep ayam rica kemangi (resep mertua ❤) tanpa harus bersusah payah.
Berikut ini resep Ayam Rica Kemangi (resep mertua ❤) yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Kemangi (resep mertua ❤):

1. Tambah 300 gr ayam
1. Diperlukan  Daun kemangi
1. Dibutuhkan  Daun jeruk
1. Jangan lupa  Bumbu Blender
1. Harus ada 4 bawang merah
1. Siapkan 6 bawang putih
1. Jangan lupa 3 cabe rawit merah
1. Harap siapkan 4 cabe keriting merah
1. Tambah 1 butir kemiri
1. Siapkan jempol Jahe sekuku
1. Dibutuhkan jempol Kunyit sekuku
1. Jangan lupa 1/2 batang serai




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica Kemangi (resep mertua ❤):

1. Goreng ayam sebentar (kata mertua ku, kalo ayam kampung enaknya ga ush goreng dulu, tapi kalo ayam biasa enaknya digoreng dulu sebentar) setelah digoreng tiriskan.
1. Cincang daun jeruk lalu sisihkan
1. Blender semua bumbu. Lalu tumis sebentar bumbunya dan beri air. Masukan garam gula merica dan totole. Koreksi rasa. Setelah rasa pas, masukan ayamnya lalu masak sampai air berkurang. Lalu masukan daun kemangi. Dan taburkan daun jeruk cincang diatasnya aduk2 sebentar di atas api. Dan ayam rica-rica siap disajikan 😊




Demikianlah cara membuat ayam rica kemangi (resep mertua ❤) yang sederhana dan teruji. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih memiliki banyak resep spesial yang sangat mudah dan cepat, anda bisa mencari di website kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
