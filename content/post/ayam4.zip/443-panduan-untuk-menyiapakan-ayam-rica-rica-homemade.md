---
description: "Panduan untuk menyiapakan Ayam Rica Rica Homemade"
title: "Panduan untuk menyiapakan Ayam Rica Rica Homemade"
slug: 443-panduan-untuk-menyiapakan-ayam-rica-rica-homemade
date: 2021-01-08T02:18:32.882Z
image: https://img-global.cpcdn.com/recipes/22e4712ecdb00406/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/22e4712ecdb00406/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/22e4712ecdb00406/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Edwin Jordan
ratingvalue: 4.2
reviewcount: 48206
recipeingredient:
- "1/2 kg ayampotong"
- "5 lmbr daun jeruk"
- "4 siung bawang merahiris"
- "1 lmbr daun pandan"
- "1/2 bh jeruk nipisperas airnya"
- "300 ml air"
- "segenggam daun kemangi"
- "secukupnya garam"
- "secukupnya minyak goreng"
- " Bumbu ulek kasar "
- "20 bh cabe merah keriting"
- "10 bh cabe rawit"
- "7 siung bawang merah"
- "2 cm jahe"
- "2 btng seraiputihnya sajairis dulu"
recipeinstructions:
- "Cuci bersih ayam,lumuri garam/air jeruk nipis,diamkan 10 menit,bilas kembali. Panaskan minyak goreng,lalu goreng ayam setengah matang saja. Angkat &amp; tiriskan minyaknya."
- "Panaskan kembali minyak (bekas menggoreng ayam),tumis bumbu ulek sampai matang &amp; harum. Tambahkan irisan bawang merah,daun pandan &amp; daun jeruk,aduk² sampai layu."
- "Masukkan ayam,aduk rata. Tuang air,bumbui garam &amp; beri perasan air jeruk nipis. Masak sampai kuahnya menyusut,jgn lupa koreksi rasanya. Terakhir masukkan daun kemangi,aduk rata,masak sebentar saja."
- "Angkat &amp; siap disajikan."
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 152 calories
recipecuisine: American
preptime: "PT29M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dessert

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/22e4712ecdb00406/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai bentuk dari masakan yang pedas,manis hingga empuk. Ciri kuliner Indonesia ayam rica rica yang kaya dengan rempah menampilkan keberaragaman yang menjadi ciri budaya kita.


Kehangatan rumah tangga bisa diperoleh dengan cara sederhana. Diantaranya adalah membuat makanan Ayam Rica Rica untuk orang di rumah bisa dicoba. Momen makan bersama keluarga sudah menjadi kultur, Tidak jarang yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.



untuk kamu yang suka memasak atau harus menyiapkan masakan untuk keluarga ada banyak jenis makanan yang bisa anda coba salah satunya ayam rica rica yang merupakan makanan favorite yang mudah dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa anda contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 15 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Rica:

1. Siapkan 1/2 kg ayam,potong²
1. Dibutuhkan 5 lmbr daun jeruk
1. Dibutuhkan 4 siung bawang merah,iris
1. Diperlukan 1 lmbr daun pandan
1. Tambah 1/2 bh jeruk nipis,peras airnya
1. Harus ada 300 ml air
1. Harus ada segenggam daun kemangi
1. Jangan lupa secukupnya garam
1. Harus ada secukupnya minyak goreng
1. Diperlukan  Bumbu ulek kasar :
1. Siapkan 20 bh cabe merah keriting
1. Harap siapkan 10 bh cabe rawit
1. Siapkan 7 siung bawang merah
1. Tambah 2 cm jahe
1. Harus ada 2 btng serai,putihnya saja,iris dulu




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica:

1. Cuci bersih ayam,lumuri garam/air jeruk nipis,diamkan 10 menit,bilas kembali. Panaskan minyak goreng,lalu goreng ayam setengah matang saja. Angkat &amp; tiriskan minyaknya.
1. Panaskan kembali minyak (bekas menggoreng ayam),tumis bumbu ulek sampai matang &amp; harum. Tambahkan irisan bawang merah,daun pandan &amp; daun jeruk,aduk² sampai layu.
1. Masukkan ayam,aduk rata. Tuang air,bumbui garam &amp; beri perasan air jeruk nipis. Masak sampai kuahnya menyusut,jgn lupa koreksi rasanya. Terakhir masukkan daun kemangi,aduk rata,masak sebentar saja.
1. Angkat &amp; siap disajikan.




Demikianlah cara membuat ayam rica rica yang sederhana dan enak. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat simple dan terbukti, anda bisa menelusuri di situs kami, jika anda terbantu konten ini jangan lupa untuk bagikan dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
