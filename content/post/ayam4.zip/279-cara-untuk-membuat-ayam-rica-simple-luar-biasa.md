---
description: "Cara untuk membuat Ayam rica simple Luar biasa"
title: "Cara untuk membuat Ayam rica simple Luar biasa"
slug: 279-cara-untuk-membuat-ayam-rica-simple-luar-biasa
date: 2021-01-29T22:54:03.345Z
image: https://img-global.cpcdn.com/recipes/8e809a03080b32c7/751x532cq70/ayam-rica-simple-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8e809a03080b32c7/751x532cq70/ayam-rica-simple-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8e809a03080b32c7/751x532cq70/ayam-rica-simple-foto-resep-utama.jpg
author: Charles Morris
ratingvalue: 4.4
reviewcount: 19708
recipeingredient:
- "1 ekor ayam"
- " Bumbu halus"
- "8 Bawang Merah"
- "5 Bawang Putih"
- " Jahe seruas jempol"
- " Lengkuas seruas jempol"
- "3 kemiri sangrai"
- " Bumbu kasar"
- " Cabe rawit sesuai keinginan"
- "1 batang serai iris iris"
- "3 daun jeruk buang batang tengah setelah itu iris iris"
- "2 daun salam Tidak usah diris"
- "2 Irisan buah jeruk dipakai setelah ayam matang"
- " Bahan pelengkap"
- "Sdt ladamerica bubuk"
- "Sdt ketumbar bubuk"
- "secukupnya Garam"
- "secukupnya Kecap"
- "Secukupnya gula"
- "Secukupnya air"
recipeinstructions:
- "Potong ayam menjadi kecil kecil"
- "Didihkan air, rebus ayam hingga matang dan sisihkan"
- "Panaskan minyak, Tumis bumbu iris sampai wangi dan setelah itu langsung masukan bumbu halus"
- "Semua bumbu sudah matang masukan ayam, dan masukkan bumbu pelengkap (masak ayam dengan api kecil biar bumbu meresap)"
- "Tunggu air menyusut sesuai keinginan. Tambahkan perasaan air jeruk 2 iris"
- "Cek rasa. Siap dihidangkan sama nasi hangat♥️"
categories:
- Recipe
tags:
- ayam
- rica
- simple

katakunci: ayam rica simple 
nutrition: 230 calories
recipecuisine: American
preptime: "PT22M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam rica simple](https://img-global.cpcdn.com/recipes/8e809a03080b32c7/751x532cq70/ayam-rica-simple-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai varian dari masakan yang manis,pedas atau enak. Karasteristik kuliner Nusantara ayam rica simple yang kaya dengan bumbu menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kehangatan keluarga bisa didapat dengan cara simple. Diantaranya adalah memasak Ayam rica simple untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu merindukan masakan di rumah mereka.

Hallo semuanya kali ini aku masak &#34;Ayam rica-rica&#34; penasaran rasanya ? Lihat juga resep Ayam Rica Kemangi (resep mertua ❤) enak lainnya. Resep ayam rica-rica ini dikenal berasal dari daerah Manado, Sulawesi Utara yang memiliki cita rasa pedas Seperti pada resep-resep olahan ayam lainnya, bumbu ayam-rica-rica juga menggunakan. Bahan bumbu ayam rica rica yang digunakan sebenarnya cukup simple dan sederhana, seperti : kunyit, jahe, serai, cabai merah, bawang putih, dan beberapa bumbu lainnya.

untuk kamu yang suka memasak atau harus menyiapkan makanan untuk keluarga ada banyak variasi masakan yang bisa anda praktekkan salah satunya ayam rica simple yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam rica simple tanpa harus bersusah payah.
Berikut ini resep Ayam rica simple yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 6 langkah dan 20 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam rica simple:

1. Diperlukan 1 ekor ayam
1. Siapkan  Bumbu halus
1. Siapkan 8 Bawang Merah
1. Diperlukan 5 Bawang Putih
1. Tambah  Jahe (seruas jempol)
1. Harus ada  Lengkuas (seruas jempol)
1. Jangan lupa 3 kemiri sangrai
1. Harap siapkan  Bumbu kasar
1. Harus ada  Cabe rawit (sesuai keinginan)
1. Siapkan 1 batang serai (iris iris)
1. Diperlukan 3 daun jeruk (buang batang tengah setelah itu iris iris)
1. Siapkan 2 daun salam (Tidak usah diris)
1. Tambah 2 Irisan buah jeruk (dipakai setelah ayam matang)
1. Tambah  Bahan pelengkap
1. Harus ada Sdt lada/merica bubuk
1. Harap siapkan Sdt ketumbar bubuk
1. Siapkan secukupnya Garam
1. Tambah secukupnya Kecap
1. Harus ada Secukupnya gula
1. Tambah Secukupnya air


Ayam rica-rica adalah salah satu kuliner kebanggaan masyarakat Indonesia khas. Ayam rica-rica memang dibuat dengan menggunakan berbagai rempah-rempah yang khas Indonesia, sama seperti makanan tradisional lainnya yang kaya akan rempah-rempah. Berikut resep memasak ayam rica-rica untuk menu harian keluarga atau buka puasa. Cobalah memasaknya dengan bumbu rica-rica khas Manado. 

<!--inarticleads2-->

##### Instruksi membuat  Ayam rica simple:

1. Potong ayam menjadi kecil kecil
1. Didihkan air, rebus ayam hingga matang dan sisihkan
1. Panaskan minyak, Tumis bumbu iris sampai wangi dan setelah itu langsung masukan bumbu halus
1. Semua bumbu sudah matang masukan ayam, dan masukkan bumbu pelengkap (masak ayam dengan api kecil biar bumbu meresap)
1. Tunggu air menyusut sesuai keinginan. Tambahkan perasaan air jeruk 2 iris
1. Cek rasa. Siap dihidangkan sama nasi hangat♥️


Berikut resep memasak ayam rica-rica untuk menu harian keluarga atau buka puasa. Cobalah memasaknya dengan bumbu rica-rica khas Manado. Resep Ayam Rica - Rica Pedas Enak dan Spesial Untuk Keluarga - Asal muasal dari resep ayam rica-rica ini berasal dari daerah Manado - Sul. Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. 

Demikianlah cara membuat ayam rica simple yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa mencari di halaman kami, apabila artikel bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
