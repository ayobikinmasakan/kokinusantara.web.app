---
description: "Step-by-Step menyiapakan Ayam rica-rica Luar biasa"
title: "Step-by-Step menyiapakan Ayam rica-rica Luar biasa"
slug: 261-step-by-step-menyiapakan-ayam-rica-rica-luar-biasa
date: 2020-10-25T19:34:28.967Z
image: https://img-global.cpcdn.com/recipes/31a71d73b4478561/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/31a71d73b4478561/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/31a71d73b4478561/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Theresa Mendez
ratingvalue: 4.6
reviewcount: 32172
recipeingredient:
- "300 gr dada ayam fillet bisa diganti bagian ayam lainnyapotong dadu"
- "2 ruas jari kunyithaluskan"
- "1 sdt garam"
- "2 ruas jari lengkuasgeprek"
- "1 batang seraigeprek"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "2 batang daun bawangiris"
- "2 sdt gula"
- "1 sdt garam"
- "1/2 sdt merica"
- "secukupnya Air"
- " Bumbu halus blender"
- "3 siung bawang putih"
- "5 siung bawang merah"
- "10 buah cabe merah"
- "6 buah rawit merah"
- "1 ruas jahe"
- "2 butir kemiri"
recipeinstructions:
- "Lumuri ayam dengan garam+kunyit,aduk rata dan diamkan selama 15-20 menit, lalu goreng hingga kuning keemasan,angkat dan sisihkan"
- "Tumis bumbu halus hingga wangi"
- "Masukkan serai+daun jeruk+daun salam+lengkuas,aduk rata"
- "Masukkan air,masak hingga mendidih lalu masukkan ayam,aduk rata"
- "Taburi gula +garam+merica,aduk rata dan masak hingga air menyusut dan bumbu meresap. angkat dan sajikan dengan taburan irisan daun bawang😊"
categories:
- Recipe
tags:
- ayam
- ricarica

katakunci: ayam ricarica 
nutrition: 273 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam rica-rica](https://img-global.cpcdn.com/recipes/31a71d73b4478561/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kebenarekaragaman budaya yang sangat banyak di Indonesia juga di ikuti kekayaan makanan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas dan empuk. Karasteristik masakan Nusantara ayam rica-rica yang penuh dengan rempah-rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga bisa didapat dengan cara mudah. Salah satunya adalah memasak Ayam rica-rica untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, bahkan banyak orang yang merantau selalu membayangkan masakan di rumah mereka.

Resep Ayam Rica Rica Bahan: Daging Ayam Lemon juice Chicken powder Garam. Bawang merah Bawang putih Cabe Jahe Serai Daun jeruk purut Daun kucai. Bagi pecinta pedas, ayam rica-rica memang memiliki banyak penggemar. Bahkan tak hanya di Manado saja, kini banyak warung makan hingga restoran menyajikan masakan ayam rica-rica.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk orang lain ada banyak variasi makanan yang dapat anda praktekkan salah satunya ayam rica-rica yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Untungnya sekarang ini anda dapat dengan cepat menemukan resep ayam rica-rica tanpa harus bersusah payah.
Berikut ini resep Ayam rica-rica yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 19 bahan dan 5 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica:

1. Diperlukan 300 gr dada ayam fillet (bisa diganti bagian ayam lainnya),potong dadu
1. Siapkan 2 ruas jari kunyit,haluskan
1. Harap siapkan 1 sdt garam
1. Dibutuhkan 2 ruas jari lengkuas,geprek
1. Tambah 1 batang serai,geprek
1. Dibutuhkan 2 lembar daun jeruk
1. Harus ada 2 lembar daun salam
1. Tambah 2 batang daun bawang,iris
1. Harus ada 2 sdt gula
1. Harus ada 1 sdt garam
1. Harap siapkan 1/2 sdt merica
1. Dibutuhkan secukupnya Air
1. Siapkan  Bumbu halus (blender):
1. Jangan lupa 3 siung bawang putih
1. Tambah 5 siung bawang merah
1. Diperlukan 10 buah cabe merah
1. Tambah 6 buah rawit merah
1. Tambah 1 ruas jahe
1. Jangan lupa 2 butir kemiri


Cara pembuatan ayam rica-rica tidaklah sulit. Dibutuhkan bahan-bahan seperti daun jeruk, serai, dan daun pandan agar aromanya menjadi kuat dan khas. Tak hanya ayam, anda juga bisa memasak. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. 

<!--inarticleads2-->

##### Bagaimana membuat  Ayam rica-rica:

1. Lumuri ayam dengan garam+kunyit,aduk rata dan diamkan selama 15-20 menit, lalu goreng hingga kuning keemasan,angkat dan sisihkan
1. Tumis bumbu halus hingga wangi
1. Masukkan serai+daun jeruk+daun salam+lengkuas,aduk rata
1. Masukkan air,masak hingga mendidih lalu masukkan ayam,aduk rata
1. Taburi gula +garam+merica,aduk rata dan masak hingga air menyusut dan bumbu meresap. angkat dan sajikan dengan taburan irisan daun bawang😊


Tak hanya ayam, anda juga bisa memasak. Learn how to make tasty ayam rica rica with a pressure cooker or on the stove. I really don&#39;t know how it was started but if you take away chili peppers from my life… I&#39;m gone! Chef S Table Ayam Rica Rica. Mukbang Nasi Sama Soup Dan Ayam Rica Makanenakindonesia. 

Demikianlah cara membuat ayam rica-rica yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa berkreasi dengan mudah di rumah. Kami masih menyimpan banyak resep istimewa yang sangat mudah dan cepat, anda bisa menemukan di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
