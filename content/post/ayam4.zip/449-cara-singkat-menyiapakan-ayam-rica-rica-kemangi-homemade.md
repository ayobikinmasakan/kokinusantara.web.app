---
description: "Cara singkat menyiapakan Ayam Rica Rica Kemangi Homemade"
title: "Cara singkat menyiapakan Ayam Rica Rica Kemangi Homemade"
slug: 449-cara-singkat-menyiapakan-ayam-rica-rica-kemangi-homemade
date: 2020-11-09T20:40:29.325Z
image: https://img-global.cpcdn.com/recipes/457277078f4f31b3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/457277078f4f31b3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/457277078f4f31b3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Travis Nguyen
ratingvalue: 4.1
reviewcount: 42465
recipeingredient:
- "1 ekor Ayam kmpg utuh"
- " Bumbu Halus"
- "8 bawang merah"
- "2 bawang putih"
- "10 cabe Rawit"
- "10 Cabe Kriting"
- " Bahan Uleg"
- "2 bh kemiri yg sdh dsangrai"
- "2 ruas kunyit"
- " Bahan geprek"
- "1 ruas laos"
- "1 ruas jahe"
- "2 Bh Daun salam"
- "2 Bh Daun jeruk"
- "1 bh Daun sere"
- "4 sdm minyak goreng utk menumis"
- "1 ikat Daun kemangi"
- "1 sdt gula"
- "1 sdt gram"
- "secukupnya kaldu ayampenyedap rasa"
- "200 ml air"
recipeinstructions:
- "Potong2 ayam dan cuci bersih ayam lalu sisihkan"
- "Blender bumbu halusss diatas lalu sisihkan kemudian uleg bumbu uleg kemiri dan kunyit sisihkan"
- "Siapkan minyak tunggu hingga panas kemudian masukkan bumbu halus dan bahan uleg ke dalam minyak tumis hingga harum lalu masukkan daun salam, serai,jahe, laos kemudian ayam tumis hingga merata"
- "Kemudian tambahkan air kemudian gula, garam dan kaldu cek rasa sesuai selera tunggu hingga mendidih dn air menyusut kemudian matikan api masukkan daun kemangi.ayam rica2 sudah siap dinikmati"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 125 calories
recipecuisine: American
preptime: "PT23M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica Rica Kemangi](https://img-global.cpcdn.com/recipes/457277078f4f31b3/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis atau empuk. Ciri khas masakan Indonesia ayam rica rica kemangi yang kaya dengan bumbu menampilkan keberaragaman yang menjadi ciri budaya kita.


Kedekatan rumah tangga dapat didapat dengan cara simple. Diantaranya adalah memasak Ayam Rica Rica Kemangi untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan makanan untuk keluarga ada banyak variasi resep yang bisa anda praktekkan salah satunya ayam rica rica kemangi yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu dapat dengan mudah menemukan resep ayam rica rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica Kemangi yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 21 bahan dan 4 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica Kemangi:

1. Tambah 1 ekor Ayam kmpg utuh
1. Jangan lupa  Bumbu Halus
1. Harus ada 8 bawang merah
1. Harap siapkan 2 bawang putih
1. Jangan lupa 10 cabe Rawit
1. Jangan lupa 10 Cabe Kriting
1. Tambah  Bahan Uleg
1. Diperlukan 2 bh kemiri yg sdh dsangrai
1. Harus ada 2 ruas kunyit
1. Harus ada  Bahan geprek
1. Tambah 1 ruas laos
1. Siapkan 1 ruas jahe
1. Tambah 2 Bh Daun salam
1. Harap siapkan 2 Bh Daun jeruk
1. Siapkan 1 bh Daun sere
1. Harap siapkan 4 sdm minyak goreng utk menumis
1. Harus ada 1 ikat Daun kemangi
1. Harap siapkan 1 sdt gula
1. Jangan lupa 1 sdt gram
1. Harap siapkan secukupnya kaldu ayam/penyedap rasa
1. Siapkan 200 ml air




<!--inarticleads2-->

##### Cara membuat  Ayam Rica Rica Kemangi:

1. Potong2 ayam dan cuci bersih ayam lalu sisihkan
1. Blender bumbu halusss diatas lalu sisihkan kemudian uleg bumbu uleg kemiri dan kunyit sisihkan
1. Siapkan minyak tunggu hingga panas kemudian masukkan bumbu halus dan bahan uleg ke dalam minyak tumis hingga harum lalu masukkan daun salam, serai,jahe, laos kemudian ayam tumis hingga merata
1. Kemudian tambahkan air kemudian gula, garam dan kaldu cek rasa sesuai selera tunggu hingga mendidih dn air menyusut kemudian matikan api masukkan daun kemangi.ayam rica2 sudah siap dinikmati




Demikianlah cara membuat ayam rica rica kemangi yang mudah dan cepat. Terima kasih buat waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep makanan spesial yang sangat mudah dan cepat, anda bisa mencari di web kami, jika anda terbantu konten ini jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
