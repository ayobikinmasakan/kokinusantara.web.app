---
description: "Panduan untuk menyiapakan Ayam Rica Homemade"
title: "Panduan untuk menyiapakan Ayam Rica Homemade"
slug: 364-panduan-untuk-menyiapakan-ayam-rica-homemade
date: 2021-02-01T01:21:52.650Z
image: https://img-global.cpcdn.com/recipes/3655db980d141b71/751x532cq70/ayam-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3655db980d141b71/751x532cq70/ayam-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3655db980d141b71/751x532cq70/ayam-rica-foto-resep-utama.jpg
author: Olivia Dean
ratingvalue: 4.3
reviewcount: 45443
recipeingredient:
- "1/2 kg ayam"
- " Lengkuas geprek"
- "2 batang sereh geprek"
- "3 lembar daun jeruk"
- "1 ikat kemangi"
- " Bumbu halus"
- "5 butir bawang merah"
- "3 butir bawang putih"
- "3 butir kemiri"
- "15 biji Cabe kriting"
- "3 biji cabe rawit"
- "1 sdt merica"
recipeinstructions:
- "Potong&#34; Ayam sesuai selera, cuci bersih,,"
- "Ulek/blender bumbu halus,"
- "Panaskan minyak, tumis bumbu halus+cemlung hingga harum,masukan ayam, aduk,tutup biarkan hingga minyaknya kluar,beri air, masak hingga empuk, beri garam, roiko, gula, biarkan air agak menyurut, beri taburan kemangi, aduk sebentar angkat,, siap di sajikan..."
categories:
- Recipe
tags:
- ayam
- rica

katakunci: ayam rica 
nutrition: 233 calories
recipecuisine: American
preptime: "PT33M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Rica](https://img-global.cpcdn.com/recipes/3655db980d141b71/751x532cq70/ayam-rica-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita lestarikan karena setiap tempat memiliki ciri tersendiri, walaupun namanya sama tetapi rasa dan tekstur yang berbeda, seperti ayam rica yang kami contohkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan rempah memberikan kesan tersendiri yang merupakan keragaman Kita

Kedekatan rumah tangga bisa diperoleh dengan cara simple. Salah satunya adalah memasak Ayam Rica untuk keluarga bisa dicoba. kebersamaan makan bersama anak sudah menjadi budaya, Banyak yang kadang mencari kuliner kampung mereka sendiri ketika di perantauan.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk orang lain ada banyak variasi masakan yang dapat anda coba salah satunya ayam rica yang merupakan resep favorite yang gampang dengan kreasi sederhana. Untungnya sekarang ini kamu dapat dengan mudah menemukan resep ayam rica tanpa harus bersusah payah.
Seperti resep Ayam Rica yang bisa kamu tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 12 bahan dan 3 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica:

1. Dibutuhkan 1/2 kg ayam
1. Diperlukan  Lengkuas geprek
1. Diperlukan 2 batang sereh geprek
1. Jangan lupa 3 lembar daun jeruk
1. Jangan lupa 1 ikat kemangi
1. Dibutuhkan  Bumbu halus:
1. Tambah 5 butir bawang merah
1. Harus ada 3 butir bawang putih
1. Harus ada 3 butir kemiri
1. Harap siapkan 15 biji Cabe kriting
1. Harap siapkan 3 biji cabe rawit
1. Tambah 1 sdt merica




<!--inarticleads2-->

##### Bagaimana membuat  Ayam Rica:

1. Potong&#34; Ayam sesuai selera, cuci bersih,,
1. Ulek/blender bumbu halus,
1. Panaskan minyak, tumis bumbu halus+cemlung hingga harum,masukan ayam, aduk,tutup biarkan hingga minyaknya kluar,beri air, masak hingga empuk, beri garam, roiko, gula, biarkan air agak menyurut, beri taburan kemangi, aduk sebentar angkat,, siap di sajikan...




Demikianlah cara membuat ayam rica yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep istimewa yang sangat mudah dan teruji, anda bisa menemukan di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
