---
description: "Bagaimana untuk membuat Ayam Rica-Rica Pedas Favorite"
title: "Bagaimana untuk membuat Ayam Rica-Rica Pedas Favorite"
slug: 348-bagaimana-untuk-membuat-ayam-rica-rica-pedas-favorite
date: 2020-11-02T04:10:07.832Z
image: https://img-global.cpcdn.com/recipes/9e9e7eb9d4f393b6/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9e9e7eb9d4f393b6/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9e9e7eb9d4f393b6/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
author: Kate Holt
ratingvalue: 4.8
reviewcount: 28055
recipeingredient:
- "1/2 kg Ayam saya bagian paha"
- "3 lembar daun jeruk"
- "2 lembar daun salam"
- "1 batang serai"
- "2 sdm kecap manis"
- " Laos digeprek"
- " Gula"
- " Garam"
- " Kaldu Jamur"
- " Bumbu Halus"
- "10 siung bawang merah"
- "5 siung bawang putih"
- "5 butir kemiri"
- "1 ruas jahe"
- "1 ruas kencur"
- "1/2 sdt ketumbar"
- "15-20 cabai merah keriting"
- "5-10 cabai rawit domba sesuai selera"
recipeinstructions:
- "Masukkan semua bumbu halus ke dalam blender. Beri sedikit minyak untuk memudahkan, dan tambahkan sedikit garam supaya tidak bau langu cabai. Kemudian blender sampai halus."
- "Potong kecil-kecil ayam atau sesuai selera. Cuci bersih."
- "Siapkan wajan dan beri minyak goreng. Panaskan."
- "Jika sudah panas, masukkan bumbu halus. Tumis sampai wangi. Masukkan laos geprek, serai geprek, daun salam, dan daun jeruk. Tumis kembali sampai layu."
- "Masukkan ayam, aduk-aduk sampai rata. Kemudian masukkan kurang lebih 500ml air."
- "Tunggu sampai mendidih dan agak menyusut airnya."
- "Masukkan gula, garam, kaldu jamur dan kecap manis. Koreksi rasa."
- "Diamkan sampai air agak surut (atau sesuai selera jika ingin lebih berkuah)."
- "Rica-rica siap dihidangkan."
categories:
- Recipe
tags:
- ayam
- ricarica
- pedas

katakunci: ayam ricarica pedas 
nutrition: 228 calories
recipecuisine: American
preptime: "PT19M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Rica-Rica Pedas](https://img-global.cpcdn.com/recipes/9e9e7eb9d4f393b6/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg)

Kekayaan budaya yang sangat beragam di Indonesia juga di ikuti kekayaan masakan yang beragam dengan berbagai citarasa dari masakan yang manis,pedas hingga enak. Karasteristik masakan Nusantara ayam rica-rica pedas yang penuh dengan rempah-rempah membawa kesan tersendiri bahkan untuk turis yang berkunjung.




Keharmonisan rumah tangga dapat didapat dengan cara mudah. Diantaranya adalah membuat makanan Ayam Rica-Rica Pedas untuk orang di rumah. Momen makan bersama keluarga sudah menjadi kultur, Banyak yang sering mencari kuliner kampung mereka sendiri ketika di perantauan.

Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak variasi masakan yang dapat anda contoh salah satunya ayam rica-rica pedas yang merupakan resep terkenal yang gampang dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan cepat menemukan resep ayam rica-rica pedas tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-Rica Pedas yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 18 bahan dan 9 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-Rica Pedas:

1. Harap siapkan 1/2 kg Ayam (saya bagian paha)
1. Jangan lupa 3 lembar daun jeruk
1. Harap siapkan 2 lembar daun salam
1. Tambah 1 batang serai
1. Tambah 2 sdm kecap manis
1. Diperlukan  Laos (digeprek)
1. Siapkan  Gula
1. Diperlukan  Garam
1. Dibutuhkan  Kaldu Jamur
1. Harus ada  Bumbu Halus
1. Tambah 10 siung bawang merah
1. Harap siapkan 5 siung bawang putih
1. Jangan lupa 5 butir kemiri
1. Jangan lupa 1 ruas jahe
1. Harap siapkan 1 ruas kencur
1. Diperlukan 1/2 sdt ketumbar
1. Dibutuhkan 15-20 cabai merah keriting
1. Harus ada 5-10 cabai rawit domba (sesuai selera)




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica-Rica Pedas:

1. Masukkan semua bumbu halus ke dalam blender. Beri sedikit minyak untuk memudahkan, dan tambahkan sedikit garam supaya tidak bau langu cabai. Kemudian blender sampai halus.
1. Potong kecil-kecil ayam atau sesuai selera. Cuci bersih.
1. Siapkan wajan dan beri minyak goreng. Panaskan.
1. Jika sudah panas, masukkan bumbu halus. Tumis sampai wangi. Masukkan laos geprek, serai geprek, daun salam, dan daun jeruk. Tumis kembali sampai layu.
1. Masukkan ayam, aduk-aduk sampai rata. Kemudian masukkan kurang lebih 500ml air.
1. Tunggu sampai mendidih dan agak menyusut airnya.
1. Masukkan gula, garam, kaldu jamur dan kecap manis. Koreksi rasa.
1. Diamkan sampai air agak surut (atau sesuai selera jika ingin lebih berkuah).
1. Rica-rica siap dihidangkan.




Demikianlah cara membuat ayam rica-rica pedas yang mudah dan cepat. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat mudah dan cepat, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
