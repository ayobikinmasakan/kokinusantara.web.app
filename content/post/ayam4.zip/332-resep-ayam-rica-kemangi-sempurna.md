---
description: "Resep : Ayam Rica Kemangi Sempurna"
title: "Resep : Ayam Rica Kemangi Sempurna"
slug: 332-resep-ayam-rica-kemangi-sempurna
date: 2020-09-28T17:56:59.789Z
image: https://img-global.cpcdn.com/recipes/ad37edc013c5307d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ad37edc013c5307d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ad37edc013c5307d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg
author: Kathryn Jimenez
ratingvalue: 4.1
reviewcount: 23106
recipeingredient:
- "1/2 ekor ayam potong kecil kecil atau sesuai selera"
- " Bumbu halus "
- "4 siung bawang merah"
- "2 siung bawang putih sy pakai baceman bawang"
- " Sekitar 2 cm kunyit"
- " Sekitar 2 cm jahe"
- "2 buah kemiri"
- "5 Cabe kriting 2 cabe rawit"
- "Sejumput ketumbar"
- "1 sdt garam gula pasir penyedap dan lada bubuk"
- " Bahan pelengkap  lengkuas dan sereh geprekdaun salam kemangi"
- "1 gelas air matang"
recipeinstructions:
- "Cuci bersih ayam dan potong2 sesuai selera"
- "Tumis bumbu yang dihaluskan sampai wangi. Masukkan sereh, lengkuas, dan daun salam"
- "Masukkan ayam aduk2 rata sampai ayam berubah warna, tambahkan air 1 gelas belimbing boleh lebih, masak sampai air menyusut tambahkan daun kemangi, tes rasa."
categories:
- Recipe
tags:
- ayam
- rica
- kemangi

katakunci: ayam rica kemangi 
nutrition: 200 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Rica Kemangi](https://img-global.cpcdn.com/recipes/ad37edc013c5307d/751x532cq70/ayam-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah warisan budaya yang patut kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi rasa dan aroma yang berbeda, seperti ayam rica kemangi yang kami paparkan berikut mungkin di kampung anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu membawa kesan tersendiri yang merupakan keragaman Nusantara

Kedekatan keluarga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Ayam Rica Kemangi untuk keluarga bisa dicoba. Momen makan bersama orang tua sudah menjadi budaya, Tidak jarang yang kadang mencari kuliner kampung mereka sendiri ketika di tempat lain.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk tamu ada banyak varian masakan yang dapat anda praktekkan salah satunya ayam rica kemangi yang merupakan resep favorite yang mudah dengan kreasi sederhana. Pasalnya saat ini anda dapat dengan gampang menemukan resep ayam rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam Rica Kemangi yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat mudah hanya dengan 3 langkah dan 12 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica Kemangi:

1. Harap siapkan 1/2 ekor ayam, potong kecil kecil atau sesuai selera
1. Diperlukan  Bumbu halus :
1. Siapkan 4 siung bawang merah
1. Harus ada 2 siung bawang putih (sy pakai baceman bawang)
1. Dibutuhkan  Sekitar 2 cm kunyit
1. Diperlukan  Sekitar 2 cm jahe
1. Tambah 2 buah kemiri
1. Siapkan 5 Cabe kriting, 2 cabe rawit
1. Tambah Sejumput ketumbar
1. Dibutuhkan 1 sdt garam, gula pasir, penyedap dan lada bubuk
1. Harus ada  Bahan pelengkap : lengkuas dan sereh geprek,daun salam, kemangi
1. Diperlukan 1 gelas air matang




<!--inarticleads2-->

##### Instruksi membuat  Ayam Rica Kemangi:

1. Cuci bersih ayam dan potong2 sesuai selera
1. Tumis bumbu yang dihaluskan sampai wangi. Masukkan sereh, lengkuas, dan daun salam
1. Masukkan ayam aduk2 rata sampai ayam berubah warna, tambahkan air 1 gelas belimbing boleh lebih, masak sampai air menyusut tambahkan daun kemangi, tes rasa.




Demikianlah cara membuat ayam rica kemangi yang mudah dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa membuatnya dengan mudah di rumah. Kami masih mempunyai banyak resep spesial yang sangat gampang dan terbukti, anda bisa menemukan di website kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari ke dapur !!!. 
