---
description: "Resep : Ayam Rica-rica Kemangi Cepat"
title: "Resep : Ayam Rica-rica Kemangi Cepat"
slug: 411-resep-ayam-rica-rica-kemangi-cepat
date: 2020-09-02T05:47:37.725Z
image: https://img-global.cpcdn.com/recipes/2b2c178f78d8d7fb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2b2c178f78d8d7fb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2b2c178f78d8d7fb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Dale Horton
ratingvalue: 4.4
reviewcount: 14492
recipeingredient:
- "1/2 ekor ayam"
- "1/2 buah jeruk nipis"
- "1 sdt garam"
- "2 batang sereh"
- "4 lembar daun jeruk iris tipis"
- "1 lembar daun kunyit iris tipis saya skip"
- "1 buah tomat merah"
- "1 batang daun bawang"
- "1/2 ikat daun kemangi"
- "Secukupnya air"
- " Bumbu halus"
- "4 buah cabe merah keriting"
- "8 buah cabe rawit merah"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "4 butir kemiri"
- "2 ruas jari kunyit"
- "2 ruas jari lengkuas"
- "1 ruas jari jahe"
- "Secukupnya minyak goreng"
- " Bumbubumbu lain"
- "1 sdm gula pasir"
- "1 sdm garam"
- "1 sdt penyedap rasa"
- "1/2 sdt lada bubuk"
recipeinstructions:
- "Cuci bersih ayam, lumuri dengan air perasan jeruk nipis dan garam, diamkan sekitar 30 menit."
- "Potong-potong bahan bumbu halus, lalu blend dengan minyak hingga halus. Jahe dan lengkuas saya blend juga tidak digeprek, supaya tidak ikut dikira daging ayam saat dimakan wkwk."
- "Masukkan bumbu kedalam wajan, lalu masak sebentar hingga minyaknya keluar."
- "Masukkan sereh dan irisan daun jeruk. Tumis hingga harum."
- "Lalu masukkan ayam, beri air secukupnya. Masukkan gula, garam, lada, penyedap. Tes rasa. Tutup wajan lalu masak dengan api kecil hingga air menyusut."
- "Setelah air menyusut, masukkan berurutan : potongan cabe rawit (optional), tomat dan daun bawang, terakhir masukkan daun kemangi sesaat sebelum diangkat."
- "Aduk hingga rata dan air semakin menyusut. Siap dihidangkan. Selamat mencoba 😉"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 181 calories
recipecuisine: American
preptime: "PT18M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam Rica-rica Kemangi](https://img-global.cpcdn.com/recipes/2b2c178f78d8d7fb/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kuliner adalah salah satu warisan budaya yang setidaknya kita lestarikan karena setiap wilayah memiliki keunikan tersendiri, walaupun namanya sama tetapi bentuk dan tekstur yang berbeda, seperti ayam rica-rica kemangi yang kami paparkan berikut mungkin di area anda berbeda cara memasaknya. Masakan yang penuh dengan bumbu memberikan keistimewahan yang merupakan keragaman Nusantara

Kehangatan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah membuat makanan Ayam Rica-rica Kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan masakan di rumah mereka.



Buat kamu yang suka masak atau harus menyiapkan masakan untuk orang lain ada banyak variasi resep yang bisa anda coba salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Untungnya saat ini anda dapat dengan mudah menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Berikut ini resep Ayam Rica-rica Kemangi yang bisa kamu contoh untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 25 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam Rica-rica Kemangi:

1. Tambah 1/2 ekor ayam
1. Dibutuhkan 1/2 buah jeruk nipis
1. Siapkan 1 sdt garam
1. Dibutuhkan 2 batang sereh
1. Diperlukan 4 lembar daun jeruk iris tipis
1. Harap siapkan 1 lembar daun kunyit iris tipis (saya skip)
1. Harap siapkan 1 buah tomat merah
1. Diperlukan 1 batang daun bawang
1. Diperlukan 1/2 ikat daun kemangi
1. Harus ada Secukupnya air
1. Tambah  Bumbu halus
1. Harus ada 4 buah cabe merah keriting
1. Diperlukan 8 buah cabe rawit merah
1. Tambah 8 siung bawang merah
1. Harus ada 4 siung bawang putih
1. Diperlukan 4 butir kemiri
1. Tambah 2 ruas jari kunyit
1. Jangan lupa 2 ruas jari lengkuas
1. Tambah 1 ruas jari jahe
1. Jangan lupa Secukupnya minyak goreng
1. Tambah  Bumbu-bumbu lain
1. Dibutuhkan 1 sdm gula pasir
1. Diperlukan 1 sdm garam
1. Jangan lupa 1 sdt penyedap rasa
1. Diperlukan 1/2 sdt lada bubuk




<!--inarticleads2-->

##### Cara membuat  Ayam Rica-rica Kemangi:

1. Cuci bersih ayam, lumuri dengan air perasan jeruk nipis dan garam, diamkan sekitar 30 menit.
1. Potong-potong bahan bumbu halus, lalu blend dengan minyak hingga halus. Jahe dan lengkuas saya blend juga tidak digeprek, supaya tidak ikut dikira daging ayam saat dimakan wkwk.
1. Masukkan bumbu kedalam wajan, lalu masak sebentar hingga minyaknya keluar.
1. Masukkan sereh dan irisan daun jeruk. Tumis hingga harum.
1. Lalu masukkan ayam, beri air secukupnya. Masukkan gula, garam, lada, penyedap. Tes rasa. Tutup wajan lalu masak dengan api kecil hingga air menyusut.
1. Setelah air menyusut, masukkan berurutan : potongan cabe rawit (optional), tomat dan daun bawang, terakhir masukkan daun kemangi sesaat sebelum diangkat.
1. Aduk hingga rata dan air semakin menyusut. Siap dihidangkan. Selamat mencoba 😉




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan enak. Terima kasih buat waktu anda untuk membaca artikel makanan ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat mudah dan teruji, anda bisa mencari di web kami, apabila artikel bermanfaat jangan lupa untuk share dan bookmark halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
