---
description: "Cara untuk membuat Ayam rica rica pedas Teruji"
title: "Cara untuk membuat Ayam rica rica pedas Teruji"
slug: 371-cara-untuk-membuat-ayam-rica-rica-pedas-teruji
date: 2020-12-28T06:19:49.261Z
image: https://img-global.cpcdn.com/recipes/9ad99f42c619faee/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9ad99f42c619faee/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9ad99f42c619faee/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg
author: Frank Conner
ratingvalue: 4.4
reviewcount: 47556
recipeingredient:
- "1 ekor ayam potong 8"
- "8 biji bawang merah"
- "5 biji bawang putih"
- "5 lembar daun jeruk"
- "1 buah sereh digeprek"
- "2 biji Kemiri"
- "secukupnya Lada"
- "secukupnya Ketumbar"
- "secukupnya Garam gula dan penyedap rasa"
- "1 ruas Kunyit dan jahe masing masing"
recipeinstructions:
- "Rebus ayam sebentar, atau boleh digoreng ayam sebentar saja."
- "Haluskan bumbu bumbu diatas kecuali daun jeruk dan sereh"
- "Siapkan minyak goreng sedikit panaskan masukan bumbu yg sudah dihaluskan, masukan juga daun jeruk dan sereh geprek dl, tumis sampai harum"
- "Setelah harum, masukan ayam dan air secukupnya, tambahkan gula, garam dan penyedap rasa, dan diamkan sampai matang/air tinggal sedikit. Sajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 199 calories
recipecuisine: American
preptime: "PT13M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dinner

---


![Ayam rica rica pedas](https://img-global.cpcdn.com/recipes/9ad99f42c619faee/751x532cq70/ayam-rica-rica-pedas-foto-resep-utama.jpg)

Makanan adalah keragaman budaya yang patut kita lestarikan karena setiap daerah memiliki karasteristik tersendiri, walaupun namanya sama tetapi bentuk dan warna yang berbeda, seperti ayam rica rica pedas yang kami contohkan berikut mungkin di wilayah anda berbeda cara memasaknya. Masakan yang kaya dengan rempah-rempah memberikan ciri khas yang merupakan keragaman Nusantara



Kehangatan keluarga bisa ditemukan dengan cara sederhana. Diantaranya adalah memasak Ayam rica rica pedas untuk orang di rumah. Momen makan bersama orang tua sudah menjadi kultur, bahkan banyak anak yang merantau selalu membayangkan masakan di kampung halaman mereka.

Buat kamu yang suka masak atau harus menyiapkan makanan untuk orang lain ada banyak jenis resep yang dapat anda buat salah satunya ayam rica rica pedas yang merupakan resep favorite yang simpel dengan kreasi sederhana. Pasalnya sekarang ini anda dapat dengan mudah menemukan resep ayam rica rica pedas tanpa harus bersusah payah.
Seperti resep Ayam rica rica pedas yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat simple hanya dengan 4 langkah dan 10 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica rica pedas:

1. Jangan lupa 1 ekor ayam potong 8
1. Tambah 8 biji bawang merah
1. Siapkan 5 biji bawang putih
1. Jangan lupa 5 lembar daun jeruk
1. Siapkan 1 buah sereh digeprek
1. Harap siapkan 2 biji Kemiri
1. Jangan lupa secukupnya Lada
1. Dibutuhkan secukupnya Ketumbar
1. Diperlukan secukupnya Garam, gula dan penyedap rasa
1. Diperlukan 1 ruas Kunyit dan jahe masing masing




<!--inarticleads2-->

##### Langkah membuat  Ayam rica rica pedas:

1. Rebus ayam sebentar, atau boleh digoreng ayam sebentar saja.
1. Haluskan bumbu bumbu diatas kecuali daun jeruk dan sereh
1. Siapkan minyak goreng sedikit panaskan masukan bumbu yg sudah dihaluskan, masukan juga daun jeruk dan sereh geprek dl, tumis sampai harum
1. Setelah harum, masukan ayam dan air secukupnya, tambahkan gula, garam dan penyedap rasa, dan diamkan sampai matang/air tinggal sedikit. Sajikan




Demikianlah cara membuat ayam rica rica pedas yang gampang dan enak. Terima kasih untuk waktu anda untuk membaca artikel resep ini. Saya yakin anda bisa membuatnya dengan mudah di rumah. Kami masih menyimpan banyak resep makanan spesial yang sangat gampang dan teruji, anda bisa mencari di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk share dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Mari memasak !!. 
