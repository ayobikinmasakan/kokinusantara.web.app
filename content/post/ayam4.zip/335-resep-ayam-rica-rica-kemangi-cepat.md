---
description: "Resep : Ayam rica-rica kemangi Cepat"
title: "Resep : Ayam rica-rica kemangi Cepat"
slug: 335-resep-ayam-rica-rica-kemangi-cepat
date: 2020-08-09T09:43:16.661Z
image: https://img-global.cpcdn.com/recipes/05d55bed5d5765ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/05d55bed5d5765ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/05d55bed5d5765ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg
author: Mark Silva
ratingvalue: 4.4
reviewcount: 12312
recipeingredient:
- "1/2 kg ayam"
- "4 lembar daun jeruk"
- "1 batang serai"
- "1 lembar daun kunyit"
- "Secukupnya daun kemangi"
- "1 buah tomat"
- "1 ruas lengkuas geprek"
- " Bumbu"
- "8 buah cabai merah"
- "6 buah cabai rawit"
- "5 siung bawang merah"
- "2 siung bawang putih"
- "4 buah kemiri geprek"
- "1 sdt bubuk kunyit"
- "1 sdt jahe dan bawang putih yg sudah digiling"
recipeinstructions:
- "Goreng ayam hingga kecoklatan"
- "Blender bumbunya hingga halus"
- "Tumis bumbu hingga harum masukan tomat serai lengkuas daun kunyit daun jeruk"
- "Aduk semuanya hingga rata beri air secukupnya"
- "Masukan ayam lalu beri garam dan kaldu bubuk secukupnya lalu masukan daun kemangi"
- "Masak hingga bumbu meresap ke ayam dan kering"
- "Ayam rica-rica kemangi siap dinikmati🤩"
categories:
- Recipe
tags:
- ayam
- ricarica
- kemangi

katakunci: ayam ricarica kemangi 
nutrition: 242 calories
recipecuisine: American
preptime: "PT34M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam rica-rica kemangi](https://img-global.cpcdn.com/recipes/05d55bed5d5765ef/751x532cq70/ayam-rica-rica-kemangi-foto-resep-utama.jpg)

Kebenarekaragaman adat yang sangat beragam di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai varian dari masakan yang pedas,manis hingga enak. Karasteristik masakan Indonesia ayam rica-rica kemangi yang kaya dengan rempah memberikan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga dapat didapat dengan cara mudah. Salah satunya adalah membuat makanan Ayam rica-rica kemangi untuk orang di rumah bisa dicoba. kebersamaan makan bersama orang tua sudah menjadi budaya, bahkan banyak orang yang merantau selalu menginginkan makanan di kampung halaman mereka.



Buat kamu yang suka memasak atau harus menyiapkan masakan untuk tamu ada banyak varian makanan yang dapat anda contoh salah satunya ayam rica-rica kemangi yang merupakan makanan terkenal yang gampang dengan kreasi sederhana. Pasalnya sekarang ini kamu dapat dengan gampang menemukan resep ayam rica-rica kemangi tanpa harus bersusah payah.
Seperti resep Ayam rica-rica kemangi yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 15 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam rica-rica kemangi:

1. Harus ada 1/2 kg ayam
1. Harap siapkan 4 lembar daun jeruk
1. Jangan lupa 1 batang serai
1. Harus ada 1 lembar daun kunyit
1. Tambah Secukupnya daun kemangi
1. Tambah 1 buah tomat
1. Siapkan 1 ruas lengkuas geprek
1. Dibutuhkan  Bumbu
1. Harus ada 8 buah cabai merah
1. Dibutuhkan 6 buah cabai rawit
1. Harus ada 5 siung bawang merah
1. Harus ada 2 siung bawang putih
1. Harap siapkan 4 buah kemiri geprek
1. Siapkan 1 sdt bubuk kunyit
1. Jangan lupa 1 sdt jahe dan bawang putih yg sudah digiling




<!--inarticleads2-->

##### Instruksi membuat  Ayam rica-rica kemangi:

1. Goreng ayam hingga kecoklatan
1. Blender bumbunya hingga halus
1. Tumis bumbu hingga harum masukan tomat serai lengkuas daun kunyit daun jeruk
1. Aduk semuanya hingga rata beri air secukupnya
1. Masukan ayam lalu beri garam dan kaldu bubuk secukupnya lalu masukan daun kemangi
1. Masak hingga bumbu meresap ke ayam dan kering
1. Ayam rica-rica kemangi siap dinikmati🤩




Demikianlah cara membuat ayam rica-rica kemangi yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa meniru dengan gampang di rumah. Kami masih mempunyai banyak resep makanan rahasia yang sangat gampang dan teruji, anda bisa menemukan di website kami, dan jika anda merasa artikel ini bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
