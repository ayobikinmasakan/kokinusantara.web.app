---
description: "Resep : Ayam Rica Rica Luar biasa"
title: "Resep : Ayam Rica Rica Luar biasa"
slug: 296-resep-ayam-rica-rica-luar-biasa
date: 2020-09-20T21:14:11.470Z
image: https://img-global.cpcdn.com/recipes/f886aba43b0bb1ce/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f886aba43b0bb1ce/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f886aba43b0bb1ce/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg
author: Lois Fowler
ratingvalue: 4.7
reviewcount: 31747
recipeingredient:
- "1 ekor ayam potong 12"
- " Jeruk nipis"
- " Kunyit bubuk"
- " BUMBU HALUS"
- "5 siung bawang merah"
- "5 siung bawang putih"
- "1 ons cabe keriting sesuai selera"
- "1/2 ons cabe rawit sesuai selera"
- "2 cm jahe"
- "1 ruas kunyit"
- "2 ruas lengkuas"
- "4 buah kemiri"
- " BUMBU KASAR"
- "2 ikat daun kemangi"
- "2 tangkai daun bawang"
- "3 batang serai digeprek"
- "1 lembar daun pandan disimpul"
- "5 lembar daun salam"
- "5 lembar daun jeruk nipis iris kecil2"
- "Sejumput garam"
- "Sejumput kaldu ayam"
recipeinstructions:
- "Siapkan bahan-bahan"
- "Baluri ayam dengan kunyit bubuk, air jeruk nipis, dan sedikit garam diamkan sekitar 10 menit"
- "Lalu goreng ayam setengah kering dan tiriskan."
- "Tumis bumbu halus sampai wangi, lalu masukkan daun jeruk, daun salam, daun pandan, dan serai."
- "Kemudian masukkan ayam yg sudah digoreng setengah kering tadi, aduk hingga merata lalu masukkan air secukupnya, masukkan sejumput garam, dan kaldu ayam. Aduk hingga merata lalu koreksi rasa. Masak ayam hingga empuk dan matang kurang lebih 30 menit."
- "Setelah ayam empuk dan air asat, masukkan daun kemangi dan daun bawang lalu aduk hingga layu. Kemudian koreksi rasa lg, jika dirasa masih ad yg kurang garam atau kaldu boleh ditambah."
- "Ayam rica rica pun siap disajikan"
categories:
- Recipe
tags:
- ayam
- rica
- rica

katakunci: ayam rica rica 
nutrition: 260 calories
recipecuisine: American
preptime: "PT14M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Rica Rica](https://img-global.cpcdn.com/recipes/f886aba43b0bb1ce/751x532cq70/ayam-rica-rica-foto-resep-utama.jpg)

Kekayaan bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai bentuk dari masakan yang manis,pedas atau gurih. Karasteristik masakan Nusantara ayam rica rica yang penuh dengan rempah menampilkan kesan tersendiri bahkan untuk turis yang berkunjung.


Kedekatan rumah tangga bisa ditemukan dengan cara simple. Diantaranya adalah memasak Ayam Rica Rica untuk keluarga bisa dicoba. kebersamaan makan bersama keluarga sudah menjadi kultur, bahkan banyak anak yang merantau selalu menginginkan makanan di rumah mereka.



Buat kamu yang suka memasak atau harus menyiapkan makanan untuk tamu ada banyak jenis makanan yang bisa anda contoh salah satunya ayam rica rica yang merupakan makanan terkenal yang mudah dengan kreasi sederhana. Pasalnya sekarang ini anda bisa dengan mudah menemukan resep ayam rica rica tanpa harus bersusah payah.
Seperti resep Ayam Rica Rica yang bisa anda tiru untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 21 bahan dan 7 langkah.


<!--inarticleads1-->

##### Bahan-bahan yang dibutuhkan membuat Ayam Rica Rica:

1. Dibutuhkan 1 ekor ayam potong 12
1. Siapkan  Jeruk nipis
1. Siapkan  Kunyit bubuk
1. Harus ada  BUMBU HALUS:
1. Tambah 5 siung bawang merah
1. Harap siapkan 5 siung bawang putih
1. Harus ada 1 ons cabe keriting (sesuai selera)
1. Tambah 1/2 ons cabe rawit (sesuai selera)
1. Harap siapkan 2 cm jahe
1. Harap siapkan 1 ruas kunyit
1. Jangan lupa 2 ruas lengkuas
1. Harap siapkan 4 buah kemiri
1. Dibutuhkan  BUMBU KASAR:
1. Jangan lupa 2 ikat daun kemangi
1. Diperlukan 2 tangkai daun bawang
1. Harap siapkan 3 batang serai digeprek
1. Jangan lupa 1 lembar daun pandan disimpul
1. Dibutuhkan 5 lembar daun salam
1. Siapkan 5 lembar daun jeruk nipis iris kecil2
1. Siapkan Sejumput garam
1. Dibutuhkan Sejumput kaldu ayam




<!--inarticleads2-->

##### Langkah membuat  Ayam Rica Rica:

1. Siapkan bahan-bahan
1. Baluri ayam dengan kunyit bubuk, air jeruk nipis, dan sedikit garam diamkan sekitar 10 menit
1. Lalu goreng ayam setengah kering dan tiriskan.
1. Tumis bumbu halus sampai wangi, lalu masukkan daun jeruk, daun salam, daun pandan, dan serai.
1. Kemudian masukkan ayam yg sudah digoreng setengah kering tadi, aduk hingga merata lalu masukkan air secukupnya, masukkan sejumput garam, dan kaldu ayam. Aduk hingga merata lalu koreksi rasa. Masak ayam hingga empuk dan matang kurang lebih 30 menit.
1. Setelah ayam empuk dan air asat, masukkan daun kemangi dan daun bawang lalu aduk hingga layu. Kemudian koreksi rasa lg, jika dirasa masih ad yg kurang garam atau kaldu boleh ditambah.
1. Ayam rica rica pun siap disajikan




Demikianlah cara membuat ayam rica rica yang gampang dan enak. Terima kasih atas waktu anda untuk membaca artikel resep ini. Saya yakin kamu bisa meniru dengan mudah di rumah. Kami masih menyimpan banyak resep makanan rahasia yang sangat mudah dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
