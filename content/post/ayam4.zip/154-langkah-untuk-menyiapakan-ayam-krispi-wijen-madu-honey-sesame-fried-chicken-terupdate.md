---
description: "Langkah untuk menyiapakan Ayam krispi wijen madu (honey sesame fried chicken) terupdate"
title: "Langkah untuk menyiapakan Ayam krispi wijen madu (honey sesame fried chicken) terupdate"
slug: 154-langkah-untuk-menyiapakan-ayam-krispi-wijen-madu-honey-sesame-fried-chicken-terupdate
date: 2020-08-11T13:44:33.986Z
image: https://img-global.cpcdn.com/recipes/610b95ef91cc8600/751x532cq70/ayam-krispi-wijen-madu-honey-sesame-fried-chicken-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/610b95ef91cc8600/751x532cq70/ayam-krispi-wijen-madu-honey-sesame-fried-chicken-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/610b95ef91cc8600/751x532cq70/ayam-krispi-wijen-madu-honey-sesame-fried-chicken-foto-resep-utama.jpg
author: Austin Stewart
ratingvalue: 4.2
reviewcount: 46263
recipeingredient:
- "500 gr paha fillet dengan kulit"
- " Marinade ayam"
- "1 sdt bawang putih bubukoptional"
- "1 sdm saos tiram"
- "2 sdm kecap asin"
- "1 sdm arak masak optional"
- "1 2 sdt five spice powder"
- "1 sdm air jahe 12 jempol jahe diparut beri air panas 1 sdm Saring"
- "1 putih telur"
- "1/2 sdt minyak wijen"
- "3-4 sdm maizena kanji"
- " Saus"
- "150 ml air"
- "4 siung bawang putih"
- "Sejempol jahe parut"
- "4 sdm kecap asin"
- "4 sdm madu"
- " Larutan maizenakanji utk pengental"
- "Sesuai selera wijen sangrai sy suka banyak"
recipeinstructions:
- "Cuci bersih fillet paha ayam. Potong2 dadu 2,5x2,5 cm atau sesuai selera. Masukkan bumbu marinasi kecuali kanji/maizena. Aduk rata. Kemudian masukkan tepung kanji/maizena aduk rata. Tutup dan marinasi min 30min di kulkas."
- "Sementara ayam dimarinasi siapkan bumbu saus yah. Parut jahe, cincang bawang putih, siapkan kecap asin,madu, wijen sangrai. Buat larutan pengental 1 sdm kanji/maizena+ 1-2 sdm air."
- "Keluarkan ayam dari kulkas. Gulingkan ayam di tepung maizena/kanji. Kemudian goreng hingga matang. Angkat tiriskan. Lakukan hingga ayam habis."
- "Kita buat saus: Panaskan wajan, masukan air. Kemudian bawang putih dan jahe. Kemudian masukkan kecap asin dan madu. Didihkan (api kecil sedang). Tes rasa jika sudah pas, masukkan larutan kanji, sedikit demi sedikit hingga cukup kental (tdk dipake semua yah, kurang lebih aja). *Kekentalan bumbu sedikit lbh encer dari susu kental manis ya. Max spt susu kental manis."
- "Besarkan api, masukkan ayam goreng. Aduk2 hingga bumbu menyelimuti ayam. Beri wijen sangrai, aduk aduk. Matikan api."
- "Pindah piring saji, siap dinikmati. Note: resep saya utk 2x makan bertiga ya. Lunch dan dinner. Supaya tetap fresh dan enak. Ayam saya goreng semua tapi dicampur saus hanya setengah. Nanti setengahnya saat mendekati waktu makan malam baru di campur supaya ttp hangat. Jadi saat membuat saus, setelah tes rasa uda pas, matikan api dulu, ambil setengahnya di mangkok kecil, simpan utk berikutnya. Lanjutkan memasak seperti langkah diatas. Enjoy^^"
categories:
- Recipe
tags:
- ayam
- krispi
- wijen

katakunci: ayam krispi wijen 
nutrition: 202 calories
recipecuisine: American
preptime: "PT11M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam krispi wijen madu (honey sesame fried chicken)](https://img-global.cpcdn.com/recipes/610b95ef91cc8600/751x532cq70/ayam-krispi-wijen-madu-honey-sesame-fried-chicken-foto-resep-utama.jpg)

Kebenarekaragaman bahasa yang sangat banyak di Indonesia juga di ikuti kekayaan kuliner yang beragam dengan berbagai rasa dari masakan yang pedas,manis hingga enak. Ciri khas makanan Nusantara ayam krispi wijen madu (honey sesame fried chicken) yang penuh dengan rempah-rempah memberikan keberaragaman yang menjadi ciri budaya kita.


Keharmonisan keluarga bisa diperoleh dengan cara simple. Diantaranya adalah memasak Ayam krispi wijen madu (honey sesame fried chicken) untuk orang di rumah bisa dicoba. Momen makan bersama anak sudah menjadi budaya, Banyak yang sering mencari makanan kampung mereka sendiri ketika di tempat lain.



untuk kamu yang suka masak atau harus menyiapkan masakan untuk keluarga ada banyak varian resep yang dapat anda buat salah satunya ayam krispi wijen madu (honey sesame fried chicken) yang merupakan makanan favorite yang simpel dengan kreasi sederhana. Pasalnya saat ini kamu bisa dengan mudah menemukan resep ayam krispi wijen madu (honey sesame fried chicken) tanpa harus bersusah payah.
Berikut ini resep Ayam krispi wijen madu (honey sesame fried chicken) yang bisa kamu coba untuk disajikan pada keluarga tercinta. Dan sangat gampang hanya dengan 6 langkah dan 19 bahan.


<!--inarticleads1-->

##### Bahan-bahan yang perlukan membuat Ayam krispi wijen madu (honey sesame fried chicken):

1. Jangan lupa 500 gr paha fillet dengan kulit
1. Tambah  Marinade ayam:
1. Harus ada 1 sdt bawang putih bubuk(optional)
1. Tambah 1 sdm saos tiram
1. Siapkan 2 sdm kecap asin
1. Diperlukan 1 sdm arak masak (optional)
1. Siapkan 1 /2 sdt five spice powder
1. Harap siapkan 1 sdm air jahe (1/2 jempol jahe diparut beri air panas 1 sdm. Saring)
1. Dibutuhkan 1 putih telur
1. Jangan lupa 1/2 sdt minyak wijen
1. Jangan lupa 3-4 sdm maizena/ kanji
1. Tambah  Saus:
1. Diperlukan 150 ml air
1. Dibutuhkan 4 siung bawang putih
1. Dibutuhkan Sejempol jahe, parut
1. Harap siapkan 4 sdm kecap asin
1. Harus ada 4 sdm madu
1. Dibutuhkan  Larutan maizena/kanji utk pengental
1. Tambah Sesuai selera wijen sangrai (sy suka banyak)




<!--inarticleads2-->

##### Bagaimana membuat  Ayam krispi wijen madu (honey sesame fried chicken):

1. Cuci bersih fillet paha ayam. Potong2 dadu 2,5x2,5 cm atau sesuai selera. Masukkan bumbu marinasi kecuali kanji/maizena. Aduk rata. Kemudian masukkan tepung kanji/maizena aduk rata. Tutup dan marinasi min 30min di kulkas.
1. Sementara ayam dimarinasi siapkan bumbu saus yah. Parut jahe, cincang bawang putih, siapkan kecap asin,madu, wijen sangrai. Buat larutan pengental 1 sdm kanji/maizena+ 1-2 sdm air.
1. Keluarkan ayam dari kulkas. Gulingkan ayam di tepung maizena/kanji. Kemudian goreng hingga matang. Angkat tiriskan. Lakukan hingga ayam habis.
1. Kita buat saus: Panaskan wajan, masukan air. Kemudian bawang putih dan jahe. Kemudian masukkan kecap asin dan madu. Didihkan (api kecil sedang). Tes rasa jika sudah pas, masukkan larutan kanji, sedikit demi sedikit hingga cukup kental (tdk dipake semua yah, kurang lebih aja). *Kekentalan bumbu sedikit lbh encer dari susu kental manis ya. Max spt susu kental manis.
1. Besarkan api, masukkan ayam goreng. Aduk2 hingga bumbu menyelimuti ayam. Beri wijen sangrai, aduk aduk. Matikan api.
1. Pindah piring saji, siap dinikmati. Note: resep saya utk 2x makan bertiga ya. Lunch dan dinner. Supaya tetap fresh dan enak. Ayam saya goreng semua tapi dicampur saus hanya setengah. Nanti setengahnya saat mendekati waktu makan malam baru di campur supaya ttp hangat. Jadi saat membuat saus, setelah tes rasa uda pas, matikan api dulu, ambil setengahnya di mangkok kecil, simpan utk berikutnya. Lanjutkan memasak seperti langkah diatas. Enjoy^^




Demikianlah cara membuat ayam krispi wijen madu (honey sesame fried chicken) yang mudah dan enak. Terima kasih untuk waktu anda untuk membaca artikel makanan ini. Saya yakin anda bisa berkreasi dengan gampang di rumah. Kami masih memiliki banyak resep makanan spesial yang sangat simple dan terbukti, anda bisa menelusuri di halaman kami, apabila artikel bermanfaat jangan lupa untuk bagikan dan simpan halaman website ini karena akan banyak update terbaru untuk resep-resep pilihan yang terbukti dan teruji. Siap Memasak !!. 
